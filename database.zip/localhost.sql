-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2017 at 06:04 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `relis_dev_admin`
--
CREATE DATABASE `relis_dev_admin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `relis_dev_admin`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_config`(_config_id INT , _project_title  VARCHAR(405) , _project_description  VARCHAR(1005) , _default_lang  VARCHAR(16) , _creator INT , _run_setup  VARCHAR(6))
BEGIN
START TRANSACTION;
INSERT INTO config (project_title , project_description , default_lang , creator , run_setup) VALUES (_project_title , _project_description , _default_lang , _creator , _run_setup);
SELECT config_id AS id_value FROM config WHERE config_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_logs`(_log_id INT , _log_type  VARCHAR(55) , _log_user_id INT , _log_event  VARCHAR(205) , _log_time  VARCHAR(205) , _log_ip_address  VARCHAR(205))
BEGIN
START TRANSACTION;
INSERT INTO log (log_type , log_user_id , log_event , log_time , log_ip_address) VALUES (_log_type , _log_user_id , _log_event , _log_time , _log_ip_address);
SELECT log_id AS id_value FROM log WHERE log_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_project`(_project_id INT , _project_creator INT , _project_label  VARCHAR(105) , _project_title  VARCHAR(255) , _project_description  VARCHAR(1005) , _project_icon  LONGBLOB )
BEGIN
START TRANSACTION;
INSERT INTO projects (project_creator , project_label , project_title , project_description , project_icon) VALUES (_project_creator , _project_label , _project_title , _project_description , _project_icon);
SELECT project_id AS id_value FROM projects WHERE project_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_str_mng`(_str_id INT , _str_label  VARCHAR(405) , _str_text  VARCHAR(805) , _str_lang  VARCHAR(8) , _str_category  VARCHAR(23))
BEGIN
START TRANSACTION;
INSERT INTO str_management (str_label , str_text , str_lang , str_category) VALUES (_str_label , _str_text , _str_lang , _str_category);
SELECT str_id AS id_value FROM str_management WHERE str_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_usergroup`(_usergroup_id INT , _usergroup_name  VARCHAR(25) , _usergroup_description  VARCHAR(55))
BEGIN
START TRANSACTION;
INSERT INTO usergroup (usergroup_name , usergroup_description) VALUES (_usergroup_name , _usergroup_description);
SELECT usergroup_id AS id_value FROM usergroup WHERE usergroup_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_users`(_user_id INT , _user_state INT , _user_name  VARCHAR(55) , _user_username  VARCHAR(25) , _user_mail  VARCHAR(105) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  LONGBLOB  , _created_by INT)
BEGIN
START TRANSACTION;
INSERT INTO users (user_state , user_name , user_username , user_mail , user_usergroup , user_password , user_picture , created_by) VALUES (_user_state , _user_name , _user_username , _user_mail , _user_usergroup , _user_password , _user_picture , _created_by);
SELECT user_id AS id_value FROM users WHERE user_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_users_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_users_project`(_userproject_id INT , _user_id INT , _project_id INT , _user_role  VARCHAR(25) , _added_by INT)
BEGIN
START TRANSACTION;
INSERT INTO userproject (user_id , project_id , user_role , added_by) VALUES (_user_id , _project_id , _user_role , _added_by);
SELECT userproject_id AS id_value FROM userproject WHERE userproject_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_users_project_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_users_project_test`(_userproject_id INT , _user_id INT , _project_id INT , _user_role  VARCHAR(25) , _added_by INT)
BEGIN
START TRANSACTION;
INSERT INTO userproject (user_id , project_id , user_role , added_by) VALUES (_user_id , _project_id , _user_role , _added_by);
SELECT userproject_id AS id_value FROM userproject WHERE userproject_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_users_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_users_test`(_user_id INT , _user_name  VARCHAR(55) , _user_username  VARCHAR(25) , _user_mail  VARCHAR(105) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  LONGBLOB  , _created_by INT)
BEGIN
START TRANSACTION;
INSERT INTO users (user_name , user_username , user_mail , user_usergroup , user_password , user_picture , created_by) VALUES (_user_name , _user_username , _user_mail , _user_usergroup , _user_password , _user_picture , _created_by);
SELECT user_id AS id_value FROM users WHERE user_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_user_project`(_userproject_id INT , _user_id INT , _project_id INT)
BEGIN START TRANSACTION; INSERT INTO userproject (user_id , project_id) VALUES (_user_id , _project_id); SELECT userproject_id AS id_value FROM userproject WHERE userproject_id = LAST_INSERT_ID(); COMMIT; END$$

DROP PROCEDURE IF EXISTS `check_login`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_login`(IN _login VARCHAR(20))
BEGIN
START TRANSACTION;
SELECT COUNT(user_id)  AS number 
FROM users
WHERE user_active=1 AND user_username = _login  ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `check_user_credentials`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_credentials`(_username VARCHAR(100), _password VARCHAR(100))
BEGIN
START TRANSACTION;
	SELECT * FROM users 
	WHERE (users.user_username = _username)
    AND (users.user_password = _password);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_list`(IN source varchar(200),IN condition_stat VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select count(*) as nombre from  ',source ,'   WHERE 1=1  ', condition_stat );
PREPARE stmt FROM @query;
EXECUTE stmt; -- execute statement
DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_detail_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_config`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_logs`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM log
WHERE log_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_project`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM projects
WHERE project_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_str_mng`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM str_management
WHERE str_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_usergroup`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM usergroup
WHERE usergroup_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_users`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM users
WHERE user_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_user_project`(IN _row_id INT)
BEGIN START TRANSACTION; SELECT * FROM userproject WHERE userproject_id= _row_id; COMMIT; END$$

DROP PROCEDURE IF EXISTS `get_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list`(IN _source varchar(100),IN _fields varchar(1000),IN _condition_stat VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select ',_fields,' from  ',_source ,'   WHERE 1=1   ', _condition_stat );
 PREPARE stmt FROM @query;
 EXECUTE stmt; -- execute statement
 DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_list_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_config`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
IF _range < 1 THEN
SELECT  * FROM config
WHERE config_active=1   ORDER BY config_id ASC;
ELSE
SELECT  * FROM config
WHERE config_active=1   ORDER BY config_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_logs`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
SET @search_log_user_id := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  log_id , log_user_id , log_event , log_time FROM log
WHERE log_active=1   AND (  (log_user_id LIKE  @search_log_user_id)  )  ORDER BY log_id DESC ;
ELSE
SELECT  log_id , log_user_id , log_event , log_time FROM log
WHERE log_active=1   AND (  (log_user_id LIKE  @search_log_user_id)  )  ORDER BY log_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_project`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
SET @search_project_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_project_description := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  * FROM projects
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  OR (project_description LIKE  @search_project_description)  )  ORDER BY project_id ASC;
ELSE
SELECT  * FROM projects
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  OR (project_description LIKE  @search_project_description)  )  ORDER BY project_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_projects`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_projects`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_project_title := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM projects
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  )    ORDER BY project_title ASC ;
ELSE
SELECT * FROM projects
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  )    ORDER BY project_title ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_projects_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_projects_test`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_project_title := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM projects_test
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  )    ORDER BY project_title ASC ;
ELSE
SELECT * FROM projects_test
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  )    ORDER BY project_title ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_str_mng`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
SET @search_str_text := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC ;
ELSE
SELECT  * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_usergroup`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
SET @search_usergroup_name := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  * FROM usergroup
WHERE usergroup_active=1   AND (  (usergroup_name LIKE  @search_usergroup_name)  )  ORDER BY usergroup_name ASC;
ELSE
SELECT  * FROM usergroup
WHERE usergroup_active=1   AND (  (usergroup_name LIKE  @search_usergroup_name)  )  ORDER BY usergroup_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_usergroups`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_usergroups`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_usergroup_name := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM usergroup
WHERE usergroup_active=1   AND (  (usergroup_name LIKE  @search_usergroup_name)  )    ORDER BY usergroup_name ASC ;
ELSE
SELECT * FROM usergroup
WHERE usergroup_active=1   AND (  (usergroup_name LIKE  @search_usergroup_name)  )    ORDER BY usergroup_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_users`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_user_name := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM users
WHERE user_active=1   AND (  (user_name LIKE  @search_user_name)  )    ORDER BY user_name ASC ;
ELSE
SELECT * FROM users
WHERE user_active=1   AND (  (user_name LIKE  @search_user_name)  )    ORDER BY user_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_users_all`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_users_all`()
BEGIN
START TRANSACTION;
SELECT  U.*,G.usergroup_name FROM users U
INNER JOIN usergroup G ON (U.user_usergroup  = G.usergroup_id)
WHERE U.user_active = 1 AND G.usergroup_active;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_user_project`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN 
START TRANSACTION;
IF _range < 1 THEN 
SELECT * FROM userproject WHERE userproject_active=1 ORDER BY userproject_id ASC; 
ELSE
SELECT * FROM userproject WHERE userproject_active=1 ORDER BY userproject_id ASC LIMIT _start_by , _range; 
END IF; 
COMMIT; 
END$$

DROP PROCEDURE IF EXISTS `get_list_user_projects`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_user_projects`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM userproject
WHERE userproject_active=1     ORDER BY user_id ASC ;
ELSE
SELECT * FROM userproject
WHERE userproject_active=1     ORDER BY user_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_user_projects_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_user_projects_test`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM userproject
WHERE userproject_active=1     ORDER BY userproject_id ASC ;
ELSE
SELECT * FROM userproject
WHERE userproject_active=1     ORDER BY userproject_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_project_detail`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_project_detail`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM projects
WHERE project_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_value`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_value`(IN  _table  VARCHAR(100), IN  _id  VARCHAR(100), IN  _field  VARCHAR(100), IN  _table_id  VARCHAR(100))
BEGIN
SET @query = CONCAT('Select ',_field,' from  ',_table ,'   WHERE ', _table_id, ' = ', _id );
PREPARE stmt FROM @query;
EXECUTE stmt; -- execute statement
DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_row`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_row`(IN source varchar(100),IN source_id VARCHAR(100),IN id_value VARCHAR(100))
BEGIN
SET @query = CONCAT("Select * from  ",source ,"  WHERE ", source_id ," = '",id_value,"'");
 PREPARE stmt FROM @query;
 EXECUTE stmt; -- execute statement
 DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_string`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_string`(IN _text VARCHAR(500),IN _category VARCHAR(30),IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
SELECT str_id, str_text 
FROM str_management
WHERE str_active=1 AND str_label = _text AND str_category = _category AND str_lang = _lang ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_userproject_detail`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_userproject_detail`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM userproject
WHERE userproject_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_user_detail`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_user_detail`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM users
WHERE user_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_config`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE config SET config_active=0
WHERE config_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_logs`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE log SET log_active=0
WHERE log_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_project`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE projects SET project_active=0
WHERE project_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_str_mng`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE str_management SET str_active=0
WHERE str_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_usergroup`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE usergroup SET usergroup_active=0
WHERE usergroup_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_userproject`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_userproject`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE userproject SET userproject_active=0
WHERE userproject_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_users`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE users SET user_active=0
WHERE user_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_user_project`(IN _element_id INT)
BEGIN START TRANSACTION; UPDATE userproject SET userproject_active=0 WHERE userproject_id= _element_id; COMMIT; END$$

DROP PROCEDURE IF EXISTS `remove_user_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_user_test`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE users SET user_active=0
WHERE user_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `test_update_projects`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `test_update_projects`(_element_id INT , _project_id INT , _project_label  VARCHAR(105) , _project_description  VARCHAR(1005))
BEGIN
START TRANSACTION;
UPDATE  projects SET project_id = _project_id , project_label = _project_label , project_description = _project_description
WHERE (project_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_config`(_element_id INT , _config_id INT , _project_description  VARCHAR(1005) , _default_lang  VARCHAR(16) , _creator INT , _run_setup  VARCHAR(6))
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , project_description = _project_description , default_lang = _default_lang , creator = _creator , run_setup = _run_setup
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_logs`(_element_id INT , _log_id INT , _log_user_id INT , _log_time  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  log SET log_id = _log_id , log_user_id = _log_user_id , log_time = _log_time
WHERE (log_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_project`(_element_id INT , _project_id INT , _project_label  VARCHAR(105) , _project_title  VARCHAR(255) , _project_description  VARCHAR(1005) , _project_creator INT , _project_icon  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  projects SET project_id = _project_id , project_label = _project_label , project_title = _project_title , project_description = _project_description , project_creator = _project_creator , project_icon = _project_icon
WHERE (project_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_projects`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_projects`(_element_id INT , _project_id INT , _project_title  VARCHAR(255) , _project_description  VARCHAR(1005) , _project_icon  LONGBLOB )
BEGIN
START TRANSACTION;
UPDATE  projects SET project_id = _project_id , project_title = _project_title , project_description = _project_description , project_icon = _project_icon
WHERE (project_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_str_mng`(_element_id INT , _str_id INT , _str_text  VARCHAR(805))
BEGIN
START TRANSACTION;
UPDATE  str_management SET str_id = _str_id , str_text = _str_text
WHERE (str_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_usergroup`(_element_id INT , _usergroup_id INT , _usergroup_name  VARCHAR(25) , _usergroup_description  VARCHAR(55))
BEGIN
START TRANSACTION;
UPDATE  usergroup SET usergroup_id = _usergroup_id , usergroup_name = _usergroup_name , usergroup_description = _usergroup_description
WHERE (usergroup_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_users`(_element_id INT , _user_id INT , _user_name  VARCHAR(55) , _user_mail  VARCHAR(105) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  LONGBLOB )
BEGIN
START TRANSACTION;
UPDATE  users SET user_id = _user_id , user_name = _user_name , user_mail = _user_mail , user_usergroup = _user_usergroup , user_password = _user_password , user_picture = _user_picture
WHERE (user_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_users_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_users_test`(_element_id INT , _user_id INT , _user_name  VARCHAR(55) , _user_mail  VARCHAR(105) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  LONGBLOB )
BEGIN
START TRANSACTION;
UPDATE  users SET user_id = _user_id , user_name = _user_name , user_mail = _user_mail , user_usergroup = _user_usergroup , user_password = _user_password , user_picture = _user_picture
WHERE (user_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user_project`(_element_id INT , _userproject_id INT , _project_id INT , _user_role  VARCHAR(25))
BEGIN
START TRANSACTION;
UPDATE  userproject SET userproject_id = _userproject_id , project_id = _project_id , user_role = _user_role
WHERE (userproject_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_user_project_2`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user_project_2`(_element_id INT , _userproject_id INT , _user_role  VARCHAR(25))
BEGIN
START TRANSACTION;
UPDATE  userproject SET userproject_id = _userproject_id , user_role = _user_role
WHERE (userproject_id = _element_id);
COMMIT;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_config`
--

DROP TABLE IF EXISTS `admin_config`;
CREATE TABLE IF NOT EXISTS `admin_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_label` varchar(100) NOT NULL,
  `config_value` varchar(100) NOT NULL,
  `config_description` varchar(500) DEFAULT NULL,
  `config_user` int(11) NOT NULL DEFAULT '0',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_type` varchar(15) NOT NULL DEFAULT 'default',
  `project_title` varchar(500) DEFAULT NULL,
  `project_description` text,
  `default_lang` varchar(15) NOT NULL DEFAULT 'en',
  `creator` int(11) NOT NULL DEFAULT '1',
  `run_setup` int(1) NOT NULL DEFAULT '0',
  `rec_per_page` int(4) NOT NULL DEFAULT '30',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_id`, `config_type`, `project_title`, `project_description`, `default_lang`, `creator`, `run_setup`, `rec_per_page`, `config_active`) VALUES
(1, 'default', 'Admin', 'Admin project', 'en', 1, 0, 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
CREATE TABLE IF NOT EXISTS `log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) NOT NULL,
  `log_event` text NOT NULL,
  `log_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `log_ip_address` varchar(50) DEFAULT NULL,
  `log_user_id` int(11) DEFAULT NULL,
  `log_poste_id` int(11) DEFAULT NULL,
  `log_user_agent` varchar(150) DEFAULT NULL,
  `log_publish` int(1) NOT NULL DEFAULT '1',
  `log_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`log_id`, `log_type`, `log_event`, `log_time`, `log_ip_address`, `log_user_id`, `log_poste_id`, `log_user_agent`, `log_publish`, `log_active`) VALUES
(1, 'Connexion', 'User connected', '2017-06-16 10:31:55', '::1', 1, NULL, NULL, 1, 1),
(2, 'Disconnection', 'User disconnected', '2017-06-16 10:48:25', '::1', 1, NULL, NULL, 1, 1),
(3, 'Connexion', 'User connected', '2017-06-16 10:48:27', '::1', 4, NULL, NULL, 1, 1),
(4, 'Disconnection', 'User disconnected', '2017-06-16 11:12:47', '::1', 4, NULL, NULL, 1, 1),
(5, 'Connexion', 'User connected', '2017-06-16 11:12:52', '::1', 3, NULL, NULL, 1, 1),
(6, 'Disconnection', 'User disconnected', '2017-06-16 11:16:53', '::1', 3, NULL, NULL, 1, 1),
(7, 'Connexion', 'User connected', '2017-06-16 11:16:54', '::1', 4, NULL, NULL, 1, 1),
(8, 'Disconnection', 'User disconnected', '2017-06-16 11:45:56', '::1', 4, NULL, NULL, 1, 1),
(9, 'Connexion', 'User connected', '2017-06-16 11:46:01', '::1', 1, NULL, NULL, 1, 1),
(10, 'Disconnection', 'User disconnected', '2017-06-16 11:46:17', '::1', 1, NULL, NULL, 1, 1),
(11, 'Connexion', 'User connected', '2017-06-16 12:30:37', '::1', 4, NULL, NULL, 1, 1),
(12, 'Connexion', 'User connected', '2017-06-16 18:31:03', '::1', 1, NULL, NULL, 1, 1),
(13, 'Disconnection', 'User disconnected', '2017-06-16 19:12:20', '::1', 1, NULL, NULL, 1, 1),
(14, 'Connexion', 'User connected', '2017-06-16 19:12:29', '::1', 1, NULL, NULL, 1, 1),
(15, 'Connexion', 'User connected', '2017-06-16 19:18:45', '::1', 3, NULL, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_label` varchar(100) NOT NULL,
  `project_title` varchar(250) NOT NULL,
  `project_description` varchar(1000) DEFAULT NULL,
  `project_creator` int(11) NOT NULL,
  `project_icon` longblob,
  `creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `project_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`project_id`, `project_label`, `project_title`, `project_description`, `project_creator`, `project_icon`, `creation_time`, `project_active`) VALUES
(1, 'mt', 'Model transformation', 'Model transformation', 1, NULL, '2017-05-31 21:10:35', 1),
(2, 'sprl', 'Sorftware product line', 'Sorftware product line', 2, NULL, '2017-05-31 21:10:35', 0),
(3, 'mtt', 'Project test 2', 'Project test 2', 1, NULL, '2017-05-31 21:11:58', 0);
INSERT INTO `projects` (`project_id`, `project_label`, `project_title`, `project_description`, `project_creator`, `project_icon`, `creation_time`, `project_active`) VALUES
(4, 'mtt3', 'Project test 4', 'Project test 4', 1, 0xffd8ffe000104a46494600010100000100010000fffe003b43524541544f523a2067642d6a7065672076312e3020287573696e6720494a47204a50454720763632292c207175616c697479203d2039300affdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc000110800c9012c03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00da796f25467bdbc4b784725633b40fa93540f8a347b304594736a72671ba01b813eee78fd6b8f9a6b4b8b802e669f57b9073e5637807fdde83f1c55a967bc44002c3a542dd0c843bfe03a03f9d79491b58e826f126ad791b33791a55aff78b6e7c7ae4e00fc8d679d4c4f26fb68a7d56e3054cf21db18c8c1f988e9fee835965ade370ce1ae6451913deb6d4fc07f80a62ea124cdb5649674ce4240be5c5f8b753f81ab480d59ee6790aa5cdd98dbb5b5929c9fa9ebf8f148d347a6af291d8863c993e799fe8a3249ae7ee3c411c01e06bd4871d6dec172ff8b0e7f95737a9789a469244b002d06df9a4189666c753bb3b57f126ad790ec77573ab3401674861b6407fe3f3567f9bfe0283a7e62b2b54f145bea362f6f713b5fc5202ad25c9fb3c1c8eca393ec3f5ae0e3d4ee6e276f25d9d9f19918099874eb230da3f006a092290cac8aecd367f87e77233ea791fa56961d8eb35bf17c7ab5b59cb7534caed6e89730ca7c984c8abb5880b9770c46ee9deaff8bbc03e26f0df8134ff0016476e8fe1fb9b75964113e7646fd0b28c91904739e0119c571f7fe15d427d12f6582d8c4e216650792c429ea4f5afba3e1c5e69bf13fe15c1a5de451dc48b6515adf5b3285219a152e8c06003861c0e946c0da5b1f9cdf678ee41bc6ba8edecb712acce1140edd4f27d47d6add9daa6a6891e99a6ddeb922b7128431c00ff00bec0023f0af51f1a7c36f0d7c17d7e6d36eed0dfb42fe65b35de242b1b7423238ff106b9dd63e2ee9d696eeb0cc906d03e55e7f0c5569d0ae66c8adbc0de22bd8905f5fdae8f6c39105a12081e85ba9fc08abb0f873c27e1f62d77335ece0fcc1d88049f5ee47d49af32d4fe2b6a178ec76f96b9cab4a76e076e3a9fcab8ed4fc5571aaccef2cceeb9c7eec6d5fcff00fac28d581ef9e21f8a563e1e8560d3a386de2551828a02807d2bca3c41f13352d6e621266652724bbe074fe11dff00fad5c45d5ccb30612444c87a65b2463d3ad56581b0092233edd4fafbd24bb94b43a3b86bfbdb47b81319046079888dc01f81ce7f1ade7f13d845e06934894cb16a054bf99111f3924e14e79e98ce3b0ae156efecd6f2c0b232c7c31d871b8e0f1c75ea3f2ab3a9feef51915537703e6cf04e39e9ce739ef5608aaa19dbee907d071fe27f954822964dbbb31828148271dfbe727b0ad1b6d16ee545dcdf658dfa97223c8fa753562c9ecf4cbbc59c5fda575f74123112fbf3c9354b407a95adf4f91a012b1554036f9870bd3dcf26b4f4ad2ee6f495b581e6c672e89c71d4e4d753e1dd12db5079a5d48219d30e1589f2f2464e00ea7b735db5e788eda2b5b6b78e148c22e3cb0a006ed9c0156b5d89db739bf0ff0080ae1e60d76fb5b00ec4393f9d7bbfc29f8532f89f55b5d2f4fb712dccce23527a29f526bcebc3735dea5a8242abe58723903e6c7f4afd1cfd93be12a786b418fc4177062e2642b6c187217bb7e3d07e35baf755d98c99f367c7bfd9e2ebe155ae9b34b247756b73b86f8c7dd75c707eb904578847ac41e1dbb827b96290060252a80305ef8e467f3afd01fda3bc37e35f17e832b2d9db43a5da9322aa1579076dc493d71e82bf3d3c6fe164b3bf91352f30dc0c911b1c9ebd48f4fc2b29fbdb95065af11fc4eb8f1e6ab1697e1ab19adec635f2a046f9a47c9ce59800724fa0f6c9ae23c6fe15d5f43d916b2b2d9c920dc20c18f39e99ee47bd7a3fecede39b7f877f13346d66e51d34db7941963801569067a73d7e9ed5d5fed9bf123c3df153c6b0eafa1a5c98c5bc71b9b8010865cf4009e3a7e359249265bdcf992cf498dada5f2a14ca025cae0ecc8ebebebdbb7bd65c91cb77043711859a6618f994ed6c13ea39e945e5d416f7b0886ec80cd86653c95c63071f5ee07e152f89a5bbb4db05b916e8bba40eb81cf7f6e393d7bd40ec558658ec5ae26dcb05ec7f379722f6e8d8fc47b75e734ade208a081da58965b991b0d146e46e8ce4f1d723a0e3dab12db4f935ab9f34ed7837f33cce470081d38c9fa7eb5a72ff006169663f3e58ee274e0476a7cd7909073b8918eff8549764892e64bcbe922b918b18e4c1f22225d70390dc90a3f314359493cb03b892ee4653ba58c960fd79240046071c0f4fc566d5ef6ea330c16f059c04f979bf61b978e81074ed9007d6a6b7d326bf2e935cdcea2108528aeb0c23919f97a9033d78e6a5e82dc91f591633180491468cbb3f72aaf3371d3007273dd88359973ab5b69fb654b200ab1c4daacc58ae476887d3d08eb5d1dc6997fa527fc4bec8471a21690456e1d9ce78073938191d4f23af5ae2fe2dd9df4105ba5c491c9792461a674c060bfc2a71ed83efc7a53577b8b439cf17fc47b9be95e182f9ef573cb95291afb2af7fa915c61d62f5ce4dc3e7d8e2a5b6d2659b7623270339f6a84c014e36fe55aab227959f7be997723c5e4c652c17eeac76a03b7fdf5d07d2acbdc45a7c8d23c82239e67988671ec09e07e00d59d5f4292ea0436728b6991f121403715c7e9eb52786fe15ebbe23be55b7d267ba8830ff0048652dbf278c13fd3f4acb9574324efb9ce6a5e26b2b72b2436925fcc4ff00ae9db6a8fa6724ff00c040ae6b56f135c5c8dd7974208b771083e5447d3e507737e26be88b2fd86bc71e22d5001a9d9e83a5140cf7332996e1bd71fc23bf735ea3e06fd867c05e15b31a8eb3737faadea00d24f73309011ea36636f5e83f5a145752eeba1f0ddaa5edec612da0305b37399d7ca43ee23182df8e2b42cbc1ba86a9305b3d3351d767520f956b6acc83fef9181f5e6bf41e3f873e04f0d797fd91a141249c991da01bc91fed9f9b3f534c87c596f6914d27d96d9d61ceeb5953f7bb719c027ae31f5e6ba6345b57b18bad14ed73e3ad0fe00f8dfc4810cfa15f5bc6bff2ed1009f99383fe7a577ba1fecbbe3848cadaf87e1d32303892e8b13ff8e835f59fc3ef887a2f8b25825b383c9ba8e4319b6384f2891d003d2bb75d59f513732245b8c12341226e07e61d548c7a73fe799941c1d9a1aa8a4ae8f837c4dfb30fc4df25a2864b265753f2299812bd0f3e5e2a97eced278c7e0efc6bbbd0fc656b24167e26005adc3cc258dee1149386ce412a318383d2bef6b4bd6bc32c657f7283313907f153ea78af9e3f6c2f851e29f1b5af84f52f07cd6d6fab68bacc57d8b86d8ac02b053b802782718ee18fa5472a294afa33ceff006e9f00c173e15d3bc58b68264b098417841653f67932010474224da327a6f26bf3aafe4b6175235879b1db360a19c0f3070320b0eb8391dfa57ed57883c227e26fc3dbfd0352b0789751b16824057ee165c6413dc1e47d057caff08ffe0999168be2d92fbc75aa43af69513fee34eb12d189ba732b7503afc8bd78f9b1c198f9971924b5381fd9eff625d27e2ffecfb7be24be9ee2c7c45a84ec74ab9627cb8a34f972e9d183b86cf19c004579cc5fb01fc6c93527b6ff00844e28d1381752ea36fe591ea3e7cfe18afd6e4b0b3b6d38dad9c7e4ac4ab1ac48b8c281850063a0c638f4abab04b369bb5ce27048e0f7c5372d6e25368fcb7b1ff8275f8b6dede3bbf15f8af4cd260c88fc9b047b97c8e3196d8a3a7504fe35ec5f0bff0062ff008630db6dbfd3ee3c40e9ba36fb65eb062dd37058f6055ce08e0fb9afad3c69a2c773a3d8c6cc1a386421c11c3311dce463918cfbd2699a069ba05c41f64b31179b28c3c20b1dd81c127240eb577f77421cdb67cadaf7ecadf0944c6d8783228548da256bdb95949e808c498fcebc87e24fec6172d6f75a9fc3d94c93c60c926997403ccfdc98a53d4fa2e07d4f4afb9fc4de16b33e2b2264334728f32351819efc127e9fad491e81abd95f4179696b1dbc613091889725473c80319e79c735a2b35e64f34933f1ca0f0c896e2637ef726789cc6eb2677020f20e79073c62ba0b0b0b5b16558adf69233b987f9ed5fa23e34fd94fc1df103c45ae6b97d2de69fabdf29bd7b7b045313b8015ced619e480783d5ebcbfc5bfb31fc35f87f6d05c788bc457b649241e6adb6c2f727ae00886700f6278af3a78a8c2a7b2b36fc91aaa91ba5d4f966c2c386cb365f2404e8464ff00435d4785fc1175addca45676b2dd5d9c2a4712976fc00ea6bb3f865e1ef87be24f894da5cba85fd86896e448935d85673962a41509cf5cedc670a7b915fa2ff09fc03e16f86d684784bc21a84b398f6b5f5cdbf90d271fde988600d77d39790e4ec7cabf01be06f87b4dd4d2efc79ae5af87bc86dc74bb893cbb87c7f7f3f733efce3a019cd7dc1a07c4ff00056a51adae95e20d2dd2102358d27550001800038e38ed5f097c69935487c437897f613d824d7134eb1ca0abc819fef31fe23c633ed5c426a4fa3a6eb5bbf2f6c6b2acb112a63700370783956e33ea38ad24ee676b9fa11fb41d96adabfc2ebf8742b8f2ee9dd0b2a4814cb1e7e65049f4e78e4e315f9a1e22d39a4f115e4be2266b68e62614864cc939ea474e33c60824743f5ad6f0c7c70d561f88b05cf8a759d5af3453283756d6b76f1bcc847620fbf4e9db8aaff143e2e7c30f126a6b259db6ad662c64678eca1196939f9448c41f4ecc3a9e6b072368c6c795de788e2d3e49e782ca332281b1a66c05503038079cfd6b96d6357bbd6d1ae5a39675fe14b750038ee71c7e7cf4ab5e30f11dadf5d95d234a8b4f8caf989f6895e575079c281f28c648c67d0570e60bfd403a4b7523866e634215081ec0d46acd2c863eaab6464496211bbe318399107a00339eddc56a3788a5d76d62b682236f36f6df35c465d82faa81d0ff00f5aafc3a72e93672cd3c36f25b2c6159640a3007ae33cd3348be86501a2b08dc82b1c723870a77760542e5723bf39f5a623193c3ecd7d0a4f7897908250472bf9418f00003ff00af562d340bdb8d71960b5b6b7552a3f724ac4147cdbb760f3c81c7522ba59e2d5351557923b5b37521beceb167d8672483c0cf393fa566eaf2ea125c887ed775711e492b1c9e585214b67e51c631d2815ee496f6365a74b0db5d2c8f21f989fb9186e320065200ebf37039f5ad286ef44b089a4b6ba4fb43f2db88e3192015503b93d31eb5c15edfbad999208c5ebaafcf34aed26d3bb85504641c77391c71491c3a94f1196796d6c54e1b1e7c68dcf006dce7f4fad4b292b9dfcbe24bbf223bb0277922562923a94888e33904e587d07a579a7883581aa6b93dc5c6c31a91b802594e001c66ba88eced21d3ad239f5467b8e8628a32ca393d08ceee73d2b85f135d0b4d56f2dadbcc5453b58489b59bbf23f2353b8ed665ebed42d45a451dba34ad2fca4c63191e95c95ca469330dbf80eded5bda4c00496d6f3798b85dc1d1c1c77edd299a9ea76a979202ab336797c63350a4d1d3ecd33f627e1ffc03f09f84a1379a8a4ba8dd151249e67264207e87fdd00735e83aaf8bf4bf0d69f0cba2d98b58d479cc91c7976518cae3b715e497df13f4d7f0a58b6a7a91b291acd77bc8b824f0188e33c11d87f3ae57c11f12e4bef103476d60671697130669888e39a266187031c11b79c9c720f6c57552a152addf4478b3ab18b4afab3d9b55f8d37412d2f86957d6ba3ddb6c176f8287b7383c60e78ebd6ac5af8aad3c49a4fc975e579ecab246db460f27760727b751d0f7af33f1a789e3d5b4c4b3b5b98d6d250b3b594602609f98b8c0fbc777d0f5ac0f0ef8e92c2e208d8ee8e260aeb16d51819e49f5e715ead1c12a90e64b538aae27d9cb95bd0f635d32595da58ee198203865270571f4fe62bcfbe22e8b75a7f957e92b069731bb45c103041e7bf19aeffc2fe25d3af6d4a899e6b49f3b23588b143c6771cfeb5ade23d2edfc59e16b8b7b3d92c9129231f75b20e39ae8837096a6324a6b43e543ad5ef8475d1736575e4c88e1cc8382473c93c1ce78afa2f43f89b1dae8906b31cf2ff61cd309259227cc867dce3ca3bb3c6113963dfaf3c7ce9e30d0e637f7103fef248d89639c8c027bfd69fe07bcbeb6bff2ed911a38b6cde5cb26d4f94f079381d4fd6bd3c461a15e9a92dd1c787c44a94dc5eccfa53c2de2ebbf115ab6a31c96cb6305ee650eac270aecd90403853f7581c91c1cfa57a0dd5cb3c31a5dc0f1cead8cb8e1b07839f715e49e0bf15dfeb1e2d3a27db124b1d4ad5d2e3cab7f981d840e79e85b820f7e735d04579abeafe182b2ac86eecfef0380cd6c0f0cbd724153ef8c57ccd5a767b58f7612ba3d66d2e565d3776401c739e86996b1b25c492052d1b90ea5413cfd7a75cf7ac5f03dff00f68d804b98fcc49530eaeb91b81ee2b6b53d5feca2e7ca450d10c942703047503f2fd6b89c75b1bdc92e008ee629b1b5f38704f3f5fc323f3268d46e1ece7531a8dac06e2cb9da7ae7b67ffaf5851fc43b09d95e431c4bd183c8b9c8ea319e38fcf35278eb5086e3c3d697168e258649d1418db3bb27eefbd46c31faa5d694125fed0996386ec6e11c9fc4e3a81f966bcffc5bf1efc27e05d3fcc9e686cda3566cddc8b1aa0c1c90b924faf15e3dfb47f88f5fd1f42b2b5d3355b782c2e0a89653388ae217e405539f955863079e411dabe31f1be9773770cf6f744486e90f99712cc659255c70436071df8fce9a9a7a5ca51bea7e9afc2bf1bafc51f0caebd60f69adda8474b36b75010a0c64f2492432e39c63233c835dc5a4fa86abbc22adb881f6a12db7f841e47be71f857c4bff0004c5f1b4da6d97887c23746402c6e16ea004701243b2503d83aa1ff811afbb34e488eb3771b7c88228dfaf56cb29fe429df5426ad7478ffc7ad475af01f840f8874cbafecf934eb885eea5846e692d0c8a26191c81b4e78e78af983f6d7b6820f1a687aaa0758eef4a5c206c1deb2383d7d8afe75f767c57d160d5fc277da6dc445ecef2dda09940e76b020fe86be2dfdaa7405d57e187c38d6ee9fccbbd3c496176f8c3492845c8fa868da89b76b9a53b5ec7c95e0fd4ee21d71aeda56b698caa490c01520923047a71cd7e8541ff000500d3fc15e13d3e0d7b46b8b9d53ecea23b8dc2349c0500330e4e73d71c7a57e7446d0dc5f5f5c190c462963448f9f999b3c67d7e5af52f1cf89340f17783f468a16d4d7c53a5c715ab477770d35b4b6e23032a588f2b0dc051c633dea79e49a496e6928a7b9f7b5d7c7df859fb42fc37be4d46e06993c71875fb4c79921939c146c73d31db835f187c59d7b4d827b3d3f472a6350617ba41cbe18b6e23b93b80fa2d70be164974fd21eed0a18664dbb2339e4647e3cd52bf6689d5d63333212c6238c81df19f4feb5a36ee428a450bd49afb526102162d81b9870b8ef584f7a34dbcba4bd85668633b5e4da0b60f719c77db9cd757a7b4b751dc2f08c5f8e7a0da3d2b0f51d192eedee39c96631b10b8191c671e9c522ae73f0ebba5bc1ba38ee8cbb7878fcb5507a939dd91f8d54b6bcf0dc51cf2c7fdb324f1ae1cc7e5704fa1e78aa9636ca8b242bccac79531a9fbb9e0723bd55bfb3b65db34b733ab9cab34806c247461b49ee3f4c50523a1b7bbd3754b48a78347b9b9b387e5582eb515c67fda08a58fafcc715b9a7eb47578a5820b0d22ca38796590caec02f076b138c807afb8ae534a8aca2b707ce9e584a9f9a343b5813d08e091c75f7c63bd26a7a769fa88fb40bc532b26d9142c80a263a9f907d33cf5ef8e5058bcf783c2f0cceb7a8aac4aa490448cc46ec6d2ec091827e94cd343ebd04f0492dcde4b334992b7612dc301905b6e33c1edec2a82699a5ca45cea5aa46f66e8008e28dc82c382fca74383d79e957a1b8d2f4b117f626a928832164520c23fdec8186efc70381468162193c0367753ac56f7514d36cf33e6b79361da71b7796e993d81e9db35a10f864db5b5bbc7a08bb69d72b3344aa08f5033f41ce73c73d6ac5ef8a7c3f1c72bdbea12adcb852ed12ed03e63bba0f51d3d31deaa1f1dd8d8096f2e6fa33027dc11e59c2e3e552b8009e3f01d3d69e81a9b9a668dab58def9767a325b4402b7eeca2b11f7882dd319dc4803b815e59f1abcab5d7acd4c115bcf7511964446072773019c7b05fae2b0fc4df19bc49ad7996d6f79269f62c788e03b5dbdcb0e7f01815c1dc4925cdc1699de6918e4b3b12c4fd4d69cb6463cd767497573f66814c7202c57f849245621696662d82d93d6a486d24c0123b39cf0b9c8a9fce8d3e5e571db1591d3767e8278b92def92d2cdafd6e2e6dfcdb697ca242028e02b9c8e5483d3ad47a2dc4d1ea36d65712379724182d12e429e543e7fcf5ab9e3336969acd94ed198acefc65653fc331254a13f87e62b3b5277d1e0bb9ccc43c8a224dcb9001e00fccd7bf82a96493ea7cde269fdaec75f709adda5ae93a94ef14f68e8a0c2b2a99b60c00081ca90beb8a93c3ff625d524fb2196e5e59098e39060053c8c8e78c579de99afcf1cd0ce1e58d2662aec15704038dc063839ef5d63d95d695a9f9ef28696352caf0a85f948c67200e318afa0a49416bd4f1aa3e67e87d0ff000b1d2da4b9b3bbbc2a8ecc36ec05be99edc66bdaec6ceda1d399214019a3c071c31193807fcf7af9b3e18f89fcb92caeaf63dd106224b90a4a32e00c360727247b8cd7b67843c42daa3c8d1c8630093b376491e983ed9c57975e9be767a146694123ce7e2cf82961b43796c9b25271288c77cf07eb8c5787db5a9b72c4afef01fef7e1c8efc1afabbe2069325ec1303ba38769955933864da793dff0af9fef74796e259a7b58517ecca595304ee19000cf5c9ebcfa1ae9c3546e2e2d98578252ba3abf01fdaf5783fd1af16c6e6365dab07fad5623008c8c107d3e95ef725a4ba5269b7d6c1a392390898e3745323b0278ea1837f8d7ceff0008deeb46f14d8cd12385b978e39279549c066db95f6c9ea47e5dfec2d2b428f4d37378cf2c82491e568800e01603278193dba57878d8f254b2d8f630af9a9dcf3ad32eae52e2eae118db489752c2ea01c6fe4639c0ea47278e86b86d7a1f1278b25d56cee67b8d2e578cc2f023296442a30723209e41cf35eebacd85b6ab63208d731939f9463923a9ff001af813f645f885aa695f167e20fc3fd4e7b91716fa8cf750a5d36f75025292264ffc01801ef5e3ceed9df1313e1bfc47f0d7ecd3e3cf1958788ac6e3c67e22431c36b757225df19283cd8f9dff002e48218a8ddb41e06d03663fdaa2f7c55ac6a5a5cba6df683a48b792e22ba7b8c4cb26df9187504e3a2819ea72306b7bf6c1f085cf86f5dd1fc71a75897f3a58a3bb68a157649a3c98643c7208dca41e3e55c835e1ff0012fe2e5c7c51d3f4cbbd72d6cecb54d3ed1f4f6bb62917dac33ee4cc6aa3695064191c723815cea2efa1aee335cf8a17facac96e5a0ba8dc6c335ddbc735d3af41f3eddc1b8eb92463ad73173796a96b3c104223984441718fdd71f28e4f5ef8e95851ebf3b5bcd65612d959bc71ee33468ecccbd0fcc7a7e04f5a82dbcc2228210b2f98be619da42549c6790402335aa8d8764b63d73f640f14ddf873f689f0f5adeeb97b7d6f7f6b3e9e6dee5ff751073e62f943a60c88bd07526bf502c02c1aac972ea189fdd103e638c06e99f527f2afc90fd96f4d1aff00ed47e0d5d5f74b1d9ccf388e052b878e17923e771e03203803071efcfeb2583cb2eb4d1bc3b6364f30104b10476c0ebc7bd0fdd1496a7477d7d66e92c73b47c8c346cc09fcbf2af99ff689f826bf17be1c5d786ed3534f0e986f7fb4e3bb756d8a544bb81231c1dfcf6e2bdcafbc4761a7c17220b7492e81e04a36e4e7d4d79a78ff00c6567aac33e8e4ef5ba436d2c31fca06f1b48dc0e7bf6a39ae4a4d33f20e3d4df41d563b3b909792445a3768972b90401206cf2783d8706ba4bab5b9bf2b23c725d5831f2e192390ba1efce0e01ebc360fb5711e33d26f741f145edb5cc4f1dddb4ef0491c99c8604839cd56d1b5f43aedb47720cb66a3ca746e0124e7b76071d7b574a8a71bf533f69253b743d7bc2fa9a59df45a699522865c18e35607e71ea33919aebb50d3dee23668b6adcaf28c78fc2b87b9f24e950c7696ab68eabfeb234232464e739e0fd3a56a41e3ab811461a088ca170449210cc47f1631d0f5e2b1674a2eda594f6692c97924d11ee531b71f8d707e20d6a4b1966488cf1db370afcfcdcf24fe3ed5bfaceaba97886e162598450f195489a31efb89208fd456f5e7c35d260f0a68dae5ef896cae6eefd5658743b7924332c058805df6854276e40241c1078cd45f97729be6d4f1db4b692e5b1e7ab9725da32c0607604e7f1e95620db34f2d8f2c586d0b23f01ce08624f4c7f4aeef54b9b7f0fcc621a459359b46cbb1ad564600b023963bb1d7e6e48c5625ab69b71e65c5c699a7a5b87f90c36aad2458ea0f424fbf3f95697121f2dc8b39923b88e2b790105cda4864420f3d39e7031c74fd28b8b5f116a76a648ed9e3b07642b3451365d01e98032011e86a2c787e7b588476567f6af99424d09c15c643330e54e2b4342f06c0d089eeb4df2ed2339f38890894ff00757078ebc1352332f5f82f3cb8a6d3f589374310b82b6af973c0deb24600f41807a007d31577c3d69acf8b61897c99de061b9a6d8117aff07185f4c83d7d3ad6fb1d0f539ae6fed749b2d074eb7408a2059185d4847cca19d9b70193c8ea7d0715af73e0bf095ce9cb3431cd6ec22dea96b33e660003c0048c9e38e0f3495d94ecb631ecfe145f3d8aa38823dce329e517643c673838ed9f5fad7947c7049b489ed34d1789710105dfcbf9773671965ec78e9dabd125f04bcc2136d1cf6714bfbbf2cdd33c8afb41cb73c707a75e2bc53e28426d35a583cc9b622ed114f2191e32319049c7e82b48dee8ce7a45ea71cf1e09f5ed525b217b98f7e08cf27a53377029f1032124646076ae87aab18276772f4977e4b931a8761c64f415466983c84c9b99fbe38148a8ce7049a468b0c7383ef59c62a254a6e4cfd44d63c156f7da0dee8d2ddb98aec9bb82694e4c2188c91ec1c67feda5795f8bec6ff4cd1b45d36f984f117729720ffaedac57047518e383eb5f455e4bf6dd774b92e22896086e5ecda3847de49072b9e38ddb0f4e08eb5e65f197c0f7b6962b2db4666860b992495a204bc4bfde393edce79cf15db81a9cb3499e7e2a178368e57c26d62f677567a9ed923e763b2648e738041ebef5d5e97a7ea1ab5adac17b7b19b2b6dcb0851b9c0000f9ba6148c73ffd7ae03c24b789a8c51c76bfda4a1d0490638907047239fc8e79af4d9744b9d3e6d26e639245d3ef4f92638948774ddb4b2c7df00e3dc86cd7d2f359dae786a3ccaf63b2f0c7852e2c2c729e71d31dd8f9c3798fb1c01d338c74f4af41f0e5ea5935a4f1f990c84851bc819c8cff00215ab653de58e8171e17d475ed39ed0432bd95e4f0ec9108df8da1db0c73f2ff00b2463d2b93f0df89dafe48e4bf489a794f9132476822642a40ced518c9c0fbbcf5c8f5e4539d7bb3aa54e349a3ddb5380eb5e126492159e475c2b2a950a319e48fbc383f98af2cd3fc2fab5d6906c45979f64f7658c4a843b63a9df8071b411827afe35ea7e14d6ee348b316d7f68e91c7929f6a731a7fdf2d990ffdf3c63af35b567f11618a3fb15aaadeca88659121561b06fe5b383c673c10bc74af31ca74db4b53bd4633b37a1b3e17f0868fa6881e2d2edad2581155634556608092a33ecc588fad75576f1c11172f1c673905db68071eb5e577ff00129208350bcfb43b2da5d3dbccb18091a958d9b24e59c8ca85f94ae49e9595f0fbe37e9be26d56e239628ed196e0c30bdca012bfc81b6e4b1e73bbbe78e95c5285495e56d8e9528ab2b9afe31f1fdc7823c43631dac126a31ea5ba496c5559f680065970303eb9c1e78cf35f117ed190782fc1df18fc3df15f4dd4753f0ddfdeea337f68c7736dba390450ae4431ae1be6c8462c4a932a9040c9afba3c60965e3bb28e1122bcf0312b2444068d81392a7d4118fe62bf3eff00e0a0292ffc25fe148352b8b89204b7b8b68639487190d19254745cee5e83b0ae69be68a4b466d05abbb3eb9d1a6f0e7ed17f0765582e04fa6ead6853ccfe38cf638eccac3a7aad7e6e78e3c2fa9f813c51ab685a859c76d77a64ad108e3567ddc677e547465c1078e08f4c5767fb197c6e6f85de3797c21ab5dbc7a4ead206b47770425c1380304f018607d40f5afa1ff6dbf856be21f0643f10f48b7696ead152df51585f617b627e594f1fc0c704ff0075bd05636b3355a3b1f154ba4dcd9082ee7b192ddaea2f39256230e8c08523e6e7918e9d47ad6af86b444d5b57b1b6bfba6d3ace69a359af3064685091960808ce01271ed54e3d4f5ad7a1d2b4bb7fb4ea62dd7c8b68e13e6ec52e5b6803fda766ff0081576da0fc0ef8adac5cc2b61e01d7676949d9757f6f24119e4742db5319e393f854b928af79d8a3e84f855e0bf81df0abc41a4ebd79e37d42fb5e97539f4dd2c2623b79860279a4042546d9f39671ce719c57db76661d3b56b38e19dcfc924655be6dff00302327b1001c67b57e317c66f077893c2baafd835c83fb3758b0982cb119412a4805701723b83907b8afd5ef869e314f157863c33e2362d70da959dbdf04810b6d668f120071d43123f3aca10e58def7b899afe3f8637ba9a14521a4003215ce0f5e2bcbe2f0fdc2dfc1bff7704336f1e60c3e7afd4f5af65d56f2491d4c76ed249bb9f39b0c07d00c560ea097b6c9717af62b0c7113b7f79b8e0f73d01353b3b8efa1f949fb64787a6f0c7c78f1445e6afd9efee45f2e3fe9a2ab9fd59bf2af17d2208aeb5e8a34244111e640393dcff2c7e35f4b7fc1416c645f1ce8fe22895dc5edb4d6b2c9172a248a76f9491c6424883f0f6ac6fd973f63ef187c5dd027f1819ad746f0e3248209ee5bcc96e0a1218a203c7ccb8cb60641f4aea9e229e1e973549591cdc979ea7316b629885e45905b9072cc0c98fe600c7b56d689a7db5cde34b19942818589a3500e7a11807f5f6e95ab75e11b3d27c23a66b306a4f75797924f07913260442360a3a750dfcfe95816de2e952078ef206d913ec89eca15462bce41207ddcf7ce71c74a2f7d8eb3635789ecb7a07549586ef220507781ce0e4f1dfaf5c5605f30d46c9ade292dedc4648777219cf1caa8c71edf31ad65f18e93040aab6eb6f2c6caed12e496ce3d0727af51ebcfae44bac41a9a1f26c6665c85d926d2f18ff6493c7a600a57048c9d174fd33529bcf9afe382e2406375bf461f374ea78e71d33c55a9bc0da9178a686de07859b2a229370183c1e323bfbf38fc26b7d46f74cbef2ee34c2f0aa12ac2504ba85cede472739cf23a1aa3a5ea90db6a33dc44b25ac88fba4b4b4730ca8bfde24101be840c67d39a6cad6fa11dd7866e63926856c666f94bca46ccb31390010b96e31d318c76ce29ba7e95ab5d33df5cddacc912146b296e0f9cc8063605cf1dfe80e7bd7a568714fab346f693dbdda4c58eed42165f978c92ca70ac707a024d6fdbe81a88d3a61fd893f90809926b2963ba183c9f9242b21e01e029fa1a9b85da3cfec348b2d49ed66b32d6f7f82e2cc3aa34400fbac0f078e7b1fe759579e17bcd3f429525be02eced7161e604674c9239fe2e4f507f038e3ab5d034ad46e254b5b8d334d925051a3955e0b993040e55c264fa839031c526ade0c9276b7bc5babbb9bb8594293664c7bc0c125ca8dcb818e49078c1a634ce4bc30dade97a3c70cdf6bb2df751a432a8054ab707db8f5cff002af39f8e1e1abb7f115c6a525b9b6b39098e12acac3e538cb60f04f5af7dd5bc4fade931fd9ae34ed2f50864f958c6fb1bfdae03363938cfad7cfbf173c66dad5d5ae9b0c725b5a5a8ff008f679448158f0482147a0eb93ef571ba7a09ebab47983c2500e7b54aff00ba838eb8fce95fe69829e99a6de1dcfb570467afad752392e44ae48072451e6ee249700fbd1b46dfa556908ddd7ad2633f70fc21a3e87e36f1b787751558989732debdba83135cc4573b881824964239c90c7d38ea7e2e780ad7523a959a3c76d04c84b606700e18330270c320e73d69df0d741d33c2ba45cc0d1ffa34f219a42cc4c884a8191ec028fd78aa1e31f10db59ead696115c47a869128687edd3b2ce56552d98df70c01c95cf5c8e6b2b28a4c9ddb4787782f41f0b695e1ebe8ec9350d4f5d5994793a64796475ce1bce5dc23c373925461464575d07873c49e25b19ac9743b3d3e29562792e1ee19d919092cc1a36f2dbef3008f2719e9d8735f197e2d5efc3e0ab66d35b2c451a34de18c4bf74ab0272a33dd38e45782f893e3febda9eada8dd595f5cd94578e41933b654e791904e074e01ef5eb51954acd382ebbbfebfcce2a8a14d3e67f247d23e23bfd0347d2c586bbac49a99b69485b18bcb81031c12842e1f80c38f31ba74c0ac9f0e7c613a64f3ae93636d616ee0acb25ac1f3803b86e0b9e872c7ad7cd96faf7db92de79a6df7b331f31998bbb1fef64ff008e6ba2b3d42686ea3b482e6457f372087c2e71827f1e7bf435ea5284ace157fe07ddb1e7d5a8aea54ffe09ef53fc497bd0ed02192e0823cfbb22470b9fe1078524639e7bfad64e97e2dbfb7b8995229bfd253c99da238ca1233c0e33c7b570f6776634255f781f29656cfb706ad9d4a7b74609210b2282c8adfceb6f722ac8c3df6eecf55d07c4968f69e2cd256569ae2e6d5a74964451930babb6460e495dfc93cfe3c788ea1e31d4b46d69b514bb316aaee55812cceac304b30c609278c7b74ef5d7782b5ffb0f8b6c1c9044eed6b2975ce565428df5fbddeb88d6b4b48bc42e65565334de63e709b0b7279c7bfe9f856b414694db92bdd195794aa4128bb599ee7f05be2aca2f34a596ea44b48c48b3218498f9f9f7295e87391b4e06318ec2bc67f6da8e7f1b7877c1fac2aacceb7372af233608575423eef7f93a7b569fc2bd6a4d27c436a8d3054b89110c60021f7380c09ce470474ea4006b94f8d9235efc1f5819e48e4d375b8973012ce418e5524f1d395fc857818fa4a352528ab23dbc1547284537a9f2fdf7855e7482e9ae1ad6443ba164cfde1ce724f1edef5faa1fb2a78f6d7e367c0d116a9241a8cfe4be9da84590c243b70d903a07521bfe055f9b56fa55b5c5b4cb79b9d0b7dd98e4237ae06315ecbfb107c408be16fc758fc385960d2f5e5113a87cc6b38c98c83eff0032e3fda15e2b573d47b1d4787fc55ac7ec93f14fc43a55a2794b1ddc6a40d88f796a32d18dcc8c002186703db3915dbea9ff00050cf10b6af9b6d374b8acb612b6971b9f238c65c1041041e78078ef5d3fedf3f0d9e78f41f1858db032066d3ef6455c9f2c82f116f60dbc73fde15f11adf5cdab958aded45d038321611b30fa11cf1ef58ba54ea2f7a370df53abf8d1f1463f8b7e20d5bc43a9dbda59dd5e84061b31e6aa32a2a8d9872470a0f27d6bdfbf60ff008d1aceb5e20d2fe1b5e0ce9fa558dd1b29e48cab3ee78dc464eee76fef083b7be33c0af978df9f38dd94856e046aa3e6f314b7723686f5f435ebbfb236a01bf69ff09158a562eb70649444c8848b771cee5c9e9dbbd68a292e55b0fa1fa3d7904d691992e5595d58ed214b37d719e95c3788aff54d5e66335ccab691e5760022527b73d6bd6afe27d4e09626caa16fe10cb903deb8af147876dedaccee976c6c3ee06e7afa673584b4d84add4f8b7f6b27b9f0a7c34f1c1b7fb3489aeea16f0c12ce011046d0c2262339e0b4031ee735e6bfb217ed3ba77c17f0bf893c277f6ba96b42675bdb086d4451264a6d97e69190f554fbbbbb903ae7ea6f89be1e87c5361a8e9336831ea36135a10b753edf2e393076e50ff165531dfad7e7e685fb34fc4bd45ad752bbd2e3f0ce9c6f574f5bdbd711979598afdde5c8cae3380391585754254dfd62dcb7ea5da2ec99ad1eb579ac689657a8ed69a5c72cfe4da467cf998b4a720e5146723b1e054d1cebe6470c502b1542ee64c2e4764217af1ea735a7e11d02d6e3e0d3789eeb5d9ade1fed23a7b5b456e1423ecdf966c9eb86edef542db4db660b1da234db9b0a64f994f1c9e38ce71d8577269ec2b90de6a71c304b6d069b095900468e37cb7a1caa824f5f4ff1ab1a6e8b6f3c8ad15a189146edb22793116c6321986ee3fddc54d2dbc121fb35a4925d1230f0c2762e38c8c9e001cf02acea5af5acf18b510c7310a41880ca2a838081bb9eff002f5e9c629328cf7d4edec6dd55ee212846ddce1dd646c7dc241e73fde23b1f7aa4b6ccc1afedb4f89c3809317f9b61032029fe21dfbfa62a1d42fc582465a0b5560ec121b9da7671fdc2323f4278c9abf16a9776709bc22c65b39b91672c651e338e76ba6ece79f434586625aea131d53ec33482d2dae000c0b0511cbcf4ced2a08edc75e9c8a6da7896f34a699639efca47953776ed81b5782724f27bedeffad68bea5a5ddc26f134ab9d3ee1976289fee3e4e3876523fefac0c67d6aa6ada2de5adbc3e45ac77df6b75323d9bee8d718e03a9055b8e73c1cfb0a4d1a2772d6b1f14eff005336fa15c88f52d26072cab748261960a4b0032aa00e72339c567e957ba4d9eb0b71f6fd5f4ab633ec92d74f6259d7182d1b16db8383c05aa379158f87a7b686d2c64fb45c10fe679cacaa33fc4bc9523d33cfe9587e3dd7755be863b49669ae2c44b8531c4238f27fda1d48cfaf1cd45d27666ca1ccaf15a1aff117e2fc5a12dee8b63711eba84908d7d69197507a317563cfb601af02935192eefbcd99b748edb893eb5dceb5f0de3b2815c5d25bdcc8e144721c6d1dd98d57f18fc3f8f4bb4d2d34c7b6ba965dcd25cadc2e59800707278c73d07e75ad39c64ae8cab529527cb2dce302bb3b3804a838dd8efe951bc52b12fb4edf522bb4d3a6b3b3f0fdbc77b7efa746f202f0c456791a404866f2c9f978dbd48f6cd615dea3e6da47e6c423209da01e71db3c0e6b6f68fb18aa51ee6049212304107be2ab9619ff001ad15b98cbf18cf7268f3a03f78a66ab9fc88e45dcfdf0f883a86970dac90476bc428137a71f30f6ef81debceac75185f4bb8d3bc4a92dd892277b6bbb668e390a3004e57203150dcf07800f5aa7aff8f6d350d4e6b2b45975dbe004674fb6914a29c93fbc24e17927dfa7b561eb7e0dd6f59bcfb7ddcde5ddd85c2c9a7c23e5894e7956500f057e527d4e7b015cb0e6e54a4c52b7368787fc659ed7e20c13e9f637bf6dd4b434dfe64911492e2d0e007009f98a1c2b7d41f5af9e6252d3b24eb8753c8e81b15f6ef8ebc3d6bae693657ba2451d8eb1a5991e255418129055e37c1194619047bd7cd7f11fc256f3c4754b3b7316652b35aa1fde4128e5e327d40ef8f98107820d7b183c4fb17cace0c4515555d1c7e8aa6786650ea1b39446fe21ec6b7f485f33624f234055b1bc0c903d6b9db0b39254696dee5662093e5142aea3af43f8d749a5dd8091b32c6c7a1590027fa71fe735ef7b5725cc8f1dd251766775a05cc8f0cb1e4b2a818c0cd74560ccc9229e49e0e47b5717a6ceb14512236c81fae392083daba6b2949f2c8cab6307af359ab4d94ef146be9b6bb759b0903790d1ba48642b92bb587e756fc7a915f789ae9e1417523b8b9370a36eedcc491b7b7040c0acb9a592ee48b643bb62e3e4c8f4a97c6da77d8ad345b888c86e99550a8390dc30ebea3cb1c7fb55d914a52573924dc62ec54d274f90de332c261da32247ea7d719ebc8ad0f8e5a46df851e2a9b4f889951e3b95c36720cf1fd3b3e6aa68ba8dda2c71c91acb2a9263327f03743d3d47eb5da788ed5b55f85be2892484ed6d2e472bdf3182d8ff00c842bc9c7a7cba9ea609abe87c3234dba966824de56738c283963f55e0743ea6b4cd9cda23e9dad58dcfd9b52d32e92e020242c4cac18118cf719e4fb52889cac8d6f6b1d94041df24b70467d3d08fceac5ce8377a8d94b6d26a3e6c72a6d10c2a0a81d86e209fc735f3a7bb73f55fc4179a6fc7dfd9aaeae96dc5dc1a969427447c102508244c1f670b5f99571e2747bef2184a8b18f2c11224688460601dbc8ebd7debedcff827ef8c9b5cf82e9e1d9e532be9170f64c8a4640fbca0fe0f8ff80d7c55fb4f78c87803e276abe14d37c35a55a45a2cbf65327d9b61993ef2bb15c1662aca4b127af180054ecc98a7b22d43af406d6ea5b772b1b6d8250b85dc0306e33db20119f4aeeff659f1ed95afed39a03dc891237867b2b69a66087cd743b723a104e540eb920f3d0e0fc06f1ce85aee9f7571a9e8514b6d6d1892fade4236b83950237e08621890473f29ee2b974f8870f817e22f85f5dd3accc9fd8fa8c373e5a06c3049036dc9eb9c1f4ebef529de4d25f329ab6e7ec4c73b5c246b265a4d80b056c0e7b76f7ae5fc4f6c9040ce316e80e06700ff008d2788be202da269ee9a6c822bbb64b868e6c23c64ff00091c8c8e323debc4fe277c71f09e92979717767733dd070f10251d6360000153a633d4919f7ab8d09d4d22ae62ea461ab66fea7a47f6e598bab690a3ac859155b31b3282a18f72723f0af0ff001beb16fa4f82751d46f754689344beb7bb5b3dac16e0c7323f963030ccc23239f72700135ed3f087c770fc4cf00596b70d99b31713cf1985883e5ed9597e9d067f1af953f6a17d56c34980e9c6de359af85bdccb2db2cfe5a329e5518609e3d3b7515cb89c2c6b47d9555b3fc5154da93527aa3e63d37c704e9c348f345b69177aa4d72f66eb850db542be3a0232c067dfb1e7762d523b791f4eb4858a86cfda664c93ee10027d7b633deb8ed0fc511abbc13627920b8f25259548db8e01254ee1d3a671cd75daa78ca45b1b5b2b7b845861b879649a1644566214659b19c0da31d79cfa9ae95b1b34d337ec74cfb05bff0069dcbaceeec7097ae23dbd38d8bcf3e87f4acf5d55e79ee59ef6decd625398e41b55be6c12001f30e0e15b3cfa5735078a1af0a34374b2b42c48558ddc9604e3e66ebd7a0e2a1b8d46e2ed02cb6a60208209e1e4f7083a64fa7e740d2ee6fcef1b6fb78d2ded54726e42991949e718c7afa927f2aaf05c587da216b2d64c52cabe5c8cb1829e60c91e6447a0e3a8f5ac9b6d66e1404092ce84f98a5a45183e8554ee3d7b9c5659335a5cc934d0b397e5d718caf4247d01f6eb4580ef23d6eeec2f5ac75045499c6d12cac5ede5ee183f2c33e8d9fa8c54fa5584964b757115afd9e5401b744c03ae73c8646ce0e473cd721a66acf7b7f6f6f793cb14037796a5739f4c0232a0ff003238ab9a3dd432eb8ceaad3aa41b4467a798a7a36181c75208c63d0e384346beb4350d426824b8beb3bbb844d8e27520c8841023dfb770273dff000e95c6cadad5b5e36972cba7d845e59f2a1bc2648e20d9e38040233c13e9d6bbad4e782dad25b73731da4ca3e5b599f7ec6ea36c9c9033ce1ba7eb5cf45653ce591a69649252a4bccbf7b07a07cf032739c81d3819a5ca99719c96cccad1fe1e6b1a95cc42e6e2dee6de3c9fb5c21674da47a83cf3ea7bf4e2bce7c791ff00677892e6dd6549561da061cbafae33ebd335ec1e26f0d2f85a39af2d1da1b9863f3e5f21d91933d30d9e41f4c9af08f13f8827f10ea6f757b3c93cb8c6e7e5ab5847526ad69d44b99dc4d53c4d71a8334a6dece26604130c0178ac77b9699704e4fa7ad48e80db672d9e3031daaa81cf233f4ad9412d8e694e52dd8a58a70c8cbf8544cc09e9fa54cd2b7a1fc4d12c12c64671c8cd3b107ee5db78234ad07c32967e1b482de19233b183fcfe602092c4720e4007f2ad3974c616f309364732956d865c20c738e3b633f5e335666d420d42f1a08ed678613fbd6711109b81dbc38e3b8e9e87d28bf7b7bf8663b8c909c0b88c8c2a01c10738f423b572a2d9e6ba8699358cd737f2158f4fb92ab2471a8051f8024e3a83d08ec707b5793f8ffc25a769136a7ae5c234163728b16a1011852eb8d93a7aba82413d719078af6ff1a6bd67a358fd9638fcf7ba263b7b48f99655e0640e8abeac7a7e55c2695a37f6a0b8b0d65526b98a225108253c93d15477c0c024f279f6154bc80f996fad2c3c2b7f29bd68964f284d04f29cabab282a01e432e0e4119e3f0ac1b3f13a5d484b086ea376e8dc32ff008ff9fc3d5be27780e09acce9720612abba594cb10f9947213d463e6c7d08f415f3dc9a5cda1dcbc7721e33d576fae7a8f6af73053527e679b8a8b4b43d92d6f6d24d3c3451bc7704e5086dc838e7a7f9e2baad2e29a2815c9de0c7bb69193cf1e9fe715e41a6deea767a6c52fda164b67c905faf6e31919eb5da786bc50d12edba06447208646c631c7f2f4af59d2d2f1d4f2d55b3b48f4cf0b8699ce5094849debc6ef4fe64559f19335e681399a22b2da4a5c2124654e08fc46d938f7ac9f0bdedbdbea2d991bca90ab2b91fc3ea7fcf6aed24b6fb5ea525a5dc8aeb3c6a80b361719c7e809f4ef4549b835248718a9a699c8691776be6ab440b47b15f206703a77fa77af46d0f4fb8d5bc25acdbb8611de58dec2a847631955cfe2cdf9d79ce8625b2b89adc43cc6246575c1047a60fb8fd2bd9bc1973326904dda142d38445db8fdd94c1c7e207e75e7e2d3716cebc359348fcdcb1d375dbbb945610408c4a2b49b555481c93b89207e94f9ed6e2ce3f26def2299e48d5a4758f691900b20e7af6e300e0d6b6b9e221e1dd62f34d8349b49e44b892125989da436df98eecf6ee6a09aca596d639a5874ed344cdbda5bc2f851eab1f2cc7dc0c7bd7ce464a4f43e8251715767d4bff0004cdd522d27e2af8abc3ef7608bbb58efe284a95cb212ad8edff002d47fdf354bf6f4f861a627c638f578679e1d6f5284bc90c8aad04b1a0544da08073907386f4e2bce7f661f14685e03fda03c29a8699732c92c927d86ee4962f251bcd5dbf2a60919765e58e2bee2fda05342ba9a3d5fc47adcfa3e9f6f22a47776f6c1cc85cae10127e4c6324f3c678351552b5d909b8cae8f80b42d1350f09f876e227b5963b473b9af6ec7971ae780dbb685efc7ff5f9c39b4cb57d2bcc9b5eb460bf78b4842b119e463be3d866baaf89daedcdc6a3a9e98fa9c777a71b8710c893c61a68f71d8c49dc338c671f9579eb681a35ac1348f287c296211bcd48fea471f98ad2364b443777ab3f447c13f1434af16fc26f025e1d6edef2ea0d1a38aed4ce5a4791498d99b8272ed1b633c92a715e43f1cb4cd374db8d3a6d42e5fc99e1745545393b5b70c7619c9193ea7f0e13e1af892c7c2ba4e811e95790f9579a34b3c9e6a99009adef67658c061fdd9401f5eb5a7f1a3c4fff0009659d85d4ac86610ab34699c2b127206471c63d7eb5eb6057bcafb1e662968edb9e8ffb20f8b1a3f006b9a5b1d8d63a899c2e780922291faa3d715fb625bdddef86641a6c2f35e437caeab6ea3714ff0027f4ae4be005d490de6b9670cd3470ea3088da489b0c8ea5994e7d36ef1f8d60fed7de3f6f0ff86f47d345c5c4ba9ea11c33ace5806da9b8312571c96dbc0fd2b8f191e5c4ce26d8577a5167cea9a15cdb5d5f2dc472d95d2b34db4a338932791c0c81ee6a6fedb82dc2c715a7fa5af1e54dd41ee063afe9d3ad743e19f893aef86342d3eff5226facaf014f3246391d0e401d7008ac5f1cfc52d335ebd547d220bdb74770acea51f667e520ae08e3deb95a69ec7727d1915beb33c17134d7329593660c30e230807400282df8d737acf89751d4268ecf4e98c71cec150443f7acc718563d40fa54ef6f6daa5acbfd8f773dbb85c8b2bd206eff0075c63e801fcea0f006a96761e24b69a781e79111963814053bce00393e833f90aa8ea295d0fd54ea9e1ad5219ae98acc141200200f6cf7aec74ff15c1ad5a0866c17c76e083ea2ba88f5bd23c4718866d1e79a274041256404ff00faabc6fc7fa543e1ef11347a7473c50b726098e0c67d339e9deab949bdf73afb722dee960bd9a4114526f4b94182076e83a76f518efd2bb5d1ecf1a8c5756713cd2024e2374570081d47f17a8619e0fa578ff86e6d5ee6e0612345553b5891d3dc679af4ff000e6bafa715b6beb42b115e1d53ee773b493fa71f5ef52d1499da35c6a1aac1fbb84ccd7116d73e47998f552739e3240fc38eb55aced2f2186ed6de155b584f9422bb62f1cbc80cb9ddb8367ae38fcf14e9bed13acd77a75dc56e42aa80cb8900519c8c93d781823a67a8e6a9e9e2f65d458fda92da4f243c802e5a4cb1cb2c7dc8078cf7fd20b392f8b315e45a3c2b6b15cda5bb127ecfbb7c44e30763e707e9807af5af099db04ef043671cf515f447892713eaf25b3b7dba081164cae046d9e873d14e0f603a9c8e327cfbc5ba7e93717729923db390082a369e9d33d0ff005aeba74db8dce59cad2b1e7433f67c77c66a02b907dbbd5fbc8a279986e08aaa002463a7154e28a491d63442ee4f0077a6d34ec2dc8ca828a193d4eeee6a32b8f5fceaf49a6dd28c342c31d33558d9ca0f28734acc68fde9b8d12058d10c6ab22f096b1670c37646413d8fe3cfe35c9f8dbc466c2e868d61145a96bce8b243a6eedb6f6a33f2cb31c1ef8c0ef8e077adff001078a67176ba2f86cadfea25f1797edf325aa8ebd060b9e8178c753eecb6f0bc1a45c35e35a892e667def74e41677f4e4f5c0ae35aec5edb9c8e97e148f4e82ef52bd95f57d76441e7de4a46e76e36a203f7532c3007039ea79a8f55d03ed5696f7272ba85b30689c395ce78da70795c1fa7b5777abd8fda030842452c322bb650f0300e0907dc73d326b89f1a6a26f6e934482e9cce8a3ed0ea7eea1fe00d8183d0927900fb8ab42b9e4bf1074e87c79a65f69e93bc4626697ed301f9fce5385e7ae14e071d70715e05f10bc1fa928fb5cf0b3cf6edb27893ae7fbebec7afb57d4fab69a9a08861102b7daa629951f714705f3c718c7e9f5af3af8b9a15f5d5e5b5e42995b7f93ca8db8ba8997961ea30411edcf5ad69cdd2929a2651535cacf9a61f10485adedc48ab14436aa98f6904839ce3afd4f35d1695a9c699180c59b2367639ea7356bc47e0ed341b4bc86664790fef44ea4b019ebdbd7bf70738e33cc297d1ef5ede58f7ba1da5718fc47f315f6b42bd2ad46eb747cad7a352955f267aee87a9992c163591bb6110fde26bbbd3fc4f26a17ba6a4a8d11526df24ed237232a924fbb578df8435c36973195c15ebeb8aebae6fde5170e4ee3feb08ce3be6b9eb2e6d0da94b9753aabad424591af2de49259c48433e54008edca81f420fe15dcf8afc650b6fd160bbf222b5b6ddf698c9cca46c70463a0280fe2d8faf8c78812eac7c511fd9c9582e2d44bb7b1542d1e7a75063cd32cb545bad76082367c480aec0a0905976ff00518ae3a91524aefa1d14e6e32765d4f17f8977575a27c42f105cd9ef8ef1af26688c85195559c907d7383c74238af2ad59356bff0022da34b8b9beb8772ab0b1666e9d8741cfff005ebec2d63e11681aaf89e6d42fe39ae7ed11a4f95b8c2e7014fca07b679cf7ad59bc25a768d6e069d6d1dac608e228d4163f975af958a7093ec7d44ea46715a6a78c7827c117be0bf87f717f791247ab41e55cc7b76ab218a412005bbf23927d2bf45ff6a1d0adfe227ecbfa8eb369fbd89b4d87518c23e06d50b2641f75fe75f1c6a568b77633d94cd9fb42bc6e07f0ab02319f535f60fecb91cde3cfd8c349d175221e7874f9b4798139f963668867fe0016b47b5ce66f53f34a3d0b569acd2eb4ad2ccd6922e77c9190c839f5c023df23e95e8be1ab18f48d2acedaf2048e7922dd70366c21cf38c7e9f8579ddc5bf88fc23e26fb3dd31d3a404c7b194f0ab919e3208e0f35d66816b3f8cacdee26f10c8f7484a488d6e8146795c0041e98ce7f4a196632e747f8ada55bc326745bd8275894b1db14bb1890b8fbb96087d326bd0bc4364f7362d0b2ef6922dff2eec020823df1835c56bde147f0ff008e3e1d5add6a43ecb79aa47135d7958113798839e7d1cfe00d7d9369fb39eaf6fe138a7996d7539ae17c9b578e422348d97ef960a0939c11fee81d0d7a983ad1a717ce7062a9b9b5ca7ce3f03ed661adb431dc3c0c5e3999558a964122ef191d4152d904e0f435c56ab67e1ef1bdb6a5bb4fb09e0d2c48eef74f8b8b6b82d87864ce1423aae558700fa6d22beaff0006fece979f0ff559358d66fa3361e5f96f2460b349b80fb9c7afe3c74c1cd7c95a878153e1ff00c4dd74dadd41addaead68f1cd0f9614c52b3168d19031c8600f4f43d38ac71b3854ace70775634c2a9429f2cb73c7fc4cf3c692695bd66d392017160ca02af94704118e9c0e4763915e7b7333c1244dcb6ef971eb5ea9730d9dc789752f0a46eb1cb6b72e9a6991b207f7edcb7d471fed0f7ae3754f0b4e26921927b6578c3c98566dc08ec38ea31ff00d7ae54751b307c3a967b04bd86e92492450c884ed2413e87a719ad3d5fe1a585b6831ddc3abd8c37b122bf96581767eaca76824f3d0f38e2b9cd2a6bcbe921305d04822406572436d61907e53d3a7f9e81da8eab601aee11a8ea05d8b61e001620c7a0db9c91fe1516655cd7f08dcea53a5c4c9a90b4fb34ac8ed220dadd382319cff855f9f4a82f2e65b8beb95be69086778e0257d323238fc2bceb4ed5ce9735c4124eeef21f31654ced2dd39f518ebf4adbf05eaf73aeeb9f63bbb832b491b346a7fbc39c7a74cf5f4aa24edacdac2c24b78e1b66712300aa8177313c0e3af35a93ead67fba8a789e1778f7c71bf3b86718e0904fd0fe35cceafe0b94c9022bc76f006dcceb27cc31dbe95b90e942294b4f733dc48e00925dc779f6c9e7f338ab4e095d93691b5e1f82fb4e8cdde4a4c5f747070762fd3df3d2b5a7bfb4d4a726e4258ea2a01577040241c92ac0e54f3d338fa572b71ab4da7c2d731c7931b7ca4ca06e19e4e39e71c0181cd74775a8d94ba2cd75220137924859472c0f5c7e7593345a1856c973a8c37524ea2e266958b48a01273ef9f97f0af3cf12a35bcd246578070c18631f874af4bf0f43143a18b8754dcc3702c3915e5be30d46492ee5020464e80baf06bb69763965dce61e2595837988719c2edcd4fa005999b316f91588dddfe99154e1b696f6ea2b68557cf9d80da8a0002bb2b1f0b1d1bc41140f0cd0e612642e5595fd0e47be7d68949458d2ba295fdc4904457cb20fbb138ff3f5ae5e569669598f1ce3815d8788da3b4462bbb19eca38fc45725f68380591d8b7390686eeb4125a9fb9ba0d9da684d194431c16ca44e5d184bd064924f3d3248cd6f5bbfda2deeae1240d1f9852dca0c854c6010003ef59f608f33dd144f2219dc7ceac55dc2e7279c1e70471506af32e8b62d737b33cc5884b58558a1949ced0c031c903249c7033c579e91a9cef88b5d3a55bae9f6f3092f6f306056f98478382ed93cfa8f523d0711c3a0b695a7ac8ac6493059dd86e2e4b0ce4f7279aa5a6f866f3fb4a29ef2e52e269c966558d400cdd4ae79180081edd735d26a32bd85abc4d290a131233a9724fa0e7af03d7ad581e6fe2981bec3e53c6dfbd401c4a3e65878f9781fc5d0fb67a560da471ea2c2c2e9737d621e6d3a5c7fad8b27f7079fbc73b97df8fe218e83c5f6c63d2e2325c79d7735c22cb0a700fcbdb8e8179e4e3f5ac1d4f4c5d6ad6674730b443f72eadb76ca14907b70318fc6a80e37c5fe15f09eb7e0bd59cb2695ac24eb73612342d89a4da04919619001da080c06083cf26be61b94904b30bc8dcbabb29c8f99481dcfa74afd0bf077c33b2f88ba6c136bb1ddd9fdaa112c91408abe66403bc13f74fcca4803f8b3c67039ef883fb09e8da9abcfe16d66e6c2e8260dbea404d1c87b12e30e9f5c3577e12bcb0f2b7438f114a35a3e67c49a2036f69e7c92c4416da104987cf5e9dc7f9f4aef743bb8752d8b2cc628c2ec2cc338e3d6b27e23fc1bf14fc2bd49535fd1e6b388be23b955df6f3f1d524191f86411e959fa3deaa952800032090783f81afa39ca3529f35cf0a1074ea72d8f49f8b5f617d3fc39a95bb4e0c96aa8db80c295441f29f77129ae034ad45a2d4edae90c80a4831c824f1c678f5aee6def5757f02cf60d19b9bcb1963990e376c40cc3a7a7efbbfa56669de1a7ba91ae8f9713c003f9647de3d871fe78ed5e5b69ad5ec7a366a5a753d5ae340b546b7ba992733496e102a0c02a095049f5c0fc2b2f51854f97122611460843ce3ebdabafb8d3b50b2d0b4afb758c903885700c80a9f9413fa935cede5bc4a1dd80048242a1e2be7ea2b4da3d88bbc51c45d2a8bd8e31c02fd870bebf8d7d45fb12ea057c31e3af0e670d63aab4b1a0ff9e73448e3f52d5f27ead70f16ab310148f2c6c7cf46fa7f5afa0bf648f155be9ff15751d24ca165d5ac45c11d0bbc6147fe8271f851d019f3b7c75bdb3f0bfc5bd66ceeacde49d66608c230422b1240c9e99dd5cf7867c89b53963b7b45b40c9bfe550bbce7a9c0eb835ea7fb6668d0e89f1e9d1d198ea76d1ddae01dbf282a49edfc1fad797786a609aee9e51085f9919fb6083fe15695d01d56afe6dadada5e858da6b7ba8be4604ee52c01231f5afd07f8776d37843c2d63a70984b6f0a010a0196299edf8123ad7c1fafdbc736873a10aa76e548ea3debeebf00dfbeafe1eb3bb806f924b752ae8b9653c6ec03dc1cd24975339b9597297f55d9a8e817104819e3843ae250081eb9e0e7bf15f9adfb47eb3e24f0deacda869b3a5c58452b45716e608cca00c842b2152ea064e02b0e4d7e8cea9aedb68b16a26613062cee6331fcc0100fd01c9e735f017c68d462d47c59a8c0b166de4642237192d9453d7df34932d2699f1bf843c09aaeaf2dddeda6a50c373142f710b073ba46c13c1ec71939aec7c431c3e2cd06f7c43a7450c7acd846d1ea566b8dc5870275c7e4defed9adcb7f827e3497c4d751693e1ad466d2ef019e293c82b1a6e3978b73000024641cf0707d6ba4f87bfb2b7c4eb0f105d6a92e9f6d60586e10dedd248b306e1e39366ee08ef8fc2b54ec53ef73e66d36efecd1cb90aeedc6e191c707fa545b646779c6e2c49f9bdfbff003af6ef8e1fb3078a3e1a6a171aa5969535df879ff7a65b506516c7ab2bf190a3b3118c62bcab4ad0353d5ad656b0d3aeef921f9a56b681a458f3fde20607e359b65ab33163b49142ba637139d8735bff000ea24b4d5cb3623768c88d9c1233c671db38a8a6b7b7b507cf525d012eae7073ff00ebae665b92b71b83b0dbf770dd292d41e87b6eaf147a9c51092e56331b6eda63c86f4cd2dbe93e5c208b979448c32b126dfd07f3ae3fc39e3589ac516f5b7cc06c24f5603a64fad75fa36b3633cf19b79c44ae08652d923af352d32958d0b5f0826c8e69cb4cd1925530300fbe3ef76ef55fc4d7521b582d83a859084d9d38fa76ff00eb55e5d42e61b9f32195a444c0217e5c8f438eb543c5f7b6d79a5c130511dcac80e07a64669adc962ea2d258e988ab9c01c280702bcb759dd712c8eeeb807eeaff005af4cd765497441bd9c3ede30320d79b691629adeb56b60f2b224b26c6754c951d7a57753d237672bdcedfc03e0f8f4e2d7b33417170f183c93b554f380c3907dc53ae678e5d6a58449225b44b85122825324e4161d47bd75d69a269de1bb58d2259a5013fd6487217db1c62b8fd56e6d6dbc425a2dde64a849c9e0f6c63b74ae57772bb37d146c725e330b1380920707d0fad73bb81c0ce36f030b5bde2b781a7554421b39c1ec2b98f382fde6c1f406baa3a18b3f78ec6e755bf9e2bd9c0d334fb6dee9032ab39c8e0003818fab76c6315c769ba9c5af6acd7b7722058d5d6cade67f9963c9fde1519cb36393d860752456bf893c490ebda87f61d933886d9d2596756c28dad92bd41ce40f6ebe98a96d84bfda925b408a8fb90665032571ce31dbffafd2bce8a36b8f9ad8036cc64cdcefca88b80992075fa6383dbb5647896e6e9f57b59ada3df6f0c9b247df8058a9e79cfdde38e324f5ad3f126a6c88b736aa4808c886518dd20e0103038037127d8552d3a13636af148a658e2463e6483e72ecb924e473ea3db8f7ab42386f15cd0cf79b010c61906e46c6e4e09c30fc4633ea2b53c0be174d4b57843cc1ace0432dda9fbae9fc38f7278c7a67daa1d26ce4bfbbba9eeb6c92caa1406fba002abb89f7c7418e31f5af5bf869e1a6d3f49b59ae625335ec9e7b8c60f96a32808fc41c7fb46ad2b899d7d969eba668ff68f200dae19c638c9e0fe840fc2afdb3c0efb8298180f94918045684d682eb45921e489158e3d79c8ac282e0c30179433f95805946723d7deb45a99973c43e1bb0f13e9373a76a36905ed85ca6d9adae5034528fa763e84720f35f1afc5ff00d87dac26fb7781e7558867769d7afb5f1927224fba71c0e71c75c1193f66c374263c31781b9041c8ad18e3f30797222cb191d08c903fad6b4eace8bbc599ce9c6a2b33e0ff0008fecb9e3ff0dea97337f675beab6135a4aa4c57488b37c8c55724820ef54f515e83e1ff00875a2585bc3a9eb104be1bba85c45716fa8c0449e61c050a4643af1c3267dfd2be97d57c150cce93dbea1a8456c9cb69f15c6d8653db3c6e5c7a2900f706ab7867c25a0e8f7d2496da4476f7a71b67977492e3be1d8b1c7b038f6ada55d4f597e066a972688f27f13f8797c5be1dcb44ba4c56d114b7b8d5a11109013966c1f9901f9704804fa735e0fe33f0ccba158c17d1df5ade5b4b33c08d0480e194024903395c30e46476ce78afa17f690d73ec969676ba7dcdb49349b85cc4d87d98fbaa4608e727afa715f35f9f15ce9a2de5d37378cc36cbe7b958d7a9dabc724f3c93d7a5704da93bd8eb8a691e69e27fb1699721ce0c3241cb7239caf4efdcd747f01e2d4f45f8c9e15d727b948944a2d27b55232ab20655079ce794278e315cd78d248b46bf8da478c49102630d1ee191caf5f4ec6b9ef877e3a16de268b37714d2c774970eaafbb3b181047e23ad673972ab1a2573ec0fdb7344b7b3b6d1f5d78f75c42ad16eda0e5495e0feb5f245ef8ad6478a64844512b2863bb90323b57dedfb50787a3f177c34d359cb94f3a36678fa818c77fad7c807e16e9535dc91e2675391f3bf00fd0015717a125430c7ac698d3445644c8720313dff004e2bed2f80f06af6da214962f2a392795e15c8cb4464255be9c918f6cf7af9a742f0525c35ae95014496e254b6438eb93824fe009afb3bc35225b0b68cc6624b7b64b76dbdb68c038ea33cd2eb713dac66fc43d1a0beb4bd8e581b64c1b7607dec823b7d6be19f8cbe1a8ec7e26dafcbe55b3c96d3209380aa88723f031d7e856bed62d651bdcde1850b7591b07afe95f3bf8c349d0bc61e328ec60587576b62258ee63883aa9cf76c82029209c139e074a22b5b01058c30f85bc0d15feadbe392441208c8e6253d063d4f5c7be3b5675cfc4af06e8f2fd9b51d7a0b7bb082436854b4ca08ddc8504e71cfd2ba0f15e9706b16b2e9af7251a15dc1739cb00c79cf607ff4122be69f889aa5a5d78f27d3af26612dc58aceab6f1812444471ac8809fbc1808dff000615d36b116b9ead77fb4afc3eb1deb6b35e6a5d88b7b67507fefbdb9accf05fc62f045849a8b786bc2e349bcd4f7ddac01562fb55c04c28217e556621549cf5e4d7cb1ad5b0f0ef88e5b271b70a268c762a4e0fe1c1fc315d37843c5afa469fa947736ad7da7c465bc8658cec36d2fd9dfb81dd5588c73b954d3690d23dab5af889f09bc7a9683c71e1ad361bdb840649aeac56e7c92491b1a755dcadc77c7d6b95d7ff00641f861e34d3e597c37610449364a9d2350cb83dbfd6ef51cf6045797e81a8693e32d5e26d66d2defa442ced72e555a491805018800a85c31dbd89ce0f06bd36d7e1dd88b88dfc2dae5c6817d10c3340cd711303e8ae720f23a1acede45e878b78cff6288b44b9315b78a4e9931f9443add9ba213cf49a32c0f4f4ae53fe1913c6da24f15d4d25a35a9e63b8b69c90ff0040c158fe55f62bea1e27d12d23b3d41ad3c71a4602bc577008e7423ba483207e209f7aad1da78635686f5ad6fbfb116e1cc7259ea2ad0ac72f52aa548523d314ac33e534f869aae8242dccb77063a99a12a33f8f6ae7bc6768961a44af34e8ec8449db9e7a0f5afb4d3e1f5c693e7490dd6a5258c8986d92799193f4c9e39fff005d71b6bf08e0f134124be21f0bd86ad0ab6df2a18120948f5322286c8fa8fad4f2ea55d58f90f5ad50cba1471c9344d191f2491e188e3b8eb5c169f777361aac53da49e6cb139646038271e86bec4f11fecddf0fb53bcfb2e9f6faee8179cb35b1ba53185c1276b323963c1e01ec79e2b80bbfd9760d1f54b6bcd33c4bf69404b79575028ea08c6e5739e4ff007735d0dae5b23151699e547e266bb72763dac0a76e4398db9fd79ac0b4bebed6bc431b4afe64aeaca88836e31c8feb5f41dc7c04f100d166b8874e8a48ce70d14be51271d30fb735e5117c33f1058ea9752ea1a06a3691db91e54cb0315c8ef90083f4cd73a8b346d58e2fc4459b5161226c60b8f7ac1912466e11b038e456cf88ae6392fa5f37cd8e4ddc8c7a563c76c6e373a348cb9c64819add68647ee5695a7470c005c2c2ecc5fcd1b06c5ef93eb927f127d738dab741756f65022b42cd18324aa79c8eac7b02781ed58eda75bdae8135a596d8e2819656c8def3647724e4b13dcfb75a35abbb98345756b88e0bebc431ab21cac09df69e327a28f526b851a1427bcb3d57c4b15a2b9215310439dde628392e40c9da7d4e0608f5e6ff008a23781a1f2964792643b9413f281b727d38fe95a1e1fd30695670194399b600649c2863dcf2b81d3b0f4f6a75f42d72ed77f3431336c0463063cf181dcb1fd056884605de9b0d9dab16f9628932ae89c74193efd2bd8bc372ca9a5591be71f6efb2c68f83ff002d4a82f8f6048af24f14b3dc68da947080a3c96877ab1322b30e80631c923bf1e95dbf82fe2ae8965a55bd96b125c457e23fdf4d345bd64c804904678e40c7d0552133d6ace355b70073b78fd2b84bdd42dcf8927b4b2b98e6982f9af02b67b90d8fa1ea3a8cd73de29f8afa069d6373f6097ed892a3a910c6729c101b27008fcebe6a996ee04b5b9b6d42f2db548e769a091646554624b640fe204fad1d6e163ebcb68fc9dd2464c258f3191f21ae86cef17ca193e5b11f78f2bf9d7977c27f8870f8f746f2efcc56faf5ba84bb8978de7a09547a1e33e9f957731836f931ab3143fbc8b764a9febfa568f52363a5665923c81b4f720f06a85f436f7b098a785248dc1055c6430efc1aa0dab5ad9dab4f2ceb6f122ee67de1028f53d2bc27e257ed27626def6d741b7bfd456dc37da2fadd540da3af967249fa81f4f5a828a7f198687a65eb699a434af383ba62676923879ced50d9c1f500e00af3882d20d42d425c38f35f07230b8073b413dc9c678f6f4ae4f51f8ba6f6e21b3b0f0dc7f6ab86012e2f2ec95009ea55579efc66ba3b7d2229f4969f512ee428691a3ca47c0232179c01b9bb9eb49a77bb2b63c3fe33432e830ea904d213711dbbbc601fbebd413db1c63f0af24f861e22d126d79de6ba31de35bb047551b5494e724f3ebd3d3bd7d81aaf85b43f8bfe12835791d26b28d6481a6c303222b156cf20e32a79af31d03f660f85fe24816f344ba9da205a33736974cc18ff00c0f3d3e951520aa46c5465cacfb875cbe1e26fd9df49d494ee5b8b3b59b2a73d429feb5f3c7f67892e77a212436323bd7d1da0e931699fb34e8fa7c723dc4767a6410ac8f8dcc11540271f4af1bb3b5796e19b690bdaa91256f08e92efe2cb2990855b193ed729939e0761ee723f5afa4e3f0f5beab6f24ee9b8021964dc54ab63b11f5f715e17f0fad669fe245de9b1e185e5ac7200e3ee90db4fe8335ed5a9c52681241a4477135d5bb261b270471c018c71c639c9f7a1e9b0ae65f88841a8583c21a6168a7ca9195d9bcf3fdc039047a9c55383c3b6da24689670a42cd80c464f1e833dab6f4c82e0c12ceeb025aae5618c12c4e3827db9f4f7ac9f10eaf15bd8dccc6544651b465803b88ff0cd74c63ca886eecf18f1edd2787f59b8be8b2d24d825dd8951f32aafd3824d782dc7875bc437ba4788a64965d46daf0ec70ca034477a9539e31b59b03af0b5e87e3ad427f10df69e8d686dd2e066e700842c38ea7a138fc80ae9af750ba4b45b3d33484b18e0c429768013263ab6377fecbdead38af88e5c42c472fee2d7f33c7fe287c0ad4fc69a9691a8e9a6d6c8ae43cb7970a81d0800fcbcb1c60741dea0bcfd98fc45a0f85654d36e3fb7754bb6d92269cc2358e3033bb7b60e7a8f70c78adef17f877c4de28d6a25b5bcb782c5149dcf2191de424658aa823030001dbf1ab1a6f857c7be16bf11aeae92408d968ade2754047b3043c8ebfe4d73ca715f6ac775385471575a9f395af832fbc2da9496d768f6b2ab7cde744c083fdd61d6ba54f124d6f69e5d979c97299e117729e73d883fa71e95f40ddcf7dac016fa8e870ddb282a66bd9e394e7f20547d0e7f2ae3a6f863a1b497371750c967296ca882ecba0c672394cfa77ac3eb34a2b591d0b0f524f489e6ba57c6196c2078af24ba598b658487746c7f000fe18aecedfc4367e35d52ccdd5d892d5b4d94cc609880f30185f97072eaa49cf1d47a55e93c0de1dbab768a1d2fed4635f3657397daa072c7247e95a9a2436366a90786fc3f04ae559898e23bd703e623be31d7152f194bbdcd1616a763cbb45f8bbe20f0c5cb45a75f3c5e44984b748b293a93dd4e554f4ceddbdebda3c21f1f63bc751e24f0f5cd934d8df73691968c1e392a4f4e7f8598fb0ae6f5cf1c4b2581b1d88612e30cb2333291d7233f4e3dab0353f11d85ce99656da5e9cb06a9148649efe401b780090003c01ebeb8ac258fa6b5358e06a6c7b8deea7e0eb459a66d42d98ba799e5348acc464f201e40f6f6af35d57c57e07b5bcf34b4a244727030030f6cfad797788fc4373a85a3bdddf665394f29631192a79249500119ec6b84090c8c649b2e98e7079ae7fed1e6da274acbd257723d79fe25d8e876724fa3ac90cf720a4ae939460bcff73a678f7c83f8668f8a977a75945325fb095480035a8998819eacee339cf71f857964f7ed12c66d152071f30ea769ed9cd645cf89ee9124594a36d6f95557a1a3eb751ad07f55a6b73d5f52f14dbeb71c53ea31596a4f3b05367a8d8c6e0827b0db91f81c5701e34d17c0f67e25bd82c742b8b748db6c89632ed8bccc7cd80c0e3d3838e2a9787679b50f14696b75292f25cc6a431dbb7e619cfd3dea8f8af5f9ec35cb911456f279cc676778c3125893d47b62b7a55aa4f7396b51843e13f51b4749ff00b4a59248fcbb55625164624edc0258e78e3a01eb5b1a55a2ebd2c977222319976c01c03b50642e3d09ebd3be2b9e9ffe4177ff00f5e47f91aeb3c39ff206d3bfeb97f515d079aca3acddc97f7f6f6c92a132208e5cb774c0761d87271f5fa1ad7b1c2db496c8f848ff0074a4f73c6307afe3581aa7fc7dbffb8bff00a39ab7358ff917350faaff0031568661de5ba35bc36d1b6de4cc4af42e4e00cfe679ae77548dd67844a89bb798dfa0db827391db903f2adb7ff8fa9bfeb8c3ff00a10ac2d5ff00e3c87d7fa353032753b245458d8c92fda9caa220c6d8c771cfb0acfd62d9aeaf16dd6131fd9426e18c93bb279fc00adabcff008ffd2ffeb87f5accb3ff0090c6a7fef8ff00d162981917d7d75e1ed574ad674ff323bdb7b88cc9e41c34899e54f3c82320fb57d0f7ff001b7c3696a6ead1e79ee36636790c848ec0970077f7af9c3c4bf7ad3feba0fe95a917de4ab5b13b9b5e30f1dcfe25f365d41c5be9ccd986ca4c7964819e8402ddcf3c0ed5e4daff008e740b8f36de3bd8249dbe511c2c36119c6dda3838fc6aa7c78ff576dff5c24fe46bc0352ff55a67fba3f99a49dd9763eb2f057c2e9a490df5f2470c8b868ad170303b03e99adff89be096d4fc05abc520fb3c50d94b202876ec21091c8c1ed5d1e91ff1efa67fd705fe95d0df7fc8bbae7fd79c9fc8d652931a47c89f05b566f855776cb0c5749a65e4c1f553712170d185215a140a029c3648c92768e98af515f8796716a577e28f006a3e6699a9b7997da6a1fddef23fd620c655b3d47d7bf15e78dff1e23fdc3ffa15779fb3a7fc8575eff757f9b54539b6eccb9455ae7d31e1c9767ecff670b6edeba785f9860e46073f9579ee8f6a1ed19f61e99ce2bd2a1ff92663feb84dff00a1d70da47fc8097feba7f856b7bb3166778466974ff8bde1f9d10ac0d0cd0c921c7de25368f5feff00e55e96f76da96a3a8993cc130fb8c8d820e718fa723bfa5799697ff251b43ffafcff00d9057a1aff00c8c3a97fc0ff0098a57d45d4aff106cb7dde971c779736ca2cc095209fe52fb9831208209cf7ae2afbc1fa6b5d2bc91c724ecbfbb927724e7fefa19ae93c51ff0020ad13febc87fe8c35cd0ff5d69ff6d2bceaf5aa466d5f43d7a34a0e09d8b1f65d3741b7748bec62671f3c623dc1beb9ebd3f4ac59efcb3246d3ed841188d13681edf952dfff00c7ebff00b87f9562dc7faf5ff3e95c552729349b3ae9c22b5b1d0ca216b6600aca78c038c81d3d2b9dd5496de7cc28a3a719c62b76c7fe3da5ff00797ff4235cceadfea2f3ea3f9d7049eb63b23a1c9ebd2a198cf218c38392621b01edd07151dbc02e230c2233a8e486e171ef9ed51ea3fea5ff00defeb5647fc8367ffae67fa544dbee6b138f76bad435d96d2dcae9ef31f28792a761563b768c76c67f2c77aa3ac786750f0eb5bc6f7b6a45d170922c9f2e17aee047ca791c7539af5ff8c5ff0024cbc03ff5ed27fec95f375d7dd6fc7fa57a6e9aa74937a9c719ba937d05bfbe12490f9cc1ff00bd1a71fad5058e33236d4e0b67e624e01f5ef52afdc6ff0078d416ff00f20e93f0fe75e6d476499db15ad8c3f10c0633210847a328e2b936b9b8877849046b8eb5d4f8bffd747f5ac74ff8f55faff515749bb0e49230491e4809362527f8ce17f3acdbcb678a366902ef2739f3148ce7eb5bf0ff00c842dffdd3fce9be3fff00511ffc03f9576c56a71cdd915fc169043af1bcbb93e4b68659088dc6eddb0ed23ae7922b9bd56f62bdbd926dcb86fba0f503b7e95a1e0fff008f9bdffaf597f90ae566fbe7f1fe75ea518a48f1eb49c99fffd9, '2017-05-31 21:11:58', 0);
INSERT INTO `projects` (`project_id`, `project_label`, `project_title`, `project_description`, `project_creator`, `project_icon`, `creation_time`, `project_active`) VALUES
(5, 'jjj', 'tr', 'tr', 1, 0xffd8ffe000104a46494600010100000100010000fffe003b43524541544f523a2067642d6a7065672076312e3020287573696e6720494a47204a50454720763632292c207175616c697479203d2039300affdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc000110800df012c03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00f6ab078a6863567684fd700fb629d7376f6c41826c018cab0c6ef706bc7ef3c53aadc5b43e5c9348ec543045f99fd7a77c739f6a35cf135ea3d9d9b34e888082324124e3193fe7ad7d4bad1dd6be4798dadac7a46a9e2485c28b4656b8248f99b38f422a8d9ea9a9994492dcce8cac0ab3cac1830e84018e9f4af29b6d6e7b7f3a799de34dfbb79195cf7c9ec3a7b53b53f14ce1e33f68491a6932db79c0ff00f562b9ea63e34ef1b6a47b3bead9ed9ff0bcf5df04d9dc1935fb98d277058dd7efbcc38e31b813dbb63a66aadffedada8cf6cb0c1e1dd2a71b40692f03bf9adfc44a861c1e7e5f7f615f30ebfe286bad5e48de7669157cb5661f7540c003ebfe7ad6f68fa126b562ccc46d40bb36b724720f1584ea53934e71b5c14a71bc62cee759f8d1ad6b13badae8fa4239890855b77c20c6490776467e5eff00c02a5b7f1df8c2e2f5ef45f43646690487ecf108c0cf6da3f8471c1041e2a9e9da3436166a2278d49c92c5f121c8c7514d98c96513235b98cedcef19c7d3383daba69ce0b67b1949d4912fc49f1c5d6b9e13787c42b1477d6e7ceb49a103e760707181f29209c83c1e08e9c72be16d46da1d1aeacd6e7ca378d1bcbb17208033b4f3cf27a1ae5fc7dad4ad7b1404ec783b13b81071807d88fe758da4ea4cf1a08884933fc1c01ebf871fad15272a8f9ae542d186c7a7ff00c23c97cad279e421c83b39218e782de9f4a44f07c811009d412540663823af5a77c3ed4e69a2786ec452430af94ea49dea1f73ab63a10bb790483cf1ed7e6d51d6674744886400be87d31592ab6566b5348d352d6e2c7e109b4dd3e4b8898b3658b479ced1920743d3fa629f6d7777631c100c490a9c8576c8c64e073d396e9ef53e9fe26b4d3adbca9da495cb9385ce013d87eb562e3c516305bbcb25b34d0918591181233d0b7b7e3571a89e80924f72ddc6bb6b6502aa20332395787aa6338054e73f8564af8b678ae124b8971b643b02ae303ffaf8e95c45f6b334977741a579583970d8e724fcaa07e1545f5217ef927cb66c7998ddfbbec411fad691837d4ca534f53dba1f8902e63b3d90895012d32b3927238fba3fa57556be29b4b8b3596d63876827309e0373ce09fe9eb5e1104f0c364ae8435b23fde099600fafa75ea3fad6ce97aa4261922c8c972324b103a7403ebcfe35509723bb6ec36eeb43d8adf5b9e4909788b33fcca14103d78c719ade975cb6b4d3a39af619e1c48515a43940e49c7ddcfa57906a1a95cd9e9f14b633c501db825c9c023d38c1e3f5a9ecf5dbcd4f4e8a29b51716eadba48572bd48e7eb9c9eb5a54ab192524cce2e4b43d16d75bb3d626905982be593b933d707a8cf6a93edd06e79ae232f1a83bb191823a579ed9cb6fa32caf0dddca472658bab0c95182474f6a9f49f10595ecd13090b794cc59e7fb8c0720153c638c631dff29facc52bad89f266e3f8d04de6be152104042490c4f3dbf0eb5c85f789efa693c996f9c24a3023563b71c75ad692c6c6674f3a4599760fdcac22355c7233b47cc79ebce71d4d5b1a769f304052359146540192060f6efc8158cb1b18efa872eba19d69e27b8d334fb68e363218a5cb492648c1c7ff005ea6d435a9f579646cb058e42005dd8c74e83d38a9d2d2db4e3e5b3486062ac43302539ce31c1f5fcaa71ac076f2c6d2e3070a72a79efe9dcd63f5cb6c8a4991e9ba6dd1dc924688a0719009e7f0c1fcea32f36961e345026ddf2c8ca3e5cf3ef57a4f1398a1c905c632c71f747a9278f6ff003ce7af8aecafa09a350556424ef118e1b9e99faf5c567f5ba937aad0d231b1674fd767fb3f9464b6fb796c05c9f987a640c66b2a1bbd5752ba7549d6538c30b7900000fca9ba2e9da7d847e74b2b4c448194838c277c8f53ec4d423c3f1e9f70874f6b8925b846550c768070324f1903907f102a5d78a6ff00c82cd15bc4d6c34dd399b51b97948c3f948031539e0963f4a9742934efecf5657f2f72fc9b86e6e832073fae2b33c6b690e9b6315b157690297964c9c37214139f5dd59b616d717e61312e0bc6ceacdc7cabd47e600fa9aae7e6a6a4d97b1e87ff0008e4771a79bb0eee8f86511051c7a1c0e3a1e6aaebb7771e1bd323b6b4b790c8eecad285dc40eb9ac7b7f1718912dd2575d8c4a0739dd939c1cf7fe749ac7c41ba8ed65f92de4f31586e03a755c015c3cd5b9ecf5436d58c37d46ee571713066691860b9e800e2aee8daa14ba595824a809ea3e5191cd56f0c6993ebb1b5d4d65bedc3b129e78841f60483d3d306b6ee961b4b26861b008ac37ac85da428c7d791fa7d715bcabc5de3d4a51764dec37c43aecd36a052d4318514e663c0248e00acf16b3a45179922194a06712479209e71cfb62a4815b4fbb85a5b889a685fe511fcea4704641f71fcea6d474692f2f249d2f07ef4ee2643924f73582ad187ba0dd8f3fb3b89f5487cab59669ae60706452e460804f19391c93ef49757bf60326a13a49f684e259949c0c600c9efd00fc6b88bbd72e749bddaf6e274f3bcb8e4b46deee7b7a761c8a75e789ef2cd225dd208f1808581c03d981e39e735946ad49fbb6dc973573a49bc54750b46f32e8b5b4872a849c30c9c64fd7d7d2be86f85dfb1f78b3c7fe13d3b559352d374cd32ee2125bf9aef24ca87a1dabc73e84e6bc5fe167c10f1afc5d849d3b43367a418da41a85d298edc8071b43918639ec39fc8d7da5e00f18defc37b5b5d2604fb469d6b1adbac20e06146d18cfd3dabaa9612556326b747453ef23c87c53ff04ecf11dadbbde695e21b2d4eed39f2191a1671e809c8cfd48fad7814f6cfe07d5aeb4cd54fd92e2da4314b672ee8d8303828c3939afd3bd0be29c3ab0545d36e564fee9e4d7cf3fb747817429ec342f120b58f4fd6eee56b7967dbf3488132a5b07aa9c738cf38cf02b2ab19af76aab153a71b7340f9750a5f389d6658b6843b77fdfea79cf39c1ad7b9f11eeb2b84b69903c6a4a7627afca463a1ae4f54b15fb1ee37bfbd48c299140c839ea50727a7e95cbea57b2c1244c3748108db70b90b9c64f0707af1deb99f355495f638a5370d59cedf5f49a8dccd24a417918066cfdefad5cd22dd54288572d197264180a5b0323d7dc74ebea29ba92d9dc59b4b6b19593cdf9c16239c8e3156f4ab022ee4818ac524831b09c725810464f73fe3dabd3552d1d0ce936df29bfe139dacaf6e0ab955450c70782793cfbff5ae973249f68f31bcd132931760a7af3efdab9bd5f489ad1ee05bdd89832aa80b22ee2a3d06727f0abfa2deb6ada7cfa6b6d8af620490d92c831f7b3dc1c007fa62b072f6caf17a949dbdd1e90ee8d4df2f91e62948581e49c75c7f21ebf4acd3aadce9ba688b502c8cef901b86201ee3af3459db47713c4fa9caee6dcfdd524ee1ec7dbeb5a4de108b55b26943246cacc5620d92fc1e39249c7f4aaa75545da6ff00af2334ce457c44d1dd2ac88a03700607e74e9ae8f9ab3988c51670482486e3a75ff3c552874abe9b545b68e292585c863b1867f3ad1d53c2ba9595b736ee9b095c48321b033907f1fa735eaaa94e2d2bee249b3434d9fed36b73023041d51d9f2307b1f4e33f8d6ce9dac0d3e5b7b65559d4b7dd6208c824100fb8faf6ae0ad1ae6297ca6220386e7b31f4ff003eb5bbe1992e92fada2587cd70f91b4ee38ee4e3a539a5677638bb1ed961656d7560f1dc279b6e7ee2c278ea7ae7b838e87d6b93d76def12e9a1b585fecca369f2ce369f7e7d05751a7476b616113dd0912352e8bb65cf9996ddc8c938e6ae7db747bb04ed90baf2aab2707b6702bc58e23d9c9e9746d350e8ce73c3b6b773470db5d45e50dfbcbb7451d4927a723f9d583e17960d48edbb59acb048563b4f5e41c75e3bd5cbed55bc98eea3b9051c11e54aa1417fe26f7196ebec7a574fa6e9b13d9c563a65b2dd4f28565f29773b313c8d9f5e9ec7b62b3a98a7177ee25152f752d4c9bedc23882dc2ac8ccb94230a463208c723ae38f7ae6b54d46ed668d2194b46088dd421db191923e61f29c73cfe35eaba8fc3dbab03f65d4e6d334e91943c902c8649932070c106d1c76de7afa536ebe0eea163a7adce902d755b193132c701c4c7207456c027923824f4ea69de74e9c6ace3a3dbcce88e1ab55bc69c6fcbbf7470d617b7a6d1926314d8906ddf261d47af1d7b7e75673389d21fb3e259240aaccfc01fa639cf27a62b2a6d5a4d16e2fa08ec079d1b66513dbe1b232392790467f5f6a7beb2d776e91b249b9d524c89368017f84679e39fceb07277bdb4338d915f56f112c134b0cb26064a991795fc3d79ae5f569a6fb7f956fb59444d23991f6a8519cb13c63fc6b7b50bcb1dec6e6de7920ced68f008071cb6339c9cf51525ea5a6a16725ac717da44604801c2a91fdd63d4fd3daba615553b3b113bc8c4f0c788165ba2c649e611baa71c8039ea7d3af15dc6a306b4774a26b454461187c90e43027b73d87e75ce456f6566316f696ca4952541eb81efef52c733ca97125b995d6421e4849c05183800f03fc2a6ad5551f3455bd41292564696ada08d5adc446f6292692345123aec545560c4e00e9ffeba75bd95ae8d1c48f70668c6f00c457e5527af39e39ce3fd9ac1d37589b58320b7965c6d78c959001d31c7e7ebdba52c52cd6b6f269f2c92bc848036460a29c1c67eb83ce4d734a734b91c8d15df43645a69b6167732dc9b6576914c72ca3e65279c9ea4e401dfbfd696e6f3c353928b736d26768dd8c9cf19fccff9e6b89bad0ae6daea75bb94cbf6998ac5118c9cf00e403dff00c2b2355857c23669746e1d6476c08c211cf7193fafd45542319cadcedb626a71d5a3d8342f106951e9b35a24b1c81c845460154a82095239e32011ff00d7ac946f0eba484de2ac8ae4070e50e7d00e9fa578cc5e3b9632c63944258e5b671cfbfad4dff0998d417cabb65b88cff7ba8fa7a7e15b7f67d9b6a4f52934d2bb3bbd4f5bd085c974bd0d74a588f9303233d4e7d3ff00d55a567e27b35b75f3678e494f2db40c03e9cd79c58785c5f2f9b04123b16dc19c6176fa8ae960d2eea2823592cf0768c66104e31c738acaa420972f36de8691a72dce5ce87a769376a9a9dc5d0f306cfb55b4598e26ece573f3639cf39c73dab8ff0014e837135f3da4291499502dded5be5b862dc301d79009c577d6d64ba74d1bfdacc6912b61ada2556723e601fd7afdec67a75c62b2b5f582ee5ff89718acf7388d628519bc85392cc08c6493cfa75f5ae7a351c67cc64e8cbb1e93fb387ed41aafecf7a05f784bc47626f74dbe90bc1243721ee2d89e0ed41d54904e370c127839af78f0a7c72f87be32547b5d6e25998670d8127e299c8fc457c3107872e6d2ee7bf9ee567113301b63c90a0e41e4f5f51f5e6b95d73481284b8483cb572497ebbcf5cf41cd7d161eb36df2bdcd60e7cbef2d11fadfe15f18583943078ae18e3e843cc90903e8596b4fe2cde7c2af19f83934af1578af4d89a0064b7b817c8d3c52631b95413bbe9835f90da369da83af970dedcc68dfc0933007f0cd6b69da65c69bab412b412b9940db3c81882f92303b7a7e358e2209bbb691bfb54a37b1ea7af58d8f86b5dd4059ddc5aac48e4c77e8362cca090adc9cf23b11c53efeed3fb4e1592c08768c3ec9e2e4211f365481f4f5ac19bcf891a6b383798230cee58b84233c107b67fc2b76693c5777e18b6d63545d423d26e31f6337b03aa4ff0029c18988c60283d4f39e320579decdcd5e3a99c214ea426dbb35b193aa69ff006fd22555b3860944850791c1db9c72077c7f3ac8b2b441a92af204b8de180da3071c1ea31b412d9e82b492f6f22d0aededa38a59446d348b2e03281d70475eb9f5a7e9da9bb4522ae9e9790dedb2ba98ed834ca43061e5bf38c90d904e1bf95d3bc56bb19d0a13a9523cab73a27f0f5b4b1ee9259087731c01f6aac64f3939edee3d2b9fd17443a66a6d74f14b0dc42df30ec70307ea3e6cd57d3fc5f7afe11bd7b999ac678246812e1140cc80719c90170075079fc2a3b2f135d6b7a29bc795bed96ac0cd1ca47ef149016453b8eee98607d41e41e33842aae6d74467568b824faeff0023abbfbbb010dddf416912dfc5110d94055875e847ebe98aa3a6eb9ae4d682f4a0b89d83116c5006886010dcf5c8cf03b62abd94f7ba5e8d25e2589912dd7cf90bc3b97a8e38ee4678fc6ba65f076aba8456fae41670c76d7ca64861ddb860b1e0004e0f51cf3c77a57e58b93dbb982836b99b33ae35eb2b5b6818a1b4bebbc2b08554291cfcd9c7b73c8eb4db2d6f50fed9b90b768d6aaa320827a8e322aedcf826feded2d1cda3dcb4b711a35bc499680c8c1172dfc3962839abfe21f87ba8f84eea6d2357b35d36ebc9f3a48e52cb9ee0e4e33c0c0c1f5f4a8738463cc9dee6ce0eca5d09a095174f8daea5b66303997742db533f30240038e339fad6558f885d6795dad17664f97730a0db229ce15b3ce327de974c02db4d22e6fedf6e7060917783edd0fa7ebf5ad0b0d3219e187f782dd65caa88082b8c839e4f1d7a703d2a1558a4efa8ad7dc8e2f19389a58d8431c9b70bb22525b9e7391d7b74aa64f90bf6859983c7976da461bae71fa53ef5751f0ca5f6a1a6ea32595f5b90a938508f24648dc14b679c3751e9ef5241a643a9cd22eab70f0ddc96be7ef0305c9c8dc78e8c41e9d0e41f5ad7daae5bf42e5454a1cd7d49f4f965ba30bfcea37094061b5704e41e7b1e9c7a57a9783be2c685e03d3aecdb584973ac188eebb91d76a9c70839e1738ef93fa0f15f04ea10fd81a6b8904902cbe5c8eb8023f947ca4e3afb7b71d6bb8860d1b4d59512c52e9482634ce77391c0eb8c1cf715c75d464f9249b3a30f52a61a5cd4f7b11dcf8ca7d4649eea4965b89a572ece580de48c939cd7a3e81f176df46d26cb4d6b3bdbd961051a4b751b48c9208dc41c631dabe7ab9f8bf26abe1ad5b4f7b6b5b2b8fb305824b588290dbd415c8e9f296eb83ef5d3f87b51d7fc4de088745b2813ed0fa7ca8d7324c1597d0124fcb805476ed8af47178cc56260a9d54ac9edf2f2b69e47a742788cb2b3ab85d6e95dd9b5aeb7d7cf43d2be2ef8a3c3de24d31b5292daf6d353b50ab24cd000977192000d824ef1c60e391d7a035e6da1d8cbe29b4966b794bd9acc63d9331528c31943e98047e75a9e39f00f883c27f02b4ebbd61ad65b6bbb94b2448e62ef14a0171961f263e5c70c7927a741e6bf0dbe20c1a689b48d6a390196672d24407c8ca369638233d00271fc3c673ce74f0f5a54e4a1ac97e5fe6799889de4ea4a29393f97fc03d460f065c1696392e2ddfd1549675c9e3d335258785acadee4da3ea6d31e923227dc38e993919ce063af3546e35e974dd29dd2e845124067f31c02caa0f4e0678e3ebf8d797e8fe2dbdd35ef218e595964b92c8c4965c03904f3f29ae2a31ab5949f35ac254a7bb47bec7e1fd29a35b633c992ac32e9c81df27b7de1d68b5d0b40b7b3df6a8af285dbe4b4814fa72a48cfe3c578b6bbafeb3632586af0ac9b638bce0d216c46fc704fa818ebd08cd6c69bf16755f1879963a96a13de40b8313cd9721cf3846ea3a1e2b09616aa8a9f3e9d46e9351fef7f5e67a63d9e9fa35b19e68a0b2891c020e067ae7000e79535cfeb1e2e8b494bdbfb18a2bb92da22f019d5b0c406c6f5e0e086e9ed51beaf7b1e906096e2329bbee4d2aae5319032dce7a7ff005fa8e6f52f1bdbf85efb74fa709ff743709cef8c2b60ed03278e9c1e6b0a71e69dd2bd8e8c2615d59c5ce6a37eaf6477be18f8d1a9f8f3484b1f1258d9c7728ccf11b5998646dfbbb1cb1073e87b6315e19f1e7c6767adeaf0d8da2491fd859d242fc02c76f039ed8c55bbbd4347f1078874cd534bb18f4eb9827479e0b72c96f7116e190769f949191c7507d4739bf1f3c19a7681e2df3f4b5963b3d4ede3d4238a47dfe517c87404f24070c0679c0af5284a97d694aceed6dd8d736a55a9d671ab352765aaea8f2a372dbb8638ab9653b191416e09eb9e0541fd972b02179ad3d1f449ee2e6ce38f969e511edfe26cf40a3d4d7b52adcbb9e1c61cc7ba45aaae9d02e9d3dd931db88a3578fa00aa14f3f5ade875bd0ada248a4baba1228c3178873ee327d315c37842fafaeef658b532f69184223134679607a119c8c7afb57497de479c0048ee7031bfcd55fcc106be4abd4b49c7a9d6e9c9c76660cba725f69b6d7b636d771c52c26222e59bcaf3769e848031c03c71d79f4f67f831fb3d6abf183c1769aaded9db78434d790b457b202d3dd01c3158c7f0f1d491d38c8af0ff0083be0cd5e54b47bb9123170cde5dace1d158ab0c8dd8c02c074e2bf40346f12db787348b8d24ed8a28150db46bd1405f2c81edc2d6d9855f60ed6df53dec55779751f7546d56fba4dab7e57bfae8729a6fec1fe07292c7adebfab6a51baec682ddd6d22233ce4282dedd6a7f15fec47f0d60d155346f0da44b12619ed2ee55b823fbdf3332b1fa8af525d6fedb34bf37c8c4907f1ae8f4cbdcc2b860081cfa578cf1f5a36b3b7a1f38eaa9f91f23a7ec85e10b8b981f4ad4752d3095017ed16e6e637603a8601393e95d9bfec4f1df69112db6b686441b962b9b2d8993c9e773301f857b07f6a41a2eb371776a8a600f8beb21c85cf22541fcf15df596a51ce8b244e1e1700a907b553c6d4ab65565745d19737bb52573f2dfe3bfecd3f16345f105be9f1f86e5974a2c552ff4e9035bb753f33e46c0067efedefe82b06e3e1a78cad443e0dd5353fb2add2a5c25ec523dc5bf988094438236918c671fc43191cd7eb4ea5aa25adb091f063dca181e4104e0ff003af9efe3dfc06f0ecb1dcf8b74879347d42d4fda2e92de5091bc6bcb3e083803a9007bf07afa71cce518f2c24924bb5db7f7fe8775254e1351e5e6e6693bcada3f97ea8f89bc57a31f86f7d0f85fc4a90c1e205420c8accd6d729d55c1dbf32be57231d8820118ae5b50f18b5e4f1e8d6e9169f65a7c5986480b4493ed2cdf3038c0f98a92073b4706bd43e21ddd8fc42d5e0d26e85cdce85a6a9bad2f511005781a420344e48532441d5f0c36e0b81df8e8f4ed47c25e3ed3f41d363d3b4a9bec36fe4fdba3b4f2a68643b8387e06e208041ea4752735aac4fb2c3fb6c4475ebf3f2e9e9d363dca31ad187d5e93f35b7dd7b6baec7ce7e22d5af353f0f4739b7b54811f24467761ba018cf20e707ea2ad68f1b4f1416ffd90b17d952385d8a9c33b31572d83dcb0c71c007b0c0d3d534b115eea5a04b611c6882550c06d3bb7fca0f38ea54f14a2f354b9d0b50d30dddcc1756c5479202334a17e76d8ddb6819c752370ed83df42a38d3b2d137a7cce3c47256a8a5be9a93f8a7579ad1ad2c4c4628638cc73491295df2ab29751fc2400a3b67a9f435bff000fbc477936a96c34e865fb17daa4825b595de454490168ca8c70418946e0403c74ae2fed8fe29d0ad6cf51d7a449c399bec7296cc7c72c8c4f391ce001d0f073cf79a7aa6a7e21f0ee9d6898bdc0954c6e017487990ee1d495395c13ca903a9aba98854e97b06b4d4e0584524e50b7f5fa9eaf6ff117c45a259c3a2e8de173a9df5d3bdc87b82b1db46d80033679dc0827ae39e456efc4f9758f12dc68efa8e8eba4ea234c8e29606b912a160f2fcc4ec039c03818fd2b88d77c676bf0c34f7bf31cb78646da900600fa96cb76e0741dc574fa7fc70b7f8afe1ad32f0583594f66cf6eecaeac5c360e36e3e5dadb8e39e18fb579d3abcf97a71dd7f99c69de9b394b6f0c4da75b379961023f9a02ef20a919ec3b71cfe156ac3c257d06b57376d02af9e9b23c92842f5c0da78e7af4fba2b27c65e09d6be2678eb42b2d3b52b6d1ec45bf377765b1010c4b31503272368000eb8071d6bd1fc416da8f8421b2d3efe1123451aadb5d101c4ea06372bf46cf1d3d7b74af3aa49c694649ddcb7f23492e5a4a5bdcf05f8a1a7df5bdfda492ac8b0dc4c626529233464a91bb6a86620853dbd2ad68f697c6c5d1efeda76680c49716659a2994bac996dea3774fba31839e78c5745f13b4d1e2cb1d3a1be95b4d8e0bd594dda80c64ea32303b64f5c75ebd8d7f83f757569e1dbdd36695264b0be9a295a450a55d4e19876c641fd6bd186352c25a3f12fcbf23654ea7b1f6c97ba703aafc3aba92d6c2c2f2f63d394ea0d70e77329747da0b0001f986dff689dc076ae8f54926b3d3a790cc8d222cca8a33f2f944a31e475dcb807d48c7ad3bc75a35dea7e38d1b5a83c4767ace9b222cbff12e997742aa770564272b9ea090339e3d2a2bed16c7558ef05d5c4b7cd2ddcbfbe4b870e18b6e70dc851cb0e00c75ee79da788b72fb47a9baa129455439fba6d2eefc196496b2daccd3ddb34788c099061cb027d37633f87b547e1e83c776fe0ebc9b49d397ec9e68826926557690ab290501e48e4648ab5e3f78bc2de14f0e5e68d630cd6b1197cc8558ab42cdb54bb06c96dc476e38edc56c69bf136f6c3e0bde6bb059c31ddd95d792b6d216319dcc996619041f98f7ed4feb135c9522b4724b5f5b1db88ab461865052f7fb79361e2eb2f12685fb3c6a173aededdbc37da9dbdb4766a4848180675971fde6cb8f4e07b63c5341d54eafe26b649d49b9ba963b62c3be59541c0ee475c5763aff00ed17e25f18f80356d02fe3b0b5d3eea6b66ff4785b2193cc232cce78393ef59df04f418bc45e30d3d5e44945a39ba2a8dd4803603e9f395afa184a3428d4afdaff0091f2b5a5ed24a28fa6efbc23a7eaba35dc72ca618cab4ae547dee39c839e703f9e2be6d8a1b3b8b187ed3e607fb4090ccac7eee4fcbe9cfd33c75afa02fedf55b5f0feb5142ef1c91412f951bb01e61d8dd33d47d3fa1af9c6d6e088d34f98792b1b132176da10f3bb3c1c77e6be432f9cb967ef5f547d664f46155cdd5d5247592eb3ff0009ada5a34701b333c33412d9472bf945812a1f00fb8f947f77debd63e07786bc3765e1b7d346a716ada9ab492b4520531e0a6d718cee04603027ba8e39af9e35cf18dbe8b35a5bdadc452a25af92f258c99f98bb336323d085fa01d0d7a0fc10d45acadaf35f167732c7836904691fcac491bc838008e31ebd6bbb1d4ea4e8b8c15bb25dce2a73843992d5d99eaff112cb4df0ef83b52b886ce36711110a8857e572400c33e99cfe15f3bea5e06d4af2d748bc84de5fbdea9674d858aaae146481d721bf003debd6fc6daedf789ac3ec2da7c9a5c0724824b33f1d3270719ed5e81f016cfc33e37f13dae857ef2c3a7dbdab2c76b0cacb22ec007de1f5c939c926b9b051ab87a4fda6ece5a14925696ad9e2117803c53f0a2db4abdbfb7f22cef5a49a13222b2cca36928ddc104f23a8ebe86adfc5bbc1e3afec7bdb58dd5a3b44565c7c888406503d3966e3d6bebef8bbf0bbc343c1a967a4c734ef6d235cc16f3dc336ec8f9933d4938c8ee4f7af91f5bb981a011c01638631b5624180a0718c5745295e5cd2dd1ea639d29d2a718ab4adabef6d11e7fa4f877cd98a3b6d3f4aecadbc251f860daeae61f3a6b7cbdb4fb494049c8f6dc2b005d7d92e4b8e307a57b6fc00b7b9f1f7881ac2dee459dbc11896e643c80990000bdc927f427b5754ab28fbccf115073f722f72b4d2e87e276b41e2c5bbd1fc48ca364932796b7c846559b7721f91ce30d91d3bdb3e0cf0d40c637b2bf661d4b14cfe82becb9b4df0f5e69b3787b54b1b5bcd266856ddece61b94478caed3d46091820f18fa57cb17fadf8722bc9a0b3ba92c2381da136f249e6152a48e19b92381d4935f338d53adfbca574faa3aaad3ab412509dce67c11e255d6fc51a3697752cab37da609e1b8b50512e13cc190e9ebf2b67b7d2bd93e26a4f6eab77031dd036f3feda646e1fcbfefacf6af8b3e017c518bc2de3fb13ae3de5b585bbb820a89593e560aadc027048ce0763c57d86bf143c25f10b4d922d275db1bc9d9770b7f33cb94f183f23e1b9048e95d99c3a9ed20d4745f70711e3278b9d3a8e164976d373b6d03c4e7c98dcc8190804107835de785fc636f79a847665c8924c8191c1af02f095f6ff0d5aa2481fc9dd6fb8647dc629dff00ddae9a0bf7b07b4b9898acb0b8707e95f373d6e8f9d8c9a48f45f10dfdce9bae1b889374aa3cb7463c30e983ed567c2de3986da56b67630465b0b1ca71b49ec2b37c797f1ced63aa439f26f610f9ec1b1822bcfbc428b7b617014e1c8deac3a8208e6a20eeacc1e92d0fa1f58d463bfd1af230c55fc83b94f1b0e320fd3deb9af0d78853c51aeea71cc04d1795f6678dc71c92483f5e2b93f86be32975ed392d2f1835eac4d6b2ef3f79941209f665dbf883e95e63fb3af8f607b7b8b8790c915dea0d720b7500cae38fcc7f4a76959bec3ad51a7195cf9f3e2bf85f53f04f8fb55f0e34d71a6436d7f2476f7982c2e6d1c23c4181fbc320739fbc1bd0d7947873c6f7be09d56fad6631cb6e65603276e0b74200c9ebefc64d7e8d7ed3de14b7f897e028adedbece755895df4e964e1cccb8222cff0075c12becdb49e95f9bd7f610687ac6a516ab6a05d288e3759586519b63af1cfa0c9ed9afb3c1ce1528c7add6a7d55294a749554fe7fa1d8fdb26beb89f57bad31961c7d9e696e810cac0e3a2e1b7021bae738155f42bf0f6f36bb2463ed50e65681c32b23aa1d8e0f752475cf5233c5635e43abc9737d6779a64d148f6c75199da5f3596203702543101b0dd3a8e9c60d52d07ecdf6896c9259a1850f9d246f86122f420673b770620f6ada7cae0ecec91514e9b514af7bfdecd5b9163e3db8b786c2c74df0feab6e5a58efb7ec8a42aa5824858edf9881838e0f078ce32d6effb52e6dac34e13e9d2c52993ceb3c9319eecb8392318e07236f7c57a66950786ee7459b4fd1b4f96d66d40c7320b59199de4575f9482718e4f000e87d39f4bf839f03cf8735d9358b89ac748d466b778174e6bd491c26e04388e3382e40ecfd0e319ae78e35544e496ddcb961791a4dad773387c39bbf8a5f0d349d3d2e605d7ac4b8bbbab8b62bba32df21694ff0016d1d39073ec297c23f08f5ff0178bfcc8958f852ead122babf78d551678d060ec2c7e62b8cf3cee278e2be87f0beade0cf01dd5f5f6a1327dae4449197ccd86238c7c90b10724609201faf5ce17c4bf8dda1eed37cc335c68d7fe6db3c724814f25794279c30c8fa81f5af3e55e5ac1c6f166cb074a7d6c78adc5e789ef35bbbb9d023592c2ce032c7335b93b50b921d971fbb69360da1ff87248e4574fe08fda0ed342f0bff677896d61bed2951d64b3bac891183151e59eaaf80318f5f4a77c4af1bd9fc31fec89fc25a6ab1d4ad1ad1212a642f236184a324ef609900b7d0e40af1af8e573a6cfa478656e7499b49f164cfbef9e7f955c608f9573b401b93a0ee4670315d1878fb59469dad064d58ac3c25cbaa5d0e5a6bed72ebe2dea724b24b756b3cad3c31b379c890baef8d588f9461481db254d75afe24b4f055dea892cff00bcd51cdf6e119214b280fd17192c2438cf000c1ae66d754834bbfb16be922b76b69112e6e63665721b902439030ac4e08eaa0649c8ae57e252eafaace353db22da32796a2d1b2a46e62a7827839c67a74f519deaa5edb964b44adf76c550a12ab08d383d37f99d07877c43a6e85e10f14786e4971aa6a378996403ecc21cb1c00ca08e0a9520e48273c632df0ddf5fd85adf4b7f750cf6e2e1fc99cc5c07c02e48e99cfa9edf4acfb1d146a5e0eb0916216de2936ab166ee5548a4446644073c07283a938c05e9dfa2f0d5ddaf896cedbc329a5b6a1af9f31ca483744f22062f98d8e09001c6304fa138ab9be6a6f4df7ff804aa7172e5937a2d3fe09c1ddea53dd6a77baa230367856fb519811b801caaf5dd9046de8327dab4dbe276a1e29d0350f04fd83cc7bb0f2a4d8c389154312c3d008fd3231dfbea6af3786e1d6bc8b78e7b96b12a574cb7b748eda39c8dc5df246ec9048edc004638ac295e6d03404d774ad3634b8bb790bea16d70d2dd23648657dd809c8cfca3f1c106aeace946318daef4b7af431a7839625da4ecbd3a18d61e19d4dfc23756ff00619deec6a36a8f12c619947932b1ce3381875cfd457b17c01d03fb1f4fd5eea585adaede58e00a54a49b40dc79f4391f95705a26bd6da8ddc88d71bee64fde30864450f26002c703924835dcf817c4574b73719590470e36abae42b64f4ce7d3d6b3c639cb0b357d5d9fe4704b0fca9d9dfccf58f166bf63a4f8435695e6e52da56405460fca7f8bd739c57c8969ab5b6b1aa48cd2e3cc932eae189f98f7af51f8c3aa5ecfe1fd374e333422fae16dc16e372e72703b00c066b8ff0010784345f87d25a5edbc973765dca9c48301b1d48c67b1c73fd2b8f2da70a54f966f5937f81d582c555c136a093bf72b6afe08430a5ec56a6ced946e9cb3e4a01d4e09e78f4c540bf111ad638e0d3ef2582dd0ec88393c01d0018aecadfc5965adf852ee386d05901f2cb2bc99dcbdc139c815c0de3596a56a96b2e9d6f6490823ceb597706f7e79cd7bf4fdd566ee4555ccee92477d178c752934706eaebed008f9640c188f6ab7f03fc7d2e91f16b4a78e4e2659a327fed9b1e7f115e67677d67a6d9bc506f607892491c91f954fe00befb3f8f2cdd658cc70879d1571b80c6d1923b90d58ce574cc6ee2e2d1f7cd96bd36bd673adc4bb99c3b2f38c004631f91ae3fc4bf096db59bb96f85b473c4e15d9a193c8970fca93c6d39e46e23a8c1ed553c25adadbb246640cc62200dc324f04ff005af42fed37b1d3ad6fe287cf480b47340dff002d607e590fe24e3e82b824bb1d5cfa6a7898f8276b15eb1bcb2d49e18db1b1e5440decc402571ed9cfb57adfc33d034df05ccb6b696cba7096325f692c4b15382cc4e49e9ec3240c57537db64b0b79ad2192f6d2750d6f78b82190745939fbcbc8e95cbfdbded6ecfdaa1900dfd4a9c1e7d6b1b3ddb279edb23a9d5b54ba8c4692366611121f39c9473fd39fc2be2bd63586bcd6b5093e60ff00687de33fc59cff005afb79ec2d358d1bcc8e6657b7cca8d8dc40c1dcb9eb820b57c9be10d06d3528f58bf0de6dbddea7732dbbfca3745bb6a9e7fddaf3f11885878f3bea73e26af2c536796db6b1a57c43822982456dad46b80fd0ce07f0b7627d0fe1f4e4aea1786491482b244c47a1520d6b5efc30bfb4f11197489628114a9114c5924c900f200201c11deb2afda4b7bebd86ec84b9495c4809cfcd9e7f5afab8548cd5933d5ab39f245548ec7d41fb346bad77f0de0b79252ef05c4c8c58e4fde247f3af71dde6c381d973fa57c93fb386bcb611dd58efe1e469319ef85afa8ecef833000f2547e78af88c74396bcac7ca6221cb36779a35c1d7fc0979a79f9ae74e6f3e31dca1ea3f0ae4ad643334c1b9529b704f4ab3e0cf122e81e268249398243e54aa7a153c1ad9f18f8524f0d6b5f69890c9a45e82619472149e707d0d79d7e595bb9928b4ee739a424f6f2db5dd9b159655f2c853d658ce571ee47cbff02af8e2c3e2debbf0a4ea9a55ac16f35e595dcb6b0dd4a09184721895e324100f5c735f6069ba9ff67232cca7cb598488e9fc0e3fc6be46f8fda2c5a2f8e758b5b2d3bcd9ee2e64bd867770cad1cdf3eee5b24e1b18c60107d2bdbcba30ab52509abdf5fb8f4f0586a788e68d5575b9b7f0efe366afaa6aff00db5ac4e75cd422fba2ee5d8a83233b71c2003270063daaddc7c3c6f16492de6b5e23d09de590cf13f985e640ce0950c76ef0320ede9c1fc3c2fc21ad47a2eaccb2ff00ab906307a735d55b68a1fc5d63a7db25b59cf2c8b209234031113f7b3fa7e1ea6be86ac1c5c654da49797fc358fa3a525ec9d38c74f2d0ee75df0dea1e1ef11cd61adea826f091804f0ea76c0c2b728f9554192486ce72993c2b1e460d6bfecf3f0c3c39e2b9fc43a5eb7a94f2fdbb30e9b796a433dbed6cabb0cf39e06d38c8dc78201ac1fda86096c3c3fe12b525fcbc4aeacbd3384500fd307f5f5aa5f02ae6ff00e165fc5aa789d6e748b4d4e131d83328f9f9059c8ce46074e3f8ab9b109fb2959eafa1961e4a75629ad3b9ed9e1dd17e1ffc38fb4e8fa8f87efb5b5908fde4f78f6f70a80e1862260bd467a13ebdabd5bc39a67c10f0b68926bba6ebf368d1bc8a248afeee33342e7f8555937301ea0b1e0fbd7cdff1434ff126b42c754d1ac2ea4b3d5afda417b6e5a77c9e7708db2503aab30c003a1f52781f885109a2d3a2955e0bab499d678b5191f3f32e412181c1f971e9cd72d2a7cf15ef69d42ade352ca3e87d59f1462d0fe2fe91e5f877c5b6771fbc416b7baa5bb948c861908c8188e3208c2f0c01af3df1678034fd13451e1ed7b508f547b7712cd2d8cac2156c6f1b73839c601e9dc76ae53e0fda787f46f02ea2fabeab3c90dcde79905b5b5d2466342a54c872a7ba81c6781c81c1af48f8a9a0f836dbc1da77886d8de5d69933ac4fe65d16133b12003820e46d3dc8e3a0e33508ba3251fb2f61cad38beeb72878161f0bf8ab47b7b1b49f51d46fb497fb52c6ac1a78594f0e84a7dc271938e320e7a1ae7fc4fa65e7c4a7bd86eb56d42fec91592d3ecd12ef5e370f97692d82a3383fceacf82fe22af85e65d4340493479adfe50e36a2953c1071ea3fc7b55ff887f18e2f0c785350f11f84f4a9733967d4afe2b3caf98ed846673c01bcff0074af200c122b674f91ab257e8671abce9ddbb753cf60f096bba47876e22b4d426d235cb4f92ea33090582648209c32b6d6cf4ea4fa9ae33c43a7788f5bb19ae9fc592cb2bbbc863d45f6c2a1b024f9b7100f0091b46768ef8ab1a4fc76b9f19f88f4c6d64ed944ccb15cd8aa45323baed5c903e75048c83ce060115e93e35f0edaddf82935a844f790e1a096cdbe76424603a9500e0e7bf42383cf173a6e2ef25a842addde0ffe01e6fe07f853ad7c55b382ebc3c65974f8c0883ea1788d2294e0aa228042f1c0c0c76e95d46b5f0d6ebf67bf8a3e16d40ea73df45a95ab4921b884c0d049bf64aa39c9032843020fcded9a6fc0ef10d87846d49b9531439d91c56e4a305eb92579ce49e739e3df8d5f8bff0013b54f18f8cfc2d6fa13c6b69671c91bcf78be68467604e4649236c639ff006b1585573b356f76c7645c24949bf7bf53ccfe38f83adbc19e2bb6baf0bd8dd0b4d56dd6e648a698488b23b12c6373c8000c00d9c60926b2a0b2bbb6b99222de55b80929323e2367d84311cf5cf5eb5ebba5de5eeb975a8693e2077d4dacaf88b7bb9e148e30a0ff000f418ca9fc1ba7535f31f8ff00589ad7c5da9daa32a25bdc3c416324af0c72467d4e4d2c27efff0075516cb7efd8e0ad39d09a941e9dbb773b5992f2cd565b78ad6efca0428b4405c2fd36824f5e464d7b5f80fc13a85a7858eaf776e05fde30796cfe613c5084e19f2319e4f0092075f41f27e9de259e195596528c3b835ee5f0ebe3e5fe97aadb3b795713d8488e0ce06d1b71f7b3d41c63d7f1c577e228fbb77771eb6e9dbe57dcf4b2da54f3253c3ca5cb3b5e2ba3eebd6db74ee6d788a2b1bbf11e9f7d97961b54794297caa96503b9e8064e7dab86f8882dadcdb40db6e6149bcf9558796e7006d518cf5cb738f4af74f88de193e2fd2e0f1f69fa6ad86957f1a09ad2171b033ca544caa31b816560c06307048c1af9c3e2058ea3abead23ad9ac701758c81966853380f263214139382738af330b38ba9cadfc374f5bd9f6f91e5cb075694da6af6b3fbf629d86a502ddbdbe9b6c1def498cc112967e79c02476ebdba735c8eab752585ec88244958646f8400a7b1e40e704119191907935dff8934bd3fe1dd8585945a94120d46d926bab98ce6e123666ca2aff00096006707a77e4d63ea52e8b771a4d11816d5502c7b9879854745099c8fa57b14e6a6b996cc9c4c2517ecddae8e6f4d371a823876d8aca768e809feb5a5e02d3ee2c7c532c45c1d96af71215563b428ce0e0719e064f1c8e6bd57e197876c66856e679123caee10c7f7b1db737aff9e6b23e34f855b42f15691a969770608752536b70371e31ce09f423f95734b11194fd9239a5869421ed5eb63d9bc11ad47722123b2f6e82bdb7c15a9a5dc13e9334816471bada563852dfdc27debe60f87b35c59431604d74a0636c68491ea0f1d7f1af5ed0bc4696ee9f6bb0be888208611a9fd370349e9b99f31de8d76f3c0f7d75a6dec12ae9376dbda3230d049fdf5fea3bd67eb3a95c5c40f22ea0d7306095ed915d241ae58f8974d16f81af58918f23704beb63fec86fbe056441e1ed2ad44b01d5becd03e4186fada589d3f0da467f135cb3bad886d989f1035ed46cfe1ac7a7e8cb21d43c4312d9c4e8d8f295958ccfcfa22b0ea39615e263e355b78187f625be9452d2cff7707996d96641c06279c9382739ef8ed5dcfed0da3a27803c3f7369e31d32da2d12fa640d14ac2490b85641903e5da7cc041fef0ed9c7cf1a66b1a7e9f6c62d434f6bdba2e59a58750789393900284c015142c9b96e79b8b8baad2bbb2ec7aeeafaa5a7896da0d5ed0986e542c37b13703383b5863a8c6474ec07415e1bf10acfecbe30d4a22413e6eeca9383b806efcf7af54f0e5cc3a3f8aae74bd5ad95b4e99f639e23381921b2781c77f7e6b97fda1f408b42f1d2cd6b219ecaf6d9268662d9de065739efc01d29e0ab28cf93ee3edf131e7c3f37665af83530105c98d0f9f6d711b703fe59c80ab13f4289ff007d57d45a6de6fda7771815f237c239e7b7d45d917f7372eb6ecd9e091f3e3ff1d15f4c6817bb970324f03935c39859d43e731d4d7eee4baafc9b476d77132aace84f1cf15ec3a078d16efc1f6526a167fda5a2b836f73e5ae5eda507bfb1041af2fd2847776db485231c966c0adbf077c43b2f865aace9730bdce9d7600b8b58d83b6474651d33f8d78353de565ba3cb83d794d1d4745b08eee59b4069efe39d48681e22a17fde278f4af95ff6c1f0f4da069fe1f76b6bbfedf9e7912292080f94b085c988be725b71560b8c8058f19afb422f15eb5e2f489b44d31b42b1b850d1390892953d0b39042fd1031f7149f123c17a5bf822feefc77a8c371a2c3087b969996182161ff2d4772fc9ef93b88ef8aac1e22542b464cebc2cd53aa9caf6eb63f2bbc57e0f9f40d374fd45de29fccf92628c0e24c6ee99c8e0f703915d5783bc7526836d6fa8c71c334b6ebe4b33282fe5f500376c1cfe74ef1acde1fb7d2b598346ba92efc3929796c96e17124787f5eb901836093c6e18e2bcebc2206ad3be912dc0852eb11894fdd5390413edc57dac652a90946a743ecea52861eac5d177e6575ea7d31e1cf89763ae7937772914b61017b89127c8846432ca8f91f32b36c38e84faf4af71f0c7c60f873f1e6de4f016b36f04b6d751ff00a3096dfcb292283cc4dfc2c0720f191918ec7e089ee6ef47d2a4d126b88e68c5cab470a4aa448a474620ff0009c639c1e7d0576bf0ee482dfc79e1bbd82ea2b7b982fe06683ef28657527041e831cfe35cf3c345ae66ddfa18a9cef68a56ea7d15e3fd0ecca6a3e1e9fc43169bafe9d31896159846ee9c346c8b9ce369071dc1604f5af204f175cfc4db6b387569edb524b4b516a5a48544a88b8c6f39c9518040e9c7383927d43e3ee81a278c358b4d5ee3455d4b56112db4ac83e778cf314a3b1dacc549f42b9ae32ebf6609ec752d23c43a4f8c2dc6993131ddcf6d010d6d2019f2c2ff00cb5ee390338c9001ae0c3c6d092bbff267a55eb7b49c2552cfcbc875cfc3c83c71a43d95869d1cb79a41487ed5a68085f7a96c119e71c614671938c64573fa2789354f845770e91aef88e0fb0de3cab2e917766d3f95b0101a54917e46242600ce7be318af47f0e6a91f85a6bed12c6d6efc4ba3da45f6bbdbeb781a068ddb8919f696c0cfa71c7180b9adaf8a49a7f8a3c2ba6c874786fae6655f2e79e0690242a7be79200ce093c7d456f4d385a33d51c55d46ab954868627823528ce9c977a0782352f11dac80716fa5ca6071e837614fd541ed58bf1abc41a7f8dfc19ab7876def75af0c6a60073a36b36c514f96bbd6000636ae546ddc3ae2b5b4ff008bbf126d2586d4da7d8ed22211255bc8c215191d8e71f5af2ef88df1aef3c50b2d86a17075630c8cb0dc5ca2c9246470db0ecc8539e84e2b582ab52a5d2dbccc67ec69d3b5f73cc7e00783b55d7be28680f06a56fa32db5da5c9bfba9022c5e59df819eac71803d4fa57d03fb48fc4cd0e5f06bea1e13b6bc84ea1fe8b35e444456b28127cec22e4ab7c800604021cf53d3c2b4dd55b4c944b6a640de8e7e5fcba575be22d7e7f16f819f46f2918dc81e5471aaa8578fe72a3f056c01d7a7522bd0ab06e4a7d8e2a12a71a73835abd8f1ab3f175cdb12c256f4e0d6de95e343e7248d230914e6b82b8b5923562181507181d7eb4ed2639ae6e70a8cea8acec14760093fa0ae8ba7a9e7ae64ec7b8b7c667b3b8d91dbc6b8f979ce3ebcd796f8c60bad4eee6d4cc4e2295c859704ab3752377af350437f26af7f0dbdbc4d24cec04621c29073c72780335f4c687f0461f17fc34d1f4d9b535d32e64bc32b44d0ef9891b81206e036b6f0073dab9aa575492948f41519566e10d4f9dbe127c36d4fe28f8c6db43b09ed6ce6955d966be97ca88b05242e707927030013cd743e34f84de2cf839e23f23c4fa79b613b37957513092094f5f95c719e3a1c1f6afa63e1c7c07d17e1f78b74e91b51981f337092701433a9560ac411b01e0e70dd0e48c66bd73c79a968fab69b649a9dc426daf5c40b72156511392c1655078253cac8fa1f535cef334a7ece2af192b3ff807a584c03c3f2d77a4a2ee7ceffb3bf8ca3f1368de22f05dddcf96f750e6c5cbe0a338c10b9e0fef042d8381f21e475ae8fc3fe27d7fc3da4db69b79a5dec1e13bc8cf9e67b66f2ddc9e7cc2060162ddf1d38e3150ebfe08d5fe185fdd0826f0fea1a95d45bc1b7b66b37bb849f9591c7cad9ee0918391dabcbb42f1b3dc69f7f690c573a7416f812c2d2b32331ce06598e718278e38154b0cbda54afa72cb95e9dd2b37f3b7de555c473da2b4777f7377b7e2ce1b59b6b5bfd66ef5096209134856de0dc58246385504fa0c0f739ae5b5cbe83ed1214894141b411dbfce7f4ae8fc49a97da6ebe4fbab91c7ad70b3334d388fab3c800fae78af4692d2ecf9ec4b49b48f52f87d2497d3491bfef15a328aa7eee40e481edd3f3a6f8e7c413dc78452d2691b729317cc3a00ca0e3f5fcea2f08cc349d4ad07fcb28c60f1d4639feb4bf12e0815edd22951bcfdee8a48e41c74fc541ae09c573dd9ac799d3b45eba9c2dbcd71a718de29a778dbe5658e4dadec01aee7c0df173c55e1cb855b5d4a49adb3b7cbb93bb61f4e4fd339ae6b46f0f5c6af73676227845ddc3ec86357daeedc718200cf23193cd7b2f86ff6779751b2692eb5dd2ed9d1c2bfda14c6ab29e819ce003804f19ce0d438c6a2b495cf1a14ea4fe13a6f0dfc5df165eda46d70da15d8dc407bab0469060e304a914fbaf8c7e26d5ef8c136bd71a5d8a3c68d6b61fb85c310b83d5c82481c1e03679a834dd33c09e1c16f6d7ff10ecace374dd88ad6698a3f3b95846cc179518f5dc3f0ba60f841e16b38f5d5f1ccfe34b8f2d8ff00614714d6ff00686e46198a9287383ce3827dabcfa30aeaa4bdabf77a1d54f0b889492e5627c57bcb2d43e065addcba6a5e241a8b5bc92dc7df8cb82c307f8798db91c90464f3cfcc7717b6cb3379716d4f4123607eb5f48eb7e3a83e2af8462f0d41a3d9f827489232d752457724d0b4ca728c43f20606304b727822b92d2fc0ff000e345b18ad75b5bcd575151fbcbb8ddc249d81509c0181d324fbf61ae1d460a51b75e9e6198e5f5b07387b4d3995ff001b1dcf887c307c4b65a7eafa5a8ba9221b67b7271e6c78ec4ff163f95607c75d1ad6e3e1de83a85a5b3da9d3e5168f14846515900eddb318fccfad79b59fc7ad52c6191acb4fb6b7321d8cd2333aaa9cf45e06467afb559d43c4de2ef19e96da6fda233a5ce05ccced184f30a8c8dcedcf5e0018e7158d2c355a32539bb247beb1d87a94e54d6adafc7a1a3f0c6f6d17c33abc735d25b5c5bde59dcc3bc9f9fe668ca803ae7cc15f45786ad9a08156423cceac474af970785e3d1747d43ed0d3dddcdd5b18e34b44251086560ccc704e0a8e83f13553c27fb47f8bbc276d1daf9f0ea50467005f465a403d37a904fe39ad2be1a589bca9bbb3c9c62a928c135b2d3f33ee3d1a6b869bec9000677fbbbf0401dcf35d0c3e15b7d377493b24d3bf25891bb3ea07a57c33aa7ed75e28bd03c9d3b4f81c7467f324c7d06e15c278abe3478cfc630bdbea3aedc9b47eb6b03795111e85571bbf1cd714729af37ef348f33eaf39f5b1fa1fe33fdb2bc15f0a3461646e7fb6b5b81362d858c9e632b0e30cfcac607fdf5ec6be29f8c1fb46f8afe396a5e76b77ad16971b66db49b762b6d00f5dbfc6feaedcf5c60715e2319e41cd5db6762d80703d3b9af7f0796d0c23e64af2eeff0043d1a34234b5dd9dbe9570174a9a29cc13c0ccafe4b8249cb6de00ef839fc2aa5e6983c33afd99b62a72dbc61b70c820e3f5ad0f0bf8565d72d667b999a0b3c055380a0fe38fe757aef4e7d3f5ad1e1d39104a76c6be7c9bd73b80f9db6803f0147b55cd25b9f5b5b0f171838f647a3eb9636975e01fed08218edae2e12432cad18c9d921dc0f1c0d8c31ef83c552f00e83e1c7f1bc1a8ea2d2dcda69912cde5c6e479b2b053b18f644f418eb8ec736a1d5aff00e21f81ee2cb4ad3eda79625613acb3ac1246718c2e4807951fa7626b98f08f8a2cd7c3d7360b17fc4e42324b95258307000f4c700935c74a2da92beb7f9ea3adecd4e2add0fb8adfe22687ab6916ba8db0d3e217046993c178a8e8e14394183d7a3fb9007a5719e218b44d47c7b670cbe2287c3ba4a586f7d32cad9512f250e46f1b4103682325813c8ec41af30f02780e6f1afc31f10687169571ac17851d218232ee2453852be879207d6be81f859fb1b5b5c5a6937de23bef2174d6135b5ae9f08135a3950bb7cd7ce0ed1f30d9c7c8436466b6828d2a6e29ea8f3abc5babcf25a3b191a1d85c7c3cb2d5751d0de28e0911e67fed39ca997e5f9b04aed180bc06005793f847c597d25ecac2eada0d0e56d8637556551d86c3db03d08fa57d23f15bf67ed2a7d434b4d1757d5263771b0934bba549ede48b80c4b36dc13bc7ca77679e38af9a7e2ff82343f81766b730f86a7f313f7d14f777524903c982140424ab6d254e0ff2ae7947da5b5d5839f22f73639bd5ec3485f115debf7da95d9b260e89e1f9a56fb3093046fc750ac3e654c719ce40c0af96e7d627b3be0aac58863c9fc3fc2ba897e21deea37b35d5e5d3dc4b331691e462c4939ce73f5fd6b99d585bcba9dbcd04636484b329380368c9c7d41af6614fd9ab1e5547ceee99d45a58eb5ac5847790da33a37400aaeefa02727af6a9ac24ba5d6eda0cdc45e55ec6d2a212a52327e7393f748dbd7dff003e5478a2e9260de693eddabd2fe176bf677f7f25cdfc515c5c98bca433461b243a153cf707bf7e9d090719b76b1ac211935667a77c51fd9a7c3769a49b8d1edf53b7d4afa246b68a7bc8b644dc3169610864195278e31fa5667c2cfd9d9f44bf8af754b925e321c0481c28ff008110057532f8de66c80446e7ab1520b1f7ae8fc27f112ead668a2b95fb4a93b42ec0c483dbd6b15751b44ed8d28735e48f64f871a2f85d658d6e343d2aee34ca2fda74d89b3ce4b6e604f526bc9bf69cf02afc3ef17e9fabe9cf33683ab83b2307e5b6957198d48e8a41040ebf7bd2be80f0af8261f13e947585bd1a7d8c79579170b196ee158fdec1e32011e86b23e2fe8ba47883e1adf69f1eb30dfc36b8b84511912663c312a598861b0b7dd03bf239079e74eef73a238887c28f0ed23c7a9aac76575a9481fcbb764b867da7ccd9e7024f70c4ed6c8f523a715e13e30f883aa5c78674049a4db04ba8dd496f9192228c204ce319e65939f6ab1e34924f0feab7d696ccd7d1b82b1a2fce33e40666f719193ed935c5fc5eb0bbd274cf0869b103234562d2bb27dd0cefbbafe9f85634694232e6b6eff24ceb9d4728b837d0f6cf0ff8c87c4ff09bf8675ad4a34907cfa6df08f12594fd01d8177329e03019c8e7a804785eaab79e1356d0ef5d4dfdb4920bb31b865326e20804750001581a76b17567298df745711e0b4792b91d41fa743597ab6a8f737d348ec59ddb924f35e961e0eed5f43cac4544a317d4b97176642cd9f535cf9bd7b4bd8a644495d1c32ac99da4f6ce08ab2d39f2df9aad67a74ba84a1feec28d92e7a13e82bd18c4f0ea3bea75361e348c6d6bcd3193cbc932594841c77f958ff5ab5e2a31cfa6c37b6f2335bb82b02c89b5c2e3393e87afb5655bc3188a5488f9aecbb063d4f1fd6bbcf8e1a65af86744f09d95aa0c9b0591e66401dd8800e481c804363dab86bae494231eace9c25ea54f7f6d7f23c8c2cc6412b49e687e85fa67d3daba4d29f790a81d2e31feae49880dfee9ef5cdd95d10ae9c143ce1ab4adef9a3da01ce0823b906a669bdcf7f06e9d1b35b1bb25d224852e3ed16cdfec8465fd57fad68d9a81b65b798cfcff0014698fe55953eb36d72a126055fd7155ed2ed20b8fdd48ac0f75ae570ba3dbfacc213f8aebf147b6785e4bcbab5f3619a713c11b3471c417686c71852304fd41af33b8f1df8ba49e47b5bb3a7c4c777916f3a8504f5273dfd6babf0c78d9acf487b68adbcabb738fb4b49f281ea07af3eb58ad1df19a6fec9b7d52fad03b0f3e7958166cf38db2018fc2b6c1d3d6499e0f16ba752387ab06dcacd3fc2c79d4085adf66d24b1ce2bea6f065b5d5dfc3ab6b68e384442d15096894ee6e413ce327a75cf1ef8c7cbda6c824942e7d00afa5be1ddf3cfe0bb60a1e49202cbe5c44e71b81ce3dbfcf5ae4ccef1a3ccba33e57053b54773ce35ed5b5182cec7cb468d218f6b28e3776c5796f88e055bb8eee35d915da79a147639c30fae6be8bd47c1f6da848c54199ae016552761049cb0f75049edfd31f3e78b758d3afa5482c2ce6b510bbef32cbb831e07000c0e9d7bd6197d45297b8bd4fa1c654856a77e6d7b799cf93e9f9d0ce11739a4cd763e0af0e69da9e91ab5cea8301a3f26d599fcb08ff0078bee38538c018279c9af6ead554a3cccf32852956972c4e42dc6f39639cf6ad5b48b6b0202a7d0738fad665aed6e430523b1ad4b52652a831b73c9f5aeab95067d21e18fecdd6fe1ce9f3469e4dfdbc4b6f2abafc8c060061efeddff9f03f152f6dac758d3a08d641f6620c82da4559707b0cf3dbaf6fcaba8f0369ba8ea1a7e8724a23b5d2a18c3c36b1619ee1f07f78fe833ebcf4ac7d53c037fe2896f2f26b65b3b8791823dcbf322eee0803240001fcbdf9f0e32a741b4deed9f418aaad538cadd8d6f09bdac1a4c5a8e9a4dbc17085250ffc3267e612104f078f9b8c7078cd472e9b7761731de59d9ed498155fb3caac241dc875e720f3900ff3cea7c1cf0deb3e13b6beb5d52d4bd85e380b130041c641ed9c9f4fa76af6af0bfc1fb7f1cbdb5deb56aba4456716db41612319e48cbe46f652301b93b724f5ce3bf146a38d676775dcce35dd58da2bde343e167c4287e1be83a5e9d717a2cc5c2b096472d2989d89e769639c6146071d3a77efbc4de358756d25f54d2f5859b5cd114cd2c9113bae20ca0fde0001046e3c81d88efc79b7c53f81b63a1e9eda9e93a9dcb18d3ce5d3ef00fbbdcc6eb8e39e0107eb5e4ba1f890e89a847012f21b96f21d5b9464209c3f18e437a7240aecad28aa7cc95ce5af5e549da4bfe01ed77ff1835a9de0babcd549b911036f68d6b1486dc1c1219dc67270030e471d7815e57f1d3e2f788fe24f82ae7c317da7c896b65730496f72c9279971b51ba60ec6c820f40738c9cf157eef47175737925ab9686384bc51c8e0b1932319c9c7af3fa71cf21a0e8bab476d3dbdecc45c3bb16f3464c793c8048ebeb5c50a94bf88b46adf79a612956c754718bb2b1f2dcf23adc150841271b7d0fa575f6ff0fb5cd67c37a7ea5a5d9cfa9f9ace1a2b688b3291c1c01c9181c9afa0f44f8356ba96a2750be2c2ca03ba49768058f5da08039fc6bd4746d6a3d42c9ec7ec31db69d08c470c580b1fd1718e95e93c6f3a4e08b9e5ca949c672d4f8647c37f12dceacd650e9770b26edbfbf5f247e6f8af5dd33e156aff000f7c1ed7fab5ab2c57338810ca8a30fb43304393b9781f30e0953ed5eef0d8786346bcfb66c8e09d4eec35bacaac7f1e47e15c97ed03e3db3d6bc23a35da5cadbd8c774d01899482242b904819e30a6b075e752a463b21470b0a7172bea8f179fe2c5df858326d4b904fee966190bfe23fc2bda3e08ebd71e20ba5d4f59d6ee62b7b583edb722da4fb3c7047cec5554db976c1393f7579ea72bf34ea30d9ebcd2a24818b1096ec8cbb5dc91953ebc7a77c57b2fecdd6d0cf16a7a5ea16635141e5910baee0ca030079183c3301e9c62bd595946ed6c714a53dafa33ea36f8872f8b1ed2ced4dd7d9678a23636db98a4500231248a7209248009c020fa60b64ea9e2bd3f5bf0b78aecadae2495e3b5bab492195911a02617fde0e842e73f771deb37c2faac926bd7ba4db19b4c3e5f92f330dee321412a49c9c02a339c0206724e6b2f42b3b0d1742f16e95a8e2eefb63d98bd2391033322c600e8c41c96ea4b8f415cff59a4a9ce0be2fc4a8e166a5194a5ff00f0df05f86ee750b0bc5bddf1c420162189cb17da15c8f6006dffbeab6fc5fe1cb4d4f5bb187688e2b5b58d634eb850c473cf4c607e55e97a6784a416c8f26d82254ca46d118c0c9e719fbd93c938ae1affc25a9f8cbc6f1c1a0dadd6a48b1792f1d91c052aedb8b39c2aafbb10323dabe66a5573bb52b23ec69d2e4b5d1e75f103c10ba96aba66a904d6f08811d2edd98247b5572a324f39391ff00eaaf0fba9cbdf3938e589c0e95f45fc6ed1ef7c0569a65a4dac58ea56f74f28bb8acacfed16f01daa04467233212031dcb80a738cf26bc16f61d1a2b8f3a069a46c93e4b11b7f3eb8afa4caa71961a2d3baff827cce654d4aade256b0b61731bcf704c76a0e33d0bfb0a7deea4d7456181447128c2a2f000a8dfed5aa3ec8232f8e1517851ec2a6834e9b4abc88dec12a9209640304af4f973c1af51caeec8f21d09593b69dfa1d67c38d11e7f115a0643706361214523e6c723a8231f85763fb485a5e0d13c3935e295b888cb01561b48190471e9f7bf2ae3bc2ebfda9a85c5b69d2359c2ea160965c860dce7763b741c575df10e58b52f858da70dccda1cb1082e46184e9929f31fe16f9b247a6381c57955e76af0573aa8d251764eef5db63c66d6033a89610091f79476fc2acc522457518910c409e79c8a8f4b9237753e61b6b91c07fe16fad6fc16c2f6716f710a31607e74ef5d32767a9ecd3c3fb48ae4dff0ff0080569ac7cff986187622aa2d84eb26620723d2b6e2d0e4b33b6395bcbce4023a7b50b1f91217c9673c601acd3b1d73c027694d599d27827496d62f552fc4cb6704665b816b8126c1c6467a751ce0e3ae2bd06cbc29f0ff0054b2b79a1b0b885366dc5cdd3339c1e09214f6c7a7d2b07e0f7c54b3f851e31b5bfbb51992331bc8c9b92342464b7d48fd2bd966fda4bc23a2cf2c3a65a6956f68ec650b6d3185493d495518c9fd0600c00057995a857ad3fddcdc57933c0cd2546a56f67395f974d753e32d2a42b32367bd7d05f0735b8d1a6d3e46082e17e56d9b8e410781fafe02be74b39028041fa576fe19f11be897b1dcab906ddd25273d06707f9d7a78aa7eda94a1dcf9ca2f92499f5a35cdb4328b2964768948e0202015079dc70320f5eb8c9af8cbe2bd8c3a67c45d72dede036f1f9fe608ff00ba59431c7b658d7da1a7ea1a75dd825e24485e58814965c6eda401bb9f979057200efef5f10f8f6f5f56f18eb376d299164bb94824ff00086217f402be672652f6d3f25afadcefac9adcc1c96e075f6afabfc31f03e6b5f09c7a6bea779a6bdc5b8f3d3c9538771870709bb19cf5c8c0ea3ad7cc7e14d3db56f1369566abbbcfba8a3c1ef9702bef06d3df518239eeaf7c962c14dbc61b715cf20e4e71c7ff005ba1af4334c44e94a1187a9e965b4a7524f915fe763e0cd47489f49d52eeca421a6b599e072872372b1071edc558b5caee200dc782476f6a76bd0dc47e29d5e09c1fb48bb984818f3b839cfeb5259c410038e075fad7d141de29b3cfb72c9a3eacf87da1db5a783741b85b7469cdaacbe72caecc0b2ff7738feef1daba775b628b1c6eaa50ed3195c6c241c9007fb3938f6accd3668c687a25a5948c121b18834790bc2a2e483c724679f61cd57beb2bbb8d6acde1b65b9b163ba58d37b3b952700819dabc8c9ea727b8af849bf69524fd4f6aacfdacb92285f1278e2c7c356f05ddfab3a81e500621b88208279039393ce38c8356f42f8b1ab456aab6cd6dbfe474b69492ee4606d18fc73ed81f46eabe1c8bc4a658ee34c8350453246662dbc0653805881923b853ce07039e7121f015dc02dda22b1bc4fc408bb6445ed86ced1ce3e52bd3bd7651e574b91ee73d3855a97f66b63b5f17f8f35ef1a5b47148b6f127929248f68488f0c0763d0f3c8f5e9d89e2ee3e1cb46b1ada5ac9f6340c1c4b29dd293c82c01e08c7008207bd761f6eb459224ba80c2ed88964f3006048c0e3b9e9c0e318a6dd6b916a177f64866b6b86442ad1dac81909ea467a63208e0f71daa9d7ab157b688e7af29a7fbd5a97fe1c2451f8901322c93d940d21f9794900f901240fef2b74ea05665ab5a69b711c7a8dd308fcccdc4f27de233963900f26a1bad60781e0b9be90bcd2e162fb3a38caa907193c96c13d72473f9f96f89f5d3b27513160c4e30714460a718dbb9f4d93c9c684dad19eede25d4aff0053b543a7fd964d1947eea5b7b85684a8ec00fd7383eb5cfe9f2cf2d9ddac72793338cee439fc2be539b58d6347d48dce9faadcdb485803fbe3b4f3fc40f047d6be86f09fc4ab6d3fc3169737f6d6da9eaaea1e59dd992139e9845233c77cf5ec2bd0a8bd9c5347346139d46a4ca3a85cdedc4e6de249ae26276f97182c73f41c9ae57e2df85f557f01c76ef6734371f6b4952de44daee42b03c1c1e8d9cd769a97c76ba4468ac92d2c011975b388286f7e3ad701aaf8dd352bb9ccd76f3fc8c22766c82c7965fd063e86b9a33a9cca5cbb1d12a34dc5c5cb73cbb42d3aeb47b23f68b6892e2525e27ddb9d17a1231900e41f7febe91f0dfc5f67e12be2bbede4991d648649b287600e1d013804fce18762531d4815c45feaa25b85823098b695d436303e6c1fe7fd695a6b62dbda025c0c3237cca7ea33cfa8e47d7b57d05297346f23c2ab4d2f723b1f4c7877e23e9c7c5a6594aadaba2adb5c46c652993cabae01e48ce7b118e4104e4fc56f1e5bf86348d7aef4f85ee3f7eb7139463199e47936f5e70080a475feb5e25a7eb5a2db4d6c2dcdd5831949902a09028c0dbb09dac0e776791c63ad55f8b9e27b4d7ae16ded6f2e23b4372d3bac0bbf2c06c50e72327009fc6b07429ba89c776ac2873d3836de88ec7c35f15b58f12ea70cd756f6b6ba705c1d32db72890ffd349010c47fb20a8e80e4715ed5a6789f54bef0fad89b98b4fd21483fd9d6112c30e31dd4727b75cfad7c6da0ead2e9773becef67916338712d9e707df0e2babd57e205cebda3411addcec93370f858d4a0e08d8090393fc45ba67e9e0e3325ab889a729c630fbff05fa9e952cc1f2db56cf60f89de39f05be853693aadd2ddbbe0a5bda8f324571d0e780a7ea477af03d77c2ba5dc3b5ce991cd670cc15a2b6926f319074396c724e338ed9ea6b02e6ded756f134c439b5846d58893e6739cfcc78cf00e4f35d55f5fa5d4507931c91218d005da07418c9f4e99fc6bbf0b82a797254e94a4efabbedf76df9fa9d14271c65492ad1565b7fc39b9e06f0f0b5b08d66897764920fd7eb567c7d6fbdb4dd9c469b909503033db38f6abf6b7f2daac71290ca8006623afd4d6cdd786cf88f4633ca59bca7caec0029e0715d4aa3e7e667d34b06aa619d082e873df0d7498db5e8c35bf9f11467c3f0061490723a73fae2bd275ef072788fc35aada4063b595e394968e3d81885057713d794ebe878ea2af68b69a569ba6d958d8442c95d11a59bef3293d989e79e719e2bb7bc821fb0794b73f6888a2199114f2aa483f36082339eddfbd7cce3b1539e279a2adcbfe67e795a1ecab38bd394f866da069e266017729c30c720d5eb15be7ded0cc51e3c6062ac78a74697c37e2bd46de252a61998796dfc499e0fe58fceb4fc3db2e56694020151c1edc9afabf68a51538ea99f6384c2c6ac92bbbfe7e654b4d42e6eb72dd0903a9c1c700d5cb4824926524009d055fb888349fbb1c63a9a96c6cc9b852c19fd803d2a1c96e7af1c1c935193b8ef105b69f77a2c3159c8b2ddb4c05d601cc600c01d3a1ce78ae7755f074b7b24261d34a08e3d8cd1ab65db7124b73d79c76e00e2bbbd47e0e45736b6f710ea8f14ce1567449084723a900f23ae7f1aee7c2bf0e26b6d2fcb17da85ca2b908e93464ede3686f30839c63a647a1ac296269d08bb4afa9f8fe3e74b1156a46aa717ccfb1e29f12f428744f1418acd0476ad129403a646549ea7baf7c1e7a549e0ed167d77554b68638e7764c48b33158c2fab639c74e95d6fc45b3fedfb880348916600a8d267739c8e3e5ee307afbfad69f82bc22ba25bc77b773fd9e152bb7cc1b0b1e70016c1c6437e63b567f59746972d5d24b43a61455492a8be167a35acf7be19f082ab6acb359d941232058004db8259403c80300723918e4702be40b898ceec5b924e4fb9afa77c6f6739d02fa7d3d7114f6929996241e6676b83cf7071ce704fe15f2f0e735196a4fda4d3bb6c789bc5a83d91e87f0234a3a9fc4ad294466410979c845dd8da87071df07071ed5f6959e9b3c76f0c6f716eaa887e65832c7be5bb13c7a9efd6be52fd97220be39babc68fcc8a0b4643c1c02eca06783d8375afaeffb5dee2c421b7df1020a90e0055ed9efff00ebaf2f349debdbb23e9326a70e5e77b9f0a7c61b6fb3fc56f132ed688b5ebcabb860e1be61fa1158f6b2bc8aaa4a9c9c640e4d7a17ed3a2dd3e2933409b0bd942d2718cb65803eff002851f8579c69f3ecb888fa303cfd6bea30b3e6c3c25e48f0b151e4c4d48f9b3e929740bc8e1d2277918a0401658d804ca9e54838f4c71dff00115dbd8788655826db7064681045b36e044428c1072739ce7d893ef5717c4f6175a7bc37360d7284978645873b5860046c7ccab827a0c77f7ae5ee27b7b679ee56d504bb7e78a25cb0c91c673d071dbbf38af8ff0069ccaed1e842ac611e6868ec6cd8df4b0c9753f94d3053e733794a5d79ce11ba8fba0904e3f3ad4d4bc40f0ea850aec88c8cb96e06013827eb93dfa5646973933b40c333066f937e338620b1c75e36f4c7f8375767b4d4a536e1bcf0fbbf7ca4aa218cfcd8ec71d3e83e94d4b9ad1e86136d41283b3361a3b0bd601ddfcc9141322aa9f2c1046093800e178fc475ae7f58d3a3b58e297497786e0a28df1129e60073b49c1ce4e38e723a73d6166b8b38678118c2e6154665c2b32ed6c96e0f2467b1e4564c76ac16096d27b89a372ce11b2030f5da3a0e83b73e9819eda2e4f76446acdbf79e861f882ee686d3ecd7724a6d0c6cc0856662473b9bae39e80f5e6bcf352d5e6bc45791b04f21401c0ec38ea7a574ff001034e9ed636927fdc82c0ca16452a091df9e3e9eb9c75e7cbe6bf68d8a9242e76a920f3f4ff0af568d1bc39923d2c0e2e3083a7276ec59d46de568c395c070581cf5a9b4bb9d4934d41f20b10c545c804f9240c90d8f5ce403d73f5ab57ef1fd82711d93bc436c313cb265871bce0f1d4fb0e0fe78fa86857e74db7487cb44ff005b3b4a582b48c4e07cb90c40c0c738cf1c9ae886ba48e4c56255ef07ef16f51d5eced5555c5cdc9623f7f0e228f3eb83922a9dc42f3333479b640bc8dfe66ef7c8e2a84466b18e18af02490cca082872067b12475aafabfdaecacbecd167eccedcc8bd71e95bca8c5d9c0e75395af26d966d659207965ba25849c927f897939faf06962bf919943ffa9e718619cfa0c8e3359e8f259c8b13c8278971ba307a12a4633edb8d2c85a0b786d9c0213043f7c11d3f0c7e95972bdd1a466a50dcaf77a9ddc57ca8b808df3293c9e3a826ae09643b25e362c9b55428fbfdf9aa51594d737eb1924855273efc1cd745a6787e692fc472b1f28c3e6ee6236e7a633e9fd056752492d772545f2de451b8d3eeae14df5bc52f9b9219829db2639009e9bbd0d6fda69f25dc1a4c773e544914481a371b73b5401fcb939f53ed5b4dacdd68d786da75476b98c7986c002403bc90c39e47518c6324f7a6476ab6739f3a78ae126710b1f3366c19cbc9bf8da016c9c9e7078e95c6eac9ab7dc5c63691cedbe931db789af3222b8844c889204f9776c0d8c1f4c907e95a7ae5b30b3b2bc8e43244c0c5200480aca78cfd571fad74ba3f8623bcf0f89c5c4d70f2107643d26e319c038e0e0e7a8e9cf5a3e270bab6f075c42d686196d9218e4b988e16561e586908ec49eddf83eb593afcf5a3cafaa5fa1e950bd16aa2343499a196dd9095393b883d7f5af4af07d9b5e7872ed2dd9648c3b874073ce06d3fcebc5f4a91a6b68a20c563d830c47dfe3ae6bdd7e0d0961b097859a067c3c79fbbd46735d2df29fa4613dfb2673fac5a5c43750496e9344b1050e54654aec079cfb9c7b7e9534dab6a1636c8d24abe426e765561f2b640209e78da4700738e0fadaf140dde21bb7b6c48914c608555b0090cdc1c9f703ad73fa5c37f0da5db386d43cc6f30336c31e0ee05339f9b923230318ea3a1f999c94e7293b6ff00a9f9b6363cd5ea3b2ddfe6799fc759611e32b35b6f2964fb386768d89eac7009fa0fc88aa1e17859f11f90657959502291cb1381fceabfc626b88bc7af1dcaa298ade258f60c02b8e3f2e47e156bc09379dade98b1b7cef7110182073bc7ad7d661e115848b7d88c166188c2cad07f7ea6efc54b7bbf86b069eed6f05d7da99d32490636503823fe055cce8be35d42f9959de3854f05635edf8e6bb9fda56d6e8f85b4591a2ff478ee0a977705c395e840038c0e0f7c578ae8b2b99116304b9e8055e11c6ad1536aec8c4e758fa955a555a5e5a7e47d6ba169d69232cd6844d6e205799dd37bef6e89cf1b4633c1ea456549af47693cf14fa8cf68cb2ba848584608048c95c1c1e3f4a6f87b53d4acf418209608669a17548a5b142dbd4291ce4838180339c641f4ab4fa1b5d7ef44303b3b3b31485dc64bb1c6778e4640fc2bc394e9d29b523c79c294df3cfe27b9e77f0ffc6735f5f0b5d4a6deb2ba3064014ae0f4e3d6bd4ce8b6f29b789963bc9d542ba48980a80b103a0c11bba91eb5f37681ba0955c6723d7803fad7b8f8235679f4d9a36731064ff5c84b1038c7cbd73bb8ce4f4af473ba5ca96263e8ce0c056f65270fb8d4f895a845e17f05ea77177648c45b1894c2c593730dab8238ead924f7ce335f2146e08ec2bed69f4fb5d56c3ec6de5ccb245e4496f34bb0ba143bc8c9fbb8c120f3c1af91bc3be105f1078aad34c5b916b6f717022fb415ddb149eb8e33f98ae3caaac14277e9a9dd8a8caab84a3bbd0fa3bf649d1ed9fc27abdeb44fe7c979e5170dc3284040fc0b1ffbeabdd7747040b1a8720ff02ee918ff00326b90f04f872cbc0da05b691a7348d6f02e4b370cec79691b8ee73df8ade7ba30ae4fdc1c920e3b578388a9edeb4aa2d99f7b83a6b0d878537ba47ca1fb4389b5af8b12db40ad24b15ac69b586cc614bfe1c1ae434cd023b8f15e9fa55bddc77a669a284c918210331018027a804f5af44f8c7790e9fe3ed7b54b4c4778d6102c6580650cc763633df60fe66b8df84b286f881a75cdc6f90c4cf3962724b05639249f5e6beba84dac2de3b28fe363e0b112e7c5cddf4b9f596a10451d98510a2a91f30c842064120818f4ff00f55735a75f44fafc90c914c90981984b090db54871bb0dd71f2e064f51dba5fb696d65d49d2f1a486e1a35754470ccaa79191c9ce3d33d79ef8d016ba786916ccc9387063692e536c8320e428c1e70480d9ee78e86be4e0d47e2378b4e493d8c1fed685eda4bb46884db5d435d6504808c1cae46782477c719ebc45a3eae7519a6b3791679da23e5893e4ddb782aa770c9f9b39ec17ae09abd3f81ecfec7772c0d32c900558fca95417c1008258e06720f6cf3cf3546137960d2cb7304f05b96dab209309d06095e303d719e9d38aefa718f2b71676f2d3e5766650d4a49a7b9f2e169da350afb982e4312339231c0238e73f5a2c63d9712c8f70af329fddcacaa1c0231c1271c607cc467d07a5e82e63bdd6dedfec1035eca0bc36f0b8ff4bc91cc6738619c8d9d41271d701fa8caba86997b210b6ed0b95713e43ac5b01e842ff77d4f4ae98cdd3564b7dce771e58ea65de2449a8308a28dafd3cb3147226f2adf7b7166071c31c1dbd07a015c8e95e119350d4cadc47677bab5fca171fc10316ce49e40c6d3c800000d68ea0755b99e43a6cad03795b64532853c8042960b861c761c6066ae78596e34e8e29351b7db76efe4932c6c0000823e6071bbe6e0923247702bae329d385d3dfef399a76b58c1f1068074f9d2dedae23bb8e3086778589eb91b5b819e879f4da7b81599a9e950eb76715b5ec6f6da743beeaea6450ae53780c139eae7d7dbad7597fa7c26fb66fdfa95d3348552dd491fc3d77025414c9c83ec4e2b2bc4ba74105b92671333f9692c9e606404a92d9033c6f6c60f38c7b52552cd58c7d9b8ab9e73e24b5d37522b05a974895d8b818dca070377bf18acf92f24b28bca78fcdb21b50b630320727f3ef5d8eafe1898ab5ba1f2fcc1e697462e3777c0fc49c7f85735756aea6ea0580158b0c8a4edc9c8cff3635dd4ea24928b3a675e539b9b4635f787c4128be81ccb6acdba42c492849efed5b53f86a6bff0aff6b431b3c36ec209d84790a09f91b3f5f973ee2ab6897f269970d1bc24a30dc0361942f756f6c67e95e817eff64f0d5b5b691ab35bda5f230bbd28ae5e15c8e4377079e08ed9068af59c52b1e9518529539cde9657f99cada6836d73e1f1711d8cb6f70d22a8925931b179041ddee33dfef569c7e1f57d2a258ee889250b1c2c0b12e06098c90b81f30f5f4f5e35fc2b187b3b8b8b27748ad6de4bb557c32edce0b60e01c11d304727ad57f0ce9f05f5b5f436134f1ee903218d00326718c1f4e187a57973a92f79be8ce68c39a3cd739ed62486c2e6d2606596f6797218426308405e01cf3907a9039efd6bafd0af34cb7bb962de63fb526e92de4db22228c03d49dd9ce78ea3ae6aede785ad6611bcb3c85d4b1122b85909c90140e7f2f419ebcd569f4ab88adbccb78488e3667778d3cc238e83273ea083d738f4c6129c6a4544f429e1ef1bdcbb6de21b2d3c5d476803dba70efc0e7660b8e9819ce41cf5aadf159f4e8be1bddc91c117daee96325f712cafe62938c83d8608e3f419e7dedad34ebfd4acee22f31110ac33390a4e48284843960c304fb62b8af11ea3a8eb13a5a4936fb0b76e0432168cf53904f7e4fdee4679ad6961bf78a6a5a2b31fbb4d357b92f8475ed42dec0b2995a1830acdb4945cf4c9e80d7b8fc1ad759ae2e95ee16dc30ded3175dbef907f9d784efb74d3356b6810e64b75fde2be42053bf68c7aedc927bd627872ee59751822791dd0b000124f5af4dc3da2725a1ec60f359e1925257ec7d910436979addfdd6971add48e81e591d8f96ce514e5474c90a4fd6427d31421d285b6a890a5b8b17525a41185747618f9875ed9f7e338cf279686fdf42b892d1afa750d28536d264344c490a32e7d14f43ce3f2d48b55986a52329dcb1c63270501e3f78c7e56e9cf5af909424e529773cbaf539e4e6f76eff79e23fb43da4965e3d8266cedbab38e6566032df33ae4e3b92a4f7eb55fe11e9b73ae78aeca1b600bc64ce49380a106ec9fcbdfe86ba0fda36d333e8777e4955c4b0b49bb81f3060b8ea08dcdf5cf1eedf8076b0ff6adf5ccd75f6344b62825039059874efd01e075afa48d497f67a71ded6fd0f22cd4da37be2fc92eabf0ce56c798b15dc32c8d22e25560a50f7071927b7a735e65f09744fed9f1b6936eebba2f343c80f4dabf31cfe55ec5f1e75a8ecfc171e991dc25f4f7f3263c98421c2e096f97ae5b681f8f35cb7c01d2bc8bfd4eeae7746228fece576293963c8e41c7ddea3915186a92a5829b6adbd8e6705ce7b57f66450c96f6b6ed1ac71aecb7b750c842aaf462c487c1c93d39ce73cd53d6f4f5bbb9433decd6f2a26c23cb7cb619b93c75edf85743677b6d717b359c255e266692d5cafcd106da76e78e4145c9c723231dc6cd869d14f6a9bee65b65525512ded9645c64f24b739c9239c7415f32eb4ae9cb70516d9f0d59de4917cb1b2fd335e9df0ffc7d2595cd9db8b19ae1ccaaa3c96c633c65791cfb743debc99e31112c6e3615eaa07cc3fc6ba0d09d44d0cb1ce6575f9b79272bf81e95fa73a70c4d37096a99f3adb834fa9ee1e35f134f22ff0066450bdbc9796f287de815f2a08552c0f27ef7e000e6bcfbc19e0ebd8359b5ba783cb5f33700dfa7f2aebb51f026a1e239209a3befb3dba8560c172fd7a839f7f4c5767e10f0241a5db4aefa94d777853012e30039cf401463f3e79af87957861697227aeccfae547d9d2e7ada5b67ea7636538b5b589431dc0740723f338cd53d575ffb32162492cb80b1f254fb01dfe9595ac6b5e54e62b778090fe5849777247b0e3df1fe154af343d725d3ae26b4b795a32332c81407618048233ea09e9fd6bcc8c4f43139942947962f5b1e3bf125ee751d4b5149e59e3554c33ccb82c81c32f19ce76fe1f311543e04e993ea5e3ed3e2b704380e438ce3846eb820e338070475eb5a5770dcf8c753bcb3db2106d36892050c015208520edcf419f619af59f047844f86744b8902dbdaead3da88a27b68fcd4b68b3c8c81f78f05bae49ebcd7d043190c2d1e596ecf9cc3c79aa3a93d2373a5bd6b29b5d9e7b78c848d023b339321e5988e09ce140cb1c9c13cf5ab66637b7fb488cc83634788c22e38cf1920632467a9cd625c59bdadac337d99044aaade6b10a5b2013819f9b8f6f4f5ad39aed12ce196385e194c7c326d2c1c9c93b719c8cf031df1d8e7e72a559547cccae75377645a9c5ba39d2d8843203fbc270a0020818038c950c7fde3e95465b9ba4b8b3b76bc8126bd885c4b199a4dac31c856076b642f2a0f0719ebc4b79a81b60966c36b4d2f2f2b6d50371dc7fdd0b9ebff00d6ac79535359bcbb67d91471b085159989dfb831c95e400d90319e9e95bd06df91d54e339dc9751d2ee2c7554bb8e4851ade7122c8a9cb02cd9f909dbc00bf360367f88f4ac6d17565d4b519252ef736a19d24473970a4a9dd8200ce09ebe87d2badd3ccba807b69112397733444280c18270a7ae01e84763ee2b2b4ed1bfd2d5e1b6ff44f9d4c8c06e5c9c0c03edce3e9d7a57a14aafbad4d6a8eda52f7251a9d3b946f352925b6b63a4c7148f385656408be4e176aee8f39c75c9e472393d4e331d5b52d5ed45cfcb147209730b2a2c8a0ee0cebeb9e7af6cd6cae917964fe4db23471cad90c11b6040467040e3a8c13f91a94c8e64d9115784213be30aaec46dc1c673ce58f4e38f5aea8d65c8da57309ce9b8dec5af0c5a785ae744d46eaf2ddd3578637f25d4c8f85003911e3009639e71d323b9cf3f696d6faa6e77b5324b24ccdbe58c12783ce0f278078c77c607665aeb02c96e84cc925d4089ccb28f3188605429c81938ebdc13f4ab6035be8b2cb3c92324cccca490c23663b82fa670173c6091df8ac673926ee73546e51d55872df59812c715aef758d8a3b27a8206d1db9c7e55cc7867c336de25bad4c4eb2466d5502ed19323371807381d39ea7a0ae9346b4fdf492c9289448e659cbbe02ae38c7ca33818e9db9e6b634dd36db42b3bd91035c4d30646591f63842a082a029180791939e47a565cfc8e496eec4c97245aeacabe70f046857b67a75bdb4f712da32369cf07eee35de15de53b816241c81b80c12d8e6b93f06e83ff0800b2d41e37d535a957cfb5db1e20b5ca8e8d9eb9048ea391debb1d1b4afed788dead846d79730798f231650c9c0dc7249e36e01031d338aab61a94d7566f996dda27f30b245289b0037de048381b08c8ec47bf15eddc534be65c68eba7cce6b48d6ac2df43d68df5a5bdccb77762336534655e73b4ee195c1c0386e0e14f600e0e168179268d05e95b7945b2966dc198f6c000e3071f5fe75bda8e9b3dd1965b792d95543130962fba5dc71b406cf21bb1eddbad67e91a8dcdcbdddc4f206fb2c6d2aa2128a635c87ce49c83b9b273ebe99ab9cb9a2ec8ed72b2e5e5349edadb7c5a8291f6d8d8acbba631b00d953b97bfcdebe87ad562f697579752aadc41242c226042185c92abd4107392464f4fc31556df4a92ef5dbc9adee23f2ccce64073968dd89070491bb07ea081dab5a5b63e7dbd891b3cc632e5011b9776739ebdfdf39ac5da2ed737f6b2a68a0da6deeb1697937f687fa9daebbe3f2ce0f041038ce14f4f41f4af3dd4219250a905a6d7964f98cbd533ea028e4f38ce48dbdcd7a178a6ed16d9b4cb779b74670c81f871cfca7033927dfb573561aa4b049f64bcb63218b3f348e55baf195fe2c76c8fc6baa8f372dd2bf9150839fbed6e5187c39f64d235071322293b5e530825ce18719ce321bdb9cfb5703e1e8163d62dd4307fde2e48c8c722bd3fc5de31bbd434696c2dff771484fdf1c8cf5ff000cf1c5713e1fd2962d4a29656088e36ab9e30c1413f96457a5439d424ea2b36152cdc52563db2efc9d692394ac91aca5577a481b04725cf1956e9f9d63c1a06a76fac416f034677bb487f7bb44710f94061ce33824633d7a9ef02d8eb1a0c32a5a996412169dd2519661fdd031ea41c673d39e6ad1d05f5db667883a4f115f3ca465d989c75e4ed6e71f435e0534a93b4dde2722497c7b181f197edf7de0fb63a85e5bde5e4378a5bc81caaec61938e31d0678ed51fc1ad3acef747bd8eee2f3bce0319ced5dbdc807d48ea0ff0043deda6990e8ba35e5a5c2a8d42ea3751218849e5c6a47ce33800e790491cf3db15cff0087bc1e9e1d89a26266b466699016cb347bbe50db3a1ca678278f4eddeaa53787953a6ac96c60a49cdb82d0f3cd53c3dabe98f711a5dacd768cb1314dc0a2b6e3807a0fbad9ef8f4e95e95f04ed67f0da489b12ea29a68c062a42b3329db824818e472dd89e0574fe1dd26cfc508d6f24135ba38077cee9b988ce085e4e14e4f3c8f5ad6d174bb3d1354586e164b8b7725f29206e00f9304121a35007181c719f4e6ab8d72a6e9496ac7149377dff00adc9dca6a56461b532c37782fe62c0652871b8ae148dcb8523af181f4ad1b15d785ba9b6b8bb680f282def0c200f42a41e6a7ba9e2d42c6cd6cde6b296c9d632e8810e14ee03cbe319ce32339f5ab1a9789f418264fb6d9f973ba07c2cb2720f7fbc319eb8f7af2acafcb6ff0032652e4d123e77d67c08f7f1854707238f9471507877e13df41701a5b988439e9cfea31fd457a4dbdb897d3dab5ed2cf680e5b03d3ad7a31c7d6a51718bb1eccf0187ab2529446e9b0cf690436913b4855769da300e3a00054f6d77b27d9728f0c903e5654cf04100ab0efc9edcf5ebd2b3b55b797509a2b457f2d643b59875dbdf9ebf955bd37c3ceb72f2b4e0a459cc4f92c18ede377248e3ae7df1e9c53b72b94b7679d9957518fd5d21d7b77792dcdf4332456ae9218e5b88b254b8009c0c0c8c1e0923a75e6b1bfe118bab9bd7974c918bc8ac71713ed2aa397619ebf41d3038eb5a5e2ab974d76dd2e76f93246ab149c8f9f70dc0edebc7722ab406ea7b8480b881229008d080c718603079c1dbc93fad66a6e3aad99f3b69735ec73da8f87357d264966b1d3137121549f999d4f208e71920038eb8c715d5e93ab6a1a45b3cd71875c088283963271dba05ea79fa0eb53369da8d9dbde6a125fa5cdb4db4c2a1db71c123bae17a104f5f7e86b3e5f12dbeb96b05dcd6b39599b6848a5452b2631924a9dc02a9c0fa7355294aa34ac9aff00805cf4b1a17fab4fa94f059ce05c5bacc56244c6d5c9525813d318c71f91e7269fa8c9ad6a1abbc703b5b5ac4f2c862751b515b6000376f6ef9a9ac20874c759635694cf1fda7cc9547ca8792146786238cfa77aced1349b9d32d755fb54ef6f7b76af7113458c468191e3538e32083d01e18f3eaa1c92df735a56935cc4f3e95aadacf7977676f71796d238cc5b414519cee52dd777208033d7e9562e2f2d6e52c2c26cbb89809594b02acdb5704f1b8a91e839e78efb16ba9cb712bdb5d0170ce0a197246f039e076ed8fd457390cff61f1030840b881e3468f185667073d70319036fd79e95d34f5d1ee8f6a335f0add1d45b3dadb6a856d2462638dc344c0bedc94e77678fbadc75e7355754b991ee5440b2e5b99500e414da06707bedce075e7349ad689fd9725e6a104ef24d76ab8881d8aaa541da79e4ee2df37b01585652cb3407177e74f6cb89564dc70db8e4fa1fbb4a2b4defa1c2ea4a4cd6b7d5239923bc901b6965cabceab9c631c8383e9c0f4c0aab19b279a6557482eae819524df8765c7de2327183e83d38cd44f09d72c6e218de394c932ee2c9b3cc63b8b1dc0640c82714fd33c396da5c82ee404de3a9da9b8b031e4746392324fe5db39ada3076693d8d3dda706ee326f03e9e34a82237fbe39c87966820694210a3211770c658e3383d738ed5872cf69a75fc3a45cc52ba4ca51a65c9daa000090067278fa633dabaad2adee20b4b7db1174d464c47087ce0f201dcc73c8dbd78f61d2a6d77c0f632bc16f6d773c772ce13724841501c83ce3d73c0c76e71c56ae4efefb2155e65cd239cb7b3974ed48c724513e9f70a645c3ab0f2f3b48619c9c03d7dc71e9a92c0ef1431cf3c8f2b0550911f9b3c109ce4f4c7bfbd58f10c3178774326491658dbe548bcbdc779c6393d0633c7bf5f48acf44786c4dc5c4a4f9a42c913b1fbc3804e38ea474ed9e738ae79efcd7279fda4aef61b7f7cdabca89712888c0ac55d004042b6402463fdae3b7e3515a69308b5d464861307da9241b16208ff0074e586e38038e5b03ef0eb9a53a569d6f616d7d7437dd409b5b6ae000003938ea00049c1c9e94fd56e9adb5553024d35d242b0c292b294259f6f539c000648efef59bbcde87a6928c123056c2d8e97713da5ab585d19f3e798b69dccb90aa73ca024e78f6c36397691a7e9c6031ce935d5f37ef84cd180c84fdde3eeb28c038e9918c018adbf1108f486b086e6e9a27ba764431c4195a4c1c1dbfc38ec0103d6b3ac0cb641e06944cf00c390b8180d82d9c707e9cf3dab5551f2dc2ea49c9ee6e6a7a7db7847c136965a469915cea77ade7cf76399d0105805cb0ea02fca4756e3902b94d3d98e7ed5feb6dd08273bda45183b492d900e0f3d3e618eb5b6b18bdd4a797cf759ad490db50100e46793ce46f238e31f8d6c2e936b7f6705da40b696b222aa940038386c0dbc8c01d07419fce673b2bc97cc215232493dcc0bd116a3a55cdcb2adb5b21f31c300ce10b1c1c6738180470783d33c5703e24d3a78b50b89d2169cac9f30880dc467962b9ede8a39c673cd7ae78821b3b6d35a286d7fd6c414210aec92090b1605b8236b28c1ee2b8cb4bd4bc996daeadcc970c64884b10500ed001dd9eb9dc7231f434f0f88706dc4e8a156c9a389874b5d505ab08762ccc4fef4e3e55c64903a77c02413838e95a977e1bd274b90ec91278edae54ba07030182100975c11946ce3a803ae4d749a8787acbfb5ae249716cd6c845a852de5e181c12170437dee7a7cc7a1e6b35f498a1b2923f395ee6e19fcc6652484041299f4048c7b37b1adaa62a555ad74febf439aacdd4968f42e5f5f451ea40e1a2bf55219224c94381b38076818e9c7a7a5749a099ec9922b97696168b7334a41c92d9e9ed91ce3f86b22d2e34e747b6ba40308448f1925822e4e0fca3dfa0e3a0356344b3325e48cd1f94e64dde623e4b1db9c10781f2a8e8072a335c4d270e5672cdb748e67c5efabcf7816076920540311e436f3b8ee181cf43ec3bd5dd3e4d66e74995ae6c2de48883195e1251842e4b024a83b82e36e3bf419aeaac2de4ba9a2902db4fa844805a1943008a5830dd8e092437d3f1e695a433c7a74bbe512cf349244e51767ce920258638dbc8ec1bf2aba756f4d452d5052b534aecc1bfd1efd6269219edac2e4c804822529e4965cfcc793c80c4e4e31d063a6ff00866e6f2e43a4b2d949034a8924b01deacc33f3ae3823e7ed8c76f4aa3e22d36c6f750732ce6de792132868a15c82a72086001ce323db03deb8bb8f8a2da5e9b6f15ac0b7456e1ccab7083cc61bf3b770f946433608048ddec2ba61175adcbabeba1d378b49ae87afda5b2cb266d70e8cfc823073b8e78efd7a7e156d2492f57cc8cbc607ca4190a7238e9915cb6873c9abe9f6d75e55bc44117124196013272a41c1cf23a7d3f0df86f2f655c4d6714d72815652bb55436d078c93d4107ea48ed5e6be68c9f2eaefff0000a857e45cda5df73fffd9, '2017-06-01 22:14:06', 0);
INSERT INTO `projects` (`project_id`, `project_label`, `project_title`, `project_description`, `project_creator`, `project_icon`, `creation_time`, `project_active`) VALUES
(6, 'apiu', 'API Usability', 'API Usability', 1, NULL, '2017-06-16 03:01:47', 1);

-- --------------------------------------------------------

--
-- Table structure for table `str_management`
--

DROP TABLE IF EXISTS `str_management`;
CREATE TABLE IF NOT EXISTS `str_management` (
  `str_id` int(11) NOT NULL AUTO_INCREMENT,
  `str_label` varchar(500) NOT NULL,
  `str_text` varchar(1000) NOT NULL,
  `str_category` varchar(20) NOT NULL DEFAULT 'default',
  `str_lang` varchar(3) NOT NULL DEFAULT 'en',
  `str_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`str_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=155 ;

--
-- Dumping data for table `str_management`
--

INSERT INTO `str_management` (`str_id`, `str_label`, `str_text`, `str_category`, `str_lang`, `str_active`) VALUES
(1, 'Log in', 'Log in', 'default', 'en', 1),
(2, 'Username', 'Username', 'default', 'en', 1),
(3, 'Password', 'Password', 'default', 'en', 1),
(4, '#', '#', 'default', 'en', 1),
(5, 'Utilisateur', 'Utilisateur', 'default', 'en', 1),
(6, 'Evenement', 'Evenement', 'default', 'en', 1),
(7, 'Time', 'Time', 'default', 'en', 1),
(8, 'Short name', 'Short name', 'default', 'en', 1),
(9, 'Title', 'Title', 'default', 'en', 1),
(10, 'Description', 'Description', 'default', 'en', 1),
(11, 'Creator', 'Creator', 'default', 'en', 1),
(12, 'Installed projects', 'Installed projects', 'default', 'en', 1),
(13, 'Welcome', 'Welcome', 'default', 'en', 1),
(14, 'General', 'General', 'default', 'en', 1),
(15, 'Home', 'Home', 'default', 'en', 1),
(16, 'New project', 'New project', 'default', 'en', 1),
(17, 'Users', 'Users', 'default', 'en', 1),
(18, 'User groups', 'User groups', 'default', 'en', 1),
(19, 'Logs', 'Logs', 'default', 'en', 1),
(20, 'Choose project', 'Choose project', 'default', 'en', 1),
(21, 'UP', 'UP', 'default', 'en', 1),
(22, 'Log Out', 'Log Out', 'default', 'en', 1),
(23, 'No project available!', 'No project available!', 'default', 'en', 1),
(24, 'ReLiS - Revue Littéraire Systématique', 'ReLiS - Revue Littéraire Systématique', 'default', 'en', 1),
(25, 'Select', 'Select', 'default', 'en', 1),
(26, 'Select multi', 'Select multi', 'default', 'en', 1),
(27, 'Add new project', 'Add new project', 'default', 'en', 1),
(28, 'Upload configuration file', 'Upload configuration file', 'default', 'en', 1),
(29, 'Open editor', 'Open editor', 'default', 'en', 1),
(30, 'Back', 'Back', 'default', 'en', 1),
(31, 'Setup file imported', 'Setup file imported', 'default', 'en', 1),
(32, 'New database created', 'New database created', 'default', 'en', 1),
(33, 'Paper', 'Paper', 'default', 'en', 1),
(34, 'Assigned to', 'Assigned to', 'default', 'en', 1),
(35, 'Assignment mode', 'Assignment mode', 'default', 'en', 1),
(36, 'Assigned by', 'Assigned by', 'default', 'en', 1),
(37, 'Screened', 'Screened', 'default', 'en', 1),
(38, 'Screened by', 'Screened by', 'default', 'en', 1),
(39, 'Decision', 'Decision', 'default', 'en', 1),
(40, 'Exclusion criteria', 'Exclusion criteria', 'default', 'en', 1),
(41, 'Note', 'Note', 'default', 'en', 1),
(42, 'Operation type', 'Operation type', 'default', 'en', 1),
(43, 'User', 'User', 'default', 'en', 1),
(44, 'Name', 'Name', 'default', 'en', 1),
(45, 'Configuration type', 'Configuration type', 'default', 'en', 1),
(46, 'Editor location(url)', 'Editor location(url)', 'default', 'en', 1),
(47, 'Editor workspace', 'Editor workspace', 'default', 'en', 1),
(48, 'CSV  separator for import', 'CSV  separator for import', 'default', 'en', 1),
(49, 'CSV separator for export', 'CSV separator for export', 'default', 'en', 1),
(50, 'Screening comfict type', 'Screening comfict type', 'default', 'en', 1),
(51, 'import papers activated', 'import papers activated', 'default', 'en', 1),
(52, 'assign papers activated', 'assign papers activated', 'default', 'en', 1),
(53, 'Screening activated', 'Screening activated', 'default', 'en', 1),
(54, 'Screening result activated', 'Screening result activated', 'default', 'en', 1),
(55, 'Screening validation activated', 'Screening validation activated', 'default', 'en', 1),
(56, 'Classification activated', 'Classification activated', 'default', 'en', 1),
(57, 'Excluded by', 'Excluded by', 'default', 'en', 1),
(58, 'Key', 'Key', 'default', 'en', 1),
(59, 'Author', 'Author', 'default', 'en', 1),
(60, 'Value', 'Value', 'default', 'en', 1),
(61, 'Label', 'Label', 'default', 'en', 1),
(62, 'Text', 'Text', 'default', 'en', 1),
(63, 'Language', 'Language', 'default', 'en', 1),
(64, 'Abreviation', 'Abreviation', 'default', 'en', 1),
(65, 'Full name', 'Full name', 'default', 'en', 1),
(66, 'Year', 'Year', 'default', 'en', 1),
(67, 'Study', 'Study', 'default', 'en', 1),
(68, 'Validation', 'Validation', 'default', 'en', 1),
(69, 'Contribution', 'Contribution', 'default', 'en', 1),
(70, 'Détection d artéfact', 'Détection d artéfact', 'default', 'en', 1),
(71, 'Sources de données', 'Sources de données', 'default', 'en', 1),
(72, 'Stade de contribution', 'Stade de contribution', 'default', 'en', 1),
(73, 'Update project', 'Update project', 'default', 'en', 1),
(74, 'Go back to the project', 'Go back to the project', 'default', 'en', 1),
(75, 'Go to the project', 'Go to the project', 'default', 'en', 1),
(76, 'View', 'View', 'default', 'en', 1),
(77, 'Edit', 'Edit', 'default', 'en', 1),
(78, 'Uninstall', 'Uninstall', 'default', 'en', 1),
(79, 'Transformation name', 'Transformation name', 'default', 'en', 1),
(80, 'Domain', 'Domain', 'default', 'en', 1),
(81, 'Transformation language', 'Transformation language', 'default', 'en', 1),
(82, 'Source language', 'Source language', 'default', 'en', 1),
(83, 'Target language', 'Target language', 'default', 'en', 1),
(84, 'Scope', 'Scope', 'default', 'en', 1),
(85, 'Email', 'Email', 'default', 'en', 1),
(86, 'Usergroup', 'Usergroup', 'default', 'en', 1),
(87, 'Created by', 'Created by', 'default', 'en', 1),
(88, 'Creation time', 'Creation time', 'default', 'en', 1),
(89, 'Project', 'Project', 'default', 'en', 1),
(90, 'User role', 'User role', 'default', 'en', 1),
(91, 'Added by', 'Added by', 'default', 'en', 1),
(92, 'Added time', 'Added time', 'default', 'en', 1),
(93, 'Delete', 'Delete', 'default', 'en', 1),
(94, 'Action', 'Action', 'default', 'en', 1),
(95, 'Add new', 'Add new', 'default', 'en', 1),
(96, 'Close', 'Close', 'default', 'en', 1),
(97, 'List of users', 'List of users', 'default', 'en', 1),
(98, 'Search for...', 'Search for...', 'default', 'en', 1),
(99, 'Add new user', 'Add new user', 'default', 'en', 1),
(100, 'Confirmation', 'Confirmation', 'default', 'en', 1),
(101, 'Picture', 'Picture', 'default', 'en', 1),
(102, 'Projects', 'Projects', 'default', 'en', 1),
(103, 'Error', 'Error', 'default', 'en', 1),
(104, 'Success', 'Success', 'default', 'en', 1),
(105, 'Edit user informations', 'Edit user informations', 'default', 'en', 1),
(106, 'User detail', 'User detail', 'default', 'en', 1),
(107, 'Edit user', 'Edit user', 'default', 'en', 1),
(108, 'Remove picture', 'Remove picture', 'default', 'en', 1),
(109, 'Success - picture removed', 'Success - picture removed', 'default', 'en', 1),
(110, 'User active', 'User active', 'default', 'en', 1),
(111, 'Configuration_managment', 'Configuration_managment', 'default', 'en', 1),
(112, 'List of usergroups', 'List of usergroups', 'default', 'en', 1),
(113, 'Add user', 'Add user', 'default', 'en', 1),
(114, 'Error : Page "" not found!', 'Error : Page "" not found!', 'default', 'en', 1),
(115, 'Users New', 'Users New', 'default', 'en', 1),
(116, ' Action not available!  ', ' Action not available!  ', 'default', 'en', 1),
(117, 'Users list', 'Users list', 'default', 'en', 1),
(118, 'List of Logs', 'List of Logs', 'default', 'en', 1),
(119, 'List usergroups', 'List usergroups', 'default', 'en', 1),
(120, 'Error : Page "project" not found!', 'Error : Page "project" not found!', 'default', 'en', 1),
(121, 'List of projects', 'List of projects', 'default', 'en', 1),
(122, 'Usergroups', 'Usergroups', 'default', 'en', 1),
(123, 'Users Projects', 'Users Projects', 'default', 'en', 1),
(124, 'List of projects and users working on', 'List of projects and users working on', 'default', 'en', 1),
(125, 'List of ', 'List of ', 'default', 'en', 1),
(126, 'Users admin', 'Users admin', 'default', 'en', 1),
(127, 'Add a new user', 'Add a new user', 'default', 'en', 1),
(128, 'Error : Page "users" not found!', 'Error : Page "users" not found!', 'default', 'en', 1),
(129, 'Add new user to the project', 'Add new user to the project', 'default', 'en', 1),
(130, 'Error : Page "user_project" not found!', 'Error : Page "user_project" not found!', 'default', 'en', 1),
(131, 'Edit user admin', 'Edit user admin', 'default', 'en', 1),
(132, 'Add a new project', 'Add a new project', 'default', 'en', 1),
(133, 'Icon', 'Icon', 'default', 'en', 1),
(134, 'Uninstall the project : ', 'Uninstall the project : ', 'default', 'en', 1),
(135, 'Cancel', 'Cancel', 'default', 'en', 1),
(136, 'Continue to uninstall', 'Continue to uninstall', 'default', 'en', 1),
(137, 'Continue uninstall', 'Continue uninstall', 'default', 'en', 1),
(138, 'Error : Page "project" not found! IN OLD', 'Error : Page "project" not found! IN OLD', 'default', 'en', 1),
(139, 'Edit project ', 'Edit project ', 'default', 'en', 1),
(140, 'Add a new user project', 'Add a new user project', 'default', 'en', 1),
(141, 'Users project', 'Users project', 'default', 'en', 1),
(142, 'Add User project', 'Add User project', 'default', 'en', 1),
(143, 'Add a project to the user', 'Add a project to the user', 'default', 'en', 1),
(144, 'Edit project for user', 'Edit project for user', 'default', 'en', 1),
(145, 'Project  uninstalled !', 'Project  uninstalled !', 'default', 'en', 1),
(146, 'Back to the list of projects', 'Back to the list of projects', 'default', 'en', 1),
(147, 'Project Project test 4 uninstalled !', 'Project Project test 4 uninstalled !', 'default', 'en', 1),
(148, 'Add a project to the user ~current_parent_name~', 'Add a project to the user ~current_parent_name~', 'default', 'en', 1),
(149, 'Add a project to the user : ~current_parent_name~', 'Add a project to the user : ~current_parent_name~', 'default', 'en', 1),
(150, 'Project Project test 2 uninstalled !', 'Project Project test 2 uninstalled !', 'default', 'en', 1),
(151, 'Abbreviation', 'Abbreviation', 'default', 'en', 1),
(152, 'Project already installed', 'Project already installed', 'default', 'en', 1),
(153, 'Error : Page "assignment_screen" not found!', 'Error : Page "assignment_screen" not found!', 'default', 'en', 1),
(154, 'Error : Page "screening_validate" not found!', 'Error : Page "screening_validate" not found!', 'default', 'en', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usergroup`
--

DROP TABLE IF EXISTS `usergroup`;
CREATE TABLE IF NOT EXISTS `usergroup` (
  `usergroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `usergroup_name` varchar(50) NOT NULL,
  `usergroup_description` varchar(50) NOT NULL,
  `usergroup_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`usergroup_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `usergroup`
--

INSERT INTO `usergroup` (`usergroup_id`, `usergroup_name`, `usergroup_description`, `usergroup_active`) VALUES
(1, 'Super Admin', 'Super Admin', 1),
(2, 'Project Admin', 'Project Admin', 1),
(3, 'Reviewer', 'Reviewer', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userproject`
--

DROP TABLE IF EXISTS `userproject`;
CREATE TABLE IF NOT EXISTS `userproject` (
  `userproject_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `user_role` enum('Reviewer','Project admin','Guest') NOT NULL DEFAULT 'Reviewer',
  `added_by` int(11) NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userproject_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`userproject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `userproject`
--

INSERT INTO `userproject` (`userproject_id`, `user_id`, `project_id`, `user_role`, `added_by`, `add_time`, `userproject_active`) VALUES
(1, 4, 1, 'Reviewer', 1, '2017-06-16 04:42:47', 1),
(2, 4, 6, 'Reviewer', 1, '2017-06-16 04:42:52', 1),
(3, 3, 1, 'Reviewer', 1, '2017-06-16 04:43:44', 1),
(4, 2, 6, 'Reviewer', 1, '2017-06-16 04:44:03', 1),
(5, 5, 6, 'Reviewer', 1, '2017-06-16 04:44:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_username` varchar(20) NOT NULL,
  `user_mail` varchar(100) DEFAULT NULL,
  `user_usergroup` int(11) NOT NULL,
  `user_password` varchar(35) DEFAULT NULL,
  `user_picture` longblob,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `creation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_state` int(2) NOT NULL DEFAULT '0',
  `user_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_username`, `user_mail`, `user_usergroup`, `user_password`, `user_picture`, `created_by`, `creation_time`, `user_state`, `user_active`) VALUES
(1, 'Admin', 'admin', '', 1, '0192023a7bbd73250516f069df18b500', '', 1, '2017-06-16 04:31:50', 1, 1),
(2, 'Alice', 'alice', '', 3, '7abdccbea8473767e91378e37850d296', '', 1, '2017-06-16 04:31:50', 1, 1),
(3, 'Bob', 'bob', '', 3, '202cb962ac59075b964b07152d234b70', '', 1, '2017-06-16 04:31:50', 1, 1),
(4, 'Eve', 'eve', '', 3, '202cb962ac59075b964b07152d234b70', '', 1, '2017-06-16 04:31:50', 1, 1),
(5, 'Brice', 'brice', '', 2, '202cb962ac59075b964b07152d234b70', '', 1, '2017-06-16 04:31:50', 1, 1);
--
-- Database: `relis_dev_apiu`
--
CREATE DATABASE `relis_dev_apiu` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `relis_dev_apiu`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignation`(_assigned_id INT , _assigned_paper_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205) , _assigned_by INT)
BEGIN
START TRANSACTION;
INSERT INTO assigned (assigned_paper_id , assigned_user_id , assigned_note , assigned_by) VALUES (_assigned_paper_id , _assigned_user_id , _assigned_note , _assigned_by);
SELECT assigned_id AS id_value FROM assigned WHERE assigned_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignment_screen`(_assignment_id INT , _paper_id INT , _user_id INT , _note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_mode  VARCHAR(35) , _assigned_by INT , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO assignment_screen (paper_id , user_id , note , assignment_type , assignment_mode , assigned_by , screening_done) VALUES (_paper_id , _user_id , _note , _assignment_type , _assignment_mode , _assigned_by , _screening_done);
SELECT assignment_id AS id_value FROM assignment_screen WHERE assignment_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignment_screen_validate`(_assignment_id INT , _paper_id INT , _user_id INT , _note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_mode  VARCHAR(35) , _assigned_by INT , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO assignment_screen_validate (paper_id , user_id , note , assignment_type , assignment_mode , assigned_by , screening_done) VALUES (_paper_id , _user_id , _note , _assignment_type , _assignment_mode , _assigned_by , _screening_done);
SELECT assignment_id AS id_value FROM assignment_screen_validate WHERE assignment_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_author`(_author_id INT , _author_name  VARCHAR(55) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
INSERT INTO author (author_name , author_desc , author_picture) VALUES (_author_name , _author_desc , _author_picture);
SELECT author_id AS id_value FROM author WHERE author_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_classification`(_class_id INT , _class_paper_id INT , _study INT , _validation  VARCHAR(105) , _contribution INT , _artefact  VARCHAR(105) , _data INT)
BEGIN
START TRANSACTION;
INSERT INTO classification (class_paper_id , study , validation , contribution , artefact , data) VALUES (_class_paper_id , _study , _validation , _contribution , _artefact , _data);
SELECT class_id AS id_value FROM classification WHERE class_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_config`(_config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
INSERT INTO config (config_type , editor_url , editor_generated_path , csv_field_separator , csv_field_separator_export , screening_screening_conflict_resolution , screening_conflict_type , import_papers_on , assign_papers_on , screening_on , screening_result_on , screening_validation_on , classification_on) VALUES (_config_type , _editor_url , _editor_generated_path , _csv_field_separator , _csv_field_separator_export , _screening_screening_conflict_resolution , _screening_conflict_type , _import_papers_on , _assign_papers_on , _screening_on , _screening_result_on , _screening_validation_on , _classification_on);
SELECT config_id AS id_value FROM config WHERE config_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_exclusion`(_exclusion_id INT , _exclusion_paper_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205) , _exclusion_by INT)
BEGIN
START TRANSACTION;
INSERT INTO exclusion (exclusion_paper_id , exclusion_criteria , exclusion_note , exclusion_by) VALUES (_exclusion_paper_id , _exclusion_criteria , _exclusion_note , _exclusion_by);
SELECT exclusion_id AS id_value FROM exclusion WHERE exclusion_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_exclusioncrieria`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
INSERT INTO ref_exclusioncrieria (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_exclusioncrieria WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_operations`(_operation_id INT , _operation_code  VARCHAR(25) , _operation_type  VARCHAR(25) , _operation_desc  VARCHAR(205) , _user_id INT)
BEGIN
START TRANSACTION;
INSERT INTO operations (operation_code , operation_type , operation_desc , user_id) VALUES (_operation_code , _operation_type , _operation_desc , _user_id);
SELECT operation_id AS id_value FROM operations WHERE operation_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_paper`(_id INT , _added_by INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _doi  VARCHAR(205) , _year INT , _venueId INT , _preview LONGTEXT , _bibtex LONGTEXT , _abstract LONGTEXT , _papers_sources INT , _search_strategy INT)
BEGIN
START TRANSACTION;
INSERT INTO paper (added_by , bibtexKey , title , doi , year , venueId , preview , bibtex , abstract , papers_sources , search_strategy) VALUES (_added_by , _bibtexKey , _title , _doi , _year , _venueId , _preview , _bibtex , _abstract , _papers_sources , _search_strategy);
SELECT id AS id_value FROM paper WHERE id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_papers`(_id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _screening_status  VARCHAR(25) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO paper (bibtexKey , title , preview , bibtex , abstract , doi , screening_status , venueId , paper_excluded) VALUES (_bibtexKey , _title , _preview , _bibtex , _abstract , _doi , _screening_status , _venueId , _paper_excluded);
SELECT id AS id_value FROM paper WHERE id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_papers_sources`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
INSERT INTO ref_papers_sources (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_papers_sources WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_paper_author`(_paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
INSERT INTO paperauthor (paperId , authorId) VALUES (_paperId , _authorId);
SELECT paperauthor_id AS id_value FROM paperauthor WHERE paperauthor_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_contribution`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_contribution (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_contribution WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_exclusioncrieria`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO zref_exclusioncrieria (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM zref_exclusioncrieria WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_sources_de_donnees`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_sources_de_donnees`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_sources_de_donnees (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_sources_de_donnees WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_stade_de_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_stade_de_contribution`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_stade_de_contribution (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_stade_de_contribution WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_study`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_study`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_study (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_study WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screening`(_screening_id INT , _paper_id INT , _user_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205) , _assignment_id INT)
BEGIN
START TRANSACTION;
INSERT INTO screening (paper_id , user_id , decision , exclusion_criteria , note , assignment_id) VALUES (_paper_id , _user_id , _decision , _exclusion_criteria , _note , _assignment_id);
SELECT screening_id AS id_value FROM screening WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screening_validate`(_screening_id INT , _paper_id INT , _user_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205) , _assignment_id INT)
BEGIN
START TRANSACTION;
INSERT INTO screening_validate (paper_id , user_id , decision , exclusion_criteria , note , assignment_id) VALUES (_paper_id , _user_id , _decision , _exclusion_criteria , _note , _assignment_id);
SELECT screening_id AS id_value FROM screening_validate WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_search_strategy`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
INSERT INTO ref_search_strategy (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_search_strategy WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_stade`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_stade`(_stade_id INT , _parent_field_id INT , _stade INT)
BEGIN
START TRANSACTION;
INSERT INTO stade (parent_field_id , stade) VALUES (_parent_field_id , _stade);
SELECT stade_id AS id_value FROM stade WHERE stade_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_str_mng`(_str_id INT , _str_label  VARCHAR(405) , _str_text  VARCHAR(805) , _str_lang  VARCHAR(8) , _str_category  VARCHAR(23))
BEGIN
START TRANSACTION;
INSERT INTO str_management (str_label , str_text , str_lang , str_category) VALUES (_str_label , _str_text , _str_lang , _str_category);
SELECT str_id AS id_value FROM str_management WHERE str_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_venue`(_venue_id INT , _venue_abbreviation  VARCHAR(25) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
INSERT INTO venue (venue_abbreviation , venue_fullName , venue_year , venue_volume , venue_totalNumPapers) VALUES (_venue_abbreviation , _venue_fullName , _venue_year , _venue_volume , _venue_totalNumPapers);
SELECT venue_id AS id_value FROM venue WHERE venue_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_list`(IN  source  VARCHAR(200), IN  condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select count(*) as nombre from  ',source ,'   WHERE 1=1  ', condition_stat );
PREPARE stmt FROM @query;
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;
END$$

DROP PROCEDURE IF EXISTS `count_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM paper WHERE paper_active=1   AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_assigned`(IN  _user_id  INT,IN _search VARCHAR(100))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM view_paper_assigned WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_class`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	SELECT count(*) as nbr FROM paper WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
	COMMIT;
	END$$

DROP PROCEDURE IF EXISTS `count_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_pending`(IN _search VARCHAR(100))
BEGIN
		START TRANSACTION;
		 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
		SELECT count(*) as nbr FROM view_paper_pending WHERE paper_active=1 AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
		COMMIT;
		END$$

DROP PROCEDURE IF EXISTS `count_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_processed`(IN _search VARCHAR(100))
BEGIN
				START TRANSACTION;
				 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
				SELECT count(*) as nbr FROM view_paper_processed WHERE paper_active=1  AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
				COMMIT;
				END$$

DROP PROCEDURE IF EXISTS `exclude_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `exclude_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 1  WHERE id = _paper_id ;
  COMMIT;
 END$$

DROP PROCEDURE IF EXISTS `get_assignations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_assignations`(_paperId INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned WHERE (assigned_paper_id = _paperId AND assigned_active=1);
COMMIT; 
END$$

DROP PROCEDURE IF EXISTS `get_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_author`(IN  _start_by  INT, IN  _range  INT, IN  _search  VARCHAR(100))
BEGIN
START TRANSACTION;
SET @search_author_name := CONCAT('%',_search,'%') ;  SET @search_author_desc := CONCAT('%',_search,'%') ; 
SELECT  author_id , author_name , author_desc FROM author
WHERE author_active=1  AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC LIMIT _start_by , _range;	
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classifications`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classifications`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * 
FROM classification 
WHERE (class_paper_id = _paperId AND class_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_paper`( _classificationId  INT)
BEGIN
START TRANSACTION;
SELECT class_paper_id
FROM classification 
WHERE (class_id = _classificationId);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_scheme`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_scheme`()
BEGIN
START TRANSACTION;
SELECT * FROM classification_scheme 
WHERE (scheme_active=1) ORDER BY field_order ASC;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_configuration`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_configuration`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignation`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned
WHERE assigned_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignment_screen`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assignment_screen
WHERE assignment_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignment_screen_validate`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assignment_screen_validate
WHERE assignment_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_author`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM author
WHERE author_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_classification`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM classification
WHERE class_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_config`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_exclusion`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion
WHERE exclusion_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_exclusioncrieria`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM ref_exclusioncrieria
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_operations`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM operations
WHERE operation_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_paper`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM paper
WHERE id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_papers`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paper
WHERE id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_papers_sources`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM ref_papers_sources
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_paper_author`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paperauthor
WHERE paperauthor_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_contribution`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_contribution
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_exclusioncrieria`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM zref_exclusioncrieria
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_sources_de_donnees`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_sources_de_donnees`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_sources_de_donnees
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_stade_de_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_stade_de_contribution`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_stade_de_contribution
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_study`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_study`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_study
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screen`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM screening_paper
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screening`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM screening
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screening_validate`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM screening_validate
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_search_strategy`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM ref_search_strategy
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_stade`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_stade`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM stade
WHERE stade_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_str_mng`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM str_management
WHERE str_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_venue`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM venue
WHERE venue_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list`(IN  _source  VARCHAR(100), IN  _fields  VARCHAR(1000), IN  _condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select ',_fields,' from  ',_source ,'   WHERE 1=1   ', _condition_stat );
 PREPARE stmt FROM @query;
 EXECUTE stmt;
 DEALLOCATE PREPARE stmt; 
END$$

DROP PROCEDURE IF EXISTS `get_list_all_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_all_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignation`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC ;
ELSE
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignments`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignments`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase     ORDER BY screening_id ASC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase     ORDER BY screening_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignment_screen`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC ;
ELSE
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignment_screen_validate`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assignment_screen_validate
WHERE assignment_active=1   ORDER BY assignment_id DESC ;
ELSE
SELECT * FROM assignment_screen_validate
WHERE assignment_active=1   ORDER BY assignment_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_author_name := CONCAT('%',TRIM(_search),'%') ;  SET @search_author_desc := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC ;
ELSE
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_authors`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_authors`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM author
WHERE author_active=1     ORDER BY author_name ASC ;
ELSE
SELECT * FROM author
WHERE author_active=1     ORDER BY author_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_classification`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC ;
ELSE
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_config`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC ;
ELSE
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_decisions`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_decisions`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screen_decison
WHERE decision_active=1     ORDER BY screening_id ASC ;
ELSE
SELECT * FROM screen_decison
WHERE decision_active=1     ORDER BY screening_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_excluded_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_excluded_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Excluded'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Excluded'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_exclusion`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC ;
ELSE
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_exclusioncrieria`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM ref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_included_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_included_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Included'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Included'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_my_assignments`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_my_assignments`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20) ,IN  _user_id   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_id ASC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_my_screenings`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_my_screenings`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20) ,IN  _user_id   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_time DESC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_time DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_operations`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM operations
WHERE operation_active=1   ORDER BY operation_id DESC ;
ELSE
SELECT * FROM operations
WHERE operation_active=1   ORDER BY operation_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _paper_excluded   VARCHAR(2))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND paper_excluded = _paper_excluded   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND paper_excluded = _paper_excluded   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_assigned`(IN  _user_id  INT,IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id)    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND  (assigned_user_id = _user_id)      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_class`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500),IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	IF _range < 1 THEN
	SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting' AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_pending`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_pending
WHERE paper_active=1  AND classification_status <> 'Waiting'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_pending
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_processed`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'     AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_screen`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(10))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase     ORDER BY id ASC ;
ELSE
SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase     ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_screen_per_status`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_screen_per_status`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(10) ,IN  _screening_status   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase  AND screening_status = _screening_status     ORDER BY id ASC ;
ELSE
SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase  AND screening_status = _screening_status     ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_sources`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM ref_papers_sources
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_papers_sources
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_paper_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC ;
ELSE
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_pending_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_pending_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Pending'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Pending'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_contribution`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_contribution
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_contribution
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_exclusioncrieria`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_sources_de_donnees`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_sources_de_donnees`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_sources_de_donnees
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_sources_de_donnees
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_stade_de_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_stade_de_contribution`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_stade_de_contribution
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_stade_de_contribution
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_study`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_study`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_study
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_study
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screening`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC ;
ELSE
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screenings`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screenings`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase     ORDER BY screening_time DESC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase     ORDER BY screening_time DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screening_validate`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM screening_validate
WHERE screening_active=1   ORDER BY screening_id DESC ;
ELSE
SELECT * FROM screening_validate
WHERE screening_active=1   ORDER BY screening_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screen_phases`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screen_phases`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_phase_title := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM screen_phase
WHERE screen_phase_active=1   AND (  (phase_title LIKE  @search_phase_title)  )    ORDER BY screen_phase_order ASC ;
ELSE
SELECT * FROM screen_phase
WHERE screen_phase_active=1   AND (  (phase_title LIKE  @search_phase_title)  )    ORDER BY screen_phase_order ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_search_strategy`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM ref_search_strategy
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_search_strategy
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_stade`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_stade`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM stade
WHERE stade_active=1   ORDER BY stade_id ASC ;
ELSE
SELECT * FROM stade
WHERE stade_active=1   ORDER BY stade_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_str_mng`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
 SET @search_str_text := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC ;
ELSE
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_venue`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_venue_abbreviation := CONCAT('%',TRIM(_search),'%') ;  SET @search_venue_fullName := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC ;
ELSE
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_venues`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_venues`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_venue_abbreviation := CONCAT('%',TRIM(_search),'%') ;  SET @search_venue_fullName := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )    ORDER BY venue_abbreviation ASC ;
ELSE
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )    ORDER BY venue_abbreviation ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_paper_exclusion_info`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_paper_exclusion_info`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion WHERE (exclusion_paper_id = _paperId AND exclusion_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_table`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_table`( _configId  VARCHAR(100))
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE (reftab_label = _configId AND reftab_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_tables_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_tables_list`()
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE reftab_active=1 order by  reftab_desc;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_value`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_value`(IN  _table  VARCHAR(100), IN  _id  VARCHAR(100), IN  _field  VARCHAR(100), IN  _table_id  VARCHAR(100))
BEGIN
SET @query = CONCAT('Select ',_field,' from  ',_table ,'   WHERE ', _table_id, ' = ', _id );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_result_count`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_result_count`(IN  _fields  VARCHAR(100))
BEGIN
SET @query = CONCAT('SELECT ',_fields,' AS field,count(*) AS nombre from classification,paper WHERE class_paper_id=id  AND paper_excluded = 0	 AND  paper_active=1 AND class_active=1 group by  ',_fields );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_row`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_row`(IN  source  VARCHAR(100), IN  source_id  VARCHAR(100), IN  id_value  VARCHAR(100))
BEGIN
SET @query = CONCAT("Select * from  ",source ,"  WHERE ", source_id ," = '",id_value,"'");
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_screen_phase_detail`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_screen_phase_detail`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM screen_phase
WHERE screen_phase_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_string`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_string`(IN  _text  VARCHAR(500), IN  _category  VARCHAR(30), IN  _lang  VARCHAR(3))
BEGIN
START TRANSACTION;
SELECT str_id, str_text FROM str_management WHERE str_active=1 AND str_label = _text AND str_category = _category AND str_lang = _lang ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `include_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `include_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 0  WHERE id = _paper_id ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `new_assignment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_assignment`(_screening_id INT , _assigned_by INT , _assignment_mode  VARCHAR(35) , _paper_id INT , _user_id INT , _assignment_type  VARCHAR(25) , _assignment_role  VARCHAR(20) , _screening_phase INT , _assignment_note  VARCHAR(205))
BEGIN
START TRANSACTION;
INSERT INTO screening_paper (assigned_by , assignment_mode , paper_id , user_id , assignment_type , assignment_role , screening_phase , assignment_note) VALUES (_assigned_by , _assignment_mode , _paper_id , _user_id , _assignment_type , _assignment_role , _screening_phase , _assignment_note);
SELECT screening_id AS id_value FROM screening_paper WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `new_decision`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_decision`(_decison_id INT , _paper_id INT , _screening_decision  VARCHAR(20) , _screening_phase INT)
BEGIN
START TRANSACTION;
INSERT INTO screen_decison (paper_id , screening_decision , screening_phase) VALUES (_paper_id , _screening_decision , _screening_phase);
SELECT decison_id AS id_value FROM screen_decison WHERE decison_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignation`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assigned SET assigned_active=0
WHERE assigned_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignment_screen`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assignment_screen SET assignment_active=0
WHERE assignment_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignment_screen_validate`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assignment_screen_validate SET assignment_active=0
WHERE assignment_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE author SET author_active=0
WHERE author_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_classification`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE classification SET class_active=0
WHERE class_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_config`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE config SET config_active=0
WHERE config_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_exclusion`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE exclusion SET exclusion_active=0
WHERE exclusion_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_exclusioncrieria`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_exclusioncrieria SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_operations`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE operations SET operation_active=0
WHERE operation_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_paper`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paper SET paper_active=0
WHERE id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_papers`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paper SET paper_active=0
WHERE id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_papers_sources`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_papers_sources SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_paper_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paperauthor SET paperauthor_active=0
WHERE paperauthor_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_contribution`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_contribution SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_exclusioncrieria`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE zref_exclusioncrieria SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_sources_de_donnees`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_sources_de_donnees`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_sources_de_donnees SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_stade_de_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_stade_de_contribution`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_stade_de_contribution SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_study`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_study`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_study SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screen`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening_paper SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screening`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screening_validate`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening_validate SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screen_phase`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screen_phase`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screen_phase SET screen_phase_active=0
WHERE screen_phase_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_search_strategy`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_search_strategy SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_stade`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_stade`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE stade SET stade_active=0
WHERE stade_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_str_mng`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE str_management SET str_active=0
WHERE str_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_venue`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE venue SET venue_active=0
WHERE venue_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignation`(_element_id INT , _assigned_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  assigned SET assigned_id = _assigned_id , assigned_user_id = _assigned_user_id , assigned_note = _assigned_note
WHERE (assigned_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment`(_element_id INT , _screening_id INT , _paper_id INT , _user_id INT , _assignment_note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_role  VARCHAR(20) , _screening_phase INT)
BEGIN
START TRANSACTION;
UPDATE  screening_paper SET screening_id = _screening_id , paper_id = _paper_id , user_id = _user_id , assignment_note = _assignment_note , assignment_type = _assignment_type , assignment_role = _assignment_role , screening_phase = _screening_phase
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment_screen`(_element_id INT , _assignment_id INT , _user_id INT , _note  VARCHAR(205) , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  assignment_screen SET assignment_id = _assignment_id , user_id = _user_id , note = _note , screening_done = _screening_done
WHERE (assignment_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment_screen_validate`(_element_id INT , _assignment_id INT , _user_id INT , _note  VARCHAR(205) , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  assignment_screen_validate SET assignment_id = _assignment_id , user_id = _user_id , note = _note , screening_done = _screening_done
WHERE (assignment_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_author`(_element_id INT , _author_id INT , _author_name  VARCHAR(55) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
UPDATE  author SET author_id = _author_id , author_name = _author_name , author_desc = _author_desc , author_picture = _author_picture
WHERE (author_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_classification`(_element_id INT , _class_id INT , _class_paper_id INT , _study INT , _validation  VARCHAR(105) , _contribution INT , _artefact  VARCHAR(105) , _data INT)
BEGIN
START TRANSACTION;
UPDATE  classification SET class_id = _class_id , class_paper_id = _class_paper_id , study = _study , validation = _validation , contribution = _contribution , artefact = _artefact , data = _data
WHERE (class_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_config`(_element_id INT , _config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , config_type = _config_type , editor_url = _editor_url , editor_generated_path = _editor_generated_path , csv_field_separator = _csv_field_separator , csv_field_separator_export = _csv_field_separator_export , screening_screening_conflict_resolution = _screening_screening_conflict_resolution , screening_conflict_type = _screening_conflict_type , import_papers_on = _import_papers_on , assign_papers_on = _assign_papers_on , screening_on = _screening_on , screening_result_on = _screening_result_on , screening_validation_on = _screening_validation_on , classification_on = _classification_on
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_configuration`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_configuration`(_element_id INT , _config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on INT , _screening_on INT , _assign_papers_on INT , _screening_result_on INT , _screening_validation_on INT , _classification_on INT , _source_papers_on INT , _search_strategy_on INT)
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , config_type = _config_type , editor_url = _editor_url , editor_generated_path = _editor_generated_path , csv_field_separator = _csv_field_separator , csv_field_separator_export = _csv_field_separator_export , screening_screening_conflict_resolution = _screening_screening_conflict_resolution , screening_conflict_type = _screening_conflict_type , import_papers_on = _import_papers_on , screening_on = _screening_on , assign_papers_on = _assign_papers_on , screening_result_on = _screening_result_on , screening_validation_on = _screening_validation_on , classification_on = _classification_on , source_papers_on = _source_papers_on , search_strategy_on = _search_strategy_on
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_exclusion`(_element_id INT , _exclusion_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  exclusion SET exclusion_id = _exclusion_id , exclusion_criteria = _exclusion_criteria , exclusion_note = _exclusion_note
WHERE (exclusion_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_exclusioncrieria`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
UPDATE  ref_exclusioncrieria SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_operations`(_element_id INT , _operation_id INT , _operation_desc  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  operations SET operation_id = _operation_id , operation_desc = _operation_desc
WHERE (operation_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_paper`(_element_id INT , _id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _doi  VARCHAR(205) , _year INT , _venueId INT , _preview LONGTEXT , _bibtex LONGTEXT , _abstract LONGTEXT , _papers_sources INT , _search_strategy INT)
BEGIN
START TRANSACTION;
UPDATE  paper SET id = _id , bibtexKey = _bibtexKey , title = _title , doi = _doi , year = _year , venueId = _venueId , preview = _preview , bibtex = _bibtex , abstract = _abstract , papers_sources = _papers_sources , search_strategy = _search_strategy
WHERE (id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_papers`(_element_id INT , _id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  paper SET id = _id , bibtexKey = _bibtexKey , title = _title , preview = _preview , bibtex = _bibtex , abstract = _abstract , doi = _doi , venueId = _venueId , paper_excluded = _paper_excluded
WHERE (id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_papers_sources`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
UPDATE  ref_papers_sources SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_paper_author`(_element_id INT , _paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
UPDATE  paperauthor SET paperauthor_id = _paperauthor_id , paperId = _paperId , authorId = _authorId
WHERE (paperauthor_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_contribution`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_contribution SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_exclusioncrieria`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  zref_exclusioncrieria SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_sources_de_donnees`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_sources_de_donnees`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_sources_de_donnees SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_stade_de_contribution`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_stade_de_contribution`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_stade_de_contribution SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_study`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_study`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_study SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screening`(_element_id INT , _screening_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  screening SET screening_id = _screening_id , decision = _decision , exclusion_criteria = _exclusion_criteria , note = _note
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screening_validate`(_element_id INT , _screening_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  screening_validate SET screening_id = _screening_id , decision = _decision , exclusion_criteria = _exclusion_criteria , note = _note
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_search_strategy`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
UPDATE  ref_search_strategy SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_stade`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_stade`(_element_id INT , _stade_id INT , _parent_field_id INT , _stade INT)
BEGIN
START TRANSACTION;
UPDATE  stade SET stade_id = _stade_id , parent_field_id = _parent_field_id , stade = _stade
WHERE (stade_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_str_mng`(_element_id INT , _str_id INT , _str_text  VARCHAR(805))
BEGIN
START TRANSACTION;
UPDATE  str_management SET str_id = _str_id , str_text = _str_text
WHERE (str_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_venue`(_element_id INT , _venue_id INT , _venue_abbreviation  VARCHAR(25) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
UPDATE  venue SET venue_id = _venue_id , venue_abbreviation = _venue_abbreviation , venue_fullName = _venue_fullName , venue_year = _venue_year , venue_volume = _venue_volume , venue_totalNumPapers = _venue_totalNumPapers
WHERE (venue_id = _element_id);
COMMIT;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assigned`
--

DROP TABLE IF EXISTS `assigned`;
CREATE TABLE IF NOT EXISTS `assigned` (
  `assigned_id` int(11) NOT NULL AUTO_INCREMENT,
  `assigned_paper_id` int(11) NOT NULL,
  `assigned_user_id` int(11) NOT NULL,
  `assigned_note` text,
  `assigned_by` int(11) NOT NULL,
  `assigned_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `assigned_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assigned_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `assignment_screen`
--

DROP TABLE IF EXISTS `assignment_screen`;
CREATE TABLE IF NOT EXISTS `assignment_screen` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) DEFAULT NULL,
  `screening_done` int(2) NOT NULL DEFAULT '0',
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `assignment_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `assignment_screen_validate`
--

DROP TABLE IF EXISTS `assignment_screen_validate`;
CREATE TABLE IF NOT EXISTS `assignment_screen_validate` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) DEFAULT NULL,
  `screening_done` int(2) NOT NULL DEFAULT '0',
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `assignment_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
CREATE TABLE IF NOT EXISTS `author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(50) NOT NULL,
  `author_desc` varchar(200) DEFAULT NULL,
  `author_picture` longblob,
  `author_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classification`
--

DROP TABLE IF EXISTS `classification`;
CREATE TABLE IF NOT EXISTS `classification` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_paper_id` int(11) DEFAULT NULL,
  `study` int(11) DEFAULT NULL,
  `validation` varchar(100) NOT NULL,
  `contribution` int(11) DEFAULT NULL,
  `artefact` varchar(100) DEFAULT NULL,
  `data` int(11) DEFAULT NULL,
  `class_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classification_scheme`
--

DROP TABLE IF EXISTS `classification_scheme`;
CREATE TABLE IF NOT EXISTS `classification_scheme` (
  `scheme_id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme_label` varchar(100) NOT NULL,
  `scheme_title` varchar(100) NOT NULL,
  `scheme_parent` varchar(100) NOT NULL DEFAULT 'main',
  `scheme_mandatory` int(1) NOT NULL DEFAULT '0',
  `scheme_category` varchar(30) NOT NULL,
  `scheme_type` varchar(30) DEFAULT NULL,
  `scheme_size` int(11) DEFAULT NULL,
  `scheme_source` varchar(1000) DEFAULT NULL,
  `scheme_source_main_field` varchar(100) DEFAULT NULL,
  `scheme_number_of_values` varchar(2) NOT NULL DEFAULT '1',
  `scheme_order` int(2) NOT NULL DEFAULT '1',
  `scheme_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`scheme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_type` varchar(100) NOT NULL,
  `editor_url` varchar(100) NOT NULL,
  `editor_generated_path` varchar(100) NOT NULL,
  `csv_field_separator` enum(';',',') NOT NULL DEFAULT ';',
  `csv_field_separator_export` enum(';',',') NOT NULL DEFAULT ',',
  `screening_screening_conflict_resolution` enum('Unanimity','Majority') NOT NULL DEFAULT 'Unanimity',
  `screening_conflict_type` enum('IncludeExclude','ExclusionCriteria') NOT NULL,
  `import_papers_on` int(2) NOT NULL DEFAULT '0',
  `assign_papers_on` int(2) NOT NULL DEFAULT '0',
  `screening_on` int(2) NOT NULL DEFAULT '0',
  `screening_result_on` int(2) NOT NULL DEFAULT '0',
  `screening_validation_on` int(2) NOT NULL DEFAULT '0',
  `classification_on` int(2) NOT NULL DEFAULT '0',
  `source_papers_on` int(2) NOT NULL DEFAULT '0',
  `search_strategy_on` int(2) NOT NULL DEFAULT '0',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_id`, `config_type`, `editor_url`, `editor_generated_path`, `csv_field_separator`, `csv_field_separator_export`, `screening_screening_conflict_resolution`, `screening_conflict_type`, `import_papers_on`, `assign_papers_on`, `screening_on`, `screening_result_on`, `screening_validation_on`, `classification_on`, `source_papers_on`, `search_strategy_on`, `config_active`) VALUES
(1, 'default', 'localhost', 'C:/', ';', ',', 'Unanimity', 'IncludeExclude', 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exclusion`
--

DROP TABLE IF EXISTS `exclusion`;
CREATE TABLE IF NOT EXISTS `exclusion` (
  `exclusion_id` int(11) NOT NULL AUTO_INCREMENT,
  `exclusion_paper_id` int(11) NOT NULL,
  `exclusion_criteria` int(11) NOT NULL,
  `exclusion_note` text,
  `exclusion_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `exclusion_by` int(11) NOT NULL,
  `exclusion_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`exclusion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `installation_info`
--

DROP TABLE IF EXISTS `installation_info`;
CREATE TABLE IF NOT EXISTS `installation_info` (
  `install_id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_tables` text NOT NULL,
  `generated_tables` text NOT NULL,
  `foreign_key_constraint` text,
  `install_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`install_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `installation_info`
--

INSERT INTO `installation_info` (`install_id`, `reference_tables`, `generated_tables`, `foreign_key_constraint`, `install_active`) VALUES
(1, '["ref_study","ref_contribution","ref_stade_de_contribution","ref_sources_de_donnees"]', '["classification","stade"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_study   , DROP FOREIGN KEY  classification_contribution   , DROP FOREIGN KEY  classification_data   ;","ALTER TABLE stade DROP FOREIGN KEY  stade_parent_field_id   , DROP FOREIGN KEY  stade_stade   ;"]', 1);

-- --------------------------------------------------------

--
-- Table structure for table `operations`
--

DROP TABLE IF EXISTS `operations`;
CREATE TABLE IF NOT EXISTS `operations` (
  `operation_id` int(11) NOT NULL AUTO_INCREMENT,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `operation_type` enum('import_paper','assign_papers','assign_papers_validation') NOT NULL DEFAULT 'import_paper',
  `operation_desc` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `operation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `paper`
--

DROP TABLE IF EXISTS `paper`;
CREATE TABLE IF NOT EXISTS `paper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bibtexKey` varchar(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `preview` longtext,
  `bibtex` longtext,
  `abstract` longtext,
  `doi` varchar(200) DEFAULT NULL,
  `year` int(4) DEFAULT NULL,
  `venueId` int(11) DEFAULT NULL,
  `papers_sources` int(11) DEFAULT NULL,
  `search_strategy` int(11) DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `addition_mode` enum('Automatic','Manually') NOT NULL DEFAULT 'Manually',
  `added_active_phase` varchar(20) NOT NULL,
  `screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded') NOT NULL DEFAULT 'Pending',
  `classification_status` enum('Waiting','To classify','Classified') NOT NULL DEFAULT 'Waiting',
  `paper_excluded` int(2) NOT NULL DEFAULT '0',
  `operation_code` varchar(20) DEFAULT NULL,
  `paper_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `paperauthor`
--

DROP TABLE IF EXISTS `paperauthor`;
CREATE TABLE IF NOT EXISTS `paperauthor` (
  `paperauthor_id` int(11) NOT NULL AUTO_INCREMENT,
  `paperId` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `paperauthor_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paperauthor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ref_contribution`
--

DROP TABLE IF EXISTS `ref_contribution`;
CREATE TABLE IF NOT EXISTS `ref_contribution` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ref_contribution`
--

INSERT INTO `ref_contribution` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Détection d artéfact', 'Détection d artéfact', 1),
(2, 'Mesure', 'Mesure', 1),
(3, 'Etude empirique', 'Etude empirique', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_exclusioncrieria`
--

DROP TABLE IF EXISTS `ref_exclusioncrieria`;
CREATE TABLE IF NOT EXISTS `ref_exclusioncrieria` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(100) NOT NULL,
  `ref_desc` varchar(100) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ref_exclusioncrieria`
--

INSERT INTO `ref_exclusioncrieria` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Crit 2', '', 1),
(2, 'Crit 3', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_papers_sources`
--

DROP TABLE IF EXISTS `ref_papers_sources`;
CREATE TABLE IF NOT EXISTS `ref_papers_sources` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(100) NOT NULL,
  `ref_desc` varchar(100) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ref_papers_sources`
--

INSERT INTO `ref_papers_sources` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'IEEE xplore', '', 1),
(2, 'Scopus', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_search_strategy`
--

DROP TABLE IF EXISTS `ref_search_strategy`;
CREATE TABLE IF NOT EXISTS `ref_search_strategy` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(100) NOT NULL,
  `ref_desc` varchar(100) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ref_search_strategy`
--

INSERT INTO `ref_search_strategy` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Snowballing', '', 1),
(2, 'Database search', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_sources_de_donnees`
--

DROP TABLE IF EXISTS `ref_sources_de_donnees`;
CREATE TABLE IF NOT EXISTS `ref_sources_de_donnees` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_sources_de_donnees`
--

INSERT INTO `ref_sources_de_donnees` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Données industrielles', 'Données industrielles', 1),
(2, 'Données Open Source', 'Données Open Source', 1),
(3, 'Données d enquête', 'Données d enquête', 1),
(4, 'Données hybrides', 'Données hybrides', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_stade_de_contribution`
--

DROP TABLE IF EXISTS `ref_stade_de_contribution`;
CREATE TABLE IF NOT EXISTS `ref_stade_de_contribution` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `ref_stade_de_contribution`
--

INSERT INTO `ref_stade_de_contribution` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Avant développement', 'Avant développement', 1),
(2, 'Pendant développement', 'Pendant développement', 1),
(3, 'Post développement', 'Post développement', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_study`
--

DROP TABLE IF EXISTS `ref_study`;
CREATE TABLE IF NOT EXISTS `ref_study` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `ref_study`
--

INSERT INTO `ref_study` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Cas', 'Cas', 1),
(2, 'Empirique', 'Empirique', 1),
(3, 'Exploratoire', 'Exploratoire', 1),
(4, 'Observatoire', 'Observatoire', 1),
(5, 'Qualitative', 'Qualitative', 1),
(6, 'Quantitative', 'Quantitative', 1),
(7, 'Revue de littérature', 'Revue de littérature', 1),
(8, 'Utilisateur', 'Utilisateur', 1),
(9, 'Aucune', 'Aucune', 1),
(10, 'Autre', 'Autre', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_tables`
--

DROP TABLE IF EXISTS `ref_tables`;
CREATE TABLE IF NOT EXISTS `ref_tables` (
  `reftab_id` int(11) NOT NULL AUTO_INCREMENT,
  `reftab_label` varchar(50) NOT NULL,
  `reftab_table` varchar(50) NOT NULL,
  `reftab_desc` varchar(200) NOT NULL,
  `reftab_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`reftab_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ref_tables`
--

INSERT INTO `ref_tables` (`reftab_id`, `reftab_label`, `reftab_table`, `reftab_desc`, `reftab_active`) VALUES
(2, 'ref_study', 'ref_study', 'Study', 1),
(3, 'ref_contribution', 'ref_contribution', 'Contribution', 1),
(4, 'ref_stade_de_contribution', 'ref_stade_de_contribution', 'Stade de contribution', 1),
(5, 'ref_sources_de_donnees', 'ref_sources_de_donnees', 'Sources de données', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screen_decison`
--

DROP TABLE IF EXISTS `screen_decison`;
CREATE TABLE IF NOT EXISTS `screen_decison` (
  `decison_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `screening_phase` int(11) NOT NULL,
  `screening_decision` enum('Pending','In review','In conflict','Included','Excluded') DEFAULT NULL,
  `decision_source` enum('new_screen','edit_screen','conflict_resolution') DEFAULT NULL,
  `decision_history` longtext,
  `decision_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`decison_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `screen_phase`
--

DROP TABLE IF EXISTS `screen_phase`;
CREATE TABLE IF NOT EXISTS `screen_phase` (
  `screen_phase_id` int(11) NOT NULL AUTO_INCREMENT,
  `phase_title` varchar(100) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `displayed_fields` varchar(200) DEFAULT NULL,
  `phase_state` enum('Pending','Open','Closed','Cancelled') NOT NULL DEFAULT 'Pending',
  `source_paper_id` varchar(11) DEFAULT NULL,
  `source_paper` enum('All papers','Previous phase') NOT NULL DEFAULT 'Previous phase',
  `source_paper_status` enum('All','Included','Excluded') NOT NULL DEFAULT 'Included',
  `screen_phase_order` int(2) NOT NULL,
  `screen_phase_final` int(2) NOT NULL DEFAULT '0',
  `phase_type` enum('Screening','Validation') NOT NULL DEFAULT 'Screening',
  `phase_history` longtext,
  `added_by` int(11) NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screen_phase_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screen_phase_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `screen_phase`
--

INSERT INTO `screen_phase` (`screen_phase_id`, `phase_title`, `description`, `displayed_fields`, `phase_state`, `source_paper_id`, `source_paper`, `source_paper_status`, `screen_phase_order`, `screen_phase_final`, `phase_type`, `phase_history`, `added_by`, `add_time`, `screen_phase_active`) VALUES
(1, 'Phase 1 screen by title', '', 'Title', 'Pending', NULL, 'Previous phase', 'Included', 10, 0, 'Screening', NULL, 1, '2017-06-16 06:27:26', 1),
(2, 'Phase 2 screen by abstract', '', 'Title|Abstract|Link', 'Pending', NULL, 'Previous phase', 'Included', 20, 1, 'Screening', NULL, 1, '2017-06-16 06:28:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screening`
--

DROP TABLE IF EXISTS `screening`;
CREATE TABLE IF NOT EXISTS `screening` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `decision` enum('accepted','excluded') NOT NULL DEFAULT 'accepted',
  `exclusion_criteria` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `screening_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `screening_paper`
--

DROP TABLE IF EXISTS `screening_paper`;
CREATE TABLE IF NOT EXISTS `screening_paper` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `screening_phase` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assignment_note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) NOT NULL,
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(15) NOT NULL,
  `screening_decision` enum('Included','Excluded') DEFAULT NULL,
  `exclusion_criteria` int(11) DEFAULT NULL,
  `screening_note` varchar(200) DEFAULT NULL,
  `screening_time` timestamp NULL DEFAULT NULL,
  `screening_status` enum('Pending','Done','Reseted') NOT NULL DEFAULT 'Pending',
  `assignment_role` enum('Screening','Validation') NOT NULL DEFAULT 'Screening',
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `screening_validate`
--

DROP TABLE IF EXISTS `screening_validate`;
CREATE TABLE IF NOT EXISTS `screening_validate` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `decision` enum('accepted','excluded') NOT NULL DEFAULT 'accepted',
  `exclusion_criteria` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `screening_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `stade`
--

DROP TABLE IF EXISTS `stade`;
CREATE TABLE IF NOT EXISTS `stade` (
  `stade_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_field_id` int(11) DEFAULT NULL,
  `stade` int(11) DEFAULT NULL,
  `stade_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`stade_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `str_management`
--

DROP TABLE IF EXISTS `str_management`;
CREATE TABLE IF NOT EXISTS `str_management` (
  `str_id` int(11) NOT NULL AUTO_INCREMENT,
  `str_label` varchar(500) NOT NULL,
  `str_text` varchar(1000) NOT NULL,
  `str_category` varchar(20) NOT NULL DEFAULT 'default',
  `str_lang` varchar(3) NOT NULL DEFAULT 'en',
  `str_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`str_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=141 ;

--
-- Dumping data for table `str_management`
--

INSERT INTO `str_management` (`str_id`, `str_label`, `str_text`, `str_category`, `str_lang`, `str_active`) VALUES
(1, 'Welcome', 'Welcome', 'default', 'en', 1),
(2, 'General', 'General', 'default', 'en', 1),
(3, 'Home', 'Home', 'default', 'en', 1),
(4, 'Papers', 'Papers', 'default', 'en', 1),
(5, 'Import papers', 'Import papers', 'default', 'en', 1),
(6, 'All papers', 'All papers', 'default', 'en', 1),
(7, 'Papers pending', 'Papers pending', 'default', 'en', 1),
(8, 'Papers included', 'Papers included', 'default', 'en', 1),
(9, 'Papers excluded', 'Papers excluded', 'default', 'en', 1),
(10, 'Screenings', 'Screenings', 'default', 'en', 1),
(11, '--Completion', '--Completion', 'default', 'en', 1),
(12, 'Result', 'Result', 'default', 'en', 1),
(13, 'Go To', 'Go To', 'default', 'en', 1),
(14, 'Admin view', 'Admin view', 'default', 'en', 1),
(15, 'Classification view', 'Classification view', 'default', 'en', 1),
(16, 'Settings', 'Settings', 'default', 'en', 1),
(17, 'Reference', 'Reference', 'default', 'en', 1),
(18, 'Exclusion criteria', 'Exclusion criteria', 'default', 'en', 1),
(19, 'Papers sources', 'Papers sources', 'default', 'en', 1),
(20, 'Search strategy', 'Search strategy', 'default', 'en', 1),
(21, 'Authors', 'Authors', 'default', 'en', 1),
(22, 'Venues', 'Venues', 'default', 'en', 1),
(23, 'Operations', 'Operations', 'default', 'en', 1),
(24, 'SQL', 'SQL', 'default', 'en', 1),
(25, 'String mangement', 'String mangement', 'default', 'en', 1),
(26, 'Configuration', 'Configuration', 'default', 'en', 1),
(27, 'General configuration', 'General configuration', 'default', 'en', 1),
(28, 'Papers configuration', 'Papers configuration', 'default', 'en', 1),
(29, 'Screening phases', 'Screening phases', 'default', 'en', 1),
(30, 'Update Installation', 'Update Installation', 'default', 'en', 1),
(31, 'Configuration_managment', 'Configuration_managment', 'default', 'en', 1),
(32, 'Choose project', 'Choose project', 'default', 'en', 1),
(33, 'UP', 'UP', 'default', 'en', 1),
(34, 'Log Out', 'Log Out', 'default', 'en', 1),
(35, 'ReLiS - Revue Littéraire Systématique', 'ReLiS - Revue Littéraire Systématique', 'default', 'en', 1),
(36, 'Select', 'Select', 'default', 'en', 1),
(37, 'Select multi', 'Select multi', 'default', 'en', 1),
(38, 'Edit', 'Edit', 'default', 'en', 1),
(39, 'Close', 'Close', 'default', 'en', 1),
(40, 'Configurations  for  papers', 'Configurations  for  papers', 'default', 'en', 1),
(41, 'Add screeninng phase', 'Add screeninng phase', 'default', 'en', 1),
(42, 'Add a new phase', 'Add a new phase', 'default', 'en', 1),
(43, 'Add validation phase', 'Add validation phase', 'default', 'en', 1),
(44, 'List phases', 'List phases', 'default', 'en', 1),
(45, 'Configurations values', 'Configurations values', 'default', 'en', 1),
(46, 'Edit configuration ', 'Edit configuration ', 'default', 'en', 1),
(47, '#', '#', 'default', 'en', 1),
(48, 'Configuration type', 'Configuration type', 'default', 'en', 1),
(49, 'Editor location(url)', 'Editor location(url)', 'default', 'en', 1),
(50, 'Editor workspace', 'Editor workspace', 'default', 'en', 1),
(51, 'CSV  separator for import', 'CSV  separator for import', 'default', 'en', 1),
(52, 'CSV separator for export', 'CSV separator for export', 'default', 'en', 1),
(53, 'Screening comfict type', 'Screening comfict type', 'default', 'en', 1),
(54, 'import papers activated', 'import papers activated', 'default', 'en', 1),
(55, 'Screening activated', 'Screening activated', 'default', 'en', 1),
(56, 'assign papers activated', 'assign papers activated', 'default', 'en', 1),
(57, 'Screening result activated', 'Screening result activated', 'default', 'en', 1),
(58, 'Screening validation activated', 'Screening validation activated', 'default', 'en', 1),
(59, 'Classification activated', 'Classification activated', 'default', 'en', 1),
(60, 'Add papers source', 'Add papers source', 'default', 'en', 1),
(61, 'Add search strategy', 'Add search strategy', 'default', 'en', 1),
(62, 'Processed', 'Processed', 'default', 'en', 1),
(63, 'Pending', 'Pending', 'default', 'en', 1),
(64, 'Assigned to me', 'Assigned to me', 'default', 'en', 1),
(65, 'Excluded', 'Excluded', 'default', 'en', 1),
(66, 'Classification', 'Classification', 'default', 'en', 1),
(67, 'Graphs', 'Graphs', 'default', 'en', 1),
(68, 'Export', 'Export', 'default', 'en', 1),
(69, 'Reference Tables', 'Reference Tables', 'default', 'en', 1),
(70, 'Contribution', 'Contribution', 'default', 'en', 1),
(71, 'Sources de données', 'Sources de données', 'default', 'en', 1),
(72, 'Stade de contribution', 'Stade de contribution', 'default', 'en', 1),
(73, 'Study', 'Study', 'default', 'en', 1),
(74, 'Screening view', 'Screening view', 'default', 'en', 1),
(75, 'Project', 'Project', 'default', 'en', 1),
(76, 'Description', 'Description', 'default', 'en', 1),
(77, 'Classification completion', 'Classification completion', 'default', 'en', 1),
(78, 'Processed papers', 'Processed papers', 'default', 'en', 1),
(79, 'Pending papers', 'Pending papers', 'default', 'en', 1),
(80, 'Participants', 'Participants', 'default', 'en', 1),
(81, 'user', 'user', 'default', 'en', 1),
(82, 'Completion', 'Completion', 'default', 'en', 1),
(83, 'Add a new paper', 'Add a new paper', 'default', 'en', 1),
(84, 'No records found', 'No records found', 'default', 'en', 1),
(85, 'Add Exclusion criteria', 'Add Exclusion criteria', 'default', 'en', 1),
(86, 'List  of Exclusion criteria', 'List  of Exclusion criteria', 'default', 'en', 1),
(87, 'Search for...', 'Search for...', 'default', 'en', 1),
(88, 'Add a Exclusion criteria', 'Add a Exclusion criteria', 'default', 'en', 1),
(89, 'Value', 'Value', 'default', 'en', 1),
(90, 'Success', 'Success', 'default', 'en', 1),
(91, 'View', 'View', 'default', 'en', 1),
(92, 'Delete', 'Delete', 'default', 'en', 1),
(93, 'Action', 'Action', 'default', 'en', 1),
(94, 'Add Papers sources', 'Add Papers sources', 'default', 'en', 1),
(95, 'List  of Papers sources', 'List  of Papers sources', 'default', 'en', 1),
(96, 'Add a Papers sources', 'Add a Papers sources', 'default', 'en', 1),
(97, 'List  of Search strategy', 'List  of Search strategy', 'default', 'en', 1),
(98, 'Add a Search strategy', 'Add a Search strategy', 'default', 'en', 1),
(99, 'Add a new venue', 'Add a new venue', 'default', 'en', 1),
(100, 'List venues', 'List venues', 'default', 'en', 1),
(101, 'Operation type', 'Operation type', 'default', 'en', 1),
(102, 'Time', 'Time', 'default', 'en', 1),
(103, 'List of Operations', 'List of Operations', 'default', 'en', 1),
(104, 'Switch to multi query!', 'Switch to multi query!', 'default', 'en', 1),
(105, 'Parse an SQL query', 'Parse an SQL query', 'default', 'en', 1),
(106, 'Return table', 'Return table', 'default', 'en', 1),
(107, 'Write your sql query here', 'Write your sql query here', 'default', 'en', 1),
(108, 'Submit', 'Submit', 'default', 'en', 1),
(109, 'Label', 'Label', 'default', 'en', 1),
(110, 'Text', 'Text', 'default', 'en', 1),
(111, 'Language', 'Language', 'default', 'en', 1),
(112, 'Open edition mode', 'Open edition mode', 'default', 'en', 1),
(113, 'List of String management', 'List of String management', 'default', 'en', 1),
(114, 'Update project', 'Update project', 'default', 'en', 1),
(115, 'Upload configuration file', 'Upload configuration file', 'default', 'en', 1),
(116, 'Back', 'Back', 'default', 'en', 1),
(117, 'Screen', 'Screen', 'default', 'en', 1),
(118, 'Papers in review', 'Papers in review', 'default', 'en', 1),
(119, 'Papers in conflict', 'Papers in conflict', 'default', 'en', 1),
(120, 'Screening', 'Screening', 'default', 'en', 1),
(121, 'My assignments', 'My assignments', 'default', 'en', 1),
(122, 'My screenings', 'My screenings', 'default', 'en', 1),
(123, 'All assignments', 'All assignments', 'default', 'en', 1),
(124, 'All screenings', 'All screenings', 'default', 'en', 1),
(125, 'Assign papers for screening', 'Assign papers for screening', 'default', 'en', 1),
(126, 'General view', 'General view', 'default', 'en', 1),
(127, 'My screening completion', 'My screening completion', 'default', 'en', 1),
(128, ' Screened papers', ' Screened papers', 'default', 'en', 1),
(129, 'Add a new screening phase', 'Add a new screening phase', 'default', 'en', 1),
(130, 'Created by', 'Created by', 'default', 'en', 1),
(131, 'Displayed fields', 'Displayed fields', 'default', 'en', 1),
(132, 'Order', 'Order', 'default', 'en', 1),
(133, 'Phase category', 'Phase category', 'default', 'en', 1),
(134, 'Source paper', 'Source paper', 'default', 'en', 1),
(135, 'Source paper status', 'Source paper status', 'default', 'en', 1),
(136, 'Title', 'Title', 'default', 'en', 1),
(137, 'Final phase', 'Final phase', 'default', 'en', 1),
(138, 'Open', 'Open', 'default', 'en', 1),
(139, 'Open the phase', 'Open the phase', 'default', 'en', 1),
(140, 'Excluded papers', 'Excluded papers', 'default', 'en', 1);

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
CREATE TABLE IF NOT EXISTS `venue` (
  `venue_id` int(11) NOT NULL AUTO_INCREMENT,
  `venue_abbreviation` varchar(20) NOT NULL,
  `venue_fullName` varchar(200) NOT NULL,
  `venue_year` int(4) DEFAULT NULL,
  `venue_volume` int(11) DEFAULT NULL,
  `venue_totalNumPapers` int(11) DEFAULT NULL,
  `venue_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`venue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_assigned`
--
DROP VIEW IF EXISTS `view_paper_assigned`;
CREATE TABLE IF NOT EXISTS `view_paper_assigned` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`doi` varchar(200)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(2)
,`operation_code` varchar(20)
,`paper_active` int(1)
,`assigned_user_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_decision`
--
DROP VIEW IF EXISTS `view_paper_decision`;
CREATE TABLE IF NOT EXISTS `view_paper_decision` (
`screening_id` int(11)
,`screening_phase` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`paper_active` int(1)
,`screening_status` varchar(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_pending`
--
DROP VIEW IF EXISTS `view_paper_pending`;
CREATE TABLE IF NOT EXISTS `view_paper_pending` (
`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`doi` varchar(200)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(2)
,`operation_code` varchar(20)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_processed`
--
DROP VIEW IF EXISTS `view_paper_processed`;
CREATE TABLE IF NOT EXISTS `view_paper_processed` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`doi` varchar(200)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(2)
,`operation_code` varchar(20)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `zref_exclusioncrieria`
--

DROP TABLE IF EXISTS `zref_exclusioncrieria`;
CREATE TABLE IF NOT EXISTS `zref_exclusioncrieria` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure for view `view_paper_assigned`
--
DROP TABLE IF EXISTS `view_paper_assigned`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_assigned` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`doi` AS `doi`,`p`.`venueId` AS `venueId`,`p`.`bibtex` AS `bibtex`,`p`.`preview` AS `preview`,`p`.`abstract` AS `abstract`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`operation_code` AS `operation_code`,`p`.`paper_active` AS `paper_active`,`a`.`assigned_user_id` AS `assigned_user_id` from (`paper` `p` join `assigned` `a` on((`p`.`id` = `a`.`assigned_paper_id`))) where ((`a`.`assigned_active` = 1) and (`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_decision`
--
DROP TABLE IF EXISTS `view_paper_decision`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_decision` AS select `s`.`screening_id` AS `screening_id`,`s`.`screening_phase` AS `screening_phase`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`paper_active` AS `paper_active`,ifnull(`d`.`screening_decision`,'Pending') AS `screening_status` from ((`screening_paper` `s` left join `paper` `p` on(((`s`.`paper_id` = `p`.`id`) and (`p`.`paper_active` = 1)))) left join `screen_decison` `d` on(((`s`.`paper_id` = `d`.`paper_id`) and (`s`.`screening_phase` = `d`.`screening_phase`) and (`d`.`decision_active` = 1)))) where (`s`.`screening_active` = 1) group by `p`.`id`,`s`.`screening_phase`;

-- --------------------------------------------------------

--
-- Structure for view `view_paper_pending`
--
DROP TABLE IF EXISTS `view_paper_pending`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_pending` AS select `paper`.`id` AS `id`,`paper`.`bibtexKey` AS `bibtexKey`,`paper`.`title` AS `title`,`paper`.`doi` AS `doi`,`paper`.`venueId` AS `venueId`,`paper`.`bibtex` AS `bibtex`,`paper`.`preview` AS `preview`,`paper`.`abstract` AS `abstract`,`paper`.`screening_status` AS `screening_status`,`paper`.`classification_status` AS `classification_status`,`paper`.`paper_excluded` AS `paper_excluded`,`paper`.`operation_code` AS `operation_code`,`paper`.`paper_active` AS `paper_active` from `paper` where ((not(`paper`.`id` in (select distinct `p`.`id` AS `id` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`c`.`class_active` = 1))))) and (`paper`.`paper_active` = 1) and (`paper`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_processed`
--
DROP TABLE IF EXISTS `view_paper_processed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_processed` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`doi` AS `doi`,`p`.`venueId` AS `venueId`,`p`.`bibtex` AS `bibtex`,`p`.`preview` AS `preview`,`p`.`abstract` AS `abstract`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`operation_code` AS `operation_code`,`p`.`paper_active` AS `paper_active` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0) and (`c`.`class_active` = 1));
--
-- Database: `relis_dev_mt`
--
CREATE DATABASE `relis_dev_mt` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `relis_dev_mt`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignation`(_assigned_id INT , _assigned_paper_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205) , _assigned_by INT)
BEGIN
START TRANSACTION;
INSERT INTO assigned (assigned_paper_id , assigned_user_id , assigned_note , assigned_by) VALUES (_assigned_paper_id , _assigned_user_id , _assigned_note , _assigned_by);
SELECT assigned_id AS id_value FROM assigned WHERE assigned_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignment_screen`(_assignment_id INT , _paper_id INT , _user_id INT , _note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_mode  VARCHAR(35) , _assigned_by INT , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO assignment_screen (paper_id , user_id , note , assignment_type , assignment_mode , assigned_by , screening_done) VALUES (_paper_id , _user_id , _note , _assignment_type , _assignment_mode , _assigned_by , _screening_done);
SELECT assignment_id AS id_value FROM assignment_screen WHERE assignment_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignment_screen_validate`(_assignment_id INT , _paper_id INT , _user_id INT , _note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_mode  VARCHAR(35) , _assigned_by INT , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO assignment_screen_validate (paper_id , user_id , note , assignment_type , assignment_mode , assigned_by , screening_done) VALUES (_paper_id , _user_id , _note , _assignment_type , _assignment_mode , _assigned_by , _screening_done);
SELECT assignment_id AS id_value FROM assignment_screen_validate WHERE assignment_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_author`(_author_id INT , _author_name  VARCHAR(55) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
INSERT INTO author (author_name , author_desc , author_picture) VALUES (_author_name , _author_desc , _author_picture);
SELECT author_id AS id_value FROM author WHERE author_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_classification`(_class_id INT , _class_paper_id INT , _transformation_name  VARCHAR(105) , _domain INT , _transformation_language INT , _source_language INT , _target_language INT , _Scope  VARCHAR(15) , _Industrial  VARCHAR(6) , _hot  VARCHAR(6) , _bidirectional  VARCHAR(6) , _implementation  VARCHAR(6) , _note  VARCHAR(505))
BEGIN
START TRANSACTION;
INSERT INTO classification (class_paper_id , transformation_name , domain , transformation_language , source_language , target_language , Scope , Industrial , hot , bidirectional , implementation , note) VALUES (_class_paper_id , _transformation_name , _domain , _transformation_language , _source_language , _target_language , _Scope , _Industrial , _hot , _bidirectional , _implementation , _note);
SELECT class_id AS id_value FROM classification WHERE class_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_config`(_config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
INSERT INTO config (config_type , editor_url , editor_generated_path , csv_field_separator , csv_field_separator_export , screening_screening_conflict_resolution , screening_conflict_type , import_papers_on , assign_papers_on , screening_on , screening_result_on , screening_validation_on , classification_on) VALUES (_config_type , _editor_url , _editor_generated_path , _csv_field_separator , _csv_field_separator_export , _screening_screening_conflict_resolution , _screening_conflict_type , _import_papers_on , _assign_papers_on , _screening_on , _screening_result_on , _screening_validation_on , _classification_on);
SELECT config_id AS id_value FROM config WHERE config_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_exclusion`(_exclusion_id INT , _exclusion_paper_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205) , _exclusion_by INT)
BEGIN
START TRANSACTION;
INSERT INTO exclusion (exclusion_paper_id , exclusion_criteria , exclusion_note , exclusion_by) VALUES (_exclusion_paper_id , _exclusion_criteria , _exclusion_note , _exclusion_by);
SELECT exclusion_id AS id_value FROM exclusion WHERE exclusion_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_exclusioncrieria`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
INSERT INTO ref_exclusioncrieria (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_exclusioncrieria WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_operations`(_operation_id INT , _operation_code  VARCHAR(25) , _operation_type  VARCHAR(25) , _operation_desc  VARCHAR(205) , _user_id INT)
BEGIN
START TRANSACTION;
INSERT INTO operations (operation_code , operation_type , operation_desc , user_id) VALUES (_operation_code , _operation_type , _operation_desc , _user_id);
SELECT operation_id AS id_value FROM operations WHERE operation_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_paper`(_id INT , _added_by INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _doi  VARCHAR(205) , _year INT , _venueId INT , _preview LONGTEXT , _bibtex LONGTEXT , _abstract LONGTEXT , _papers_sources INT , _search_strategy INT)
BEGIN
START TRANSACTION;
INSERT INTO paper (added_by , bibtexKey , title , doi , year , venueId , preview , bibtex , abstract , papers_sources , search_strategy) VALUES (_added_by , _bibtexKey , _title , _doi , _year , _venueId , _preview , _bibtex , _abstract , _papers_sources , _search_strategy);
SELECT id AS id_value FROM paper WHERE id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_papers`(_id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _screening_status  VARCHAR(25) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO paper (bibtexKey , title , preview , bibtex , abstract , doi , screening_status , venueId , paper_excluded) VALUES (_bibtexKey , _title , _preview , _bibtex , _abstract , _doi , _screening_status , _venueId , _paper_excluded);
SELECT id AS id_value FROM paper WHERE id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_papers_sources`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
INSERT INTO ref_papers_sources (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_papers_sources WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_paper_author`(_paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
INSERT INTO paperauthor (paperId , authorId) VALUES (_paperId , _authorId);
SELECT paperauthor_id AS id_value FROM paperauthor WHERE paperauthor_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_domain`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_domain (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_domain WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_exclusioncrieria`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO zref_exclusioncrieria (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM zref_exclusioncrieria WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_language`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_language (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_language WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_transformation_language`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_transformation_language (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_transformation_language WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screening`(_screening_id INT , _paper_id INT , _user_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205) , _assignment_id INT)
BEGIN
START TRANSACTION;
INSERT INTO screening (paper_id , user_id , decision , exclusion_criteria , note , assignment_id) VALUES (_paper_id , _user_id , _decision , _exclusion_criteria , _note , _assignment_id);
SELECT screening_id AS id_value FROM screening WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screening_validate`(_screening_id INT , _paper_id INT , _user_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205) , _assignment_id INT)
BEGIN
START TRANSACTION;
INSERT INTO screening_validate (paper_id , user_id , decision , exclusion_criteria , note , assignment_id) VALUES (_paper_id , _user_id , _decision , _exclusion_criteria , _note , _assignment_id);
SELECT screening_id AS id_value FROM screening_validate WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screen_phase`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screen_phase`(_screen_phase_id INT , _added_by INT , _phase_title  VARCHAR(105) , _description  VARCHAR(1005) , _displayed_fields  VARCHAR(205) , _source_paper INT , _source_paper_status  VARCHAR(20) , _screen_phase_order INT , _screen_phase_final INT)
BEGIN
START TRANSACTION;
INSERT INTO screen_phase (added_by , phase_title , description , displayed_fields , source_paper , source_paper_status , screen_phase_order , screen_phase_final) VALUES (_added_by , _phase_title , _description , _displayed_fields , _source_paper , _source_paper_status , _screen_phase_order , _screen_phase_final);
SELECT screen_phase_id AS id_value FROM screen_phase WHERE screen_phase_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_search_strategy`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
INSERT INTO ref_search_strategy (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_search_strategy WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_str_mng`(_str_id INT , _str_label  VARCHAR(405) , _str_text  VARCHAR(805) , _str_lang  VARCHAR(8) , _str_category  VARCHAR(23))
BEGIN
START TRANSACTION;
INSERT INTO str_management (str_label , str_text , str_lang , str_category) VALUES (_str_label , _str_text , _str_lang , _str_category);
SELECT str_id AS id_value FROM str_management WHERE str_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_venue`(_venue_id INT , _venue_abbreviation  VARCHAR(25) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
INSERT INTO venue (venue_abbreviation , venue_fullName , venue_year , venue_volume , venue_totalNumPapers) VALUES (_venue_abbreviation , _venue_fullName , _venue_year , _venue_volume , _venue_totalNumPapers);
SELECT venue_id AS id_value FROM venue WHERE venue_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_list`(IN  source  VARCHAR(200), IN  condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select count(*) as nombre from  ',source ,'   WHERE 1=1  ', condition_stat );
PREPARE stmt FROM @query;
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;
END$$

DROP PROCEDURE IF EXISTS `count_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM paper WHERE paper_active=1   AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_assigned`(IN  _user_id  INT,IN _search VARCHAR(100))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM view_paper_assigned WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_class`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	SELECT count(*) as nbr FROM paper WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
	COMMIT;
	END$$

DROP PROCEDURE IF EXISTS `count_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_pending`(IN _search VARCHAR(100))
BEGIN
		START TRANSACTION;
		 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
		SELECT count(*) as nbr FROM view_paper_pending WHERE paper_active=1 AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
		COMMIT;
		END$$

DROP PROCEDURE IF EXISTS `count_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_processed`(IN _search VARCHAR(100))
BEGIN
				START TRANSACTION;
				 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
				SELECT count(*) as nbr FROM view_paper_processed WHERE paper_active=1  AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
				COMMIT;
				END$$

DROP PROCEDURE IF EXISTS `exclude_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `exclude_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 1  WHERE id = _paper_id ;
  COMMIT;
 END$$

DROP PROCEDURE IF EXISTS `get_assignations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_assignations`(_paperId INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned WHERE (assigned_paper_id = _paperId AND assigned_active=1);
COMMIT; 
END$$

DROP PROCEDURE IF EXISTS `get_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_author`(IN  _start_by  INT, IN  _range  INT, IN  _search  VARCHAR(100))
BEGIN
START TRANSACTION;
SET @search_author_name := CONCAT('%',_search,'%') ;  SET @search_author_desc := CONCAT('%',_search,'%') ; 
SELECT  author_id , author_name , author_desc FROM author
WHERE author_active=1  AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC LIMIT _start_by , _range;	
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classifications`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classifications`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * 
FROM classification 
WHERE (class_paper_id = _paperId AND class_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_paper`( _classificationId  INT)
BEGIN
START TRANSACTION;
SELECT class_paper_id
FROM classification 
WHERE (class_id = _classificationId);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_scheme`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_scheme`()
BEGIN
START TRANSACTION;
SELECT * FROM classification_scheme 
WHERE (scheme_active=1) ORDER BY field_order ASC;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_configuration`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_configuration`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignation`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned
WHERE assigned_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignment_screen`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assignment_screen
WHERE assignment_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignment_screen_validate`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assignment_screen_validate
WHERE assignment_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_author`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM author
WHERE author_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_classification`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM classification
WHERE class_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_config`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_exclusion`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion
WHERE exclusion_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_exclusioncrieria`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM ref_exclusioncrieria
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_operations`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM operations
WHERE operation_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_paper`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM paper
WHERE id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_papers`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paper
WHERE id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_papers_sources`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM ref_papers_sources
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_paper_author`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paperauthor
WHERE paperauthor_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_domain`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_domain
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_exclusioncrieria`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM zref_exclusioncrieria
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_language`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_language
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_transformation_language`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_transformation_language
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screen`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM screening_paper
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screening`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM screening
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screening_validate`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM screening_validate
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_search_strategy`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM ref_search_strategy
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_str_mng`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM str_management
WHERE str_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_venue`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM venue
WHERE venue_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list`(IN  _source  VARCHAR(100), IN  _fields  VARCHAR(1000), IN  _condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select ',_fields,' from  ',_source ,'   WHERE 1=1   ', _condition_stat );
 PREPARE stmt FROM @query;
 EXECUTE stmt;
 DEALLOCATE PREPARE stmt; 
END$$

DROP PROCEDURE IF EXISTS `get_list_all_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_all_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignation`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC ;
ELSE
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignments`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignments`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase     ORDER BY screening_id ASC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase     ORDER BY screening_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignment_screen`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC ;
ELSE
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignment_screen_validate`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assignment_screen_validate
WHERE assignment_active=1   ORDER BY assignment_id DESC ;
ELSE
SELECT * FROM assignment_screen_validate
WHERE assignment_active=1   ORDER BY assignment_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_author_name := CONCAT('%',TRIM(_search),'%') ;  SET @search_author_desc := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC ;
ELSE
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_authors`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_authors`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_author_name := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  )    ORDER BY author_name ASC ;
ELSE
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  )    ORDER BY author_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_classification`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC ;
ELSE
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_config`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC ;
ELSE
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_decisions`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_decisions`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screen_decison
WHERE decision_active=1     ORDER BY screening_id ASC ;
ELSE
SELECT * FROM screen_decison
WHERE decision_active=1     ORDER BY screening_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_excluded_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_excluded_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Excluded'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Excluded'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_exclusion`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC ;
ELSE
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_exclusioncrieria`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM ref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_included_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_included_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Included'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Included'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_my_assignments`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_my_assignments`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20) ,IN  _user_id   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_id ASC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_my_screenings`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_my_screenings`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20) ,IN  _user_id   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_time DESC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase  AND user_id = _user_id     ORDER BY screening_time DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_operations`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM operations
WHERE operation_active=1   ORDER BY operation_id DESC ;
ELSE
SELECT * FROM operations
WHERE operation_active=1   ORDER BY operation_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _paper_excluded   VARCHAR(2))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND paper_excluded = _paper_excluded   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND paper_excluded = _paper_excluded   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_assigned`(IN  _user_id  INT,IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id)    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND  (assigned_user_id = _user_id)      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_class`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500),IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	IF _range < 1 THEN
	SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting' AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_pending`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_pending
WHERE paper_active=1  AND classification_status <> 'Waiting'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_pending
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_processed`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'     AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_screen`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(10))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase     ORDER BY id ASC ;
ELSE
SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase     ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_screen_per_status`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_screen_per_status`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(10) ,IN  _screening_status   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase  AND screening_status = _screening_status     ORDER BY id ASC ;
ELSE
SELECT * FROM view_paper_decision
WHERE paper_active=1  AND screening_phase = _screening_phase  AND screening_status = _screening_status     ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_sources`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM ref_papers_sources
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_papers_sources
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_paper_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC ;
ELSE
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_pending_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_pending_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Pending'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND screening_status =  'Pending'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )    ORDER BY id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_domain`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_domain
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_domain
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_exclusioncrieria`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_language`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_transformation_language`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_transformation_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_transformation_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screening`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC ;
ELSE
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screenings`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screenings`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN  _screening_phase   VARCHAR(20))
BEGIN
					START TRANSACTION;
					
					IF _range < 1 THEN
					SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase     ORDER BY screening_time DESC ;
ELSE
SELECT * FROM screening_paper
WHERE screening_active=1  AND screening_status =  'Done'   AND screening_phase = _screening_phase     ORDER BY screening_time DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screening_validate`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM screening_validate
WHERE screening_active=1   ORDER BY screening_id DESC ;
ELSE
SELECT * FROM screening_validate
WHERE screening_active=1   ORDER BY screening_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screen_phases`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screen_phases`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_phase_title := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM screen_phase
WHERE screen_phase_active=1   AND (  (phase_title LIKE  @search_phase_title)  )    ORDER BY screen_phase_order ASC ;
ELSE
SELECT * FROM screen_phase
WHERE screen_phase_active=1   AND (  (phase_title LIKE  @search_phase_title)  )    ORDER BY screen_phase_order ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_search_strategy`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM ref_search_strategy
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_search_strategy
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )    ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_str_mng`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
 SET @search_str_text := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC ;
ELSE
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_venue`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_venue_abbreviation := CONCAT('%',TRIM(_search),'%') ;  SET @search_venue_fullName := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC ;
ELSE
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_venues`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_venues`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
					START TRANSACTION;
					 SET @search_venue_abbreviation := CONCAT('%',TRIM(_search),'%') ;  SET @search_venue_fullName := CONCAT('%',TRIM(_search),'%') ; 
					IF _range < 1 THEN
					SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )    ORDER BY venue_abbreviation ASC ;
ELSE
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )    ORDER BY venue_abbreviation ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_paper_exclusion_info`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_paper_exclusion_info`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion WHERE (exclusion_paper_id = _paperId AND exclusion_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_table`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_table`( _configId  VARCHAR(100))
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE (reftab_label = _configId AND reftab_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_tables_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_tables_list`()
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE reftab_active=1 order by  reftab_desc;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_value`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_value`(IN  _table  VARCHAR(100), IN  _id  VARCHAR(100), IN  _field  VARCHAR(100), IN  _table_id  VARCHAR(100))
BEGIN
SET @query = CONCAT('Select ',_field,' from  ',_table ,'   WHERE ', _table_id, ' = ', _id );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_result_count`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_result_count`(IN  _fields  VARCHAR(100))
BEGIN
SET @query = CONCAT('SELECT ',_fields,' AS field,count(*) AS nombre from classification,paper WHERE class_paper_id=id  AND paper_excluded = 0	 AND  paper_active=1 AND class_active=1 group by  ',_fields );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_row`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_row`(IN  source  VARCHAR(100), IN  source_id  VARCHAR(100), IN  id_value  VARCHAR(100))
BEGIN
SET @query = CONCAT("Select * from  ",source ,"  WHERE ", source_id ," = '",id_value,"'");
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_screen_phase_detail`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_screen_phase_detail`(IN _row_id INT)
BEGIN
					START TRANSACTION;
					SELECT * FROM screen_phase
WHERE screen_phase_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_string`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_string`(IN  _text  VARCHAR(500), IN  _category  VARCHAR(30), IN  _lang  VARCHAR(3))
BEGIN
START TRANSACTION;
SELECT str_id, str_text FROM str_management WHERE str_active=1 AND str_label = _text AND str_category = _category AND str_lang = _lang ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `include_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `include_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 0  WHERE id = _paper_id ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `new_assignment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_assignment`(_screening_id INT , _assigned_by INT , _assignment_mode  VARCHAR(35) , _paper_id INT , _user_id INT , _assignment_type  VARCHAR(25) , _assignment_role  VARCHAR(20) , _screening_phase INT , _assignment_note  VARCHAR(205))
BEGIN
START TRANSACTION;
INSERT INTO screening_paper (assigned_by , assignment_mode , paper_id , user_id , assignment_type , assignment_role , screening_phase , assignment_note) VALUES (_assigned_by , _assignment_mode , _paper_id , _user_id , _assignment_type , _assignment_role , _screening_phase , _assignment_note);
SELECT screening_id AS id_value FROM screening_paper WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `new_decision`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `new_decision`(_decison_id INT , _paper_id INT , _screening_decision  VARCHAR(20) , _screening_phase INT)
BEGIN
START TRANSACTION;
INSERT INTO screen_decison (paper_id , screening_decision , screening_phase) VALUES (_paper_id , _screening_decision , _screening_phase);
SELECT decison_id AS id_value FROM screen_decison WHERE decison_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignation`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assigned SET assigned_active=0
WHERE assigned_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignment_screen`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assignment_screen SET assignment_active=0
WHERE assignment_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignment_screen_validate`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assignment_screen_validate SET assignment_active=0
WHERE assignment_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE author SET author_active=0
WHERE author_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_classification`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE classification SET class_active=0
WHERE class_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_config`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE config SET config_active=0
WHERE config_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_exclusion`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE exclusion SET exclusion_active=0
WHERE exclusion_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_exclusioncrieria`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_exclusioncrieria SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_operations`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE operations SET operation_active=0
WHERE operation_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_paper`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paper SET paper_active=0
WHERE id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_papers`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paper SET paper_active=0
WHERE id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_papers_sources`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_papers_sources SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_paper_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paperauthor SET paperauthor_active=0
WHERE paperauthor_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_domain`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_domain SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_exclusioncrieria`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE zref_exclusioncrieria SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_language`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_language SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_transformation_language`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_transformation_language SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screen`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening_paper SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screening`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screening_validate`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening_validate SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screen_phase`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screen_phase`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screen_phase SET screen_phase_active=0
WHERE screen_phase_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_search_strategy`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_search_strategy SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_str_mng`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE str_management SET str_active=0
WHERE str_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_venue`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE venue SET venue_active=0
WHERE venue_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignation`(_element_id INT , _assigned_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  assigned SET assigned_id = _assigned_id , assigned_user_id = _assigned_user_id , assigned_note = _assigned_note
WHERE (assigned_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment`(_element_id INT , _screening_id INT , _paper_id INT , _user_id INT , _assignment_note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_role  VARCHAR(20) , _screening_phase INT)
BEGIN
START TRANSACTION;
UPDATE  screening_paper SET screening_id = _screening_id , paper_id = _paper_id , user_id = _user_id , assignment_note = _assignment_note , assignment_type = _assignment_type , assignment_role = _assignment_role , screening_phase = _screening_phase
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment_screen`(_element_id INT , _assignment_id INT , _user_id INT , _note  VARCHAR(205) , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  assignment_screen SET assignment_id = _assignment_id , user_id = _user_id , note = _note , screening_done = _screening_done
WHERE (assignment_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment_screen_validate`(_element_id INT , _assignment_id INT , _user_id INT , _note  VARCHAR(205) , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  assignment_screen_validate SET assignment_id = _assignment_id , user_id = _user_id , note = _note , screening_done = _screening_done
WHERE (assignment_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_author`(_element_id INT , _author_id INT , _author_name  VARCHAR(55) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
UPDATE  author SET author_id = _author_id , author_name = _author_name , author_desc = _author_desc , author_picture = _author_picture
WHERE (author_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_classification`(_element_id INT , _class_id INT , _class_paper_id INT , _transformation_name  VARCHAR(105) , _domain INT , _transformation_language INT , _source_language INT , _target_language INT , _Scope  VARCHAR(15) , _Industrial  VARCHAR(6) , _hot  VARCHAR(6) , _bidirectional  VARCHAR(6) , _implementation  VARCHAR(6) , _note  VARCHAR(505))
BEGIN
START TRANSACTION;
UPDATE  classification SET class_id = _class_id , class_paper_id = _class_paper_id , transformation_name = _transformation_name , domain = _domain , transformation_language = _transformation_language , source_language = _source_language , target_language = _target_language , Scope = _Scope , Industrial = _Industrial , hot = _hot , bidirectional = _bidirectional , implementation = _implementation , note = _note
WHERE (class_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_config`(_element_id INT , _config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , config_type = _config_type , editor_url = _editor_url , editor_generated_path = _editor_generated_path , csv_field_separator = _csv_field_separator , csv_field_separator_export = _csv_field_separator_export , screening_screening_conflict_resolution = _screening_screening_conflict_resolution , screening_conflict_type = _screening_conflict_type , import_papers_on = _import_papers_on , assign_papers_on = _assign_papers_on , screening_on = _screening_on , screening_result_on = _screening_result_on , screening_validation_on = _screening_validation_on , classification_on = _classification_on
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_configuration`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_configuration`(_element_id INT , _config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on INT , _screening_on INT , _assign_papers_on INT , _screening_result_on INT , _screening_validation_on INT , _classification_on INT , _source_papers_on INT , _search_strategy_on INT)
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , config_type = _config_type , editor_url = _editor_url , editor_generated_path = _editor_generated_path , csv_field_separator = _csv_field_separator , csv_field_separator_export = _csv_field_separator_export , screening_screening_conflict_resolution = _screening_screening_conflict_resolution , screening_conflict_type = _screening_conflict_type , import_papers_on = _import_papers_on , screening_on = _screening_on , assign_papers_on = _assign_papers_on , screening_result_on = _screening_result_on , screening_validation_on = _screening_validation_on , classification_on = _classification_on , source_papers_on = _source_papers_on , search_strategy_on = _search_strategy_on
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_exclusion`(_element_id INT , _exclusion_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  exclusion SET exclusion_id = _exclusion_id , exclusion_criteria = _exclusion_criteria , exclusion_note = _exclusion_note
WHERE (exclusion_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_exclusioncrieria`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
UPDATE  ref_exclusioncrieria SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_operations`(_element_id INT , _operation_id INT , _operation_desc  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  operations SET operation_id = _operation_id , operation_desc = _operation_desc
WHERE (operation_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_paper`(_element_id INT , _id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _doi  VARCHAR(205) , _year INT , _venueId INT , _preview LONGTEXT , _bibtex LONGTEXT , _abstract LONGTEXT , _papers_sources INT , _search_strategy INT)
BEGIN
START TRANSACTION;
UPDATE  paper SET id = _id , bibtexKey = _bibtexKey , title = _title , doi = _doi , year = _year , venueId = _venueId , preview = _preview , bibtex = _bibtex , abstract = _abstract , papers_sources = _papers_sources , search_strategy = _search_strategy
WHERE (id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_papers`(_element_id INT , _id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  paper SET id = _id , bibtexKey = _bibtexKey , title = _title , preview = _preview , bibtex = _bibtex , abstract = _abstract , doi = _doi , venueId = _venueId , paper_excluded = _paper_excluded
WHERE (id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_papers_sources`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_papers_sources`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
UPDATE  ref_papers_sources SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_paper_author`(_element_id INT , _paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
UPDATE  paperauthor SET paperauthor_id = _paperauthor_id , paperId = _paperId , authorId = _authorId
WHERE (paperauthor_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_domain`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_domain SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_exclusioncrieria`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  zref_exclusioncrieria SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_language`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_language SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_transformation_language`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_transformation_language SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screening`(_element_id INT , _screening_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  screening SET screening_id = _screening_id , decision = _decision , exclusion_criteria = _exclusion_criteria , note = _note
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screening_validate`(_element_id INT , _screening_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  screening_validate SET screening_id = _screening_id , decision = _decision , exclusion_criteria = _exclusion_criteria , note = _note
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screen_phase`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screen_phase`(_element_id INT , _screen_phase_id INT , _phase_title  VARCHAR(105) , _description  VARCHAR(1005) , _displayed_fields  VARCHAR(205) , _source_paper  VARCHAR(20) , _source_paper_status  VARCHAR(20) , _screen_phase_order INT , _screen_phase_final INT)
BEGIN
START TRANSACTION;
UPDATE  screen_phase SET screen_phase_id = _screen_phase_id , phase_title = _phase_title , description = _description , displayed_fields = _displayed_fields , source_paper = _source_paper , source_paper_status = _source_paper_status , screen_phase_order = _screen_phase_order , screen_phase_final = _screen_phase_final
WHERE (screen_phase_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_search_strategy`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_search_strategy`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(105))
BEGIN
START TRANSACTION;
UPDATE  ref_search_strategy SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_str_mng`(_element_id INT , _str_id INT , _str_text  VARCHAR(805))
BEGIN
START TRANSACTION;
UPDATE  str_management SET str_id = _str_id , str_text = _str_text
WHERE (str_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_venue`(_element_id INT , _venue_id INT , _venue_abbreviation  VARCHAR(25) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
UPDATE  venue SET venue_id = _venue_id , venue_abbreviation = _venue_abbreviation , venue_fullName = _venue_fullName , venue_year = _venue_year , venue_volume = _venue_volume , venue_totalNumPapers = _venue_totalNumPapers
WHERE (venue_id = _element_id);
COMMIT;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assigned`
--

DROP TABLE IF EXISTS `assigned`;
CREATE TABLE IF NOT EXISTS `assigned` (
  `assigned_id` int(11) NOT NULL AUTO_INCREMENT,
  `assigned_paper_id` int(11) NOT NULL,
  `assigned_user_id` int(11) NOT NULL,
  `assigned_note` text,
  `assigned_by` int(11) NOT NULL,
  `assigned_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `assigned_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assigned_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `assigned`
--

INSERT INTO `assigned` (`assigned_id`, `assigned_paper_id`, `assigned_user_id`, `assigned_note`, `assigned_by`, `assigned_time`, `assigned_active`) VALUES
(1, 3, 3, '', 1, '2017-06-16 05:40:15', 1),
(2, 6, 1, '', 1, '2017-06-16 06:00:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `assignment_screen`
--

DROP TABLE IF EXISTS `assignment_screen`;
CREATE TABLE IF NOT EXISTS `assignment_screen` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) DEFAULT NULL,
  `screening_done` int(2) NOT NULL DEFAULT '0',
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `assignment_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `assignment_screen_validate`
--

DROP TABLE IF EXISTS `assignment_screen_validate`;
CREATE TABLE IF NOT EXISTS `assignment_screen_validate` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) DEFAULT NULL,
  `screening_done` int(2) NOT NULL DEFAULT '0',
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `assignment_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
CREATE TABLE IF NOT EXISTS `author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(50) NOT NULL,
  `author_desc` varchar(200) DEFAULT NULL,
  `author_picture` longblob,
  `author_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`author_id`, `author_name`, `author_desc`, `author_picture`, `author_active`) VALUES
(1, 'Eugene Syriani', 'University of Montreal (DIRO)', NULL, 1),
(2, 'Brice', '', '', 0),
(3, 'Brice', '', '', 1),
(4, 'Michel', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `classification`
--

DROP TABLE IF EXISTS `classification`;
CREATE TABLE IF NOT EXISTS `classification` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_paper_id` int(11) DEFAULT NULL,
  `transformation_name` varchar(100) NOT NULL,
  `domain` int(11) DEFAULT NULL,
  `transformation_language` int(11) DEFAULT NULL,
  `source_language` int(11) DEFAULT NULL,
  `target_language` int(11) DEFAULT NULL,
  `Scope` enum('Exogenous','Inplace','Outplace') NOT NULL,
  `Industrial` int(2) DEFAULT NULL,
  `hot` int(2) NOT NULL,
  `bidirectional` int(2) DEFAULT NULL,
  `implementation` int(2) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `class_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `classification`
--

INSERT INTO `classification` (`class_id`, `class_paper_id`, `transformation_name`, `domain`, `transformation_language`, `source_language`, `target_language`, `Scope`, `Industrial`, `hot`, `bidirectional`, `implementation`, `note`, `class_active`) VALUES
(1, 3, 'test', 1, 3, 1, 3, 'Exogenous', 1, 1, 1, 1, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `classification_scheme`
--

DROP TABLE IF EXISTS `classification_scheme`;
CREATE TABLE IF NOT EXISTS `classification_scheme` (
  `scheme_id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme_label` varchar(100) NOT NULL,
  `scheme_title` varchar(100) NOT NULL,
  `scheme_parent` varchar(100) NOT NULL DEFAULT 'main',
  `scheme_mandatory` int(1) NOT NULL DEFAULT '0',
  `scheme_category` varchar(30) NOT NULL,
  `scheme_type` varchar(30) DEFAULT NULL,
  `scheme_size` int(11) DEFAULT NULL,
  `scheme_source` varchar(1000) DEFAULT NULL,
  `scheme_source_main_field` varchar(100) DEFAULT NULL,
  `scheme_number_of_values` varchar(2) NOT NULL DEFAULT '1',
  `scheme_order` int(2) NOT NULL DEFAULT '1',
  `scheme_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`scheme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_type` varchar(100) NOT NULL DEFAULT 'default',
  `editor_url` varchar(100) NOT NULL,
  `editor_generated_path` varchar(100) DEFAULT NULL,
  `csv_field_separator` enum(';',',') NOT NULL DEFAULT ';',
  `csv_field_separator_export` enum(';',',') NOT NULL DEFAULT ',',
  `screening_screening_conflict_resolution` enum('Unanimity','Majority') NOT NULL DEFAULT 'Unanimity',
  `screening_conflict_type` enum('IncludeExclude','ExclusionCriteria') NOT NULL DEFAULT 'IncludeExclude',
  `import_papers_on` int(2) NOT NULL DEFAULT '1',
  `assign_papers_on` int(2) NOT NULL DEFAULT '1',
  `screening_on` int(2) NOT NULL DEFAULT '1',
  `screening_validation_on` int(2) NOT NULL DEFAULT '1',
  `classification_on` int(2) NOT NULL DEFAULT '1',
  `screening_result_on` int(2) NOT NULL DEFAULT '1',
  `source_papers_on` int(2) NOT NULL DEFAULT '0',
  `search_strategy_on` int(2) NOT NULL DEFAULT '0',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_id`, `config_type`, `editor_url`, `editor_generated_path`, `csv_field_separator`, `csv_field_separator_export`, `screening_screening_conflict_resolution`, `screening_conflict_type`, `import_papers_on`, `assign_papers_on`, `screening_on`, `screening_validation_on`, `classification_on`, `screening_result_on`, `source_papers_on`, `search_strategy_on`, `config_active`) VALUES
(1, 'default', 'http://127.0.0.1:8080/relis/texteditor', 'C:/relis_workspace', ';', ',', 'Majority', 'IncludeExclude', 1, 1, 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `config_test`
--

DROP TABLE IF EXISTS `config_test`;
CREATE TABLE IF NOT EXISTS `config_test` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_type` varchar(100) NOT NULL,
  `editor_url` varchar(100) NOT NULL,
  `editor_generated_path` varchar(100) NOT NULL,
  `csv_field_separator` enum(';',',') NOT NULL DEFAULT ';',
  `csv_field_separator_export` enum(';',',') NOT NULL DEFAULT ',',
  `screening_screening_conflict_resolution` enum('Unanimity','Majority') NOT NULL DEFAULT 'Unanimity',
  `screening_conflict_type` enum('IncludeExclude','ExclusionCriteria') NOT NULL,
  `import_papers_on` int(2) NOT NULL DEFAULT '0',
  `assign_papers_on` int(2) NOT NULL DEFAULT '0',
  `screening_on` int(2) NOT NULL DEFAULT '0',
  `screening_result_on` int(2) NOT NULL DEFAULT '0',
  `screening_validation_on` int(2) NOT NULL DEFAULT '0',
  `classification_on` int(2) NOT NULL DEFAULT '0',
  `search_strategy_on` int(2) NOT NULL DEFAULT '0',
  `source_papers_on` int(2) NOT NULL DEFAULT '0',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `exclusion`
--

DROP TABLE IF EXISTS `exclusion`;
CREATE TABLE IF NOT EXISTS `exclusion` (
  `exclusion_id` int(11) NOT NULL AUTO_INCREMENT,
  `exclusion_paper_id` int(11) NOT NULL,
  `exclusion_criteria` int(11) NOT NULL,
  `exclusion_note` text,
  `exclusion_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `exclusion_by` int(11) NOT NULL,
  `exclusion_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`exclusion_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `exclusion`
--

INSERT INTO `exclusion` (`exclusion_id`, `exclusion_paper_id`, `exclusion_criteria`, `exclusion_note`, `exclusion_time`, `exclusion_by`, `exclusion_active`) VALUES
(1, 8, 1, '', '2017-06-16 06:01:31', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `installation_info`
--

DROP TABLE IF EXISTS `installation_info`;
CREATE TABLE IF NOT EXISTS `installation_info` (
  `install_id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_tables` text NOT NULL,
  `generated_tables` text NOT NULL,
  `foreign_key_constraint` text,
  `install_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`install_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `installation_info`
--

INSERT INTO `installation_info` (`install_id`, `reference_tables`, `generated_tables`, `foreign_key_constraint`, `install_active`) VALUES
(1, '["ref_domain","ref_transformation_language","ref_language"]', '["classification"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_transformation_language   , DROP FOREIGN KEY  classification_source_language   , DROP FOREIGN KEY  classification_target_language   ;"]', 1);

-- --------------------------------------------------------

--
-- Table structure for table `operations`
--

DROP TABLE IF EXISTS `operations`;
CREATE TABLE IF NOT EXISTS `operations` (
  `operation_id` int(11) NOT NULL AUTO_INCREMENT,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `operation_type` enum('import_paper','assign_papers','assign_papers_validation') NOT NULL DEFAULT 'import_paper',
  `operation_desc` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `operation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`operation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `operations`
--

INSERT INTO `operations` (`operation_id`, `operation_code`, `operation_type`, `operation_desc`, `user_id`, `operation_time`, `operation_active`) VALUES
(1, '1_1496692479', 'import_paper', 'Paper import before screening', 1, '2017-06-05 19:54:39', 1),
(2, '1_1496692942', 'import_paper', 'Paper import before screening', 1, '2017-06-05 20:02:23', 1),
(3, '1_1496699765', 'import_paper', 'Paper import before screening', 1, '2017-06-05 21:56:05', 1),
(4, '1_1496699881', 'import_paper', 'Paper import before screening', 1, '2017-06-05 21:58:01', 1),
(5, '1_1496700139', 'import_paper', 'Paper import before screening', 1, '2017-06-05 22:02:20', 1),
(6, '1_1496700522', 'import_paper', 'Paper import before screening', 1, '2017-06-05 22:08:43', 1),
(7, '1_1496700657', 'import_paper', 'Paper import before screening', 1, '2017-06-05 22:10:57', 1),
(8, '1_1496700685', 'import_paper', 'Paper import before screening', 1, '2017-06-05 22:11:27', 1),
(9, '1_1496778143', 'import_paper', 'Paper import before screening', 1, '2017-06-06 19:42:24', 1),
(10, '1_1496782787', 'assign_papers', 'Assign papers for screening', 1, '2017-06-06 20:59:49', 1),
(11, '1_1496792901', 'assign_papers', 'Assign papers for screening', 1, '2017-06-06 23:48:22', 1),
(12, '1_1496794563', 'assign_papers', 'Assign papers for screening', 1, '2017-06-07 00:16:05', 1),
(13, '1_1496810068', 'assign_papers', 'Assign papers for screening', 1, '2017-06-07 04:34:29', 1),
(14, '1_1496811907', 'assign_papers', 'Assign papers for screening', 1, '2017-06-07 05:05:09', 1),
(15, '1_1496855586', 'assign_papers', 'Assign papers for screening', 1, '2017-06-07 17:13:07', 1),
(16, '1_1497278376', 'assign_papers', 'Assign papers for screening', 1, '2017-06-12 14:39:38', 1),
(17, '1_1497310721', 'assign_papers', 'Assign papers for screening', 1, '2017-06-12 23:38:42', 1),
(18, '2_1497314656', 'assign_papers', 'Assign papers for screening', 2, '2017-06-13 00:44:18', 1),
(19, '1_1497492936', 'assign_papers', 'Assign papers for screening', 1, '2017-06-15 02:15:37', 1),
(20, '1_1497493426', 'assign_papers', 'Assign papers for screening', 1, '2017-06-15 02:23:47', 1),
(21, '1_1497543585', 'assign_papers_validation', 'Assign 20 % (2) of Excluded papers for Validate phase 1', 1, '2017-06-15 16:19:45', 1),
(22, '1_1497544202', 'assign_papers', 'Assign papers for screening', 1, '2017-06-15 16:30:04', 1),
(23, '1_1497544596', 'assign_papers_validation', 'Assign 50 % (3) of Excluded papers for Validate phase 1', 1, '2017-06-15 16:36:37', 1),
(24, '1_1497544650', 'assign_papers', 'Assign papers for screening', 1, '2017-06-15 16:37:30', 1),
(25, '1_1497544804', 'assign_papers', 'Assign papers for screening', 1, '2017-06-15 16:40:04', 1),
(26, '1_1497573654', 'assign_papers_validation', 'Assign 100 % (3) of Excluded papers for Validate phase 1', 1, '2017-06-16 00:40:54', 1),
(27, '1_1497588349', 'import_paper', 'Paper import before screening', 1, '2017-06-16 04:45:49', 1),
(28, '1_1497588391', 'assign_papers', 'Assign papers for screening', 1, '2017-06-16 04:46:32', 1),
(29, '1_1497588784', 'assign_papers_validation', 'Assign 50 % (5) of Excluded papers for Validate phase 1', 1, '2017-06-16 04:53:04', 1),
(30, '1_1497589316', 'assign_papers', 'Assign papers for screening', 1, '2017-06-16 05:01:57', 1),
(31, '1_1497590182', 'assign_papers', 'Assign papers for screening', 1, '2017-06-16 05:16:22', 1),
(32, '1_1497594617', 'assign_papers_validation', 'Assign 50 % (8) of Excluded papers for Validate all screenings', 1, '2017-06-16 06:30:17', 1);

-- --------------------------------------------------------

--
-- Table structure for table `paper`
--

DROP TABLE IF EXISTS `paper`;
CREATE TABLE IF NOT EXISTS `paper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bibtexKey` varchar(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `preview` longtext,
  `bibtex` longtext,
  `abstract` longtext,
  `doi` varchar(200) DEFAULT NULL,
  `year` int(4) DEFAULT NULL,
  `venueId` int(11) DEFAULT NULL,
  `papers_sources` int(11) DEFAULT NULL,
  `search_strategy` int(11) DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `addition_mode` enum('Automatic','Manually') NOT NULL DEFAULT 'Manually',
  `added_active_phase` varchar(20) NOT NULL,
  `screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded') NOT NULL DEFAULT 'Pending',
  `classification_status` enum('Waiting','To classify','Classified') NOT NULL DEFAULT 'Waiting',
  `paper_excluded` int(2) NOT NULL DEFAULT '0',
  `operation_code` varchar(20) DEFAULT NULL,
  `paper_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `paper`
--

INSERT INTO `paper` (`id`, `bibtexKey`, `title`, `preview`, `bibtex`, `abstract`, `doi`, `year`, `venueId`, `papers_sources`, `search_strategy`, `added_by`, `add_time`, `addition_mode`, `added_active_phase`, `screening_status`, `classification_status`, `paper_excluded`, `operation_code`, `paper_active`) VALUES
(1, 'paper_1', '5W+1H pattern: A perspective of systematic mapping studies and a case study on cloud software testing', '<b>Key words:</b><br/>5W+1H pattern, Cloud software testing, Systematic mapping study <br/>', '', 'A common type of study used by researchers to map out the landscape of a research topic is known as mapping study. Such a study typically begins with an exploratory search on the possible ideas of the research topic, which is often done in an unsystematic manner. Hence, the activity of formulating research questions in mapping studies is ill-defined, rendering it difficult for researchers who are new to the topic. There is a need to guide them kicking off a mapping study of an unfamiliar domain. This paper proposes a 5W+1H pattern to help investigators systematically examine a generic set of dimensions in a mapping study toward the formulation of research questions before identifying, reading, and analyzing sufficient articles of the topic. We have validated the feasibility of our proposal by conducting a case study of a mapping study on cloud software testing, that is, software testing for and on cloud computing platforms. The case study reveals that the 5W+1H pattern can lead investigators to define a set of systematic, generic, and complementary research questions, enabling them to kick off and expedite the mapping study process in a well-defined manner. We also share our experiences and lessons learned from our case study on the use of the 5W+1H pattern in mapping studies. Â© 2015 Elsevier Inc. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84923328222&partnerID=40&md5=ab9586291eb660686744b0d525513668', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(2, 'paper_2', 'A Mapping Study of Software Causal Factors for Improving Maintenance', '<b>Key words:</b><br/>controlled experiments, defects, mapping study, Software maintenance, systematic literature review <br/>', '', 'Context: Software maintenance is important to keep existing software systems functional for organizations or users that depend on that software. Goal: We aim to identify the factors, i.e., software characteristics such as code complexity, leading to maintenance problems. Method: We present a Mapping Study (MS) on controlled experiments that investigated software characteristics related to defects during maintenance. Results: The search strategy identified 78 papers, of which 9 have been included in our study, dated from 1985 to 2013, after applying our inclusion and exclusion criteria. We extracted data from these papers to identify the research methods, and the independent, dependent, blocked, and measured variables. Conclusions: Our MS results point to a weak evidence on software factors causing defects during maintenance. Stronger evidence can be developed via more controlled experiments that address multiple independent variables and hold the software objects constant. Â© 2015 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84961661951&partnerID=40&md5=692d940e823529be710d2f4f2ee0307f', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(3, 'paper_3', 'A first systematic mapping study on combinatorial interaction testing for software product lines', '', '', 'Software Product Lines (SPLs) are families of related software systems distinguished by the set of features each one provides. Over the past decades SPLs have been the subject of extensive research and application both in academia and industry. SPLs practices have proven benefits such as better product customization and reduced time to market. Testing SPLs pose additional challenges stemming from the typically large number of product variants which make it infeasible to test every single one of them. In recent years, there has been an extensive research on applying Combinatorial Interaction Testing (CIT) for SPL testing. In this paper we present the first systematic mapping study on this subject. Our research questions aim to gather information regarding the techniques that have been applied, the nature of the case studies used for their evaluation, and what phases of CIT have been addressed. Our goal is to identify common trends, gaps, and opportunities for further research and application. Â© 2015 IEEE.,', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84934343294&partnerID=40&md5=ec6b20b311c1f97790d067319331ba4d', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Included', 'To classify', 0, '1_1497588349', 1),
(4, 'paper_4', 'A systematic literature review of literature reviews in software testing', '<b>Key words:</b><br/>Secondary studies, Software testing, Surveys, Systematic literature reviews, Systematic mapping, Tertiary study <br/>', '', 'Context Any newcomer or industrial practitioner is likely to experience difficulties in digesting large volumes of knowledge in software testing. In an ideal world, all knowledge used in industry, education and research should be based on high-quality evidence. Since no decision should be made based on a single study, secondary studies become essential in presenting the evidence. According to our search, over 101 secondary studies have been published in the area of software testing since 1994. With this high number of secondary studies, it is important to conduct a review in this area to provide an overview of the research landscape in this area. Objective The goal of this study is to systematically map (classify) the secondary studies in software testing. We propose that tertiary studies can serve as summarizing indexes which facilitate finding the most relevant information from secondary studies and thus supporting evidence-based decision making in any given area of software engineering. Our research questions (RQs) investigate: (1) Software-testing-specific areas, (2) Types of RQs investigated, (3) Numbers and Trends, and (4) Citations of the secondary studies. Method To conduct the tertiary study, we use the systematic-mapping approach. Additionally, we contrast the testing topics to the number of Google hits to address a general popularity of a testing topic and study the most popular papers in terms of citations. We furthermore demonstrate the practicality and usefulness of our results by mapping them to ISTQB foundation syllabus and to SWEBOK to provide implications for practitioners, testing educators, and researchers. Results After a systematic search and voting process, our study pool included 101 secondary studies in the area of software testing between 1994 and 2015. Among our results are the following: (1) In terms of number of secondary studies, model-based approach is the most popular testing method, web services are the most popular system under test (SUT), while regression testing is the most popular testing phase, (2) The quality of secondary studies, as measured by a criteria set established in the community, is slowly increasing as the years go by, and (3) Analysis of research questions, raised and studied in the pool of secondary studies, showed that there is a lack of causality and relationship type of research questions, a situation which needs to be improved if we, as a community, want to advance as a scientific field. (4) Among secondary studies, we found that regular surveys receive significantly more citations than SMs (pÂ =Â 0.009) and SLRs (pÂ =Â 0.014). Conclusion Despite the large number of secondary studies, we found that many important areas of software testing currently lack secondary studies, e.g., test management, role of product risk in testing, human factors in software testing, beta-testing (A/B-testing), exploratory testing, testability, test stopping criteria, and test-environment development. Having secondary studies in those areas is important for satisfying industrial and educational needs in software testing. On the other hand, education material of ISTQB foundation syllabus and SWEBOK could benefit from the inclusion of the latest research topics, namely search-based testing, use of cloud-computing for testing and symbolic execution. Â© 2016 Elsevier B.V.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84987968030&partnerID=40&md5=39f3eeecc191a79349289ea4d0d321f6', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(5, 'paper_5', 'A systematic mapping of data generation for integration software testing', '', '', 'Different techniques have been proposed to test software artifacts and source code. Integration testing, however, has not been sufficiently applied to all types of systems that require high-quality evaluation. This paper summarizes approaches proposed to test data generation for integration testing identifying gaps and opportunities for further research. We conducted a systematic mapping study in order to discover how data generation for integration testing is supported by existing approaches. A subjective evaluation of the studies was also carried out to evaluate them in terms of quality. As a result of the systematic mapping we found 38 primary studies, published between 1996 and 2015. Most of them focus on specification-based coverage, and to a lesser extent, code coverage. The following trends were identified: increased use of UML models and concern regarding automated test data generation. Gaps were found in the use of gray-box approaches, mutation testing, data generation tools, and experimental validation studies. The study''s findings enable researchers to attain an overview of existing approaches and identify points that require further attention. Future research work should look at cost and effectiveness of such approaches.,', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988345153&partnerID=40&md5=f10417d2aad10c1c762d0ff6ba8926ac', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(6, 'paper_6', 'A systematic mapping study of software product lines testing', '<b>Key words:</b><br/>Mapping study, Software product lines, Software testing <br/>', '', 'Context: In software development, Testing is an important mechanism both to identify defects and assure that completed products work as specified. This is a common practice in single-system development, and continues to hold in Software Product Lines (SPL). Even though extensive research has been done in the SPL Testing field, it is necessary to assess the current state of research and practice, in order to provide practitioners with evidence that enable fostering its further development. Objective: This paper focuses on Testing in SPL and has the following goals: investigate state-of-the-art testing practices, synthesize available evidence, and identify gaps between required techniques and existing approaches, available in the literature. Method: A systematic mapping study was conducted with a set of nine research questions, in which 120 studies, dated from 1993 to 2009, were evaluated. Results: Although several aspects regarding testing have been covered by single-system development approaches, many cannot be directly applied in the SPL context due to specific issues. In addition, particular aspects regarding SPL are not covered by the existing SPL approaches, and when the aspects are covered, the literature just gives brief overviews. This scenario indicates that additional investigation, empirical and practical, should be performed. Conclusion: The results can help to understand the needs in SPL Testing, by identifying points that still require additional investigation, since important aspects regarding particular points of software product lines have not been addressed yet. Â© 2010 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-79952451558&partnerID=40&md5=a966054f3f281e0f2e4234c8bea7f399', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Included', 'To classify', 0, '1_1497588349', 1),
(7, 'paper_7', 'A systematic mapping study on non-functional search-based software testing', '', '', 'Automated software test generation has been applied across the spectrum of test case design methods, this includes white-box (structural), black-box (functional), grey-box (combination of structural and functional) and non-functional testing. In this paper, we undertake a systematic mapping study to present a broad review of primary studies on the application of search-based optimization techniques to non-functional testing. The motivation is to identify the evidence available on the topic and to identify gaps in the application of search-based optimization techniques to different types of non-functional testing. The study is based on a comprehensive set of 35 papers obtained after using a multi-stage selection criteria and are published in workshops, conferences and journals in the time span 1996-2007. We conclude that the search-based software testing community needs to do more and broader studies on non-functional search-based software testing (NFSBST) and the results from our systematic map can help direct such efforts.,', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-79952453274&partnerID=40&md5=0d3653455ce936d871b57b8f516b2988', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Included', 'To classify', 0, '1_1497588349', 1),
(8, 'paper_8', 'A systematic mapping study on software engineering testbeds', '<b>Key words:</b><br/>Empirical software engineering, Technology evaluation, Technology transfer, Testbeds <br/>', '', 'Even though empirical research has grown in interest, techniques, methodologies and best practices are still in debate. In this context, testbeds are effective when one needs to evaluate and compare technologies. The concept is well disseminated in other areas such as Computer Networks, but remains poorly explored in Software Engineering (SE). This paper presents a systematic mapping study on the SE testbeds literature. From the initial set of 4239 studies, 13 primary studies were selected and categorized. Based on that, we found that Software Architecture is the most investigated topic, controlled experiment is the most used method to evaluate such testbeds, 20 benefits of using testbeds in SE have been identified and that testbeds comprise very heterogeneous structural elements. Â© 2011 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84858737751&partnerID=40&md5=ea351c7fbb76a17afc002da9e7fa4d10', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Included', 'To classify', 0, '1_1497588349', 1),
(9, 'paper_9', 'Alignment of requirements specification and testing: A systematic mapping study', '', '', 'Requirements should specify expectations on a software system and testing should ensure these expectations are met. Thus, to enable high product quality and efficient development it is crucial that requirements and testing activities and information are aligned. A lot of research has been done in the respective fields Requirements Engineering and Testing but there is a lack of summaries of the current state of the art on how to link the two. This study presents a systematic mapping of the alignment of specification and testing of functional or nonfunctional requirements in order to identify useful approaches and needs for future research. In particular we focus on results relevant for nonfunctional requirements but since only a few studies was found on alignment in total we also cover the ones on functional requirements. The map summarizes the 35 relevant papers found and discuss them within six major sub categories with model-based testing and traceability being the ones with most prior results. Â© 2011 IEEE.,', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-80051659665&partnerID=40&md5=946d9ca5308f2b04884f4276b6c2a12e', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Included', 'To classify', 0, '1_1497588349', 1),
(10, 'paper_10', 'Analyzing an automotive testing process with evidence-based software engineering', '<b>Key words:</b><br/>Automotive software testing, Evidence-based software engineering, Process assessment <br/>', '', 'Context: Evidence-based software engineering (EBSE) provides a process for solving practical problems based on a rigorous research approach. The primary focus so far was on mapping and aggregating evidence through systematic reviews. Objectives: We extend existing work on evidence-based software engineering by using the EBSE process in an industrial case to help an organization to improve its automotive testing process. With this we contribute in (1) providing experiences on using evidence based processes to analyze a real world automotive test process and (2) provide evidence of challenges and related solutions for automotive software testing processes. Methods: In this study we perform an in-depth investigation of an automotive test process using an extended EBSE process including case study research (gain an understanding of practical questions to define a research scope), systematic literature review (identify solutions through systematic literature), and value stream mapping (map out an improved automotive test process based on the current situation and improvement suggestions identified). These are followed by reflections on the EBSE process used. Results: In the first step of the EBSE process we identified 10 challenge areas with a total of 26 individual challenges. For 15 out of those 26 challenges our domain specific systematic literature review identified solutions. Based on the input from the challenges and the solutions, we created a value stream map of the current and future process. Conclusions: Overall, we found that the evidence-based process as presented in this study helps in technology transfer of research results to industry, but at the same time some challenges lie ahead (e.g. scoping systematic reviews to focus more on concrete industry problems, and understanding strategies of conducting EBSE with respect to effort and quality of the evidence). Â© 2013 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877922741&partnerID=40&md5=b6dc2fcdca02a51db47c5925cfbaaa66', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(11, 'paper_11', 'Challenges and opportunities for software change request repositories: A systematic mapping study', '<b>Key words:</b><br/>bug report, bug tracking, change request repository, software evolution, software maintenance, software quality assurance <br/>', '', 'Software maintenance starts as soon as the first artifacts are delivered and is essential for the success of the software. However, keeping maintenance activities and their related artifacts on track comes at a high cost. In this respect, change request (CR) repositories are fundamental in software maintenance. They facilitate the management of CRs and are also the central point to coordinate activities and communication among stakeholders. However, the benefits of CR repositories do not come without issues, and commonly occurring ones should be dealt with, such as the following: duplicate CRs, the large number of CRs to assign, or poorly described CRs. Such issues have led researchers to an increased interest in investigating CR repositories, by considering different aspects of software development and CR management. In this paper, we performed a systematic mapping study to characterize this research field. We analyzed 142 studies, which we classified in two ways. First, we classified the studies into different topics and grouped them into two dimensions: challenges and opportunities. Second, the challenge topics were classified in accordance with an existing taxonomy for information retrieval models. In addition, we investigated tools and services for CR management, to understand whether and how they addressed the topics identified. Copyright Â© 2013 John Wiley & Sons, Ltd. Change request repositories are fundamental for software maintenance. However, their benefits do not come without issues. We analyzed 142 studies to characterize the research on these issues and provide directions for future investigation. The studies were classified into topics and grouped into two dimensions: challenges and opportunities. Then, the challenges were classified in accordance with an existing taxonomy for information retrieval models. Additionally, we investigated different change request repositories to understand whether and how they addressed the topics identified. Copyright Â© 2013 John Wiley & Sons, Ltd.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84904626790&partnerID=40&md5=7e8fe6e32dba1cdb6f3f9a3e39b3fed1', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(12, 'paper_12', 'Change impact in product lines: A systematic mapping study', '<b>Key words:</b><br/>Change impact analysis, Embedded systems, Hardware/Software, Product family, Product line, Systematic mapping study <br/>', '', 'A product line (PL) supports and simplifies the development process of (software) systems by reusing assets. As systems are subjected to frequent alterations, the implementation of this changes can be a complex and error-prone task. For this reason a change impact analysis (CIA) systematically identifies locations that are affected by a change. While both approaches (PL and CIA) per se are often discussed in literature, the combination of them is still a challenge. This paper gives a comprehensive overview of literature, which addresses the integration of PL and CIA concepts. Furthermore, we classify our results to outline both, the current research stage as well as gaps. Therefore, we conducted a systematic mapping study incorporating 165 papers. While most of the papers have their background within Software Product Lines (SPLs) (44.2%) or PLs (5.5%), CIA in the combination with Multi Product Lines (2.4%) or Product Families (PFs) (1.8%) is sparsely addressed in literature. The results show that CIA for SPLs has been partially addressed yet, whereas the consideration of different disciplines (PFs) is insufficiently covered. Â© Springer International Publishing Switzerland 2016.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988892509&partnerID=40&md5=e13d8fd1207f2f064c58fb7a85a09838', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(13, 'paper_13', 'Characteristics, attributes, metrics and usability recommendations: A systematic mapping', '<b>Key words:</b><br/>Systematic Mapping, Usability Evaluation <br/>', '', 'The research scenario concerned about software usability addresses a wide range of characteristics, attributes and evaluation models. As result, we can observe the evaluators difficult in order to select the characteristics that best apply to the product that is being evaluated. By this way, this paper presents a systematic mapping in order to identify the main characteristics of usability evaluation related to web, desktop and mobile devices environments. As results, we selected 31 papers in order to perform data extraction and way possible to produce a list of 28 evaluation characteristics. Copyright Â© IARIA, 2014.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84966602566&partnerID=40&md5=7b11e8b0f75c1d4766c99f68b59e8772', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(14, 'paper_14', 'Concurrent software testing in practice: A catalog of tools', '<b>Key words:</b><br/>Concurrent programs, Systematic mapping, Testing tools <br/>', '', 'The testing of concurrent programs is very complex due to the non-determinism present in those programs. They must be subjected to a systematic testing process that assists in the identification of defects and guarantees quality. Although testing tools have been proposed to support the concurrent program testing, to the best of our knowledge, no study that concentrates all testing tools to be used as a catalog for testers is available in the literature. This paper proposes a new classification for a set of testing tools for concurrent programs, regarding attributes, such as testing technique supported, programming language, and paradigm of development. The purpose is to provide a useful categorization guide that helps testing practitioners and researchers in the selection of testing tools for concurrent programs. A systematic mapping was conducted so that studies on testing tools for concurrent programs could be identified. As a main result, we provide a catalog with 116 testing tools appropriately selected and classified, among which the following techniques were identifies with higher support were Java and C/C++. Although a large number of tools have been categoirzed, most of them are academic and only few are available on a commercial scale. The classification proposed here can contribute to the state-of-the-art of testing tools for concurrent programs and also provides information for the exchange of knowledge between academy and industry. Â© 2015 ACM.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84960350804&partnerID=40&md5=5490f6be1c5b623eff6d7593c770b4cd', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(15, 'paper_15', 'Cost, benefits and quality of software development documentation: A systematic mapping', '<b>Key words:</b><br/>Documentation benefit, Software documentation, Systematic mapping <br/>', '', 'Context: Software documentation is an integral part of any software development process. Researchers and practitioners have expressed concerns about costs, benefits and quality of software documentation in practice. On the one hand, there is a lack of a comprehensive model to evaluate the quality of documentation. On the other hand, researchers and practitioners need to assess whether documentation cost outweighs its benefit. Objectives: In this study, we aim to summarize the existing literature and provide an overview of the field of software documentation cost, benefit and quality. Method: We use the systematic-mapping methodology to map the existing body of knowledge related to software documentation cost, benefit and quality. To achieve our objectives, 11 Research Questions (RQ) are raised. The primary papers are carefully selected. After applying the inclusion and exclusion criteria, our study pool included a set of 69 papers from 1971 to 2011. A systematic map is developed and refined iteratively. Results: We present the results of a systematic mapping covering different research aspects related to software documentation cost, benefit and quality (RQ 1-11). Key findings include: (1) validation research papers are dominating (27 papers), followed by solution proposals (21 papers). (2) Most papers (61 out of 69) do not mention the development life-cycle model explicitly. Agile development is only mentioned in 6 papers. (3) Most papers include only one System under Study (SUS) which is mostly academic prototype. The average number of participants in survey-based papers is 106, the highest one having approximately 1000 participants. (4) In terms of focus of papers, 50 papers focused on documentation quality, followed by 37 papers on benefit, and 12 papers on documentation cost. (5) The quality attributes of documentation that appear in most papers are, in order: completeness, consistency and accessibility. Additionally, improved meta-models for documentation cost, benefit and quality are also presented. Furthermore, we have created an online paper repository of the primary papers analyzed and mapped during this study. Conclusion: Our study results show that this research area is emerging but far from mature. Firstly, documentation cost aspect seems to have been neglected in the existing literature and there are no systematic methods or models to measure cost. Also, despite a substantial number of solutions proposed during the last 40 years, more and stronger empirical evidences are still needed to enhance our understanding of this area. In particular, what we expect includes (1) more validation or evaluation studies, (2) studies involving large-scale development projects, or from large number of study participants of various organizations, (3) more industry-academia collaborations, (4) more estimation models or methods to assess documentation quality, benefit and, especially, cost. Â© 2014 Elsevier Inc. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84912534729&partnerID=40&md5=5a2b8c80ac6e71817e1fa2ffb79f59fc', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(16, 'paper_16', 'Empirical studies concerning the maintenance of UML diagrams and their use in the maintenance of code: A systematic mapping study', '<b>Key words:</b><br/>Empirical studies, Software maintenance, Systematic literature review, Systematic mapping study, UML <br/>', '', 'Context: The Unified Modelling Language (UML) has, after ten years, become established as the de facto standard for the modelling of object-oriented software systems. It is therefore relevant to investigate whether its use is important as regards the costs involved in its implantation in industry being worthwhile. Method: We have carried out a systematic mapping study to collect the empirical studies published in order to discover What is the current existing empirical evidence with regard to the use of UML diagrams in source code maintenance and the maintenance of the UML diagrams themselves? Results: We found 38 papers, which contained 63 experiments and 3 case studies. Conclusion: Although there is common belief that the use of UML is beneficial for source code maintenance, since the quality of the modifications is greater when UML diagrams are available, only 3 papers concerning this issue have been published. Most research (60 empirical studies) concerns the maintainability and comprehensibility of the UML diagrams themselves which form part of the system''s documentation, since it is assumed that they may influence source code maintainability, although this has not been empirically validated. Moreover, the generalizability of the majority of the experiments is questionable given the material, tasks and subjects used. There is thus a need for more experiments and case studies to be performed in industrial contexts, i.e., with real systems and using maintenance tasks conducted by practitioners under real conditions that truly show the utility of UML diagrams in maintaining code, and that the fact that a diagram is more comprehensible or modifiable influences the maintainability of the code itself. This utility should also be studied from the viewpoint of cost and productivity, and the consistent and simultaneous maintenance of diagrams and code must also be considered in future empirical studies. Â© 2013 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877909370&partnerID=40&md5=b548f09fd4efa3d1319209f1db1125a6', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(17, 'paper_17', 'Evaluating software product quality: A systematic mapping study', '', '', 'Evaluating software product quality (SPQ) is an important task to ensure the quality of software products. In this paper a systematic mapping study was performed to summarize the existing SPQ evaluation (SPQE) approaches in literature and to classify the selected studies according to seven classification criteria: SPQE approaches, research types, empirical types, data sets used in the empirical evaluation of these studies, artifacts, SQ models, and SQ characteristics. Publication channels and trends were also identified. 57 papers were selected. The results show that the main publication sources of the papers identified were journals. Data mining techniques are the most frequently approaches reported in literature. Solution proposals were the main research type identified. The majority of the selected papers were history-based evaluations using existing data, which were mainly obtained from open source software projects and domain specific projects. Source code was the main artifacts used by SPQE approaches. Well-known SQ models were mentioned by half of the selected papers and reliability is the SQ characteristic through which SPQE was mainly achieved. SPQE-related subjects seem to attract more interest from researchers since the past years. Â© 2014 IEEE.,', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84924054129&partnerID=40&md5=19c52fa109db72d3bcb6b46d8b326ee1', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(18, 'paper_18', 'Feature location for software product line migration: A mapping study', '<b>Key words:</b><br/>Evolution, Reengineering, Reuse, Software product line <br/>', '', 'Developing software from scratch is a high cost and errorprone activity. A possible solution to reduce time-to-market and produce high quality software is the reuse of existing software. But when the number of features in the system grows, the maintenance becomes more complex. In such cases, to adopt a systematic approach, such as Software Product Line Engineering, is necessary. Existing systems are generally migrated to a product line, allowing systematic reuse of artefacts and easing maintenance. To this end, some approaches have been proposed in the literature in the last years. A mapping of works on this subject and the identification of some research gaps can lead to an improvement of such approaches. This paper describes the main outcomes of a systematic mapping study on the evolution and migration of systems to SPL. The main works found are presented and classified according to adopted strategy, artefacts used, and evaluation conducted. Analysis of the evolution along the past years are also presented. At the end, we summarize some trends and open issues to serve as reference to new researches. Copyright 2014 ACM.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907833307&partnerID=40&md5=48b514819a4aba2c01c7cea8bb911254', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(19, 'paper_19', 'Graphical user interface (GUI) testing: Systematic mapping and repository', '<b>Key words:</b><br/>Bibliometrics, GUI application, Paper repository, Systematic mapping, Testing <br/>', '', 'Context GUI testing is system testing of a software that has a graphical-user interface (GUI) front-end. Because system testing entails that the entire software system, including the user interface, be tested as a whole, during GUI testing, test cases - modeled as sequences of user input events - are developed and executed on the software by exercising the GUI''s widgets (e.g., text boxes and clickable buttons). More than 230 articles have appeared in the area of GUI testing since 1991. Objective In this paper, we study this existing body of knowledge using a systematic mapping (SM). Method The SM is conducted using the guidelines proposed by Petersen et al. We pose three sets of research questions. We define selection and exclusion criteria. From the initial pool of 230 articles, published in years 1991-2011, our final pool consisted of 136 articles. We systematically develop a classification scheme and map the selected articles to this scheme. Results We present two types of results. First, we report the demographics and bibliometrics trends in this domain, including: top-cited articles, active researchers, top venues, and active countries in this research area. Moreover, we derive the trends, for instance, in terms of types of articles, sources of information to derive test cases, types of evaluations used in articles, etc. Our second major result is a publicly-accessible repository that contains all our mapping data. We plan to update this repository on a regular basis, making it a live resource for all researchers. Conclusion Our SM provides an overview of existing GUI testing approaches and helps spot areas in the field that require more attention from the research community. For example, much work is needed to connect academic model-based techniques with commercially available tools. To this end, studies are needed to compare the state-of-the-art in GUI testing in academic techniques and industrial tools. Â© 2013 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84880786120&partnerID=40&md5=6a4843e704cb6d905ce9da59d7d402ad', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(20, 'paper_20', 'ISBSG variables most frequently used for software effort estimation: A mapping review', '<b>Key words:</b><br/>ISBSG, missing values, software effort estimation, software engineering, systematic mapping study <br/>', '', 'Background: The International Software Benchmarking Standards Group (ISBSG) dataset makes it possible to estimate a project''s size, effort, duration, and cost. Aim: The aim was to analyze the ISBSG variables that have been used by researchers for software effort estimation from 2000, when the first papers were published, until the end of 2013. Method: A systematic mapping review was applied to over 167 papers obtained after the filtering process. From these, it was found that 133 papers produce effort estimation and only 107 list the independent variables used in the effort estimation models. Results: Seventy-one out of 118 ISBSG variables have been used at least once. There is a group of 20 variables that appear in more than 50% of the papers and include Functional Size (62%), Development Type (58%), Language Type (53%), and Development Platform (52%) following ISBSG recommendations. Sizing and Size attributes altogether represent the most relevant group along with Project attributes that includes 24 technical features of the project and the development platform. All in all, variables that have more missing values are used less frequently. Conclusions: This work presents a snapshot of the existing usage of ISBSG variables in software development estimation. Moreover, some insights are provided to guide future studies. Â© 2014 ACM.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907808906&partnerID=40&md5=cf63a03ed883a32324a27bd726f9a00e', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(21, 'paper_21', 'Knowledge management applied to software testing: A systematic mapping', '<b>Key words:</b><br/>Knowledge management, Software testing, Systematic mapping <br/>', '', 'With the growth of data from several different sources of knowledge within an organization, it becomes necessary to provide computerized support for tasks of acquiring, processing, analyzing and disseminating knowledge. In the software process, testing is a critical factor for product quality, and thus there is an increasing concern in how to improve the accomplishment of this task. In software testing, finding relevant knowledge to reuse can be a difficult and complex task, due to the lack of a strategy to represent or to associate semantics to a large volume of test data, including test cases, testing techniques to be applied and so on. This paper aims to investigate, through a Systematic Mapping of the Literature, some aspects associated with applying Knowledge Management to Software Testing. Copyright Â© 2013 by Knowledge Systems Institute Graduate School.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84922663129&partnerID=40&md5=f38645ba853196e34678283ee883a71e', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(22, 'paper_22', 'Predicting software product quality: A systematic mapping study', '<b>Key words:</b><br/>Prediction, Software product quality, Systematic mapping study <br/>', '', 'Predicting software product quality (SPQ) is becoming a permanent concern during software life cycle phases. In this paper, a systematic mapping study was performed to summarize the existing SPQ prediction (SPQP) approaches in literature and to organize the selected studies according to seven classification criteria: SPQP approaches, research types, empirical types, data sets used in the empirical evaluation of these studies, artifacts, SQ models, and SQ characteristics. Publication channels and trends were also identified. After identifying 182 documents in ACM Digital Library, IEEE Xplore, ScienceDirect, SpringerLink, and Google scholar, 69 papers were selected. The results show that the main publication source of the papers identified was conference. Data mining techniques are the most frequently SPQP approaches reported in literature. Solution proposal was the main research type identified. The majority of the papers selected were history-based evaluations using existing data which were mainly obtained from open source software projects and domain specific projects. Source code was the main artifact concerned with SPQP approaches. Well-known SQ models were hardly mentioned and reliability is the SQ characteristic through which SPQP was mainly achieved. SPQP-related subject seems to need more investigation from researchers and practitioners. Moreover, SQ models and standards need to be considered more in future SPQP research.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84943600627&partnerID=40&md5=27f0050c8409ce3cf88e684e2a45a4b4', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(23, 'paper_23', 'Reducing test effort: A systematic mapping study on existing approaches', '<b>Key words:</b><br/>Efficiency improvement, Mapping study, Quality assurance, Software testing, Test effort reduction <br/>', '', 'Context: Quality assurance effort, especially testing effort, is often a major cost factor during software development, which sometimes consumes more than 50% of the overall development effort. Consequently, one major goal is often to reduce testing effort. Objective: The main goal of the systematic mapping study is the identification of existing approaches that are able to reduce testing effort. Therefore, an overview should be presented both for researchers and practitioners in order to identify, on the one hand, future research directions and, on the other hand, potential for improvements in practical environments. Method: Two researchers performed a systematic mapping study, focusing on four databases with an initial result set of 4020 articles. Results: In total, we selected and categorized 144 articles. Five different areas were identified that exploit different ways to reduce testing effort: approaches that predict defect-prone parts or defect content, automation, test input reduction approaches, quality assurance techniques applied before testing, and test strategy approaches. Conclusion: The results reflect an increased interest in this topic in recent years. A lot of different approaches have been developed, refined, and evaluated in different environments. The highest attention was found with respect to automation and prediction approaches. In addition, some input reduction approaches were found. However, in terms of combining early quality assurance activities with testing to reduce test effort, only a small number of approaches were found. Due to the continuous challenge of reducing test effort, future research in this area is expected. Â© 2012 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84863453536&partnerID=40&md5=2d892e6bc6835d86cc6e6c508857db8f', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(24, 'paper_24', 'Risk management in software product line engineering: A mapping study', '<b>Key words:</b><br/>Mapping study, Risk management, Software product lines <br/>', '', 'Software Product Line (SPL) Engineering focuses on systematic software reuse, which has benefits such as reductions in time-to-market and effort, and improvements in the quality of products. However, establishing a SPL is not a simple matter, and can affect all aspects of the organization, since the approach is complex and involves major investment and considerable risk. These risks can have a negative impact on the expected ROI for an organization, if SPL is not sufficiently managed. This paper presents a mapping study of Risk Management (RM) in SPL Engineering. We analyzed a set of thirty studies in the field. The results points out the need for risk management practices in SPL, due to the little research on RM practices in SPL and the importance of identifying insight on RM in SPL. Most studies simply mention the importance of RM, however the steps for managing risk are not clearly specified. Our findings suggest that greater attention should be given, through the use of industrial case studies and experiments, to improve SPL productivity and ensure its success. This research is a first attempt within the SPL community to identify, classify, and manage risks, and establish mitigation strategies. Â© 2013 World Scientific Publishing Company.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84881014807&partnerID=40&md5=83fe16cebf1cd3ccebfb7b597fcd2cae', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(25, 'paper_25', 'Software fault prediction: A systematic mapping study', '<b>Key words:</b><br/>Fault prediction models, Software metrics, Software quality <br/>', '', 'Context: Software fault prediction has been an important research topic in the software engineering field for more than 30 years. Software defect prediction models are commonly used to detect faulty software modules based on software metrics collected during the software development process. Objective: Data mining techniques and machine learning studies in the fault prediction software context are mapped and characterized. We investigated the metrics and techniques and their performance according to performance metrics studied. An analysis and synthesis of these studies is conducted. Method: A systematic mapping study has been conducted for identifying and aggregating evidence about software fault prediction. Results: About 70 studies published from January 2002 to December 2014 were identified. Top 40 studies were selected for analysis, based on the quality criteria results. The main metrics used were: Halstead, McCabe and LOC (67.14%), Halstead, McCabe and LOC + Object-Oriented (15.71%), others (17.14%). The main models were: Machine Learning(ML) (47.14%), ML + Statistical Analysis (31.42%), others (21.41%). The data sets used were: private access (35%) and public access (65%). The most frequent combination of metrics, models and techniques were: Halstead, McCabe and LOC + Random Forest, Naive Bayes, Logistic Regression and Decision Tree representing the (60%) of the analyzed studies. Conclusions: This article has identified and classified the performance of the metrics, techniques and their combinations. This will help researchers to select datasets, metrics and models based on experimental results, with the objective to generate learning schemes that allow a better prediction software failures. Copyright Â© 2015 by the authors.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84936110818&partnerID=40&md5=f18253acbe762249e0a5803739257b51', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(26, 'paper_26', 'Software product line testing - A systematic mapping study', '<b>Key words:</b><br/>Software product line testing, Systematic literature review, Systematic mapping, Testing <br/>', '', 'Context: Software product lines (SPL) are used in industry to achieve more efficient software development. However, the testing side of SPL is underdeveloped. Objective: This study aims at surveying existing research on SPL testing in order to identify useful approaches and needs for future research. Method: A systematic mapping study is launched to find as much literature as possible, and the 64 papers found are classified with respect to focus, research type and contribution type. Results: A majority of the papers are of proposal research types (64%). System testing is the largest group with respect to research focus (40%), followed by management (23%). Method contributions are in majority. Conclusions: More validation and evaluation research is needed to provide a better foundation for SPL testing. Â© 2010 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-78049529957&partnerID=40&md5=d0c91740e3fa70679e4560d266a06d48', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1);
INSERT INTO `paper` (`id`, `bibtexKey`, `title`, `preview`, `bibtex`, `abstract`, `doi`, `year`, `venueId`, `papers_sources`, `search_strategy`, `added_by`, `add_time`, `addition_mode`, `added_active_phase`, `screening_status`, `classification_status`, `paper_excluded`, `operation_code`, `paper_active`) VALUES
(27, 'paper_27', 'Software quality requirements: A systematic mapping study', '<b>Key words:</b><br/>Requirement engineering, Software quality requirements, Systematic mapping study <br/>', '', 'Software quality requirements (SQR) play a central role in software quality (SQ) success. The importance of mastering SQR can be seen as obvious, however, when it comes to customer satisfaction, end-users are often dissatisfied with SQ. In this paper, a systematic mapping study aims to summarize SQR research by answering nine mapping questions. In total, 51 articles were selected and classified according to multiple criteria: publication source, publication year, research type, research approach, contribution type of SQR literature, requirements engineering activity, well-known SQ model, software artifact and SQR type. The results show an increased interest in SQR research in recent years and reveal that conferences are the main SQR publication target. Most SQR research has used case studies. The dominant contribution type of SQR research is method while specification is the main requirements engineering activity identified. SQ models need to be more used for SQR identification. Design module and requirements documentation are the principal artifacts reported in SQR literature. External and internal SQR were the main SQR types addressed in literature. Identifying empirical solutions to address SQR is a promising research direction for researchers. Â© 2013 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84933501221&partnerID=40&md5=16c9a1d2da950000184c6347a78c4f83', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(28, 'paper_28', 'Software test-code engineering: A systematic mapping', '<b>Key words:</b><br/>Development of test code, Quality assessment of test code, Software test-code engineering, Study repository, Survey, Systematic mapping <br/>', '', 'Context: As a result of automated software testing, large amounts of software test code (script) are usually developed by software teams. Automated test scripts provide many benefits, such as repeatable, predictable, and efficient test executions. However, just like any software development activity, development of test scripts is tedious and error prone. We refer, in this study, to all activities that should be conducted during the entire lifecycle of test-code as Software Test-Code Engineering (STCE). Objective: As the STCE research area has matured and the number of related studies has increased, it is important to systematically categorize the current state-of-the-art and to provide an overview of the trends in this field. Such summarized and categorized results provide many benefits to the broader community. For example, they are valuable resources for new researchers (e.g., PhD students) aiming to conduct additional secondary studies. Method: In this work, we systematically classify the body of knowledge related to STCE through a systematic mapping (SM) study. As part of this study, we pose a set of research questions, define selection and exclusion criteria, and systematically develop and refine a systematic map. Results: Our study pool includes a set of 60 studies published in the area of STCE between 1999 and 2012. Our mapping data is available through an online publicly-accessible repository. We derive the trends for various aspects of STCE. Among our results are the following: (1) There is an acceptable mix of papers with respect to different contribution facets in the field of STCE and the top two leading facets are tool (68%) and method (65%). The studies that presented new processes, however, had a low rate (3%), which denotes the need for more process-related studies in this area. (2) Results of investigation about research facet of studies and comparing our result to other SM studies shows that, similar to other fields in software engineering, STCE is moving towards more rigorous validation approaches. (3) A good mixture of STCE activities has been presented in the primary studies. Among them, the two leading activities are quality assessment and co-maintenance of test-code with production code. The highest growth rate for co-maintenance activities in recent years shows the importance and challenges involved in this activity. (4) There are two main categories of quality assessment activity: detection of test smells and oracle assertion adequacy. (5) JUnit is the leading test framework which has been used in about 50% of the studies. (6) There is a good mixture of SUT types used in the studies: academic experimental systems (or simple code examples), real open-source and commercial systems. (7) Among 41 tools that are proposed for STCE, less than half of the tools (45%) were available for download. It is good to have this percentile of tools to be available, although not perfect, since the availability of tools can lead to higher impact on research community and industry. Conclusion: We discuss the emerging trends in STCE, and discuss the implications for researchers and practitioners in this area. The results of our systematic mapping can help researchers to obtain an overview of existing STCE approaches and spot areas in the field that require more attention from the research community. Â© 2014 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84914181487&partnerID=40&md5=c284c62c41ba472eab9a053ccbd08710', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(29, 'paper_29', 'Strategies for consistency checking on software product lines: A mapping study', '<b>Key words:</b><br/>Consistency checking, Literature review, Mapping study, Software product line engineering <br/>', '', 'Context. Software Product Lines (SPL) has become one of the most prominents way to promote the systematic reuse of software artifacts. Like any other piece of software, with the SPL aging, it becomes necessary to manage their evolution. However, in this process, engineers might introduce divergences among the SPL artifacts. Thus, a number of initiatives address the management of such inconsistencies. Objective. In this paper, we mapped the existing approaches to inconsistency management within SPL. Method. We used the systematic mapping study methodology. Results. We classified and performed a characterization of the approaches found, which we mangaged to arrange in three main categories. Most papers selected proposed new methods as solution research. Besides, there is still a need for validation and evaluation studies. Conclusion. We identified a lack of support for a number of activities of consistency assurance. For instance, no paper addressed the tracking of findings, decisions, and actions, as well as, few papers describing either the handling or a management policy for identified inconsistencies. Copyright 2015 ACM.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84961159520&partnerID=40&md5=27caea57da59de999eb3c9a77aee00ed', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(30, 'paper_30', 'Systematic mapping study of quality attributes measurement in service oriented architecture', '<b>Key words:</b><br/>Quality attributes measurement, service oriented architecture, systematic mapping study <br/>', '', 'Background: Service oriented architecture (SOA) promotes software reuse and interoperability as its niche. Developer usually expects that services being used are performing as promised. Capability to measure quality of services helps developer to predict the software behavior. Measuring quality attributes of software can be treated as a way to ensure that the developed software will/does meet expected qualities. Objectives: This study investigates the state-of-art in quality attributes measurement for service oriented architecture. It will try to answer on type of studies that have been done regarding quality attributes measurement over service oriented architecture. Method: Systematic mapping study is selected as method for this study where primary studies related to quality attributes measurement are chosen and analyzed based on research questions. Result: Based on research questions, results of this mapping study shows, performance as highly seek quality attributes in this fields, where measurement technique that mostly used is metric and finally the measurement usually done on service level. Conclusion: this study is initiated to seek for how studies on quality attributes measurement in service oriented architecture has mature during these recent years. The result shows an up and down trends regarding number of studies whilst a lot of research gap can still be covered for future researches. Â© 2012 AICIT.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84866998707&partnerID=40&md5=a7fad9b2f2d879fe0b8d347d9936099b', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(31, 'paper_31', 'Ten years of research on fault management in grid computing: A systematic mapping study', '', '', 'BACKGROUND: There is a large body of literature on research about fault management in grid computing. Despite being a well-established research area, there are no systematic studies focusing on characterizing the sorts of research that have been conducted, identifying well-explored topics as well as opportunities for further research. OBJECTIVE: This study aims at surveying the existing research on fault management in grid computing in order to identify useful approaches and opportunities for future research. METHOD: We conducted a systematic mapping study to collect, classify and analyze the research literature on fault management in grid computing indexed by the main search engines in the field. RESULTS: Our study selected and classified 257 scientific papers and was able to answer five research questions regarding the distribution of the scientific production over the time and space. CONCLUSIONS: The majority of the selected studies focus on fault tolerance, with very few efforts towards fault prevention, prediction and removal. Â© 2013 IEEE.,', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84908011115&partnerID=40&md5=2721d0954867de0184a7751167f088e8', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(32, 'paper_32', 'Testability and software performance: A systematic mapping study', '<b>Key words:</b><br/>Software performance, Systematic mapping study, Testability <br/>', '', 'In most of the research on software testability, functional correctness of the software has been the focus while the evidence regarding testability and non-functional properties such as performance is sporadic. The objective of this study is to present the current state-of-the-art related to issues of importance, types and domains of software under test, types of research, contribution types and design evaluation methods concerning testability and software performance. We find that observability, controllability and testing effort are the main testability issues while timeliness and response time (i.e., time constraints) are the main performance issues in focus. The primary studies in the area use diverse types of software under test within different domains, with realtime systems as being a dominant domain. The researchers have proposed many different methods in the area, however these methods lack implementation in practice. Â© 2016 ACM.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84975789870&partnerID=40&md5=aa948ec1cf1aee77815cf56d0b933199', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(33, 'paper_33', 'The role of process in early software defect prediction: Methods, attributes and metrics', '<b>Key words:</b><br/>Defect prediction, Early, Prediction model, Process metrics, Software defect, Software quality, Software reliability, Systematic mapping <br/>', '', 'Software quality is the set of inherent characteristics that are built into a software product throughout software development process. An important indicator of software quality is the trend of software defects in the life-cycle. The models of software defect prediction and software reliability provide the opportunity for practitioners to observe the defectiveness distribution of their products in development and operation. However, reported studies are mostly focused on coding or testing stages. Though this is reasonable due to executable nature of the product, it prevents practitioners from taking the advantages (such as cost reduction) of identifying and predicting software defects earlier in the life-cycle. This paper, therefore, provides an overview of the trend of early software defect prediction studies as retrieved by a systematic mapping of the literature, and elaborates on the methods, attributes, and metrics of the studies that comprise software process data in the defect prediction. Â© Springer International Publishing Switzerland 2016.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84994005243&partnerID=40&md5=aa6f7438c816fe1687d04b9c387b2b7d', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(34, 'paper_34', 'Usable results from the field of API usability: A systematic mapping and further analysis', '<b>Key words:</b><br/>API usability, application programming interface, meta-analysis, systematic map, systematic review <br/>', '', 'Modern software development often involves the use of complex, reusable components called Application Programming Interfaces (APIs). Developers use APIs to complete tasks they could not otherwise accomplish in a reasonable time. These components are now vital to mainstream software development. But as APIs have become more important, understanding how to make them more usable is becoming a significant research question. To assess the current state of research in the field, we conducted a systematic mapping. A total of 28 papers were reviewed and categorized based on their research type and on the evaluation method employed by its authors. We extended the analysis of a subset of the papers we reviewed beyond the usual limits of a systematic map in order to more closely examine details of their evaluations - such as their structure and validity - and to summarize their recommendations. Based on these results, common problems in the field are discussed and future research directions are suggested. Â© 2012 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84870895497&partnerID=40&md5=f9dac6e9ebcbd3d7c1d02844ae3aee4a', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(35, 'paper_35', 'Validation of software visualization tools: A systematic mapping study', '<b>Key words:</b><br/>Software visualization, Systematic mapping study, Validation techniques <br/>', '', 'Software visualization as a research field focuses on the visualization of the structure, behavior, and evolution of software. It studies techniques and methods for graphically representing these different aspects of software. Interest in software visualization has grown in recent years, producing rapid advances in the diversity of research and in the scope of proposed techniques, and aiding the application experts who use these techniques to advance their own research. Despite the importance of evaluating software visualization research, there is little work studying validation methods. As a consequence, it is usually difficult producing compelling evidence about the effectiveness of software visualization contributions. The goal of this paper is to study the validation techniques performed in the software visualization literature. We conducted a systematic mapping study of validation methods in software visualization. We consider 752 articles from multiple sources, published between 2000 and 2012, and study the validation techniques of the software visualization articles. The main outcome of this study is the lack in rigor when validating software visualization tool and techniques. Although software visualization has grown in interest in the last decade, it still lacks the necessary maturity to be properly and thoroughly evaluating its claims. Most article evaluations studied in this paper are qualitative case studies, including discussions about the benefits of the proposed visualizations. The results help understand the needs in software visualization validation techniques. They identify the type of evaluations that should be performed to address this deficiency. The specific analysis of SOFTVIS series articles shows that the specialized conference suffers from the same shortage. Â© 2014 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84920660808&partnerID=40&md5=797cc12a015ec2d7ef9d22b3103e0bb5', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(36, 'paper_36', 'Vertical Test Reuse for Embedded Systems: A Systematic Mapping Study', '<b>Key words:</b><br/>embedded system, systematic mapping study, vertical test reuse <br/>', '', 'Vertical test reuse refers to the reuse of test cases or other test artifacts over different integration levels in the software or system engineering process. Vertical test reuse has previously been proposed for reducing test effort and improving test effectiveness, particularly for embedded system development. The goal of this study is to provide an overview of the state of the art in the field of vertical test reuse for embedded system development. For this purpose, a systematic mapping study has been performed, identifying 11 papers on vertical test reuse for embedded systems. The primary result from the mapping is a classification of published work on vertical test reuse in the embedded system domain, covering motivations for reuse, reuse techniques, test levels and reusable test artifacts considered, and to what extent the effects of reuse have been evaluated. Â© 2015 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84958235305&partnerID=40&md5=16444cc014261bf229bc5003e5f50f50', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Excluded', 'Waiting', 0, '1_1497588349', 1),
(37, 'paper_37', 'What do we know about the defect types detected in conceptual models?', '<b>Key words:</b><br/>Conceptual Schema Defects, Defect Classification Scheme, Model-Driven Development, Systematic Mapping Study <br/>', '', 'In Model-Driven Development (MDD), defects are managed at the level of conceptual models because the other artefacts are generated from them, such as more refined models, test cases and code. Although some studies have reported on defect types at model level, there still does not exist a clear and complete overview of the defect types that occur at the abstraction level. This paper presents a systematic mapping study to identify the model defect types reported in the literature and determine how they have been detected. Among the 282 articles published in software engineering area, 28 articles were selected for analysis. A total of 226 defects were identified, classified and their results analysed. For this, an appropriate defect classification scheme was built based on appropriate dimensions for models in an MDD context. Â© 2015 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84937942055&partnerID=40&md5=f5d60b4ef9d480f4806a8bad04269abe', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(38, 'paper_38', 'When and what to automate in software testing? A multi-vocal literature review', '<b>Key words:</b><br/>Decision support, Multivocal literature review, Software test automation, Systematic literature review, Systematic Mapping study, What to automate, When to automate <br/>', '', 'Context Many organizations see software test automation as a solution to decrease testing costs and to reduce cycle time in software development. However, establishment of automated testing may fail if test automation is not applied in the right time, right context and with the appropriate approach. Objective The decisions on when and what to automate is important since wrong decisions can lead to disappointments and major wrong expenditures (resources and efforts). To support decision making on when and what to automate, researchers and practitioners have proposed various guidelines, heuristics and factors since the early days of test automation technologies. As the number of such sources has increased, it is important to systematically categorize the current state-of-The-art and -practice, and to provide a synthesized overview. Method To achieve the above objective, we have performed a Multivocal Literature Review (MLR) study on when and what to automate in software testing. A MLR is a form of a Systematic Literature Review (SLR) which includes the grey literature (e.g., blog posts and white papers) in addition to the published (formal) literature (e.g., journal and conference papers). We searched the academic literature using the Google Scholar and the grey literature using the regular Google search engine. Results Our MLR and its results are based on 78 sources, 52 of which were grey literature and 26 were formally published sources. We used the qualitative analysis (coding) to classify the factors affecting the when- And what-to-automate questions to five groups: (1) Software Under Test (SUT)-related factors, (2) test-related factors, (3) test-tool-related factors, (4) human and organizational factors, and (5) cross-cutting and other factors. The most frequent individual factors were: need for regression testing (44 sources), economic factors (43), and maturity of SUT (39). Conclusion We show that current decision-support in software test automation provides reasonable advice for industry, and as a practical outcome of this research we have summarized it as a checklist that can be used by practitioners. However, we recommend developing systematic empirically-validated decision-support approaches as the existing advice is often unsystematic and based on weak empirical evidence. Â© 2016 Elsevier B.V.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84969529104&partnerID=40&md5=b1a7b786fb5bbbec9737993a11f4e652', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(39, 'paper_39', 'A Systematic Mapping Study on Test Generation from Input/Output Transition Systems', '<b>Key words:</b><br/>Input/Output Transition Systems, systematic mapping study, test generation <br/>', '', 'Context: The construction of complex systems has increased the adoption of technologies that aim at automating the testing activity. Model-Based Testing (MBT) has emerged as an approach to automate the generation of high-quality test suites from behavioural models. Input/Output Transition Systems(IOTSs) have been used in MBT because they are more expressive than other formalisms. Objective: This paper focuses on methods for test generation from IOTSs, aiming at synthesizing available knowledge and identifying gaps in the existing approaches. Method: A systematic mapping was conducted, in which 84 studies were evaluated and categorized in the taxonomy of MBT approaches. Results: The results indicate most of the reported approaches apply non-deterministic algorithms to test generation which do not employ measures of coverage or quality. This scenario underscores the importance of further research into this topic. Conclusion: The evidences indicate that the generation of complete test suites is guaranteed in theory without satisfying a certain test selection criterion. This result points out the need of additional investigation in this topic. Â© 2015 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84958235921&partnerID=40&md5=4a11222530cf3542f8047a0b76a39271', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(40, 'paper_40', 'A mapping study to investigate component-based software system metrics', '<b>Key words:</b><br/>Component-based software system, Software components, Software metrics, Software quality, Systematic mapping study <br/>', '', 'A component-based software system (CBSS) is a software system that is developed by integrating components that have been deployed independently. In the last few years, many researchers have proposed metrics to evaluate CBSS attributes. However, the practical use of these metrics can be difficult. For example, some of the metrics have concepts that either overlap or are not well defined, which could hinder their implementation. The aim of this study is to understand, classify and analyze existing research in component-based metrics, focusing on approaches and elements that are used to evaluate the quality of CBSS and its components from a component consumer''s point of view. This paper presents a systematic mapping study of several metrics that were proposed to measure the quality of CBSS and its components. We found 17 proposals that could be applied to evaluate CBSSs, while 14 proposals could be applied to evaluate individual components in isolation. Various elements of the software components that were measured are reviewed and discussed. Only a few of the proposed metrics are soundly defined. The quality assessment of the primary studies detected many limitations and suggested guidelines for possibilities for improving and increasing the acceptance of metrics. However, it remains a challenge to characterize and evaluate a CBSS and its components quantitatively. For this reason, much effort must be made to achieve a better evaluation approach in the future. Â© 2012 Elsevier Inc.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84872676227&partnerID=40&md5=168cb6d0d2c29588e6a74450ccc234fc', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(41, 'paper_41', 'A review of research on risk analysis methods for IT systems', '<b>Key words:</b><br/>IT systems, Mapping study, Risk analysis <br/>', '', 'Context: At the same time as our dependence on IT systems increases, the number of reports of problems caused by failures of critical IT systems has also increased. This means that there is a need for risk analysis in the development of this kind of systems. Risk analysis of technical systems has a long history in mechanical and electrical engineering. Objective: Even if a number of methods for risk analysis of technical systems exist, the failure behavior of information systems is typically very different from mechanical systems. Therefore, risk analysis of IT systems requires different risk analysis techniques, or at least adaptations of traditional approaches. This means that there is a need to understand what types of methods are available for IT systems and what research that has been conducted on these methods. Method: In this paper we present a systematic mapping study on risk analysis for IT systems. 1086 unique papers were identified in a database search and 57 papers were identified as relevant for this study. These papers were classified based on 5 different criteria. Results: This classification, for example, shows that most of the discussed risk analysis methods are qualitative and not quantitative and that most of the risk analysis methods that are presented in these papers are developed for IT systems in general and not for specific types of IT system. Conclusions: The results show that many new risk analysis methods have been proposed in the last decade but even more that there is a need for more empirical evaluations of the different risk analysis methods. Many papers were identified that propose new risk analysis methods, but few papers discuss a systematic evaluation of these methods or a comparison of different methods based on empirical data. Copyright 2013 ACM.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877289265&partnerID=40&md5=e1f98654dd2286cf5fd9e00497f14c7b', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(42, 'paper_42', 'A systematic mapping study of mobile application testing techniques', '<b>Key words:</b><br/>Mobile application testing, Software testing, Systematic mapping <br/>', '', 'The importance of mobile application specific testing techniques and methods has been attracting much attention of software engineers over the past few years. This is due to the fact that mobile applications are different than traditional web and desktop applications, and more and more they are moving to being used in critical domains. Mobile applications require a different approach to application quality and dependability and require an effective testing approach to build high quality and more reliable software. We performed a systematic mapping study to categorize and to structure the research evidence that has been published in the area of mobile application testing techniques and challenges that they have reported. Seventy nine (79) empirical studies are mapped to a classification schema. Several research gaps are identified and specific key testing issues for practitioners are identified: there is a need for eliciting testing requirements early during development process, the need to conduct research in real-world development environments, specific testing techniques targeting application life-cycle conformance and mobile services testing, and comparative studies for security and usability testing. Â© 2016 Elsevier Inc. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84963641809&partnerID=40&md5=76dba7bb0f8605cbc0fd95a05873dca4', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(43, 'paper_43', 'A systematic mapping study of web application testing', '<b>Key words:</b><br/>Bibliometrics, Paper repository, Systematic mapping, Testing, Web application <br/>', '', 'Context: The Web has had a significant impact on all aspects of our society. As our society relies more and more on the Web, the dependability of web applications has become increasingly important. To make these applications more dependable, for the past decade researchers have proposed various techniques for testing web-based software applications. Our literature search for related studies retrieved 147 papers in the area of web application testing, which have appeared between 2000 and 2011. Objective As this research area matures and the number of related papers increases, it is important to systematically identify, analyze, and classify the publications and provide an overview of the trends in this specialized field. Method We review and structure the body of knowledge related to web application testing through a systematic mapping (SM) study. As part of this study, we pose two sets of research questions, define selection and exclusion criteria, and systematically develop and refine a classification schema. In addition, we conduct a bibliometrics analysis of the papers included in our study. Results Our study includes a set of 79 papers (from the 147 retrieved papers) published in the area of web application testing between 2000 and 2011. We present the results of our systematic mapping study. Our mapping data is available through a publicly-accessible repository. We derive the observed trends, for instance, in terms of types of papers, sources of information to derive test cases, and types of evaluations used in papers. We also report the demographics and bibliometrics trends in this domain, including top-cited papers, active countries and researchers, and top venues in this research area. Conclusion We discuss the emerging trends in web application testing, and discuss the implications for researchers and practitioners in this area. The results of our systematic mapping can help researchers to obtain an overview of existing web application testing approaches and indentify areas in the field that require more attention from the research community. Â© 2013 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84878316262&partnerID=40&md5=efb3d8db2cdcf51f20930ef18222929d', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(44, 'paper_44', 'A systematic mapping study on fault management in cloud computing', '<b>Key words:</b><br/>Cloud Computing, Dependability, Evidence-Based Research, Fault Management, Mapping Study, Secondary Study <br/>', '', 'Background: The large computational infrastructures required to provide the on-demand services that most users are now used to are more prone to failures than any single computational device. Thus, fault management is a essential activity in the realization of the cloud computing model. Aims: This work aims at identifying well-explored topics on fault management in cloud computing as well as pin-pointing gaps in the scientific literature that may represent opportunities for further research and development in this area. Method: We conducted a systematic mapping study to collect, filter and classify scientific works in this area. The 4535 scientific papers found on major search engines were filtered and the remaining 166 papers were classified according to a taxonomy described in this work. Results: We found that IaaS is most explored in the selected studies. The main dependability functions explored were Tolerance and Removal, and the attributes were Reliability and Availability. Most papers had been classified by research type as Solution Proposal. Conclusion: This work summarizes and classifies the research effort conducted on fault management in cloud computing, providing a good starting point for further research in this area. Â© 2013 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84908005906&partnerID=40&md5=4d276f88513f45493729ad18a23aebee', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(45, 'paper_45', 'A systematic mapping study on legacy system modernization', '<b>Key words:</b><br/>Legacy systems, Mapping studies in software engineering, Software modernization <br/>', '', 'Legacy system modernization has gained increasing attention from both researchers and practitioners, mainly due to the need of maintaining legacy systems towards business needs and technology advances. In this way, a set of techniques, tools and terms related to software modernization have been proposed- although they have not been consolidated yet. This hinders the characterization of real modernization scenarios according to the existing literature. This paper synthesize the existing contributions related to software modernization by means of a mapping study that characterizes the main results in terms of proposed processes, techniques, and tools. As one of our main findings, we report a lack of empirical studies trying to understand the benefits of using the existing approaches for software modernization.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988349883&partnerID=40&md5=451bac271599396ea4902529ffac10fa', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(46, 'paper_46', 'A systematic mapping study on testing technique experiments: Has the situation changed since 2000?', '<b>Key words:</b><br/>mapping study, software testing techniques, testing experiments <br/>', '', 'Context Juristo et al. [7] published a literature review about testing technique expenments. The goal was to provide a picture of which techniques and aspects of techniques had been studied experimentally, and try to compile a body of knowledge on testing techniques. Goal: In this paper, we extend Junsto et al.''s study to cover the years from 2000 (where it ended) until 2013. Method: We have performed a systematic mapping study. Results: The situation in testing experimentation has not changed since Junsto et al.''s study. Conclusions: The research field has the same shortcomings. Â© 2014 ACM.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907807087&partnerID=40&md5=00c82980bdc011d47bb2182dc9e3a806', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(47, 'paper_47', 'A systematic mapping study on the combination of static and dynamic quality assurance techniques', '<b>Key words:</b><br/>Combination, Dynamic quality assurance, Inspection, Static quality assurance, Systematic mapping study, Testing <br/>', '', 'Context: A lot of different quality assurance techniques exist to ensure high quality products. However, most often they are applied in isolation. A systematic combination of different static and dynamic quality assurance techniques promises to exploit synergy effects, such as higher defect detection rates or reduced quality assurance costs. However, a systematic overview of such combinations and reported evidence about achieving synergy effects with such kinds of combinations is missing. Objective: The main goal of this article is the classification and thematic analysis of existing approaches that combine different static and dynamic quality assurance technique, including reported effects, characteristics, and constraints. The result is an overview of existing approaches and a suitable basis for identifying future research directions. Method: A systematic mapping study was performed by two researchers, focusing on four databases with an initial result set of 2498 articles, covering articles published between 1985 and 2010. Results: In total, 51 articles were selected and classified according to multiple criteria. The two main dimensions of a combination are integration (i.e., the output of one quality assurance technique is used for the second one) and compilation (i.e., different quality assurance techniques are applied to ensure a common goal, but in isolation). The combination of static and dynamic analyses is one of the most common approaches and usually conducted in an integrated manner. With respect to the combination of inspection and testing techniques, this is done more often in a compiled way than in an integrated way. Conclusion: The results show an increased interest in this topic in recent years, especially with respect to the integration of static and dynamic analyses. Inspection and testing techniques are currently mostly performed in an isolated manner. The integration of inspection and testing techniques is a promising research direction for the exploitation of additional synergy effects. Â© 2011 Elsevier B.V. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-80055068778&partnerID=40&md5=79090e7196d4dd5edae0bed3976791e4', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(48, 'paper_48', 'Agile testing: Past, present, and future - Charting a systematic map of testing in agile software development', '<b>Key words:</b><br/>agile software development, empirical, software testing, systematic mapping, test-driven development, testing tools <br/>', '', 'Testing has been a cornerstone of agile software development methodologies since early in the history of the field. However, the terminology used to describe the field - as well as the evidence in existing literature - is largely inconsistent. In order to better structure our understanding of the field and to guide future work, we conducted a systematic mapping of agile testing. We investigated five research questions: which authors are most active in agile testing, what is agile testing used for, what types of paper tend to be published in this field, how do practitioners and academics contribute to research in this field, and what tools are used to conduct agile testing? Of particular interest is our investigation into the source of these publications, which indicates that academics and practitioners focus on different types of publication and, disturbingly, that the number of practitioner papers in the sources we searched is strongly down since 2010. Â© 2012 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84868294056&partnerID=40&md5=07cb548e86ce68641af0917124a13d80', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(49, 'paper_49', 'RiPLE-TE: A process for testing Software Product Lines', '<b>Key words:</b><br/>Software process, Software product lines, Software reuse, Software testing <br/>', '', 'Software Product Lines Testing has received special attention in recent years, due to its crucial role in quality and also due to the high cost this activity poses. In this effect, to make testing a feasible activity, some improvements are required. This paper presents a process for testing product lines, designed based on the gaps identified by a systematic mapping study, performed in order to understand the current scenario in this research field. An experimental study was performed in order to evaluate the proposed process in terms of understanding the role of a structured testing process in a SPL project.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84855554904&partnerID=40&md5=e8613b35f4a36d18abc967fb4a53af68', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(50, 'paper_50', 'Systematic mapping study in automatic test case generation', '<b>Key words:</b><br/>Automatic test case generation methods, Software testing, Test case generation, Test case generation methods <br/>', '', 'Test case generation is a painstaking task in software testing and has a strong influence on the efficiency and the effectiveness of software tests. It is an important subject in software testing research that has led to the development of several tools and approaches over the decades. This paper presented a systematic mapping study to get an overview about the current studies of distinct techniques for generation of test cases automatically. The techniques presented in this paper are random-based methods, search-based methods and data mining-based methods. Each technique is explored briefly to give the basic idea behind it. In general, the paper''s objective is to give an up-to-date introduction and short review of the research in generation of test cases automatically. Systematic mapping study is the process of finding and collecting as much literature as possible, provides a structure of the type of research reports and the results that have been published by categorizing them depending on specific search questions to provide a background for further research. This study was based on a comprehensive set of 85 papers published in conference and journals between 2002 and 2013 obtained after using multistage selection criteria in the field of automatic test cases generation. The results from our systematic mapping study include information about the researches techniques used to generate test cases automatically and types of coverage within a specific period that can help researchers in this field through providing an overview of the current researches in this area. Furthermore, it may serve as a first step towards a great explanation of the topic with the help of systematic literature review. Â© 2014 The authors and IOS Press. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84948782811&partnerID=40&md5=ce17b999150fefd2e67fae653350f6ca', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(51, 'paper_51', 'Systematic mapping study of model transformations for concrete problems', '<b>Key words:</b><br/>Model Transformation, Software Engineering, Systematic Mapping <br/>', '', 'As a contribution to the adoption of the Model-Driven Engineering (MDE) paradigm, the research community has proposed concrete model transformation solutions for the MDE infrastructure and for domain-specific problems. However, as the adoption increases and with the advent of the new initiatives for the creation of repositories, it is legitimate to question whether proposals for concrete transformation problems can be still considered as research contributions or if they respond to a practical/technical work. In this paper, we report on a systematic mapping study that aims at understanding the trends and characteristics of concrete model transformations published in the past decade. Our study shows that the number of papers with, as main contribution, a concrete transformation solution, is not as high as expected. This number increased to reach a peak in 2010 and is decreasing since then. Our results also include a characterization and an analysis of the published proposals following a rigorous classification scheme. Â© Copyright 2016 by SCITEPRESS - Science and Technology Publications, Lda. All rights reserved.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84969921820&partnerID=40&md5=3845b641095db79942e3712d847bb345', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(52, 'paper_52', 'Test case prioritization: A systematic mapping study', '<b>Key words:</b><br/>Regression testing, Systematic literature review, Systematic mapping study, Test case prioritization <br/>', '', 'Test case prioritization techniques, which are used to improve the cost-effectiveness of regression testing, order test cases in such a way that those cases that are expected to outperform others in detecting software faults are run earlier in the testing phase. The objective of this study is to examine what kind of techniques have been widely used in papers on this subject, determine which aspects of test case prioritization have been studied, provide a basis for the improvement of test case prioritization research, and evaluate the current trends of this research area. We searched for papers in the following five electronic databases: IEEE Explorer, ACM Digital Library, Science Direct, Springer, and Wiley. Initially, the search string retrieved 202 studies, but upon further examination of titles and abstracts, 120 papers were identified as related to test case prioritization. There exists a large variety of prioritization techniques in the literature, with coverage-based prioritization techniques (i.e., prioritization in terms of the number of statements, basic blocks, or methods test cases cover) dominating the field. The proportion of papers on model-based techniques is on the rise, yet the growth rate is still slow. The proportion of papers that use datasets from industrial projects is found to be 64 %, while those that utilize public datasets for validation are only 38 %. On the basis of this study, the following recommendations are provided for researchers: (1) Give preference to public datasets rather than proprietary datasets, (2) develop more model-based prioritization methods, (3) conduct more studies on the comparison of prioritization methods, (4) always evaluate the effectiveness of the proposed technique with well-known evaluation metrics and compare the performance with the existing methods, (5) publish surveys and systematic review papers on test case prioritization, and (6) use datasets from industrial projects that represent real industrial problems. Â© 2012 Springer Science+Business Media, LLC.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84880587969&partnerID=40&md5=442d06af0d109613e52157d932d6d107', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1);
INSERT INTO `paper` (`id`, `bibtexKey`, `title`, `preview`, `bibtex`, `abstract`, `doi`, `year`, `venueId`, `papers_sources`, `search_strategy`, `added_by`, `add_time`, `addition_mode`, `added_active_phase`, `screening_status`, `classification_status`, `paper_excluded`, `operation_code`, `paper_active`) VALUES
(53, 'paper_53', 'Web application testing: A systematic literature review', '<b>Key words:</b><br/>Systematic literature review, Testing, Web application <br/>', '', 'Context The web has had a significant impact on all aspects of our society. As our society relies more and more on the web, the dependability of web applications has become increasingly important. To make these applications more dependable, for the past decade researchers have proposed various techniques for testing web-based software applications. Our literature search for related studies retrieved 193 papers in the area of web application testing, which have appeared between 2000 and 2013. Objective As this research area matures and the number of related papers increases, it is important to systematically identify, analyze, and classify the publications and provide an overview of the trends and empirical evidence in this specialized field. Methods We systematically review the body of knowledge related to functional testing of web application through a systematic literature review (SLR) study. This SLR is a follow-up and complimentary study to a recent systematic mapping (SM) study that we conducted in this area. As part of this study, we pose three sets of research questions, define selection and exclusion criteria, and synthesize the empirical evidence in this area. Results Our pool of studies includes a set of 95 papers (from the 193 retrieved papers) published in the area of web application testing between 2000 and 2013. The data extracted during our SLR study is available through a publicly-accessible online repository. Among our results are the followings: (1) the list of test tools in this area and their capabilities, (2) the types of test models and fault models proposed in this domain, (3) the way the empirical studies in this area have been designed and reported, and (4) the state of empirical evidence and industrial relevance. Conclusion We discuss the emerging trends in web application testing, and discuss the implications for researchers and practitioners in this area. The results of our SLR can help researchers to obtain an overview of existing web application testing approaches, fault models, tools, metrics and empirical evidence, and subsequently identify areas in the field that require more attention from the research community. Â© 2014 Elsevier Inc.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84900597825&partnerID=40&md5=29b2691a945894ddceca3e7f69123b48', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1),
(54, 'paper_54', 'What a long, strange trip it''s been: Past, present, and future perspectives on software testing research', '<b>Key words:</b><br/>Software Testing, systematic mapping <br/>', '', 'Over the past 25 years the Brazilian Symposium on Software Engineering (SBES) has evolved to become the most important event on software engineering in Brazil. Throughout these years, SBES has gathered a large body of studies in software testing. Aimed at providing an insightful understanding of what has already been published in such event, we synthesized its rich 25-year history of research on software testing. Using information drawn from this overview we attempted to highlight which types of study have been the most applied for conveying software testing efforts. We also devised a co-authorship network to obtain a bird''s-eye view of which research groups and scholars have been the most prolific ones. Moreover, by performing a citation analysis of the selected studies we set out to ascertain the importance of SBES in a wider scenario. Finally, borne out by the information extracted from the studies, we shed some light on the state-of-the-art of software testing in Brazil and provide an outlook on its foreseeable future. Â© 2011 IEEE.', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-82255172046&partnerID=40&md5=cd89afa234a6f03b9cae5e3e617ab60d', 0, NULL, 2, 2, 1, '2017-06-16 04:45:49', 'Automatic', 'Screening', 'Pending', 'Waiting', 0, '1_1497588349', 1);

-- --------------------------------------------------------

--
-- Table structure for table `paperauthor`
--

DROP TABLE IF EXISTS `paperauthor`;
CREATE TABLE IF NOT EXISTS `paperauthor` (
  `paperauthor_id` int(11) NOT NULL AUTO_INCREMENT,
  `paperId` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `paperauthor_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paperauthor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ref_domain`
--

DROP TABLE IF EXISTS `ref_domain`;
CREATE TABLE IF NOT EXISTS `ref_domain` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ref_domain`
--

INSERT INTO `ref_domain` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Artificial Intelligence', 'Artificial Intelligence', 1),
(2, 'Collaborative system', 'Collaborative system', 1),
(3, 'Compilation', 'Compilation', 1),
(4, 'E-commerce', 'E-commerce', 1),
(5, 'Any', 'Any', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_exclusioncrieria`
--

DROP TABLE IF EXISTS `ref_exclusioncrieria`;
CREATE TABLE IF NOT EXISTS `ref_exclusioncrieria` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(100) NOT NULL,
  `ref_desc` varchar(100) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ref_exclusioncrieria`
--

INSERT INTO `ref_exclusioncrieria` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Criteria 1', 'criteria 1', 1),
(2, 'Criteria2', 'criteria 2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_language`
--

DROP TABLE IF EXISTS `ref_language`;
CREATE TABLE IF NOT EXISTS `ref_language` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_language`
--

INSERT INTO `ref_language` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'UML', 'UML', 1),
(2, 'SySML', 'SySML', 1),
(3, 'Java', 'Java', 1),
(4, 'DSL', 'DSL', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_papers_sources`
--

DROP TABLE IF EXISTS `ref_papers_sources`;
CREATE TABLE IF NOT EXISTS `ref_papers_sources` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(100) NOT NULL,
  `ref_desc` varchar(100) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ref_papers_sources`
--

INSERT INTO `ref_papers_sources` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'IEEE xplorer', 'IEEE xplorer', 1),
(2, 'Scopus', 'Scopus', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_search_strategy`
--

DROP TABLE IF EXISTS `ref_search_strategy`;
CREATE TABLE IF NOT EXISTS `ref_search_strategy` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(100) NOT NULL,
  `ref_desc` varchar(100) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ref_search_strategy`
--

INSERT INTO `ref_search_strategy` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Snowballing', '', 1),
(2, 'Database search', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_tables`
--

DROP TABLE IF EXISTS `ref_tables`;
CREATE TABLE IF NOT EXISTS `ref_tables` (
  `reftab_id` int(11) NOT NULL AUTO_INCREMENT,
  `reftab_label` varchar(50) NOT NULL,
  `reftab_table` varchar(50) NOT NULL,
  `reftab_desc` varchar(200) NOT NULL,
  `reftab_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`reftab_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_tables`
--

INSERT INTO `ref_tables` (`reftab_id`, `reftab_label`, `reftab_table`, `reftab_desc`, `reftab_active`) VALUES
(1, 'ref_exclusioncrieria', 'zref_exclusioncrieria', 'Exclusion criteria', 0),
(2, 'ref_domain', 'ref_domain', 'Domain', 1),
(3, 'ref_transformation_language', 'ref_transformation_language', 'Transformation Language', 1),
(4, 'ref_language', 'ref_language', 'Language', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_transformation_language`
--

DROP TABLE IF EXISTS `ref_transformation_language`;
CREATE TABLE IF NOT EXISTS `ref_transformation_language` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_transformation_language`
--

INSERT INTO `ref_transformation_language` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'MoTif', 'MoTif', 1),
(2, 'ATL', 'ATL', 1),
(3, 'Henshin', 'Henshin', 1),
(4, 'QVT', 'QVT', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screen_decison`
--

DROP TABLE IF EXISTS `screen_decison`;
CREATE TABLE IF NOT EXISTS `screen_decison` (
  `decison_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `screening_phase` int(11) NOT NULL,
  `screening_decision` enum('Pending','In review','In conflict','Included','Excluded') DEFAULT NULL,
  `decision_source` enum('new_screen','edit_screen','conflict_resolution') DEFAULT NULL,
  `decision_history` longtext,
  `decision_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`decison_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `screen_decison`
--

INSERT INTO `screen_decison` (`decison_id`, `paper_id`, `screening_phase`, `screening_decision`, `decision_source`, `decision_history`, `decision_active`) VALUES
(1, 1, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:46:48"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:48:46"}~~__{"decision_source":"new_screen","user":"3","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 15:19:30"}', 1),
(2, 2, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:46:50"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:48:49"}', 1),
(3, 3, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:46:52"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:48:52"}', 1),
(4, 4, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:46:55"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:48:55"}', 1),
(5, 5, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:46:57"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:48:58"}', 1),
(6, 6, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:46:59"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:49:02"}', 1),
(7, 7, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:01"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:49:05"}', 1),
(8, 8, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:03"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:49:08"}', 1),
(9, 9, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:05"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:49:11"}', 1),
(10, 10, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:07"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:49:15"}', 1),
(11, 11, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:08"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:49:18"}', 1),
(12, 12, 1, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:10"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:49:21"}', 1),
(13, 13, 1, 'Included', 'conflict_resolution', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:13"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:24"}~~__{"decision_source":"conflict_resolution","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 15:20:34"}', 1),
(14, 14, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:16"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:27"}', 1),
(15, 15, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:18"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:31"}', 1),
(16, 16, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:21"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:34"}', 1),
(17, 17, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:24"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:37"}', 1),
(18, 18, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:27"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:40"}', 1),
(19, 19, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:29"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:43"}', 1),
(20, 20, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:32"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:47"}', 1),
(21, 21, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:34"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:50"}', 1),
(22, 22, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:36"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:53"}', 1),
(23, 23, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:39"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:56"}', 1),
(24, 24, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:41"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:49:59"}', 1),
(25, 25, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:43"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:50:03"}', 1),
(26, 26, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:46"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:50:07"}', 1),
(27, 27, 1, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:50"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 06:50:10"}', 1),
(28, 28, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:52"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:50:37"}', 1),
(29, 29, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:54"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:50:41"}', 1),
(30, 30, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:47:57"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:50:44"}', 1),
(31, 31, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:50:53"}~~__{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:51:30"}', 1),
(32, 32, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:50:57"}~~__{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:51:33"}', 1),
(33, 33, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:51:01"}~~__{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:51:35"}', 1),
(34, 34, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"In review","screening_time":"2017-06-16 06:51:04"}~~__{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:51:37"}', 1),
(35, 35, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:51:11"}~~__{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:51:42"}', 1),
(36, 36, 1, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:51:17"}~~__{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:51:44"}', 1),
(37, 37, 1, 'In review', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 06:51:47"}', 1),
(38, 30, 8, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:53:27"}', 1),
(39, 32, 8, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 06:53:30"}', 1),
(40, 36, 8, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:53:34"}', 1),
(41, 29, 8, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:53:39"}', 1),
(42, 33, 8, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 06:53:43"}', 1),
(43, 1, 2, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:04"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In conflict","screening_time":"2017-06-16 07:02:34"}~~__{"decision_source":"conflict_resolution","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:12:17"}~~__{"decision_source":"new_screen","user":"3","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 07:14:18"}', 1),
(44, 2, 2, 'Excluded', 'conflict_resolution', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:06"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In conflict","screening_time":"2017-06-16 07:02:38"}~~__{"decision_source":"conflict_resolution","user":"1","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 07:12:00"}', 1),
(45, 3, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:08"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In conflict","screening_time":"2017-06-16 07:02:42"}~~__{"decision_source":"new_screen","user":"3","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:13:20"}', 1),
(46, 4, 2, 'Excluded', 'conflict_resolution', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:11"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In conflict","screening_time":"2017-06-16 07:02:47"}~~__{"decision_source":"conflict_resolution","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 07:15:20"}', 1),
(47, 5, 2, 'In conflict', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:12"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"In conflict","screening_time":"2017-06-16 07:03:00"}', 1),
(48, 6, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:14"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:03:03"}', 1),
(49, 7, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:16"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:03:07"}', 1),
(50, 8, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:02:18"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:03:10"}', 1),
(51, 9, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:03:13"}~~__{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:03:57"}', 1),
(52, 10, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:03:17"}~~__{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:03:59"}', 1),
(53, 11, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:03:20"}~~__{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:04:01"}', 1),
(54, 12, 2, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:03:23"}~~__{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:04:03"}', 1),
(55, 3, 3, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:28"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:17:12"}', 1),
(56, 6, 3, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:30"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:17:16"}', 1),
(57, 7, 3, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:32"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:17:20"}', 1),
(58, 8, 3, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:34"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:17:23"}', 1),
(59, 9, 3, 'Included', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Included","criteria":null,"note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:37"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"Included","screening_time":"2017-06-16 07:17:27"}', 1),
(60, 10, 3, 'Excluded', 'conflict_resolution', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:41"}~~__{"decision_source":"new_screen","user":"4","decision":"Included","criteria":null,"note":"","paper_status":"In conflict","screening_time":"2017-06-16 07:17:30"}~~__{"decision_source":"conflict_resolution","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 07:18:26"}', 1),
(61, 11, 3, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:45"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 07:17:36"}', 1),
(62, 12, 3, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"1","decision":"Excluded","criteria":"1","note":"","paper_status":"In review","screening_time":"2017-06-16 07:16:48"}~~__{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 07:17:41"}', 1),
(63, 34, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:30:53"}', 1),
(64, 30, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:30:58"}', 1),
(65, 36, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:31:03"}', 1),
(66, 29, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:32:20"}', 1),
(67, 12, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:32:25"}', 1),
(68, 28, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:32:30"}', 1),
(69, 2, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"2","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:32:34"}', 1),
(70, 10, 9, 'Excluded', 'new_screen', '{"decision_source":"new_screen","user":"4","decision":"Excluded","criteria":"1","note":"","paper_status":"Excluded","screening_time":"2017-06-16 08:32:39"}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screen_phase`
--

DROP TABLE IF EXISTS `screen_phase`;
CREATE TABLE IF NOT EXISTS `screen_phase` (
  `screen_phase_id` int(11) NOT NULL AUTO_INCREMENT,
  `phase_title` varchar(100) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `displayed_fields` varchar(200) DEFAULT NULL,
  `phase_state` enum('Pending','Open','Closed','Cancelled') NOT NULL DEFAULT 'Pending',
  `source_paper_id` varchar(11) DEFAULT NULL,
  `source_paper` enum('All papers','Previous phase') NOT NULL DEFAULT 'Previous phase',
  `source_paper_status` enum('All','Included','Excluded') NOT NULL DEFAULT 'Included',
  `screen_phase_order` int(2) NOT NULL,
  `screen_phase_final` int(2) NOT NULL DEFAULT '0',
  `phase_type` enum('Screening','Validation') NOT NULL DEFAULT 'Screening',
  `phase_history` longtext,
  `added_by` int(11) NOT NULL,
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screen_phase_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screen_phase_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `screen_phase`
--

INSERT INTO `screen_phase` (`screen_phase_id`, `phase_title`, `description`, `displayed_fields`, `phase_state`, `source_paper_id`, `source_paper`, `source_paper_status`, `screen_phase_order`, `screen_phase_final`, `phase_type`, `phase_history`, `added_by`, `add_time`, `screen_phase_active`) VALUES
(1, 'Phase 1', 'Screen by Title', 'Title', 'Open', NULL, 'All papers', 'All', 10, 0, 'Screening', NULL, 1, '2017-06-13 23:19:45', 1),
(2, 'Phase 2', 'Screen by abstract', 'Title|Abstract', 'Closed', NULL, 'Previous phase', 'Included', 20, 0, 'Screening', NULL, 1, '2017-06-13 23:21:02', 1),
(3, 'Final screening phase', '', 'Title|Abstract|Link', 'Closed', NULL, 'Previous phase', 'Included', 30, 1, 'Screening', NULL, 1, '2017-06-13 23:21:33', 1),
(4, 'Phase 3', '', 'Preview', 'Pending', NULL, 'Previous phase', 'Included', 40, 0, 'Screening', NULL, 1, '2017-06-13 23:41:40', 0),
(5, 'Validate screening', '', 'Title|Abstract|Preview', 'Pending', NULL, 'All papers', 'Excluded', 40, 1, 'Validation', NULL, 1, '2017-06-14 00:03:24', 0),
(6, 'Phase 1', '', 'Abstract', 'Pending', NULL, 'All papers', 'Excluded', 50, 0, 'Validation', NULL, 1, '2017-06-14 00:09:51', 0),
(7, 'Final screen', '', 'Title|Abstract|Preview|Bibtex', 'Pending', NULL, 'All papers', 'Excluded', 40, 0, 'Validation', NULL, 1, '2017-06-14 00:10:28', 0),
(8, 'Validate phase 1', 'Validate phase 1', 'Title', 'Open', NULL, 'Previous phase', 'Excluded', 15, 0, 'Validation', NULL, 1, '2017-06-14 00:12:10', 1),
(9, 'Validate all screenings', '', 'Title|Abstract|Link', 'Open', NULL, 'All papers', 'Excluded', 40, 0, 'Validation', NULL, 1, '2017-06-14 00:13:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screening`
--

DROP TABLE IF EXISTS `screening`;
CREATE TABLE IF NOT EXISTS `screening` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `decision` enum('accepted','excluded') NOT NULL DEFAULT 'accepted',
  `exclusion_criteria` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `screening_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `screening_paper`
--

DROP TABLE IF EXISTS `screening_paper`;
CREATE TABLE IF NOT EXISTS `screening_paper` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) NOT NULL,
  `screening_phase` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assignment_note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) NOT NULL,
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(15) NOT NULL,
  `screening_decision` enum('Included','Excluded') DEFAULT NULL,
  `exclusion_criteria` int(11) DEFAULT NULL,
  `screening_note` varchar(200) DEFAULT NULL,
  `screening_time` timestamp NULL DEFAULT NULL,
  `screening_status` enum('Pending','Done','Reseted') NOT NULL DEFAULT 'Pending',
  `assignment_role` enum('Screening','Validation') NOT NULL DEFAULT 'Screening',
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=165 ;

--
-- Dumping data for table `screening_paper`
--

INSERT INTO `screening_paper` (`screening_id`, `paper_id`, `screening_phase`, `user_id`, `assignment_note`, `assignment_type`, `assignment_mode`, `assigned_by`, `assignment_time`, `operation_code`, `screening_decision`, `exclusion_criteria`, `screening_note`, `screening_time`, `screening_status`, `assignment_role`, `screening_active`) VALUES
(1, 1, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:48:46', 'Done', 'Screening', 1),
(2, 1, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:46:48', 'Done', 'Screening', 1),
(3, 2, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:46:50', 'Done', 'Screening', 1),
(4, 2, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:48:49', 'Done', 'Screening', 1),
(5, 3, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:48:52', 'Done', 'Screening', 1),
(6, 3, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:46:52', 'Done', 'Screening', 1),
(7, 4, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:46:55', 'Done', 'Screening', 1),
(8, 4, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:48:55', 'Done', 'Screening', 1),
(9, 5, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:48:58', 'Done', 'Screening', 1),
(10, 5, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:46:57', 'Done', 'Screening', 1),
(11, 6, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:46:59', 'Done', 'Screening', 1),
(12, 6, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:02', 'Done', 'Screening', 1),
(13, 7, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:05', 'Done', 'Screening', 1),
(14, 7, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:47:01', 'Done', 'Screening', 1),
(15, 8, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:47:03', 'Done', 'Screening', 1),
(16, 8, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:08', 'Done', 'Screening', 1),
(17, 9, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:11', 'Done', 'Screening', 1),
(18, 9, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:47:04', 'Done', 'Screening', 1),
(19, 10, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:47:06', 'Done', 'Screening', 1),
(20, 10, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:15', 'Done', 'Screening', 1),
(21, 11, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:18', 'Done', 'Screening', 1),
(22, 11, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:47:08', 'Done', 'Screening', 1),
(23, 12, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:47:10', 'Done', 'Screening', 1),
(24, 12, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:21', 'Done', 'Screening', 1),
(25, 13, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:24', 'Done', 'Screening', 1),
(26, 13, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 19:20:34', 'Done', 'Screening', 1),
(27, 14, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:16', 'Done', 'Screening', 1),
(28, 14, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:27', 'Done', 'Screening', 1),
(29, 15, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:31', 'Done', 'Screening', 1),
(30, 15, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:47:18', 'Done', 'Screening', 1),
(31, 16, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:21', 'Done', 'Screening', 1),
(32, 16, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:33', 'Done', 'Screening', 1),
(33, 17, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:37', 'Done', 'Screening', 1),
(34, 17, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:47:24', 'Done', 'Screening', 1),
(35, 18, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:26', 'Done', 'Screening', 1),
(36, 18, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:40', 'Done', 'Screening', 1),
(37, 19, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:43', 'Done', 'Screening', 1),
(38, 19, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:47:29', 'Done', 'Screening', 1),
(39, 20, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:32', 'Done', 'Screening', 1),
(40, 20, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:47', 'Done', 'Screening', 1),
(41, 21, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:50', 'Done', 'Screening', 1),
(42, 21, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:34', 'Done', 'Screening', 1),
(43, 22, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:36', 'Done', 'Screening', 1),
(44, 22, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:53', 'Done', 'Screening', 1),
(45, 23, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:56', 'Done', 'Screening', 1),
(46, 23, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:39', 'Done', 'Screening', 1),
(47, 24, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:41', 'Done', 'Screening', 1),
(48, 24, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:49:59', 'Done', 'Screening', 1),
(49, 25, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:50:03', 'Done', 'Screening', 1),
(50, 25, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:47:43', 'Done', 'Screening', 1),
(51, 26, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:47:46', 'Done', 'Screening', 1),
(52, 26, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:50:07', 'Done', 'Screening', 1),
(53, 27, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Included', NULL, '', '2017-06-16 10:50:10', 'Done', 'Screening', 1),
(54, 27, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:50', 'Done', 'Screening', 1),
(55, 28, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:52', 'Done', 'Screening', 1),
(56, 28, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:50:37', 'Done', 'Screening', 1),
(57, 29, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:50:41', 'Done', 'Screening', 1),
(58, 29, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:54', 'Done', 'Screening', 1),
(59, 30, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:47:57', 'Done', 'Screening', 1),
(60, 30, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:50:44', 'Done', 'Screening', 1),
(61, 31, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:50:53', 'Done', 'Screening', 1),
(62, 31, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:51:30', 'Done', 'Screening', 1),
(63, 32, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:31', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:51:33', 'Done', 'Screening', 1),
(64, 32, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:50:57', 'Done', 'Screening', 1),
(65, 33, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:51:01', 'Done', 'Screening', 1),
(66, 33, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:51:35', 'Done', 'Screening', 1),
(67, 34, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:51:37', 'Done', 'Screening', 1),
(68, 34, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:51:04', 'Done', 'Screening', 1),
(69, 35, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:51:11', 'Done', 'Screening', 1),
(70, 35, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 2, '', '2017-06-16 10:51:42', 'Done', 'Screening', 1),
(71, 36, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:51:44', 'Done', 'Screening', 1),
(72, 36, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:51:17', 'Done', 'Screening', 1),
(73, 37, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(74, 37, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', 'Excluded', 1, '', '2017-06-16 10:51:47', 'Done', 'Screening', 1),
(75, 38, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(76, 38, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(77, 39, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(78, 39, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(79, 40, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(80, 40, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(81, 41, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(82, 41, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(83, 42, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(84, 42, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(85, 43, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(86, 43, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(87, 44, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(88, 44, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(89, 45, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(90, 45, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(91, 46, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(92, 46, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(93, 47, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(94, 47, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(95, 48, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(96, 48, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(97, 49, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(98, 49, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(99, 50, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(100, 50, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(101, 51, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(102, 51, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(103, 52, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(104, 52, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(105, 53, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(106, 53, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(107, 54, 1, 1, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(108, 54, 1, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:46:32', '1_1497588391', NULL, NULL, NULL, NULL, 'Pending', 'Screening', 1),
(109, 30, 8, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:53:04', '1_1497588784', 'Included', NULL, '', '2017-06-16 10:53:27', 'Done', 'Validation', 1),
(110, 32, 8, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:53:04', '1_1497588784', 'Included', NULL, '', '2017-06-16 10:53:30', 'Done', 'Validation', 1),
(111, 36, 8, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:53:04', '1_1497588784', 'Excluded', 1, '', '2017-06-16 10:53:34', 'Done', 'Validation', 1),
(112, 29, 8, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:53:04', '1_1497588784', 'Excluded', 1, '', '2017-06-16 10:53:39', 'Done', 'Validation', 1),
(113, 33, 8, 4, '', 'Normal', 'auto', 1, '2017-06-16 04:53:04', '1_1497588784', 'Excluded', 2, '', '2017-06-16 10:53:43', 'Done', 'Validation', 1),
(114, 1, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:12:17', 'Done', 'Screening', 1),
(115, 1, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:02:04', 'Done', 'Screening', 1),
(116, 2, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Excluded', 2, '', '2017-06-16 11:12:00', 'Done', 'Screening', 1),
(117, 2, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Excluded', 1, '', '2017-06-16 11:02:38', 'Done', 'Screening', 1),
(118, 3, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Excluded', 1, '', '2017-06-16 11:02:42', 'Done', 'Screening', 1),
(119, 3, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:02:08', 'Done', 'Screening', 1),
(120, 4, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Excluded', 1, '', '2017-06-16 11:15:20', 'Done', 'Screening', 1),
(121, 4, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Excluded', 1, '', '2017-06-16 11:02:47', 'Done', 'Screening', 1),
(122, 5, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Excluded', 1, '', '2017-06-16 11:03:00', 'Done', 'Screening', 1),
(123, 5, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:02:12', 'Done', 'Screening', 1),
(124, 6, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:02:14', 'Done', 'Screening', 1),
(125, 6, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:03', 'Done', 'Screening', 1),
(126, 7, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:07', 'Done', 'Screening', 1),
(127, 7, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:02:16', 'Done', 'Screening', 1),
(128, 8, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:02:18', 'Done', 'Screening', 1),
(129, 8, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:10', 'Done', 'Screening', 1),
(130, 9, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:13', 'Done', 'Screening', 1),
(131, 9, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:57', 'Done', 'Screening', 1),
(132, 10, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:59', 'Done', 'Screening', 1),
(133, 10, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:17', 'Done', 'Screening', 1),
(134, 11, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:20', 'Done', 'Screening', 1),
(135, 11, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:04:01', 'Done', 'Screening', 1),
(136, 12, 2, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:01:56', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:04:03', 'Done', 'Screening', 1),
(137, 12, 2, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:01:57', '1_1497589316', 'Included', NULL, '', '2017-06-16 11:03:23', 'Done', 'Screening', 1),
(138, 3, 2, 3, '', 'Veto', 'manualy_single', 1, '2017-06-16 05:12:42', '', 'Included', NULL, '', '2017-06-16 11:13:20', 'Done', 'Screening', 1),
(139, 1, 2, 3, '', 'Veto', 'manualy_single', 1, '2017-06-16 05:14:06', '', 'Excluded', 1, '', '2017-06-16 11:14:18', 'Done', 'Screening', 1),
(140, 3, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:17:12', 'Done', 'Screening', 1),
(141, 3, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:16:28', 'Done', 'Screening', 1),
(142, 6, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:16:30', 'Done', 'Screening', 1),
(143, 6, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:17:16', 'Done', 'Screening', 1),
(144, 7, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:17:20', 'Done', 'Screening', 1),
(145, 7, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:16:32', 'Done', 'Screening', 1),
(146, 8, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:16:34', 'Done', 'Screening', 1),
(147, 8, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:17:23', 'Done', 'Screening', 1),
(148, 9, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:17:27', 'Done', 'Screening', 1),
(149, 9, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Included', NULL, '', '2017-06-16 11:16:37', 'Done', 'Screening', 1),
(150, 10, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Excluded', 1, '', '2017-06-16 11:16:41', 'Done', 'Screening', 1),
(151, 10, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Excluded', 1, '', '2017-06-16 11:18:26', 'Done', 'Screening', 1),
(152, 11, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Excluded', 1, '', '2017-06-16 11:17:36', 'Done', 'Screening', 1),
(153, 11, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Excluded', 1, '', '2017-06-16 11:16:45', 'Done', 'Screening', 1),
(154, 12, 3, 1, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Excluded', 1, '', '2017-06-16 11:16:48', 'Done', 'Screening', 1),
(155, 12, 3, 4, '', 'Normal', 'auto', 1, '2017-06-16 05:16:22', '1_1497590182', 'Excluded', 1, '', '2017-06-16 11:17:41', 'Done', 'Screening', 1),
(156, 34, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 1, '', '2017-06-16 12:30:53', 'Done', 'Validation', 1),
(157, 30, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 1, '', '2017-06-16 12:30:58', 'Done', 'Validation', 1),
(158, 36, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 2, '', '2017-06-16 12:31:03', 'Done', 'Validation', 1),
(159, 29, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 2, '', '2017-06-16 12:32:20', 'Done', 'Validation', 1),
(160, 12, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 1, '', '2017-06-16 12:32:25', 'Done', 'Validation', 1),
(161, 28, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 1, '', '2017-06-16 12:32:30', 'Done', 'Validation', 1),
(162, 2, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 2, '', '2017-06-16 12:32:34', 'Done', 'Validation', 1),
(163, 10, 9, 4, '', 'Normal', 'auto', 1, '2017-06-16 06:30:17', '1_1497594617', 'Excluded', 1, '', '2017-06-16 12:32:38', 'Done', 'Validation', 1),
(164, 1, 1, 3, '', 'Veto', 'manualy_single', 1, '2017-06-16 13:18:27', '', 'Excluded', 1, '', '2017-06-16 19:19:30', 'Done', 'Screening', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screening_validate`
--

DROP TABLE IF EXISTS `screening_validate`;
CREATE TABLE IF NOT EXISTS `screening_validate` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `decision` enum('accepted','excluded') NOT NULL DEFAULT 'accepted',
  `exclusion_criteria` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `screening_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `str_management`
--

DROP TABLE IF EXISTS `str_management`;
CREATE TABLE IF NOT EXISTS `str_management` (
  `str_id` int(11) NOT NULL AUTO_INCREMENT,
  `str_label` varchar(500) NOT NULL,
  `str_text` varchar(1000) NOT NULL,
  `str_category` varchar(20) NOT NULL DEFAULT 'default',
  `str_lang` varchar(3) NOT NULL DEFAULT 'en',
  `str_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`str_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=333 ;

--
-- Dumping data for table `str_management`
--

INSERT INTO `str_management` (`str_id`, `str_label`, `str_text`, `str_category`, `str_lang`, `str_active`) VALUES
(1, 'Welcome', 'Welcome', 'default', 'en', 1),
(2, 'General', 'General', 'default', 'en', 1),
(3, 'Home', 'Home', 'default', 'en', 1),
(4, 'Screen', 'Screen', 'default', 'en', 1),
(5, 'Papers', 'Papers', 'default', 'en', 1),
(6, 'Import papers', 'Import papers', 'default', 'en', 1),
(7, 'All papers', 'All papers', 'default', 'en', 1),
(8, 'Papers pending', 'Papers pending', 'default', 'en', 1),
(9, 'Papers in review', 'Papers in review', 'default', 'en', 1),
(10, 'Papers included', 'Papers included', 'default', 'en', 1),
(11, 'Papers excluded', 'Papers excluded', 'default', 'en', 1),
(12, 'Papers in conflict', 'Papers in conflict', 'default', 'en', 1),
(13, 'Screening', 'Screening', 'default', 'en', 1),
(14, 'Assign papers for screening', 'Assign papers for screening', 'default', 'en', 1),
(15, 'My assignments', 'My assignments', 'default', 'en', 1),
(16, 'My screenings', 'My screenings', 'default', 'en', 1),
(17, 'All assignments', 'All assignments', 'default', 'en', 1),
(18, 'All screenings', 'All screenings', 'default', 'en', 1),
(19, 'Completion', 'Completion', 'default', 'en', 1),
(20, 'Result', 'Result', 'default', 'en', 1),
(21, 'Screening validation', 'Screening validation', 'default', 'en', 1),
(22, 'Assign papers for validation', 'Assign papers for validation', 'default', 'en', 1),
(23, 'Assignments', 'Assignments', 'default', 'en', 1),
(24, 'Screenings', 'Screenings', 'default', 'en', 1),
(25, 'Validation result', 'Validation result', 'default', 'en', 1),
(26, 'Settings', 'Settings', 'default', 'en', 1),
(27, 'Admin', 'Admin', 'default', 'en', 1),
(28, 'Exclusion criteria', 'Exclusion criteria', 'default', 'en', 1),
(29, 'Operations', 'Operations', 'default', 'en', 1),
(30, 'SQL', 'SQL', 'default', 'en', 1),
(31, 'String mangement', 'String mangement', 'default', 'en', 1),
(32, 'Configuration', 'Configuration', 'default', 'en', 1),
(33, 'Update Installation', 'Update Installation', 'default', 'en', 1),
(34, 'Choose project', 'Choose project', 'default', 'en', 1),
(35, 'UP', 'UP', 'default', 'en', 1),
(36, 'Log Out', 'Log Out', 'default', 'en', 1),
(37, 'Project', 'Project', 'default', 'en', 1),
(38, 'Description', 'Description', 'default', 'en', 1),
(39, 'My screening completion', 'My screening completion', 'default', 'en', 1),
(40, ' Screened papers', ' Screened papers', 'default', 'en', 1),
(41, 'Pending papers', 'Pending papers', 'default', 'en', 1),
(42, 'Participants', 'Participants', 'default', 'en', 1),
(43, 'user', 'user', 'default', 'en', 1),
(44, 'ReLiS - Revue Littéraire Systématique', 'ReLiS - Revue Littéraire Systématique', 'default', 'en', 1),
(45, 'Select', 'Select', 'default', 'en', 1),
(46, 'Select multi', 'Select multi', 'default', 'en', 1),
(47, 'Back', 'Back', 'default', 'en', 1),
(48, 'Load a CSV file', 'Load a CSV file', 'default', 'en', 1),
(49, 'Upload the CSV file', 'Upload the CSV file', 'default', 'en', 1),
(50, 'Upload', 'Upload', 'default', 'en', 1),
(51, '#', '#', 'default', 'en', 1),
(52, 'Key', 'Key', 'default', 'en', 1),
(53, 'Title', 'Title', 'default', 'en', 1),
(54, 'Add new', 'Add new', 'default', 'en', 1),
(55, 'Close', 'Close', 'default', 'en', 1),
(56, 'List of papers', 'List of papers', 'default', 'en', 1),
(57, 'No records found', 'No records found', 'default', 'en', 1),
(58, 'Operation type', 'Operation type', 'default', 'en', 1),
(59, 'Time', 'Time', 'default', 'en', 1),
(60, 'List of Operations', 'List of Operations', 'default', 'en', 1),
(61, 'Error : Page "users" not found!', 'Error : Page "users" not found!', 'default', 'en', 1),
(62, 'Processed', 'Processed', 'default', 'en', 1),
(63, 'Pending', 'Pending', 'default', 'en', 1),
(64, 'Assigned to me', 'Assigned to me', 'default', 'en', 1),
(65, 'Excluded', 'Excluded', 'default', 'en', 1),
(66, 'Classification', 'Classification', 'default', 'en', 1),
(67, 'Graphs', 'Graphs', 'default', 'en', 1),
(68, 'Export', 'Export', 'default', 'en', 1),
(69, 'Reference Tables', 'Reference Tables', 'default', 'en', 1),
(70, 'Domain', 'Domain', 'default', 'en', 1),
(71, 'Language', 'Language', 'default', 'en', 1),
(72, 'Transformation Language', 'Transformation Language', 'default', 'en', 1),
(73, 'Classification completion', 'Classification completion', 'default', 'en', 1),
(74, 'Processed papers', 'Processed papers', 'default', 'en', 1),
(75, 'Configuration type', 'Configuration type', 'default', 'en', 1),
(76, 'Editor location(url)', 'Editor location(url)', 'default', 'en', 1),
(77, 'Editor workspace', 'Editor workspace', 'default', 'en', 1),
(78, 'CSV  separator for import', 'CSV  separator for import', 'default', 'en', 1),
(79, 'CSV separator for export', 'CSV separator for export', 'default', 'en', 1),
(80, 'Screening comfict type', 'Screening comfict type', 'default', 'en', 1),
(81, 'import papers activated', 'import papers activated', 'default', 'en', 1),
(82, 'assign papers activated', 'assign papers activated', 'default', 'en', 1),
(83, 'Screening activated', 'Screening activated', 'default', 'en', 1),
(84, 'Screening result activated', 'Screening result activated', 'default', 'en', 1),
(85, 'Screening validation activated', 'Screening validation activated', 'default', 'en', 1),
(86, 'Classification activated', 'Classification activated', 'default', 'en', 1),
(87, 'Edit', 'Edit', 'default', 'en', 1),
(88, 'Edit Configuration', 'Edit Configuration', 'default', 'en', 1),
(89, 'Configuration_managment', 'Configuration_managment', 'default', 'en', 1),
(90, 'Utilisateur', 'Utilisateur', 'default', 'en', 1),
(91, 'Evenement', 'Evenement', 'default', 'en', 1),
(92, 'New project', 'New project', 'default', 'en', 1),
(93, 'Users', 'Users', 'default', 'en', 1),
(94, 'Usergroups', 'Usergroups', 'default', 'en', 1),
(95, 'Logs', 'Logs', 'default', 'en', 1),
(96, ' Action not available!  ', ' Action not available!  ', 'default', 'en', 1),
(97, 'Configurations values', 'Configurations values', 'default', 'en', 1),
(98, 'Edit user ', 'Edit user ', 'default', 'en', 1),
(99, 'Success', 'Success', 'default', 'en', 1),
(100, 'Configurations  for  papers', 'Configurations  for  papers', 'default', 'en', 1),
(101, 'Edit configuration for papers ', 'Edit configuration for papers ', 'default', 'en', 1),
(102, 'Add papers source', 'Add papers source', 'default', 'en', 1),
(103, 'Add search strategy', 'Add search strategy', 'default', 'en', 1),
(104, 'General configuration', 'General configuration', 'default', 'en', 1),
(105, 'Papers configuration', 'Papers configuration', 'default', 'en', 1),
(106, 'Value', 'Value', 'default', 'en', 1),
(107, 'List of Exclusion criteria', 'List of Exclusion criteria', 'default', 'en', 1),
(108, 'Search for...', 'Search for...', 'default', 'en', 1),
(109, 'Error : Page "exclusioncrieria" not found!', 'Error : Page "exclusioncrieria" not found!', 'default', 'en', 1),
(110, 'Update project', 'Update project', 'default', 'en', 1),
(111, 'Upload configuration file', 'Upload configuration file', 'default', 'en', 1),
(112, 'List  of Exclusion criteria', 'List  of Exclusion criteria', 'default', 'en', 1),
(113, 'Add Exclusion criteria', 'Add Exclusion criteria', 'default', 'en', 1),
(114, 'Add a Exclusion criteria', 'Add a Exclusion criteria', 'default', 'en', 1),
(115, 'View', 'View', 'default', 'en', 1),
(116, 'Delete', 'Delete', 'default', 'en', 1),
(117, 'Action', 'Action', 'default', 'en', 1),
(118, 'Papers sources', 'Papers sources', 'default', 'en', 1),
(119, 'Search strategy', 'Search strategy', 'default', 'en', 1),
(120, 'Error : Page "search_strategy" not found!', 'Error : Page "search_strategy" not found!', 'default', 'en', 1),
(121, 'Error : Page "papers_sources" not found!', 'Error : Page "papers_sources" not found!', 'default', 'en', 1),
(122, 'Add Papers sources', 'Add Papers sources', 'default', 'en', 1),
(123, 'List  of Papers sources', 'List  of Papers sources', 'default', 'en', 1),
(124, 'Add a Papers sources', 'Add a Papers sources', 'default', 'en', 1),
(125, 'Edit Papers sources', 'Edit Papers sources', 'default', 'en', 1),
(126, 'List  of Search strategy', 'List  of Search strategy', 'default', 'en', 1),
(127, 'Add a Search strategy', 'Add a Search strategy', 'default', 'en', 1),
(128, 'Edit Search strategy', 'Edit Search strategy', 'default', 'en', 1),
(129, 'Reference', 'Reference', 'default', 'en', 1),
(130, 'Authors', 'Authors', 'default', 'en', 1),
(131, 'Add a new author', 'Add a new author', 'default', 'en', 1),
(132, 'List authors', 'List authors', 'default', 'en', 1),
(133, 'AAdd a new author', 'AAdd a new author', 'default', 'en', 1),
(134, 'Name', 'Name', 'default', 'en', 1),
(135, 'Picture', 'Picture', 'default', 'en', 1),
(136, 'Remove picture', 'Remove picture', 'default', 'en', 1),
(137, 'Author ', 'Author ', 'default', 'en', 1),
(138, 'Edit author ', 'Edit author ', 'default', 'en', 1),
(139, 'Venues', 'Venues', 'default', 'en', 1),
(140, 'Add a new venue', 'Add a new venue', 'default', 'en', 1),
(141, 'List venues', 'List venues', 'default', 'en', 1),
(142, 'AAdd a new venue', 'AAdd a new venue', 'default', 'en', 1),
(143, 'Abreviation', 'Abreviation', 'default', 'en', 1),
(144, 'Full name', 'Full name', 'default', 'en', 1),
(145, 'Year', 'Year', 'default', 'en', 1),
(146, 'Volume', 'Volume', 'default', 'en', 1),
(147, 'Papers number', 'Papers number', 'default', 'en', 1),
(148, 'Edit venue ', 'Edit venue ', 'default', 'en', 1),
(149, 'Papers test', 'Papers test', 'default', 'en', 1),
(150, 'Add a new paper', 'Add a new paper', 'default', 'en', 1),
(151, 'List papers', 'List papers', 'default', 'en', 1),
(152, 'Add new paper', 'Add new paper', 'default', 'en', 1),
(153, 'Added by', 'Added by', 'default', 'en', 1),
(154, 'Link', 'Link', 'default', 'en', 1),
(155, 'Venue', 'Venue', 'default', 'en', 1),
(156, 'Preview', 'Preview', 'default', 'en', 1),
(157, 'Bibtex', 'Bibtex', 'default', 'en', 1),
(158, 'Abstract', 'Abstract', 'default', 'en', 1),
(159, 'Source', 'Source', 'default', 'en', 1),
(160, 'Search strategy used ', 'Search strategy used ', 'default', 'en', 1),
(161, 'Paper', 'Paper', 'default', 'en', 1),
(162, 'Transformation name', 'Transformation name', 'default', 'en', 1),
(163, 'Source language', 'Source language', 'default', 'en', 1),
(164, 'Target language', 'Target language', 'default', 'en', 1),
(165, 'Scope', 'Scope', 'default', 'en', 1),
(166, 'Note', 'Note', 'default', 'en', 1),
(167, 'Excluded by', 'Excluded by', 'default', 'en', 1),
(168, 'Add classification', 'Add classification', 'default', 'en', 1),
(169, 'Assigned to', 'Assigned to', 'default', 'en', 1),
(170, 'Assigned by', 'Assigned by', 'default', 'en', 1),
(171, 'Success - picture removed', 'Success - picture removed', 'default', 'en', 1),
(172, 'Edit paper', 'Edit paper', 'default', 'en', 1),
(173, 'Assignment mode', 'Assignment mode', 'default', 'en', 1),
(174, 'Screened', 'Screened', 'default', 'en', 1),
(175, 'Paper assignment for screening', 'Paper assignment for screening', 'default', 'en', 1),
(176, 'Papers assigned to me for screening', 'Papers assigned to me for screening', 'default', 'en', 1),
(177, 'No papers assigned to you for screening', 'No papers assigned to you for screening', 'default', 'en', 1),
(178, 'Import papers - match fields', 'Import papers - match fields', 'default', 'en', 1),
(179, 'Match csv fields', 'Match csv fields', 'default', 'en', 1),
(180, 'Screening phases', 'Screening phases', 'default', 'en', 1),
(181, 'Add a new phase', 'Add a new phase', 'default', 'en', 1),
(182, 'List phases', 'List phases', 'default', 'en', 1),
(183, 'Add a new screening phase', 'Add a new screening phase', 'default', 'en', 1),
(184, 'Displayed fields', 'Displayed fields', 'default', 'en', 1),
(185, 'State', 'State', 'default', 'en', 1),
(186, 'Final phase', 'Final phase', 'default', 'en', 1),
(187, 'All assignments test', 'All assignments test', 'default', 'en', 1),
(188, 'Add a new project', 'Add a new project', 'default', 'en', 1),
(189, 'List of assignments', 'List of assignments', 'default', 'en', 1),
(190, 'Assign a paper', 'Assign a paper', 'default', 'en', 1),
(191, 'Assignment type', 'Assignment type', 'default', 'en', 1),
(192, 'Assignment role', 'Assignment role', 'default', 'en', 1),
(193, 'Screening phase', 'Screening phase', 'default', 'en', 1),
(194, 'Assignment ', 'Assignment ', 'default', 'en', 1),
(195, 'Error', 'Error', 'default', 'en', 1),
(196, 'Phase ', 'Phase ', 'default', 'en', 1),
(197, 'Edit  screening phase ', 'Edit  screening phase ', 'default', 'en', 1),
(198, ' Action not available!  detail_paper', ' Action not available!  detail_paper', 'default', 'en', 1),
(199, '--My assignments', '--My assignments', 'default', 'en', 1),
(200, '--My screenings', '--My screenings', 'default', 'en', 1),
(201, '--All assignments', '--All assignments', 'default', 'en', 1),
(202, '--All screenings', '--All screenings', 'default', 'en', 1),
(203, '--Completion', '--Completion', 'default', 'en', 1),
(204, '--Screening validation', '--Screening validation', 'default', 'en', 1),
(205, ' Action not available!  list_papersee', ' Action not available!  list_papersee', 'default', 'en', 1),
(206, ' Action not available!  list_papereeees', ' Action not available!  list_papereeees', 'default', 'en', 1),
(207, ' Action not available!  list_pdddapers', ' Action not available!  list_pdddapers', 'default', 'en', 1),
(208, ' Action not available!  list_papeeeeers', ' Action not available!  list_papeeeeers', 'default', 'en', 1),
(209, ' Action not available!  list_pauuuuupers', ' Action not available!  list_pauuuuupers', 'default', 'en', 1),
(210, 'Reviews per paper', 'Reviews per paper', 'default', 'en', 1),
(211, 'Assignement done', 'Assignement done', 'default', 'en', 1),
(212, 'Assign papers for screening (Step 1)', 'Assign papers for screening (Step 1)', 'default', 'en', 1),
(213, ' Please provide  "The screening phase" concerned ', ' Please provide  "The screening phase" concerned ', 'default', 'en', 1),
(214, ' Please fill the form !', ' Please fill the form !', 'default', 'en', 1),
(215, ' Please provide  "Reviews per paper" ', ' Please provide  "Reviews per paper" ', 'default', 'en', 1),
(216, ' Please provide  "The screening phase" concerned !', ' Please provide  "The screening phase" concerned !', 'default', 'en', 1),
(217, 'The Reviews per paper cannot exceed the number of selected users  ', 'The Reviews per paper cannot exceed the number of selected users  ', 'default', 'en', 1),
(218, 'Assign papers for screening (Step 2)', 'Assign papers for screening (Step 2)', 'default', 'en', 1),
(219, 'Save and Next', 'Save and Next', 'default', 'en', 1),
(220, 'Element saved', 'Element saved', 'default', 'en', 1),
(221, 'List of screenings', 'List of screenings', 'default', 'en', 1),
(222, 'Edit assignement ', 'Edit assignement ', 'default', 'en', 1),
(223, 'Screening Progress', 'Screening Progress', 'default', 'en', 1),
(224, 'Add a reviewer', 'Add a reviewer', 'default', 'en', 1),
(225, 'No screening data', 'No screening data', 'default', 'en', 1),
(226, 'Error : Page "screen_decison" not found!', 'Error : Page "screen_decison" not found!', 'default', 'en', 1),
(227, 'Screened by', 'Screened by', 'default', 'en', 1),
(228, 'Decision', 'Decision', 'default', 'en', 1),
(229, 'Screening Results', 'Screening Results', 'default', 'en', 1),
(230, 'Save', 'Save', 'default', 'en', 1),
(231, 'Edit screening', 'Edit screening', 'default', 'en', 1),
(232, ' Action not available!  simple_screen', ' Action not available!  simple_screen', 'default', 'en', 1),
(233, 'Criteria', 'Criteria', 'default', 'en', 1),
(234, 'new Paper assignment for screening', 'new Paper assignment for screening', 'default', 'en', 1),
(235, ' Action not available!  display_paper_screen', ' Action not available!  display_paper_screen', 'default', 'en', 1),
(236, 'Resolve screening conflict', 'Resolve screening conflict', 'default', 'en', 1),
(237, 'Screening history', 'Screening history', 'default', 'en', 1),
(238, 'No history for this paper', 'No history for this paper', 'default', 'en', 1),
(239, 'Excluded papers', 'Excluded papers', 'default', 'en', 1),
(240, 'No value !', 'No value !', 'default', 'en', 1),
(241, 'Display element', 'Display element', 'default', 'en', 1),
(242, 'Add a project to the user : ~current_parent_name~', 'Add a project to the user : ~current_parent_name~', 'default', 'en', 1),
(243, 'User role', 'User role', 'default', 'en', 1),
(244, 'Add a reviewer to the paper : ~current_parent_name~', 'Add a reviewer to the paper : ~current_parent_name~', 'default', 'en', 1),
(245, 'No history available for this paper', 'No history available for this paper', 'default', 'en', 1),
(246, 'Source papers', 'Source papers', 'default', 'en', 1),
(247, 'Source paper status', 'Source paper status', 'default', 'en', 1),
(248, 'Order', 'Order', 'default', 'en', 1),
(249, 'Created by', 'Created by', 'default', 'en', 1),
(250, 'Source paper', 'Source paper', 'default', 'en', 1),
(251, 'Phase category', 'Phase category', 'default', 'en', 1),
(252, 'Problem with uploading image', 'Problem with uploading image', 'default', 'en', 1),
(253, 'You have to select at least one field to be displayed', 'You have to select at least one field to be displayed', 'default', 'en', 1),
(254, 'There is already a final phase ', 'There is already a final phase ', 'default', 'en', 1),
(255, 'There is already a final phase ! ', 'There is already a final phase ! ', 'default', 'en', 1),
(256, 'Label', 'Label', 'default', 'en', 1),
(257, 'Text', 'Text', 'default', 'en', 1),
(258, 'Open edition mode', 'Open edition mode', 'default', 'en', 1),
(259, 'List of String management', 'List of String management', 'default', 'en', 1),
(260, 'Add validation phase', 'Add validation phase', 'default', 'en', 1),
(261, 'Add screeninng phase', 'Add screeninng phase', 'default', 'en', 1),
(262, 'Add a new validation phase', 'Add a new validation phase', 'default', 'en', 1),
(263, 'Open', 'Open', 'default', 'en', 1),
(264, 'Open the phase', 'Open the phase', 'default', 'en', 1),
(265, 'Homesss', 'Homesss', 'default', 'en', 1),
(266, 'Screening general view', 'Screening general view', 'default', 'en', 1),
(267, 'Go To', 'Go To', 'default', 'en', 1),
(268, 'General view', 'General view', 'default', 'en', 1),
(269, 'Admin view', 'Admin view', 'default', 'en', 1),
(270, 'Classification view', 'Classification view', 'default', 'en', 1),
(271, 'Screening view', 'Screening view', 'default', 'en', 1),
(272, 'Assign papers for screening ( all papers from  all phases )', 'Assign papers for screening ( all papers from  all phases )', 'default', 'en', 1),
(273, 'Assign papers for screening ( Included papers   from  )', 'Assign papers for screening ( Included papers   from  )', 'default', 'en', 1),
(274, 'Assign papers for screening ( Included papers   from Phase 2 )', 'Assign papers for screening ( Included papers   from Phase 2 )', 'default', 'en', 1),
(275, 'Assign papers for screening ( Excluded papers   from Final screening phase )', 'Assign papers for screening ( Excluded papers   from Final screening phase )', 'default', 'en', 1),
(276, 'Assign papers for screening ( all papers    )', 'Assign papers for screening ( all papers    )', 'default', 'en', 1),
(277, 'Assign papers for screening ( Included papers   from Phase 1 )', 'Assign papers for screening ( Included papers   from Phase 1 )', 'default', 'en', 1),
(278, 'Set screening validation ( Excluded papers   from Phase 1 )', 'Set screening validation ( Excluded papers   from Phase 1 )', 'default', 'en', 1),
(279, 'Percentage of papers(%)', 'Percentage of papers(%)', 'default', 'en', 1),
(280, 'Operation completed', 'Operation completed', 'default', 'en', 1),
(281, 'Go', 'Go', 'default', 'en', 1),
(282, 'Included papers', 'Included papers', 'default', 'en', 1),
(283, 'Userss', 'Userss', 'default', 'en', 1),
(284, ' User', ' User', 'default', 'en', 1),
(285, '--Validation result', '--Validation result', 'default', 'en', 1),
(286, 'Screening validation progress', 'Screening validation progress', 'default', 'en', 1),
(287, ' Action not available!  Array', ' Action not available!  Array', 'default', 'en', 1),
(288, 'matches out of', 'matches out of', 'default', 'en', 1),
(289, 'Validation result : 5 matches out of 6 <i class="fa fa-arrow-right"></i> 83.33  % ', 'Validation result : 5 matches out of 6 <i class="fa fa-arrow-right"></i> 83.33  % ', 'default', 'en', 1),
(290, 'Validation result : 0 matches out of 0 <i class="fa fa-arrow-right"></i> 0  % ', 'Validation result : 0 matches out of 0 <i class="fa fa-arrow-right"></i> 0  % ', 'default', 'en', 1),
(291, 'Validation result : 0 matches out of 6 <i class="fa fa-arrow-right"></i> 0  % ', 'Validation result : 0 matches out of 6 <i class="fa fa-arrow-right"></i> 0  % ', 'default', 'en', 1),
(292, 'Validation result : 4 matches out of 6 <i class="fa fa-arrow-right"></i> 66.67  % ', 'Validation result : 4 matches out of 6 <i class="fa fa-arrow-right"></i> 66.67  % ', 'default', 'en', 1),
(293, 'Validation result : 6 matches out of 6 <i class="fa fa-arrow-right"></i> 100  % ', 'Validation result : 6 matches out of 6 <i class="fa fa-arrow-right"></i> 100  % ', 'default', 'en', 1),
(294, 'Validation result : 2 matches out of 6 <i class="fa fa-arrow-right"></i> 33.33  % ', 'Validation result : 2 matches out of 6 <i class="fa fa-arrow-right"></i> 33.33  % ', 'default', 'en', 1),
(295, 'Validation result : 3 matches out of 5 <i class="fa fa-arrow-right"></i> 60  % ', 'Validation result : 3 matches out of 5 <i class="fa fa-arrow-right"></i> 60  % ', 'default', 'en', 1),
(296, 'Assigne to someone', 'Assigne to someone', 'default', 'en', 1),
(297, 'Assigne to a user', 'Assigne to a user', 'default', 'en', 1),
(298, 'Exclude', 'Exclude', 'default', 'en', 1),
(299, 'Exclude the paper', 'Exclude the paper', 'default', 'en', 1),
(300, 'No classification', 'No classification', 'default', 'en', 1),
(301, 'Assignations', 'Assignations', 'default', 'en', 1),
(302, 'No assignation', 'No assignation', 'default', 'en', 1),
(303, 'Add a Classification to the ', 'Add a Classification to the ', 'default', 'en', 1),
(304, 'Industrial', 'Industrial', 'default', 'en', 1),
(305, 'HOT', 'HOT', 'default', 'en', 1),
(306, 'Bidirectional', 'Bidirectional', 'default', 'en', 1),
(307, 'Implementation Available', 'Implementation Available', 'default', 'en', 1),
(308, 'Add a classification  to the paper : ', 'Add a classification  to the paper : ', 'default', 'en', 1),
(309, 'Remove the classification', 'Remove the classification', 'default', 'en', 1),
(310, 'Edit the classification', 'Edit the classification', 'default', 'en', 1),
(311, 'Edit  classification for the paper : ', 'Edit  classification for the paper : ', 'default', 'en', 1),
(312, 'Remove the assignation', 'Remove the assignation', 'default', 'en', 1),
(313, 'Edit the assignation', 'Edit the assignation', 'default', 'en', 1),
(314, 'Classifications', 'Classifications', 'default', 'en', 1),
(315, 'Edit Domain', 'Edit Domain', 'default', 'en', 1),
(316, 'List of Domain', 'List of Domain', 'default', 'en', 1),
(317, 'Edit Language', 'Edit Language', 'default', 'en', 1),
(318, 'List of Language', 'List of Language', 'default', 'en', 1),
(319, 'Edit Transformation Language', 'Edit Transformation Language', 'default', 'en', 1),
(320, 'List of Transformation Language', 'List of Transformation Language', 'default', 'en', 1),
(321, 'Classifications for "Domain" :  Artificial Intelligence', 'Classifications for "Domain" :  Artificial Intelligence', 'default', 'en', 1),
(322, 'Error : Page "ref_exclusioncrieria" not found!', 'Error : Page "ref_exclusioncrieria" not found!', 'default', 'en', 1),
(323, 'Cancel the exclusion', 'Cancel the exclusion', 'default', 'en', 1),
(324, 'Edit the exclusion', 'Edit the exclusion', 'default', 'en', 1),
(325, 'Paper excluded', 'Paper excluded', 'default', 'en', 1),
(326, 'Exclusion Info', 'Exclusion Info', 'default', 'en', 1),
(327, 'Exclusion cancelled', 'Exclusion cancelled', 'default', 'en', 1),
(328, 'Exports', 'Exports', 'default', 'en', 1),
(329, 'Update file', 'Update file', 'default', 'en', 1),
(330, 'File generated', 'File generated', 'default', 'en', 1),
(331, 'Set screening validation ( Excluded papers    )', 'Set screening validation ( Excluded papers    )', 'default', 'en', 1),
(332, 'Validation result : 8 matches out of 8 <i class="fa fa-arrow-right"></i> 100  % ', 'Validation result : 8 matches out of 8 <i class="fa fa-arrow-right"></i> 100  % ', 'default', 'en', 1);

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
CREATE TABLE IF NOT EXISTS `venue` (
  `venue_id` int(11) NOT NULL AUTO_INCREMENT,
  `venue_abbreviation` varchar(20) NOT NULL,
  `venue_fullName` varchar(200) NOT NULL,
  `venue_year` int(11) DEFAULT '0',
  `venue_volume` int(11) DEFAULT '0',
  `venue_totalNumPapers` int(11) DEFAULT '0',
  `venue_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`venue_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`venue_id`, `venue_abbreviation`, `venue_fullName`, `venue_year`, `venue_volume`, `venue_totalNumPapers`, `venue_active`) VALUES
(1, 'MODELS 2017', 'Models conference 2017', 2017, 15, 40, 0),
(2, 'MODELS 2017', 'Models conference 2017', 2017, 5, 40, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_assigned`
--
DROP VIEW IF EXISTS `view_paper_assigned`;
CREATE TABLE IF NOT EXISTS `view_paper_assigned` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`doi` varchar(200)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(2)
,`operation_code` varchar(20)
,`paper_active` int(1)
,`assigned_user_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_decision`
--
DROP VIEW IF EXISTS `view_paper_decision`;
CREATE TABLE IF NOT EXISTS `view_paper_decision` (
`screening_id` int(11)
,`screening_phase` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`paper_active` int(1)
,`screening_status` varchar(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_pending`
--
DROP VIEW IF EXISTS `view_paper_pending`;
CREATE TABLE IF NOT EXISTS `view_paper_pending` (
`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`doi` varchar(200)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(2)
,`operation_code` varchar(20)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_processed`
--
DROP VIEW IF EXISTS `view_paper_processed`;
CREATE TABLE IF NOT EXISTS `view_paper_processed` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`doi` varchar(200)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(2)
,`operation_code` varchar(20)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `zref_exclusioncrieria`
--

DROP TABLE IF EXISTS `zref_exclusioncrieria`;
CREATE TABLE IF NOT EXISTS `zref_exclusioncrieria` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure for view `view_paper_assigned`
--
DROP TABLE IF EXISTS `view_paper_assigned`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_assigned` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`doi` AS `doi`,`p`.`venueId` AS `venueId`,`p`.`bibtex` AS `bibtex`,`p`.`preview` AS `preview`,`p`.`abstract` AS `abstract`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`operation_code` AS `operation_code`,`p`.`paper_active` AS `paper_active`,`a`.`assigned_user_id` AS `assigned_user_id` from (`paper` `p` join `assigned` `a` on((`p`.`id` = `a`.`assigned_paper_id`))) where ((`a`.`assigned_active` = 1) and (`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_decision`
--
DROP TABLE IF EXISTS `view_paper_decision`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_decision` AS select `s`.`screening_id` AS `screening_id`,`s`.`screening_phase` AS `screening_phase`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`paper_active` AS `paper_active`,ifnull(`d`.`screening_decision`,'Pending') AS `screening_status` from ((`screening_paper` `s` left join `paper` `p` on(((`s`.`paper_id` = `p`.`id`) and (`p`.`paper_active` = 1)))) left join `screen_decison` `d` on(((`s`.`paper_id` = `d`.`paper_id`) and (`s`.`screening_phase` = `d`.`screening_phase`) and (`d`.`decision_active` = 1)))) where (`s`.`screening_active` = 1) group by `p`.`id`,`s`.`screening_phase`;

-- --------------------------------------------------------

--
-- Structure for view `view_paper_pending`
--
DROP TABLE IF EXISTS `view_paper_pending`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_pending` AS select `paper`.`id` AS `id`,`paper`.`bibtexKey` AS `bibtexKey`,`paper`.`title` AS `title`,`paper`.`doi` AS `doi`,`paper`.`venueId` AS `venueId`,`paper`.`bibtex` AS `bibtex`,`paper`.`preview` AS `preview`,`paper`.`abstract` AS `abstract`,`paper`.`screening_status` AS `screening_status`,`paper`.`classification_status` AS `classification_status`,`paper`.`paper_excluded` AS `paper_excluded`,`paper`.`operation_code` AS `operation_code`,`paper`.`paper_active` AS `paper_active` from `paper` where ((not(`paper`.`id` in (select distinct `p`.`id` AS `id` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`c`.`class_active` = 1))))) and (`paper`.`paper_active` = 1) and (`paper`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_processed`
--
DROP TABLE IF EXISTS `view_paper_processed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_processed` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`doi` AS `doi`,`p`.`venueId` AS `venueId`,`p`.`bibtex` AS `bibtex`,`p`.`preview` AS `preview`,`p`.`abstract` AS `abstract`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`operation_code` AS `operation_code`,`p`.`paper_active` AS `paper_active` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0) and (`c`.`class_active` = 1));
--
-- Database: `relis_general_admin`
--
CREATE DATABASE `relis_general_admin` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `relis_general_admin`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_config`(_config_id INT , _project_title  VARCHAR(405) , _project_description  VARCHAR(1005) , _default_lang  VARCHAR(16) , _creator INT , _run_setup  VARCHAR(6))
BEGIN
START TRANSACTION;
INSERT INTO config (project_title , project_description , default_lang , creator , run_setup) VALUES (_project_title , _project_description , _default_lang , _creator , _run_setup);
SELECT config_id AS id_value FROM config WHERE config_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_logs`(_log_id INT , _log_type  VARCHAR(55) , _log_user_id INT , _log_event  VARCHAR(205) , _log_time  VARCHAR(205) , _log_ip_address  VARCHAR(205))
BEGIN
START TRANSACTION;
INSERT INTO log (log_type , log_user_id , log_event , log_time , log_ip_address) VALUES (_log_type , _log_user_id , _log_event , _log_time , _log_ip_address);
SELECT log_id AS id_value FROM log WHERE log_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_project`(_project_id INT , _project_label  VARCHAR(105) , _project_title  VARCHAR(255) , _project_description  VARCHAR(1005) , _project_creator INT , _project_icon  VARCHAR(205))
BEGIN
START TRANSACTION;
INSERT INTO projects (project_label , project_title , project_description , project_creator , project_icon) VALUES (_project_label , _project_title , _project_description , _project_creator , _project_icon);
SELECT project_id AS id_value FROM projects WHERE project_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_str_mng`(_str_id INT , _str_label  VARCHAR(405) , _str_text  VARCHAR(805) , _str_lang  VARCHAR(8) , _str_category  VARCHAR(23))
BEGIN
START TRANSACTION;
INSERT INTO str_management (str_label , str_text , str_lang , str_category) VALUES (_str_label , _str_text , _str_lang , _str_category);
SELECT str_id AS id_value FROM str_management WHERE str_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_usergroup`(_usergroup_id INT , _usergroup_name  VARCHAR(25) , _usergroup_description  VARCHAR(55))
BEGIN
START TRANSACTION;
INSERT INTO usergroup (usergroup_name , usergroup_description) VALUES (_usergroup_name , _usergroup_description);
SELECT usergroup_id AS id_value FROM usergroup WHERE usergroup_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_users`(_user_id INT , _user_name  VARCHAR(55) , _user_username  VARCHAR(25) , _user_mail  VARCHAR(55) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  VARCHAR(205), _user_default_lang  VARCHAR(5))
BEGIN
START TRANSACTION;
INSERT INTO users (user_name , user_username , user_mail , user_usergroup , user_password , user_picture,user_default_lang) VALUES (_user_name , _user_username , _user_mail , _user_usergroup , _user_password , _user_picture,_user_default_lang);
SELECT user_id AS id_value FROM users WHERE user_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_user_project`(_userproject_id INT , _user_id INT , _project_id INT)
BEGIN START TRANSACTION; INSERT INTO userproject (user_id , project_id) VALUES (_user_id , _project_id); SELECT userproject_id AS id_value FROM userproject WHERE userproject_id = LAST_INSERT_ID(); COMMIT; END$$

DROP PROCEDURE IF EXISTS `check_login`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_login`(IN _login VARCHAR(20))
BEGIN
START TRANSACTION;
SELECT COUNT(user_id)  AS number 
FROM users
WHERE user_active=1 AND user_username = _login  ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `check_user_credentials`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_user_credentials`(_username VARCHAR(100), _password VARCHAR(100))
BEGIN
START TRANSACTION;
	SELECT * FROM users 
	WHERE (users.user_username = _username)
    AND (users.user_password = _password);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_list`(IN source varchar(200),IN condition_stat VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select count(*) as nombre from  ',source ,'   WHERE 1=1  ', condition_stat );
PREPARE stmt FROM @query;
EXECUTE stmt; -- execute statement
DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_detail_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_config`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_logs`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM log
WHERE log_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_project`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM projects
WHERE project_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_str_mng`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM str_management
WHERE str_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_usergroup`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM usergroup
WHERE usergroup_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_users`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM users
WHERE user_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_user_project`(IN _row_id INT)
BEGIN START TRANSACTION; SELECT * FROM userproject WHERE userproject_id= _row_id; COMMIT; END$$

DROP PROCEDURE IF EXISTS `get_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list`(IN _source varchar(100),IN _fields varchar(1000),IN _condition_stat VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select ',_fields,' from  ',_source ,'   WHERE 1=1   ', _condition_stat );
 PREPARE stmt FROM @query;
 EXECUTE stmt; -- execute statement
 DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_list_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_config`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
IF _range < 1 THEN
SELECT  * FROM config
WHERE config_active=1   ORDER BY config_id ASC;
ELSE
SELECT  * FROM config
WHERE config_active=1   ORDER BY config_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_logs`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
SET @search_log_user_id := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  log_id , log_user_id , log_event , log_time FROM log
WHERE log_active=1   AND (  (log_user_id LIKE  @search_log_user_id)  )  ORDER BY log_id DESC ;
ELSE
SELECT  log_id , log_user_id , log_event , log_time FROM log
WHERE log_active=1   AND (  (log_user_id LIKE  @search_log_user_id)  )  ORDER BY log_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_project`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
SET @search_project_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_project_description := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  * FROM projects
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  OR (project_description LIKE  @search_project_description)  )  ORDER BY project_id ASC;
ELSE
SELECT  * FROM projects
WHERE project_active=1   AND (  (project_title LIKE  @search_project_title)  OR (project_description LIKE  @search_project_description)  )  ORDER BY project_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_str_mng`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
SET @search_str_text := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC ;
ELSE
SELECT  * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_usergroup`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
SET @search_usergroup_name := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  * FROM usergroup
WHERE usergroup_active=1   AND (  (usergroup_name LIKE  @search_usergroup_name)  )  ORDER BY usergroup_name ASC;
ELSE
SELECT  * FROM usergroup
WHERE usergroup_active=1   AND (  (usergroup_name LIKE  @search_usergroup_name)  )  ORDER BY usergroup_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_users`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
SET @search_user_name := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT  * FROM users
WHERE user_active=1   AND (  (user_name LIKE  @search_user_name)  )  ORDER BY user_name ASC ;
ELSE
SELECT  * FROM users
WHERE user_active=1   AND (  (user_name LIKE  @search_user_name)  )  ORDER BY user_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_users_all`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_users_all`()
BEGIN
START TRANSACTION;
SELECT  U.*,G.usergroup_name FROM users U
INNER JOIN usergroup G ON (U.user_usergroup  = G.usergroup_id)
WHERE U.user_active = 1 AND G.usergroup_active;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_user_project`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN 
START TRANSACTION;
IF _range < 1 THEN 
SELECT * FROM userproject WHERE userproject_active=1 ORDER BY userproject_id ASC; 
ELSE
SELECT * FROM userproject WHERE userproject_active=1 ORDER BY userproject_id ASC LIMIT _start_by , _range; 
END IF; 
COMMIT; 
END$$

DROP PROCEDURE IF EXISTS `get_reference_value`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_value`(IN  _table  VARCHAR(100), IN  _id  VARCHAR(100), IN  _field  VARCHAR(100), IN  _table_id  VARCHAR(100))
BEGIN
SET @query = CONCAT('Select ',_field,' from  ',_table ,'   WHERE ', _table_id, ' = ', _id );
PREPARE stmt FROM @query;
EXECUTE stmt; -- execute statement
DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_row`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_row`(IN source varchar(100),IN source_id VARCHAR(100),IN id_value VARCHAR(100))
BEGIN
SET @query = CONCAT("Select * from  ",source ,"  WHERE ", source_id ," = '",id_value,"'");
 PREPARE stmt FROM @query;
 EXECUTE stmt; -- execute statement
 DEALLOCATE PREPARE stmt; -- release the statement memory.
END$$

DROP PROCEDURE IF EXISTS `get_string`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_string`(IN _text VARCHAR(500),IN _category VARCHAR(30),IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
SELECT str_id, str_text 
FROM str_management
WHERE str_active=1 AND str_label = _text AND str_category = _category AND str_lang = _lang ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_config`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE config SET config_active=0
WHERE config_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_logs`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE log SET log_active=0
WHERE log_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_project`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE projects SET project_active=0
WHERE project_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_str_mng`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE str_management SET str_active=0
WHERE str_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_usergroup`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE usergroup SET usergroup_active=0
WHERE usergroup_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_users`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE users SET user_active=0
WHERE user_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_user_project`(IN _element_id INT)
BEGIN START TRANSACTION; UPDATE userproject SET userproject_active=0 WHERE userproject_id= _element_id; COMMIT; END$$

DROP PROCEDURE IF EXISTS `update_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_config`(_element_id INT , _config_id INT , _project_description  VARCHAR(1005) , _default_lang  VARCHAR(16) , _creator INT , _run_setup  VARCHAR(6))
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , project_description = _project_description , default_lang = _default_lang , creator = _creator , run_setup = _run_setup
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_logs`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_logs`(_element_id INT , _log_id INT , _log_user_id INT , _log_time  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  log SET log_id = _log_id , log_user_id = _log_user_id , log_time = _log_time
WHERE (log_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_project`(_element_id INT , _project_id INT , _project_label  VARCHAR(105) , _project_title  VARCHAR(255) , _project_description  VARCHAR(1005) , _project_creator INT , _project_icon  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  projects SET project_id = _project_id , project_label = _project_label , project_title = _project_title , project_description = _project_description , project_creator = _project_creator , project_icon = _project_icon
WHERE (project_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_str_mng`(_element_id INT , _str_id INT , _str_text  VARCHAR(805))
BEGIN
START TRANSACTION;
UPDATE  str_management SET str_id = _str_id , str_text = _str_text
WHERE (str_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_usergroup`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_usergroup`(_element_id INT , _usergroup_id INT , _usergroup_name  VARCHAR(25) , _usergroup_description  VARCHAR(55))
BEGIN
START TRANSACTION;
UPDATE  usergroup SET usergroup_id = _usergroup_id , usergroup_name = _usergroup_name , usergroup_description = _usergroup_description
WHERE (usergroup_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_users`(_element_id INT , _user_id INT , _user_name  VARCHAR(55) , _user_mail  VARCHAR(55) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  VARCHAR(205), _user_default_lang  VARCHAR(5) )
BEGIN
START TRANSACTION;
UPDATE  users SET user_id = _user_id , user_name = _user_name , user_mail = _user_mail , user_usergroup = _user_usergroup , user_password = _user_password , user_picture = _user_picture, user_default_lang = _user_default_lang
WHERE (user_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_user_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user_project`(_element_id INT , _userproject_id INT , _user_id INT , _project_id INT)
BEGIN START TRANSACTION; UPDATE userproject SET userproject_id = _userproject_id , user_id = _user_id , project_id = _project_id WHERE (userproject_id = _element_id); COMMIT; END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_type` varchar(15) NOT NULL DEFAULT 'default',
  `project_title` varchar(500) DEFAULT NULL,
  `project_description` text,
  `default_lang` varchar(15) NOT NULL DEFAULT 'en',
  `creator` int(11) NOT NULL DEFAULT '1',
  `run_setup` int(1) NOT NULL DEFAULT '0',
  `rec_per_page` int(4) NOT NULL DEFAULT '30',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_id`, `config_type`, `project_title`, `project_description`, `default_lang`, `creator`, `run_setup`, `rec_per_page`, `config_active`) VALUES
(1, 'default', 'Admin', 'Admin project', 'en', 1, 0, 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
CREATE TABLE IF NOT EXISTS `log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) NOT NULL,
  `log_event` text NOT NULL,
  `log_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `log_ip_address` varchar(50) DEFAULT NULL,
  `log_user_id` int(11) DEFAULT NULL,
  `log_poste_id` int(11) DEFAULT NULL,
  `log_user_agent` varchar(150) DEFAULT NULL,
  `log_publish` int(1) NOT NULL DEFAULT '1',
  `log_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=161 ;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`log_id`, `log_type`, `log_event`, `log_time`, `log_ip_address`, `log_user_id`, `log_poste_id`, `log_user_agent`, `log_publish`, `log_active`) VALUES
(4, 'Connexion', 'User connected', '2017-02-20 00:58:13', '::1', 1, NULL, NULL, 1, 1),
(5, 'Connexion', 'User connected', '2017-02-20 04:50:09', '::1', 1, NULL, NULL, 1, 1),
(6, 'Connexion', 'User connected', '2017-02-21 00:22:28', '::1', 1, NULL, NULL, 1, 1),
(7, 'Connexion', 'User connected', '2017-02-21 20:53:49', '::1', 1, NULL, NULL, 1, 1),
(8, 'Connexion', 'User connected', '2017-02-22 03:35:25', '::1', 1, NULL, NULL, 1, 1),
(9, 'Connexion', 'User connected', '2017-02-22 10:45:08', '::1', 1, NULL, NULL, 1, 1),
(10, 'Connexion', 'User connected', '2017-02-22 20:55:19', '::1', 1, NULL, NULL, 1, 1),
(11, 'Disconnection', 'User disconnected', '2017-02-23 03:41:37', '::1', 1, NULL, NULL, 1, 1),
(12, 'Connexion', 'User connected', '2017-02-23 03:41:48', '::1', 4, NULL, NULL, 1, 1),
(13, 'Connexion', 'User connected', '2017-02-23 08:56:19', '::1', 1, NULL, NULL, 1, 1),
(14, 'Connexion', 'User connected', '2017-02-23 18:24:35', '::1', 1, NULL, NULL, 1, 1),
(15, 'Disconnection', 'User disconnected', '2017-02-23 20:10:40', '::1', 1, NULL, NULL, 1, 1),
(16, 'Connexion', 'User connected', '2017-02-23 20:10:53', '::1', 4, NULL, NULL, 1, 1),
(17, 'Connexion', 'User connected', '2017-02-23 20:12:05', '::1', 1, NULL, NULL, 1, 1),
(18, 'Disconnection', 'User disconnected', '2017-02-23 22:48:42', '::1', 4, NULL, NULL, 1, 1),
(19, 'Connexion', 'User connected', '2017-02-23 22:48:50', '::1', 1, NULL, NULL, 1, 1),
(20, 'Connexion', 'User connected', '2017-02-25 05:08:57', '::1', 1, NULL, NULL, 1, 1),
(21, 'Connexion', 'User connected', '2017-02-25 05:21:25', '::1', 1, NULL, NULL, 1, 1),
(22, 'Connexion', 'User connected', '2017-03-01 02:53:00', '::1', 1, NULL, NULL, 1, 1),
(23, 'Disconnection', 'User disconnected', '2017-03-01 02:54:35', '::1', 1, NULL, NULL, 1, 1),
(24, 'Connexion', 'User connected', '2017-03-01 02:54:50', '::1', 4, NULL, NULL, 1, 1),
(25, 'Disconnection', 'User disconnected', '2017-03-01 02:56:08', '::1', 4, NULL, NULL, 1, 1),
(26, 'Connexion', 'User connected', '2017-03-01 02:56:14', '::1', 1, NULL, NULL, 1, 1),
(27, 'Disconnection', 'User disconnected', '2017-03-01 06:55:30', '::1', 1, NULL, NULL, 1, 1),
(28, 'Connexion', 'User connected', '2017-03-01 06:55:37', '::1', 4, NULL, NULL, 1, 1),
(29, 'Connexion', 'User connected', '2017-03-01 23:42:37', '::1', 1, NULL, NULL, 1, 1),
(30, 'Connexion', 'User connected', '2017-03-01 23:45:34', '::1', 1, NULL, NULL, 1, 1),
(31, 'Connexion', 'User connected', '2017-03-03 02:32:48', '::1', 1, NULL, NULL, 1, 1),
(32, 'Disconnection', 'User disconnected', '2017-03-03 03:24:38', '::1', 1, NULL, NULL, 1, 1),
(33, 'Connexion', 'User connected', '2017-03-03 03:24:43', '::1', 4, NULL, NULL, 1, 1),
(34, 'Connexion', 'User connected', '2017-03-03 03:26:44', '::1', 1, NULL, NULL, 1, 1),
(35, 'Connexion', 'User connected', '2017-03-03 05:26:42', '::1', 1, NULL, NULL, 1, 1),
(36, 'Connexion', 'User connected', '2017-03-03 11:13:27', '::1', 1, NULL, NULL, 1, 1),
(37, 'Disconnection', 'User disconnected', '2017-03-03 12:12:23', '::1', 1, NULL, NULL, 1, 1),
(38, 'Connexion', 'User connected', '2017-03-03 12:12:28', '::1', 4, NULL, NULL, 1, 1),
(39, 'Disconnection', 'User disconnected', '2017-03-03 12:15:33', '::1', 4, NULL, NULL, 1, 1),
(40, 'Connexion', 'User connected', '2017-03-03 12:15:46', '::1', 3, NULL, NULL, 1, 1),
(41, 'Disconnection', 'User disconnected', '2017-03-03 12:19:10', '::1', 3, NULL, NULL, 1, 1),
(42, 'Connexion', 'User connected', '2017-03-03 12:19:25', '::1', 2, NULL, NULL, 1, 1),
(43, 'Disconnection', 'User disconnected', '2017-03-03 12:42:54', '::1', 2, NULL, NULL, 1, 1),
(44, 'Connexion', 'User connected', '2017-03-03 12:42:59', '::1', 1, NULL, NULL, 1, 1),
(45, 'Disconnection', 'User disconnected', '2017-03-03 12:48:06', '::1', 1, NULL, NULL, 1, 1),
(46, 'Connexion', 'User connected', '2017-03-03 12:48:12', '::1', 4, NULL, NULL, 1, 1),
(47, 'Connexion', 'User connected', '2017-03-03 12:48:32', '::1', 1, NULL, NULL, 1, 1),
(48, 'Connexion', 'User connected', '2017-03-04 02:33:05', '::1', 1, NULL, NULL, 1, 1),
(49, 'Disconnection', 'User disconnected', '2017-03-04 02:47:12', '::1', 1, NULL, NULL, 1, 1),
(50, 'Connexion', 'User connected', '2017-03-04 02:47:18', '::1', 5, NULL, NULL, 1, 1),
(51, 'Disconnection', 'User disconnected', '2017-03-04 02:59:42', '::1', 5, NULL, NULL, 1, 1),
(52, 'Connexion', 'User connected', '2017-03-04 02:59:47', '::1', 1, NULL, NULL, 1, 1),
(53, 'Connexion', 'User connected', '2017-03-04 03:10:26', '::1', 4, NULL, NULL, 1, 1),
(54, 'Disconnection', 'User disconnected', '2017-03-04 03:12:56', '::1', 4, NULL, NULL, 1, 1),
(55, 'Connexion', 'User connected', '2017-03-04 03:13:03', '::1', 2, NULL, NULL, 1, 1),
(56, 'Connexion', 'User connected', '2017-03-04 05:18:01', '::1', 1, NULL, NULL, 1, 1),
(57, 'Connexion', 'User connected', '2017-03-05 01:03:22', '::1', 1, NULL, NULL, 1, 1),
(58, 'Connexion', 'User connected', '2017-03-07 01:18:39', '::1', 1, NULL, NULL, 1, 1),
(59, 'Connexion', 'User connected', '2017-03-07 05:08:48', '::1', 4, NULL, NULL, 1, 1),
(60, 'Disconnection', 'User disconnected', '2017-03-07 05:48:29', '::1', 4, NULL, NULL, 1, 1),
(61, 'Connexion', 'User connected', '2017-03-07 06:43:43', '::1', 1, NULL, NULL, 1, 1),
(62, 'Disconnection', 'User disconnected', '2017-03-07 06:44:29', '::1', 1, NULL, NULL, 1, 1),
(63, 'Connexion', 'User connected', '2017-03-07 06:44:35', '::1', 1, NULL, NULL, 1, 1),
(64, 'Disconnection', 'User disconnected', '2017-03-07 07:44:45', '::1', 1, NULL, NULL, 1, 1),
(65, 'Connexion', 'User connected', '2017-03-07 07:44:50', '::1', 4, NULL, NULL, 1, 1),
(66, 'Disconnection', 'User disconnected', '2017-03-07 07:49:14', '::1', 4, NULL, NULL, 1, 1),
(67, 'Connexion', 'User connected', '2017-03-07 07:49:21', '::1', 1, NULL, NULL, 1, 1),
(68, 'Connexion', 'User connected', '2017-03-08 01:18:16', '::1', 1, NULL, NULL, 1, 1),
(69, '', '', '0000-00-00 00:00:00', '', 0, NULL, NULL, 1, 1),
(70, '', '', '0000-00-00 00:00:00', '', 0, NULL, NULL, 1, 1),
(71, 'Disconnection', 'User disconnected', '2017-03-08 01:24:49', '::1', 0, NULL, NULL, 1, 1),
(72, 'Connexion', 'User connected', '2017-03-08 01:25:17', '::1', 1, NULL, NULL, 1, 1),
(73, 'Disconnection', 'User disconnected', '2017-03-08 01:27:13', '::1', 1, NULL, NULL, 1, 1),
(74, 'Connexion', 'User connected', '2017-03-08 01:45:58', '::1', 1, NULL, NULL, 1, 1),
(75, 'Connexion', 'User connected', '2017-03-08 02:46:45', '::1', 1, NULL, NULL, 1, 1),
(76, 'Connexion', 'User connected', '2017-03-08 04:55:16', '::1', 1, NULL, NULL, 1, 1),
(77, 'Connexion', 'User connected', '2017-03-08 06:32:46', '::1', 1, NULL, NULL, 1, 1),
(78, 'Disconnection', 'User disconnected', '2017-03-08 06:33:30', '::1', 1, NULL, NULL, 1, 1),
(79, 'Connexion', 'User connected', '2017-03-08 06:33:35', '::1', 4, NULL, NULL, 1, 1),
(80, 'Connexion', 'User connected', '2017-03-08 23:59:57', '::1', 1, NULL, NULL, 1, 1),
(81, 'Connexion', 'User connected', '2017-03-09 10:13:11', '::1', 1, NULL, NULL, 1, 1),
(82, 'Connexion', 'User connected', '2017-03-09 21:32:03', '::1', 1, NULL, NULL, 1, 1),
(83, 'Disconnection', 'User disconnected', '2017-03-09 21:33:00', '::1', 1, NULL, NULL, 1, 1),
(84, 'Connexion', 'User connected', '2017-03-09 21:33:12', '::1', 1, NULL, NULL, 1, 1),
(85, 'Disconnection', 'User disconnected', '2017-03-09 22:31:11', '::1', 1, NULL, NULL, 1, 1),
(86, 'Connexion', 'User connected', '2017-03-09 22:31:20', '::1', 1, NULL, NULL, 1, 1),
(87, 'Connexion', 'User connected', '2017-03-09 22:31:47', '::1', 1, NULL, NULL, 1, 1),
(88, 'Disconnection', 'User disconnected', '2017-03-09 22:32:02', '::1', 1, NULL, NULL, 1, 1),
(89, 'Connexion', 'User connected', '2017-03-09 22:32:07', '::1', 4, NULL, NULL, 1, 1),
(90, 'Disconnection', 'User disconnected', '2017-03-10 00:20:22', '::1', 1, NULL, NULL, 1, 1),
(91, 'Connexion', 'User connected', '2017-03-10 00:20:30', '::1', 1, NULL, NULL, 1, 1),
(92, 'Disconnection', 'User disconnected', '2017-03-10 01:09:55', '::1', 1, NULL, NULL, 1, 1),
(93, 'Connexion', 'User connected', '2017-03-10 01:10:10', '::1', 1, NULL, NULL, 1, 1),
(94, 'Connexion', 'User connected', '2017-03-15 04:43:09', '::1', 1, NULL, NULL, 1, 1),
(95, 'Connexion', 'User connected', '2017-03-28 02:26:15', '::1', 1, NULL, NULL, 1, 1),
(96, 'Connexion', 'User connected', '2017-03-28 05:20:44', '::1', 1, NULL, NULL, 1, 1),
(97, 'Connexion', 'User connected', '2017-03-28 07:54:09', '::1', 1, NULL, NULL, 1, 1),
(98, 'Disconnection', 'User disconnected', '2017-03-28 07:54:22', '::1', 1, NULL, NULL, 1, 1),
(99, 'Connexion', 'User connected', '2017-03-28 07:54:28', '::1', 1, NULL, NULL, 1, 1),
(100, 'Disconnection', 'User disconnected', '2017-03-28 08:05:25', '::1', 0, NULL, NULL, 1, 1),
(101, 'Connexion', 'User connected', '2017-03-28 08:05:31', '::1', 1, NULL, NULL, 1, 1),
(102, 'Connexion', 'User connected', '2017-03-29 00:02:01', '::1', 1, NULL, NULL, 1, 1),
(103, 'Connexion', 'User connected', '2017-03-29 22:15:30', '::1', 1, NULL, NULL, 1, 1),
(104, 'Connexion', 'User connected', '2017-03-30 01:54:51', '::1', 1, NULL, NULL, 1, 1),
(105, 'Connexion', 'User connected', '2017-03-31 00:28:55', '::1', 1, NULL, NULL, 1, 1),
(106, 'Disconnection', 'User disconnected', '2017-03-31 00:57:26', '::1', 1, NULL, NULL, 1, 1),
(107, 'Connexion', 'User connected', '2017-03-31 04:29:08', '::1', 1, NULL, NULL, 1, 1),
(108, 'Connexion', 'User connected', '2017-04-06 01:47:57', '::1', 1, NULL, NULL, 1, 1),
(109, 'Connexion', 'User connected', '2017-04-11 10:01:26', '::1', 1, NULL, NULL, 1, 1),
(110, 'Disconnection', 'User disconnected', '2017-04-11 10:03:07', '::1', 1, NULL, NULL, 1, 1),
(111, 'Connexion', 'User connected', '2017-04-11 10:03:22', '::1', 1, NULL, NULL, 1, 1),
(112, 'Connexion', 'User connected', '2017-04-11 22:02:59', '::1', 1, NULL, NULL, 1, 1),
(113, 'Connexion', 'User connected', '2017-04-12 02:20:28', '::1', 1, NULL, NULL, 1, 1),
(114, 'Connexion', 'User connected', '2017-04-13 01:36:24', '::1', 1, NULL, NULL, 1, 1),
(115, 'Connexion', 'User connected', '2017-04-14 02:12:14', '::1', 1, NULL, NULL, 1, 1),
(116, 'Connexion', 'User connected', '2017-04-14 23:40:43', '::1', 1, NULL, NULL, 1, 1),
(117, 'Connexion', 'User connected', '2017-04-18 04:26:54', '::1', 1, NULL, NULL, 1, 1),
(118, 'Connexion', 'User connected', '2017-04-18 10:58:25', '::1', 1, NULL, NULL, 1, 1),
(119, 'Connexion', 'User connected', '2017-04-20 19:47:27', '::1', 1, NULL, NULL, 1, 1),
(120, 'Connexion', 'User connected', '2017-04-21 00:52:42', '::1', 1, NULL, NULL, 1, 1),
(121, 'Connexion', 'User connected', '2017-04-25 10:49:33', '::1', 1, NULL, NULL, 1, 1),
(122, 'Connexion', 'User connected', '2017-04-25 21:38:41', '::1', 1, NULL, NULL, 1, 1),
(123, 'Connexion', 'User connected', '2017-04-29 01:49:59', '::1', 1, NULL, NULL, 1, 1),
(124, 'Connexion', 'User connected', '2017-04-30 01:28:15', '::1', 1, NULL, NULL, 1, 1),
(125, 'Connexion', 'User connected', '2017-05-02 20:54:07', '::1', 1, NULL, NULL, 1, 1),
(126, 'Disconnection', 'User disconnected', '2017-05-02 23:57:42', '::1', 1, NULL, NULL, 1, 1),
(127, 'Connexion', 'User connected', '2017-05-05 00:09:34', '::1', 1, NULL, NULL, 1, 1),
(128, 'Connexion', 'User connected', '2017-05-10 22:33:59', '::1', 1, NULL, NULL, 1, 1),
(129, 'Connexion', 'User connected', '2017-05-17 22:26:38', '::1', 1, NULL, NULL, 1, 1),
(130, 'Connexion', 'User connected', '2017-05-19 01:06:23', '::1', 1, NULL, NULL, 1, 1),
(131, 'Connexion', 'User connected', '2017-05-19 02:23:30', '::1', 1, NULL, NULL, 1, 1),
(132, 'Connexion', 'User connected', '2017-05-23 22:25:38', '::1', 1, NULL, NULL, 1, 1),
(133, 'Connexion', 'User connected', '2017-05-24 01:19:50', '::1', 1, NULL, NULL, 1, 1),
(134, 'Connexion', 'User connected', '2017-06-02 22:15:17', '::1', 1, NULL, NULL, 1, 1),
(135, 'Connexion', 'User connected', '2017-06-04 02:55:46', '::1', 1, NULL, NULL, 1, 1),
(136, 'Connexion', 'User connected', '2017-06-05 04:23:20', '::1', 1, NULL, NULL, 1, 1),
(137, 'Connexion', 'User connected', '2017-06-05 08:54:44', '::1', 1, NULL, NULL, 1, 1),
(138, 'Connexion', 'User connected', '2017-06-06 00:02:02', '::1', 1, NULL, NULL, 1, 1),
(139, 'Connexion', 'User connected', '2017-06-06 04:07:45', '::1', 1, NULL, NULL, 1, 1),
(140, 'Connexion', 'User connected', '2017-06-06 16:45:46', '::1', 1, NULL, NULL, 1, 1),
(141, 'Connexion', 'User connected', '2017-06-07 07:17:41', '::1', 1, NULL, NULL, 1, 1),
(142, 'Connexion', 'User connected', '2017-06-07 11:07:00', '::1', 1, NULL, NULL, 1, 1),
(143, 'Connexion', 'User connected', '2017-06-08 00:15:54', '::1', 1, NULL, NULL, 1, 1),
(144, 'Connexion', 'User connected', '2017-06-08 20:59:43', '::1', 1, NULL, NULL, 1, 1),
(145, 'Connexion', 'User connected', '2017-06-10 22:30:43', '::1', 1, NULL, NULL, 1, 1),
(146, 'Connexion', 'User connected', '2017-06-12 21:08:39', '::1', 1, NULL, NULL, 1, 1),
(147, 'Connexion', 'User connected', '2017-06-13 09:32:06', '::1', 1, NULL, NULL, 1, 1),
(148, 'Connexion', 'User connected', '2017-06-14 22:22:27', '::1', 1, NULL, NULL, 1, 1),
(149, 'Connexion', 'User connected', '2017-06-15 09:44:16', '::1', 1, NULL, NULL, 1, 1),
(150, 'Disconnection', 'User disconnected', '2017-06-15 09:45:06', '::1', 1, NULL, NULL, 1, 1),
(151, 'Connexion', 'User connected', '2017-06-15 21:34:07', '::1', 1, NULL, NULL, 1, 1),
(152, 'Disconnection', 'User disconnected', '2017-06-15 22:24:12', '::1', 1, NULL, NULL, 1, 1),
(153, 'Connexion', 'User connected', '2017-06-16 00:09:47', '::1', 1, NULL, NULL, 1, 1),
(154, 'Disconnection', 'User disconnected', '2017-06-16 04:16:02', '::1', 0, NULL, NULL, 1, 1),
(155, 'Connexion', 'User connected', '2017-06-16 05:13:31', '::1', 1, NULL, NULL, 1, 1),
(156, 'Connexion', 'User connected', '2017-06-16 07:02:58', '::1', 1, NULL, NULL, 1, 1),
(157, 'Disconnection', 'User disconnected', '2017-06-16 07:32:00', '::1', 1, NULL, NULL, 1, 1),
(158, 'Connexion', 'User connected', '2017-06-16 07:32:15', '::1', 4, NULL, NULL, 1, 1),
(159, 'Connexion', 'User connected', '2017-06-16 11:46:32', '::1', 1, NULL, NULL, 1, 1),
(160, 'Connexion', 'User connected', '2017-06-18 21:52:04', '::1', 1, NULL, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_label` varchar(100) NOT NULL,
  `project_title` varchar(250) NOT NULL,
  `project_description` varchar(1000) DEFAULT NULL,
  `project_creator` int(11) NOT NULL DEFAULT '1',
  `project_icon` blob,
  `project_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`project_id`, `project_label`, `project_title`, `project_description`, `project_creator`, `project_icon`, `project_active`) VALUES
(10, 'mt_bm_d', 'Model transformation BM Depends Xtext', 'Model transformation BM Depends Xtext', 1, NULL, 1),
(18, 'apiu', 'API Usability', 'API Usability', 1, NULL, 0),
(26, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(27, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(28, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(29, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(30, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(31, 'sm', 'Systematic mappings in SE', 'Systematic mappings in SE', 1, NULL, 0),
(32, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(33, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(34, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(35, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(36, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(37, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 0),
(38, 'mt', 'Model transformation test', 'Model transformation test', 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `str_management`
--

DROP TABLE IF EXISTS `str_management`;
CREATE TABLE IF NOT EXISTS `str_management` (
  `str_id` int(11) NOT NULL AUTO_INCREMENT,
  `str_label` varchar(500) NOT NULL,
  `str_text` varchar(1000) NOT NULL,
  `str_category` varchar(20) NOT NULL DEFAULT 'default',
  `str_lang` varchar(3) NOT NULL DEFAULT 'en',
  `str_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`str_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=147 ;

--
-- Dumping data for table `str_management`
--

INSERT INTO `str_management` (`str_id`, `str_label`, `str_text`, `str_category`, `str_lang`, `str_active`) VALUES
(1, '#', '#', 'default', 'en', 1),
(2, 'Short name', 'Short name', 'default', 'en', 1),
(3, 'Title', 'Title', 'default', 'en', 1),
(4, 'Description', 'Description', 'default', 'en', 1),
(5, 'Creator', 'Creator', 'default', 'en', 1),
(6, 'Installed projects', 'Installed projects', 'default', 'en', 1),
(7, 'Welcome', 'Welcome', 'default', 'en', 1),
(8, 'General', 'General', 'default', 'en', 1),
(9, 'Home', 'Home', 'default', 'en', 1),
(10, 'New project', 'New project', 'default', 'en', 1),
(11, 'Users', 'Users', 'default', 'en', 1),
(12, 'User groups', 'User groups', 'default', 'en', 1),
(13, 'Logs', 'Logs', 'default', 'en', 1),
(14, 'Choose project', 'Choose project', 'default', 'en', 1),
(15, 'UP', 'UP', 'default', 'en', 1),
(16, 'Log Out', 'Log Out', 'default', 'en', 1),
(17, 'No project available!', 'No project available!', 'default', 'en', 1),
(18, 'ReLiS - Revue Littéraire Systématique', 'ReLiS - Revue Littéraire Systématique', 'default', 'en', 1),
(19, 'Select', 'Select', 'default', 'en', 1),
(20, 'Select multi', 'Select multi', 'default', 'en', 1),
(21, 'Add new project', 'Add new project', 'default', 'en', 1),
(22, 'Upload configuration file', 'Upload configuration file', 'default', 'en', 1),
(23, 'Back', 'Back', 'default', 'en', 1),
(24, 'Name', 'Name', 'default', 'en', 1),
(25, 'Username', 'Username', 'default', 'en', 1),
(26, 'Email', 'Email', 'default', 'en', 1),
(27, 'Usergroup', 'Usergroup', 'default', 'en', 1),
(28, 'Project', 'Project', 'default', 'en', 1),
(29, 'Edit', 'Edit', 'default', 'en', 1),
(30, 'View', 'View', 'default', 'en', 1),
(31, 'Delete', 'Delete', 'default', 'en', 1),
(32, 'Action', 'Action', 'default', 'en', 1),
(33, 'Add new', 'Add new', 'default', 'en', 1),
(34, 'Close', 'Close', 'default', 'en', 1),
(35, 'List of users', 'List of users', 'default', 'en', 1),
(36, 'Search for...', 'Search for...', 'default', 'en', 1),
(37, 'Add user', 'Add user', 'default', 'en', 1),
(38, 'List of usergroups', 'List of usergroups', 'default', 'en', 1),
(39, 'Utilisateur', 'Utilisateur', 'default', 'en', 1),
(40, 'Evenement', 'Evenement', 'default', 'en', 1),
(41, 'Time', 'Time', 'default', 'en', 1),
(42, 'List of Logs', 'List of Logs', 'default', 'en', 1),
(43, 'Log in', 'Log in', 'default', 'en', 1),
(44, 'Password', 'Password', 'default', 'en', 1),
(45, 'Open editor', 'Open editor', 'default', 'en', 1),
(46, 'ReLiS editor', 'ReLiS editor', 'default', 'en', 1),
(47, 'Load from editor', 'Load from editor', 'default', 'en', 1),
(48, 'Choose setup file', 'Choose setup file', 'default', 'en', 1),
(49, 'Setup file imported', 'Setup file imported', 'default', 'en', 1),
(50, 'New database created', 'New database created', 'default', 'en', 1),
(51, 'Paper', 'Paper', 'default', 'en', 1),
(52, 'Assigned to', 'Assigned to', 'default', 'en', 1),
(53, 'Assigned by', 'Assigned by', 'default', 'en', 1),
(54, 'Editor location(url)', 'Editor location(url)', 'default', 'en', 1),
(55, 'Editor workspace', 'Editor workspace', 'default', 'en', 1),
(56, 'CSV  separator for import', 'CSV  separator for import', 'default', 'en', 1),
(57, 'CSV separator for export', 'CSV separator for export', 'default', 'en', 1),
(58, 'Exclusion criteria', 'Exclusion criteria', 'default', 'en', 1),
(59, 'Excluded by', 'Excluded by', 'default', 'en', 1),
(60, 'Key', 'Key', 'default', 'en', 1),
(61, 'Author', 'Author', 'default', 'en', 1),
(62, 'Value', 'Value', 'default', 'en', 1),
(63, 'Label', 'Label', 'default', 'en', 1),
(64, 'Text', 'Text', 'default', 'en', 1),
(65, 'Language', 'Language', 'default', 'en', 1),
(66, 'Abreviation', 'Abreviation', 'default', 'en', 1),
(67, 'Full name', 'Full name', 'default', 'en', 1),
(68, 'Year', 'Year', 'default', 'en', 1),
(69, 'Update project', 'Update project', 'default', 'en', 1),
(70, 'Transformation name', 'Transformation name', 'default', 'en', 1),
(71, 'Domain', 'Domain', 'default', 'en', 1),
(72, 'Goal', 'Goal', 'default', 'en', 1),
(73, 'Transformation language', 'Transformation language', 'default', 'en', 1),
(74, 'Emplementation Status', 'Emplementation Status', 'default', 'en', 1),
(75, 'Industrial', 'Industrial', 'default', 'en', 1),
(76, 'Is HOT', 'Is HOT', 'default', 'en', 1),
(77, 'Note', 'Note', 'default', 'en', 1),
(78, 'Source language', 'Source language', 'default', 'en', 1),
(79, 'Scope', 'Scope', 'default', 'en', 1),
(80, 'Intent', 'Intent', 'default', 'en', 1),
(81, 'Name used by the author', 'Name used by the author', 'default', 'en', 1),
(82, 'Comment', 'Comment', 'default', 'en', 1),
(83, 'Intent relation', 'Intent relation', 'default', 'en', 1),
(84, 'Intent 1', 'Intent 1', 'default', 'en', 1),
(85, 'Intent 2', 'Intent 2', 'default', 'en', 1),
(86, 'Go back to the project', 'Go back to the project', 'default', 'en', 1),
(87, 'Go to the project', 'Go to the project', 'default', 'en', 1),
(88, 'Uninstall', 'Uninstall', 'default', 'en', 1),
(89, 'Edit user', 'Edit user', 'default', 'en', 1),
(90, 'Confirmation', 'Confirmation', 'default', 'en', 1),
(91, 'Picture', 'Picture', 'default', 'en', 1),
(92, 'Projects', 'Projects', 'default', 'en', 1),
(93, 'Default language', 'Default language', 'default', 'en', 1),
(94, 'Success', 'Success', 'default', 'en', 1),
(95, 'Study', 'Study', 'default', 'en', 1),
(96, 'Validation', 'Validation', 'default', 'en', 1),
(97, 'Contribution', 'Contribution', 'default', 'en', 1),
(98, 'Détection d artéfact', 'Détection d artéfact', 'default', 'en', 1),
(99, 'Sources de données', 'Sources de données', 'default', 'en', 1),
(100, 'Stade de contribution', 'Stade de contribution', 'default', 'en', 1),
(101, 'Project already installed', 'Project already installed', 'default', 'en', 1),
(102, 'Domaine', 'Domaine', 'default', 'en', 1),
(103, 'Type de document', 'Type de document', 'default', 'en', 1),
(104, 'Processuss suivie', 'Processuss suivie', 'default', 'en', 1),
(105, 'Source de papiers', 'Source de papiers', 'default', 'en', 1),
(106, 'Add new user', 'Add new user', 'default', 'en', 1),
(107, 'Error', 'Error', 'default', 'en', 1),
(108, 'Edit user informations', 'Edit user informations', 'default', 'en', 1),
(109, 'User detail', 'User detail', 'default', 'en', 1),
(110, 'Uninstall the project : ', 'Uninstall the project : ', 'default', 'en', 1),
(111, 'Cancel', 'Cancel', 'default', 'en', 1),
(112, 'Continue to uninstall', 'Continue to uninstall', 'default', 'en', 1),
(113, 'Continue uninstall', 'Continue uninstall', 'default', 'en', 1),
(114, 'Project Systematic mappings in SE2 uninstalled !', 'Project Systematic mappings in SE2 uninstalled !', 'default', 'en', 1),
(115, 'Back to the list of projects', 'Back to the list of projects', 'default', 'en', 1),
(116, 'Error : Page "project" not found! IN OLD', 'Error : Page "project" not found! IN OLD', 'default', 'en', 1),
(117, 'Project Systematic mappings in SE uninstalled !', 'Project Systematic mappings in SE uninstalled !', 'default', 'en', 1),
(118, 'Assignment type', 'Assignment type', 'default', 'en', 1),
(119, 'Assignment mode', 'Assignment mode', 'default', 'en', 1),
(120, 'Error : Page "screening" not found!', 'Error : Page "screening" not found!', 'default', 'en', 1),
(121, 'Target language', 'Target language', 'default', 'en', 1),
(122, 'Project Model transformation test uninstalled !', 'Project Model transformation test uninstalled !', 'default', 'en', 1),
(123, 'Decision', 'Decision', 'default', 'en', 1),
(124, 'Project Model transformation BM Depends new uninstalled !', 'Project Model transformation BM Depends new uninstalled !', 'default', 'en', 1),
(125, 'Project Model transformation BM uninstalled !', 'Project Model transformation BM uninstalled !', 'default', 'en', 1),
(126, 'Project API Usability uninstalled !', 'Project API Usability uninstalled !', 'default', 'en', 1),
(127, 'Project Model transformation BM Depends newsss uninstalled !', 'Project Model transformation BM Depends newsss uninstalled !', 'default', 'en', 1),
(128, 'Screening done', 'Screening done', 'default', 'en', 1),
(129, 'Screened by', 'Screened by', 'default', 'en', 1),
(130, 'Project detail', 'Project detail', 'default', 'en', 1),
(131, 'Screened', 'Screened', 'default', 'en', 1),
(132, 'Error : Page "assignment_screen_validate" not found!', 'Error : Page "assignment_screen_validate" not found!', 'default', 'en', 1),
(133, 'Operation type', 'Operation type', 'default', 'en', 1),
(134, 'user', 'user', 'default', 'en', 1),
(135, 'Configuration type', 'Configuration type', 'default', 'en', 1),
(136, 'Screening comfict type', 'Screening comfict type', 'default', 'en', 1),
(137, 'import papers activated', 'import papers activated', 'default', 'en', 1),
(138, 'assign papers activated', 'assign papers activated', 'default', 'en', 1),
(139, 'Screening activated', 'Screening activated', 'default', 'en', 1),
(140, 'Screening validation activated', 'Screening validation activated', 'default', 'en', 1),
(141, 'Classification activated', 'Classification activated', 'default', 'en', 1),
(142, 'Screening result activated', 'Screening result activated', 'default', 'en', 1),
(143, 'Add a user to the usergroup', 'Add a user to the usergroup', 'default', 'en', 1),
(144, 'Remove picture', 'Remove picture', 'default', 'en', 1),
(145, 'Success - picture removed', 'Success - picture removed', 'default', 'en', 1),
(146, 'Edit usergroup', 'Edit usergroup', 'default', 'en', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usergroup`
--

DROP TABLE IF EXISTS `usergroup`;
CREATE TABLE IF NOT EXISTS `usergroup` (
  `usergroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `usergroup_name` varchar(100) NOT NULL,
  `usergroup_description` varchar(100) DEFAULT NULL,
  `usergroup_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`usergroup_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `usergroup`
--

INSERT INTO `usergroup` (`usergroup_id`, `usergroup_name`, `usergroup_description`, `usergroup_active`) VALUES
(1, 'Super Admin', 'Super Admin', 1),
(2, 'Project Admin', 'Project Admin', 1),
(3, 'Reviewer', 'Reviewer', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userproject`
--

DROP TABLE IF EXISTS `userproject`;
CREATE TABLE IF NOT EXISTS `userproject` (
  `userproject_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `userproject_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`userproject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `userproject`
--

INSERT INTO `userproject` (`userproject_id`, `user_id`, `project_id`, `userproject_active`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0),
(3, 2, 1, 0),
(4, 3, 1, 0),
(5, 4, 1, 0),
(6, 5, 2, 0),
(7, 3, 2, 0),
(8, 5, 1, 0),
(9, 2, 10, 0),
(10, 3, 10, 0),
(11, 5, 10, 0),
(12, 4, 10, 0),
(13, 4, 11, 0),
(14, 4, 12, 0),
(15, 5, 11, 0),
(16, 5, 12, 0),
(17, 3, 11, 0),
(18, 2, 13, 0),
(19, 3, 13, 0),
(20, 5, 15, 0),
(21, 3, 15, 0),
(22, 2, 15, 0),
(23, 4, 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_username` varchar(20) NOT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `user_mail` varchar(100) DEFAULT NULL,
  `user_usergroup` int(11) DEFAULT NULL,
  `user_picture` varchar(300) DEFAULT NULL,
  `user_default_lang` varchar(3) NOT NULL DEFAULT 'en',
  `user_status` int(1) NOT NULL DEFAULT '1',
  `user_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_username` (`user_username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_username`, `user_password`, `user_mail`, `user_usergroup`, `user_picture`, `user_default_lang`, `user_status`, `user_active`) VALUES
(1, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', '', 1, '', 'en', 1, 1),
(2, 'Alice', 'alice', '7abdccbea8473767e91378e37850d296', '', 3, '', 'en', 1, 1),
(3, 'Bob', 'bob', '2acba7f51acfd4fd5102ad090fc612ee', '', 3, '', 'en', 1, 1),
(4, 'Eve', 'eve', '202cb962ac59075b964b07152d234b70', '', 2, NULL, 'en', 1, 1),
(5, 'Brice', 'brice', '202cb962ac59075b964b07152d234b70', '', 2, '', 'en', 1, 1);
--
-- Database: `relis_general_mt`
--
CREATE DATABASE `relis_general_mt` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `relis_general_mt`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignation`(_assigned_id INT , _assigned_paper_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205) , _assigned_by INT)
BEGIN
START TRANSACTION;
INSERT INTO assigned (assigned_paper_id , assigned_user_id , assigned_note , assigned_by) VALUES (_assigned_paper_id , _assigned_user_id , _assigned_note , _assigned_by);
SELECT assigned_id AS id_value FROM assigned WHERE assigned_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignment_screen`(_assignment_id INT , _paper_id INT , _user_id INT , _note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_mode  VARCHAR(35) , _assigned_by INT , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO assignment_screen (paper_id , user_id , note , assignment_type , assignment_mode , assigned_by , screening_done) VALUES (_paper_id , _user_id , _note , _assignment_type , _assignment_mode , _assigned_by , _screening_done);
SELECT assignment_id AS id_value FROM assignment_screen WHERE assignment_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignment_screen_validate`(_assignment_id INT , _paper_id INT , _user_id INT , _note  VARCHAR(205) , _assignment_type  VARCHAR(25) , _assignment_mode  VARCHAR(35) , _assigned_by INT , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO assignment_screen_validate (paper_id , user_id , note , assignment_type , assignment_mode , assigned_by , screening_done) VALUES (_paper_id , _user_id , _note , _assignment_type , _assignment_mode , _assigned_by , _screening_done);
SELECT assignment_id AS id_value FROM assignment_screen_validate WHERE assignment_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_author`(_author_id INT , _author_name  VARCHAR(35) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
INSERT INTO author (author_name , author_desc , author_picture) VALUES (_author_name , _author_desc , _author_picture);
SELECT author_id AS id_value FROM author WHERE author_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_classification`(_class_id INT , _class_paper_id INT , _transformation_name  VARCHAR(105) , _domain INT , _transformation_language INT , _source_language INT , _target_language INT , _Scope  VARCHAR(15) , _Industrial  VARCHAR(6) , _hot  VARCHAR(6) , _bidirectional  VARCHAR(6) , _implementation  VARCHAR(6) , _note  VARCHAR(505))
BEGIN
START TRANSACTION;
INSERT INTO classification (class_paper_id , transformation_name , domain , transformation_language , source_language , target_language , Scope , Industrial , hot , bidirectional , implementation , note) VALUES (_class_paper_id , _transformation_name , _domain , _transformation_language , _source_language , _target_language , _Scope , _Industrial , _hot , _bidirectional , _implementation , _note);
SELECT class_id AS id_value FROM classification WHERE class_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_config`(_config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
INSERT INTO config (config_type , editor_url , editor_generated_path , csv_field_separator , csv_field_separator_export , screening_screening_conflict_resolution , screening_conflict_type , import_papers_on , assign_papers_on , screening_on , screening_result_on , screening_validation_on , classification_on) VALUES (_config_type , _editor_url , _editor_generated_path , _csv_field_separator , _csv_field_separator_export , _screening_screening_conflict_resolution , _screening_conflict_type , _import_papers_on , _assign_papers_on , _screening_on , _screening_result_on , _screening_validation_on , _classification_on);
SELECT config_id AS id_value FROM config WHERE config_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_exclusion`(_exclusion_id INT , _exclusion_paper_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205) , _exclusion_by INT)
BEGIN
START TRANSACTION;
INSERT INTO exclusion (exclusion_paper_id , exclusion_criteria , exclusion_note , exclusion_by) VALUES (_exclusion_paper_id , _exclusion_criteria , _exclusion_note , _exclusion_by);
SELECT exclusion_id AS id_value FROM exclusion WHERE exclusion_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_operations`(_operation_id INT , _operation_code  VARCHAR(25) , _operation_type  VARCHAR(25) , _operation_desc  VARCHAR(205) , _user_id INT)
BEGIN
START TRANSACTION;
INSERT INTO operations (operation_code , operation_type , operation_desc , user_id) VALUES (_operation_code , _operation_type , _operation_desc , _user_id);
SELECT operation_id AS id_value FROM operations WHERE operation_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_papers`(_id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _screening_status  VARCHAR(25) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO paper (bibtexKey , title , preview , bibtex , abstract , doi , screening_status , venueId , paper_excluded) VALUES (_bibtexKey , _title , _preview , _bibtex , _abstract , _doi , _screening_status , _venueId , _paper_excluded);
SELECT id AS id_value FROM paper WHERE id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_paper_author`(_paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
INSERT INTO paperauthor (paperId , authorId) VALUES (_paperId , _authorId);
SELECT paperauthor_id AS id_value FROM paperauthor WHERE paperauthor_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_domain`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_domain (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_domain WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_exclusioncrieria`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO zref_exclusioncrieria (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM zref_exclusioncrieria WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_language`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_language (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_language WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_transformation_language`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_transformation_language (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_transformation_language WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screening`(_screening_id INT , _paper_id INT , _user_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205) , _assignment_id INT)
BEGIN
START TRANSACTION;
INSERT INTO screening (paper_id , user_id , decision , exclusion_criteria , note , assignment_id) VALUES (_paper_id , _user_id , _decision , _exclusion_criteria , _note , _assignment_id);
SELECT screening_id AS id_value FROM screening WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screening_validate`(_screening_id INT , _paper_id INT , _user_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205) , _assignment_id INT)
BEGIN
START TRANSACTION;
INSERT INTO screening_validate (paper_id , user_id , decision , exclusion_criteria , note , assignment_id) VALUES (_paper_id , _user_id , _decision , _exclusion_criteria , _note , _assignment_id);
SELECT screening_id AS id_value FROM screening_validate WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_str_mng`(_str_id INT , _str_label  VARCHAR(405) , _str_text  VARCHAR(805) , _str_lang  VARCHAR(8) , _str_category  VARCHAR(23))
BEGIN
START TRANSACTION;
INSERT INTO str_management (str_label , str_text , str_lang , str_category) VALUES (_str_label , _str_text , _str_lang , _str_category);
SELECT str_id AS id_value FROM str_management WHERE str_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_venue`(_venue_id INT , _venue_abbreviation  VARCHAR(15) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
INSERT INTO venue (venue_abbreviation , venue_fullName , venue_year , venue_volume , venue_totalNumPapers) VALUES (_venue_abbreviation , _venue_fullName , _venue_year , _venue_volume , _venue_totalNumPapers);
SELECT venue_id AS id_value FROM venue WHERE venue_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_list`(IN  source  VARCHAR(200), IN  condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select count(*) as nombre from  ',source ,'   WHERE 1=1  ', condition_stat );
PREPARE stmt FROM @query;
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;
END$$

DROP PROCEDURE IF EXISTS `count_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM paper WHERE paper_active=1   AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_assigned`(IN  _user_id  INT,IN _search VARCHAR(100))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM view_paper_assigned WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_class`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	SELECT count(*) as nbr FROM paper WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
	COMMIT;
	END$$

DROP PROCEDURE IF EXISTS `count_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_pending`(IN _search VARCHAR(100))
BEGIN
		START TRANSACTION;
		 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
		SELECT count(*) as nbr FROM view_paper_pending WHERE paper_active=1 AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
		COMMIT;
		END$$

DROP PROCEDURE IF EXISTS `count_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_processed`(IN _search VARCHAR(100))
BEGIN
				START TRANSACTION;
				 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
				SELECT count(*) as nbr FROM view_paper_processed WHERE paper_active=1  AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
				COMMIT;
				END$$

DROP PROCEDURE IF EXISTS `exclude_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `exclude_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 1  WHERE id = _paper_id ;
  COMMIT;
 END$$

DROP PROCEDURE IF EXISTS `get_assignations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_assignations`(_paperId INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned WHERE (assigned_paper_id = _paperId AND assigned_active=1);
COMMIT; 
END$$

DROP PROCEDURE IF EXISTS `get_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_author`(IN  _start_by  INT, IN  _range  INT, IN  _search  VARCHAR(100))
BEGIN
START TRANSACTION;
SET @search_author_name := CONCAT('%',_search,'%') ;  SET @search_author_desc := CONCAT('%',_search,'%') ; 
SELECT  author_id , author_name , author_desc FROM author
WHERE author_active=1  AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC LIMIT _start_by , _range;	
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classifications`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classifications`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * 
FROM classification 
WHERE (class_paper_id = _paperId AND class_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_paper`( _classificationId  INT)
BEGIN
START TRANSACTION;
SELECT class_paper_id
FROM classification 
WHERE (class_id = _classificationId);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_scheme`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_scheme`()
BEGIN
START TRANSACTION;
SELECT * FROM classification_scheme 
WHERE (scheme_active=1) ORDER BY field_order ASC;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignation`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned
WHERE assigned_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignment_screen`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assignment_screen
WHERE assignment_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignment_screen_validate`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assignment_screen_validate
WHERE assignment_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_author`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM author
WHERE author_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_classification`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM classification
WHERE class_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_config`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_exclusion`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion
WHERE exclusion_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_operations`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM operations
WHERE operation_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_papers`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paper
WHERE id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_paper_author`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paperauthor
WHERE paperauthor_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_domain`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_domain
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_exclusioncrieria`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM zref_exclusioncrieria
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_language`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_language
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_transformation_language`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_transformation_language
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screening`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM screening
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screening_validate`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM screening_validate
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_str_mng`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM str_management
WHERE str_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_venue`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM venue
WHERE venue_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list`(IN  _source  VARCHAR(100), IN  _fields  VARCHAR(1000), IN  _condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select ',_fields,' from  ',_source ,'   WHERE 1=1   ', _condition_stat );
 PREPARE stmt FROM @query;
 EXECUTE stmt;
 DEALLOCATE PREPARE stmt; 
END$$

DROP PROCEDURE IF EXISTS `get_list_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignation`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC ;
ELSE
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignment_screen`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC ;
ELSE
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignment_screen_validate`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assignment_screen_validate
WHERE assignment_active=1   ORDER BY assignment_id DESC ;
ELSE
SELECT * FROM assignment_screen_validate
WHERE assignment_active=1   ORDER BY assignment_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_author_name := CONCAT('%',TRIM(_search),'%') ;  SET @search_author_desc := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC ;
ELSE
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_classification`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC ;
ELSE
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_config`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC ;
ELSE
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_exclusion`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC ;
ELSE
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_operations`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM operations
WHERE operation_active=1   ORDER BY operation_id DESC ;
ELSE
SELECT * FROM operations
WHERE operation_active=1   ORDER BY operation_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500),IN _excluded VARCHAR(2))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM paper
WHERE paper_active=1  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_assigned`(IN  _user_id  INT,IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id)    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND  (assigned_user_id = _user_id)      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_class`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500),IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	IF _range < 1 THEN
	SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting' AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_pending`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_pending
WHERE paper_active=1  AND classification_status <> 'Waiting'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_pending
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_processed`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'     AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_paper_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC ;
ELSE
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_domain`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_domain
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_domain
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_exclusioncrieria`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_language`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_transformation_language`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_transformation_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_transformation_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screening`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC ;
ELSE
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screening_validate`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM screening_validate
WHERE screening_active=1   ORDER BY screening_id DESC ;
ELSE
SELECT * FROM screening_validate
WHERE screening_active=1   ORDER BY screening_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_str_mng`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
 SET @search_str_text := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC ;
ELSE
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_venue`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_venue_abbreviation := CONCAT('%',TRIM(_search),'%') ;  SET @search_venue_fullName := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC ;
ELSE
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_paper_exclusion_info`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_paper_exclusion_info`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion WHERE (exclusion_paper_id = _paperId AND exclusion_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_table`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_table`( _configId  VARCHAR(100))
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE (reftab_label = _configId AND reftab_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_tables_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_tables_list`()
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE reftab_active=1 order by  reftab_desc;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_value`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_value`(IN  _table  VARCHAR(100), IN  _id  VARCHAR(100), IN  _field  VARCHAR(100), IN  _table_id  VARCHAR(100))
BEGIN
SET @query = CONCAT('Select ',_field,' from  ',_table ,'   WHERE ', _table_id, ' = ', _id );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_result_count`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_result_count`(IN  _fields  VARCHAR(100))
BEGIN
SET @query = CONCAT('SELECT ',_fields,' AS field,count(*) AS nombre from classification,paper WHERE class_paper_id=id  AND paper_excluded = 0	 AND  paper_active=1 AND class_active=1 group by  ',_fields );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_row`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_row`(IN  source  VARCHAR(100), IN  source_id  VARCHAR(100), IN  id_value  VARCHAR(100))
BEGIN
SET @query = CONCAT("Select * from  ",source ,"  WHERE ", source_id ," = '",id_value,"'");
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_string`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_string`(IN  _text  VARCHAR(500), IN  _category  VARCHAR(30), IN  _lang  VARCHAR(3))
BEGIN
START TRANSACTION;
SELECT str_id, str_text FROM str_management WHERE str_active=1 AND str_label = _text AND str_category = _category AND str_lang = _lang ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `include_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `include_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 0  WHERE id = _paper_id ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignation`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assigned SET assigned_active=0
WHERE assigned_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignment_screen`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assignment_screen SET assignment_active=0
WHERE assignment_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignment_screen_validate`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assignment_screen_validate SET assignment_active=0
WHERE assignment_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE author SET author_active=0
WHERE author_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_classification`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE classification SET class_active=0
WHERE class_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_config`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE config SET config_active=0
WHERE config_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_exclusion`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE exclusion SET exclusion_active=0
WHERE exclusion_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_operations`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE operations SET operation_active=0
WHERE operation_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_papers`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paper SET paper_active=0
WHERE id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_paper_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paperauthor SET paperauthor_active=0
WHERE paperauthor_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_domain`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_domain SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_exclusioncrieria`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE zref_exclusioncrieria SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_language`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_language SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_transformation_language`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_transformation_language SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screening`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screening_validate`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening_validate SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_str_mng`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE str_management SET str_active=0
WHERE str_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_venue`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE venue SET venue_active=0
WHERE venue_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignation`(_element_id INT , _assigned_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  assigned SET assigned_id = _assigned_id , assigned_user_id = _assigned_user_id , assigned_note = _assigned_note
WHERE (assigned_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment_screen`(_element_id INT , _assignment_id INT , _user_id INT , _note  VARCHAR(205) , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  assignment_screen SET assignment_id = _assignment_id , user_id = _user_id , note = _note , screening_done = _screening_done
WHERE (assignment_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment_screen_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment_screen_validate`(_element_id INT , _assignment_id INT , _user_id INT , _note  VARCHAR(205) , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  assignment_screen_validate SET assignment_id = _assignment_id , user_id = _user_id , note = _note , screening_done = _screening_done
WHERE (assignment_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_author`(_element_id INT , _author_id INT , _author_name  VARCHAR(35) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
UPDATE  author SET author_id = _author_id , author_name = _author_name , author_desc = _author_desc , author_picture = _author_picture
WHERE (author_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_classification`(_element_id INT , _class_id INT , _class_paper_id INT , _transformation_name  VARCHAR(105) , _domain INT , _transformation_language INT , _source_language INT , _target_language INT , _Scope  VARCHAR(15) , _Industrial  VARCHAR(6) , _hot  VARCHAR(6) , _bidirectional  VARCHAR(6) , _implementation  VARCHAR(6) , _note  VARCHAR(505))
BEGIN
START TRANSACTION;
UPDATE  classification SET class_id = _class_id , class_paper_id = _class_paper_id , transformation_name = _transformation_name , domain = _domain , transformation_language = _transformation_language , source_language = _source_language , target_language = _target_language , Scope = _Scope , Industrial = _Industrial , hot = _hot , bidirectional = _bidirectional , implementation = _implementation , note = _note
WHERE (class_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_config`(_element_id INT , _config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , config_type = _config_type , editor_url = _editor_url , editor_generated_path = _editor_generated_path , csv_field_separator = _csv_field_separator , csv_field_separator_export = _csv_field_separator_export , screening_screening_conflict_resolution = _screening_screening_conflict_resolution , screening_conflict_type = _screening_conflict_type , import_papers_on = _import_papers_on , assign_papers_on = _assign_papers_on , screening_on = _screening_on , screening_result_on = _screening_result_on , screening_validation_on = _screening_validation_on , classification_on = _classification_on
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_exclusion`(_element_id INT , _exclusion_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  exclusion SET exclusion_id = _exclusion_id , exclusion_criteria = _exclusion_criteria , exclusion_note = _exclusion_note
WHERE (exclusion_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_operations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_operations`(_element_id INT , _operation_id INT , _operation_desc  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  operations SET operation_id = _operation_id , operation_desc = _operation_desc
WHERE (operation_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_papers`(_element_id INT , _id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  paper SET id = _id , bibtexKey = _bibtexKey , title = _title , preview = _preview , bibtex = _bibtex , abstract = _abstract , doi = _doi , venueId = _venueId , paper_excluded = _paper_excluded
WHERE (id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_paper_author`(_element_id INT , _paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
UPDATE  paperauthor SET paperauthor_id = _paperauthor_id , paperId = _paperId , authorId = _authorId
WHERE (paperauthor_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_domain`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_domain SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_exclusioncrieria`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  zref_exclusioncrieria SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_language`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_language SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_transformation_language`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_transformation_language SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screening`(_element_id INT , _screening_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  screening SET screening_id = _screening_id , decision = _decision , exclusion_criteria = _exclusion_criteria , note = _note
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screening_validate`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screening_validate`(_element_id INT , _screening_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  screening_validate SET screening_id = _screening_id , decision = _decision , exclusion_criteria = _exclusion_criteria , note = _note
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_str_mng`(_element_id INT , _str_id INT , _str_text  VARCHAR(805))
BEGIN
START TRANSACTION;
UPDATE  str_management SET str_id = _str_id , str_text = _str_text
WHERE (str_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_venue`(_element_id INT , _venue_id INT , _venue_abbreviation  VARCHAR(15) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
UPDATE  venue SET venue_id = _venue_id , venue_abbreviation = _venue_abbreviation , venue_fullName = _venue_fullName , venue_year = _venue_year , venue_volume = _venue_volume , venue_totalNumPapers = _venue_totalNumPapers
WHERE (venue_id = _element_id);
COMMIT;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assigned`
--

DROP TABLE IF EXISTS `assigned`;
CREATE TABLE IF NOT EXISTS `assigned` (
  `assigned_id` int(11) NOT NULL AUTO_INCREMENT,
  `assigned_paper_id` int(11) NOT NULL,
  `assigned_user_id` int(11) NOT NULL,
  `assigned_note` text,
  `assigned_by` int(11) NOT NULL,
  `assigned_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `assigned_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assigned_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `assignment_screen`
--

DROP TABLE IF EXISTS `assignment_screen`;
CREATE TABLE IF NOT EXISTS `assignment_screen` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) DEFAULT NULL,
  `screening_done` int(2) NOT NULL DEFAULT '0',
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `assignment_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;

--
-- Dumping data for table `assignment_screen`
--

INSERT INTO `assignment_screen` (`assignment_id`, `paper_id`, `user_id`, `note`, `assignment_type`, `assignment_mode`, `assigned_by`, `screening_done`, `assignment_time`, `operation_code`, `assignment_active`) VALUES
(1, 1, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(2, 1, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(3, 2, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(4, 2, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(5, 3, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(6, 3, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(7, 4, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(8, 4, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(9, 5, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(10, 5, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(11, 6, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(12, 6, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(13, 7, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(14, 7, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(15, 8, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(16, 8, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(17, 9, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(18, 9, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(19, 10, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(20, 10, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(21, 11, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(22, 11, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(23, 12, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(24, 12, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(25, 13, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(26, 13, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(27, 14, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(28, 14, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(29, 15, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(30, 15, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(31, 16, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(32, 16, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(33, 17, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(34, 17, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(35, 18, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(36, 18, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(37, 19, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(38, 19, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(39, 20, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(40, 20, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(41, 21, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(42, 21, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(43, 22, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(44, 22, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(45, 23, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(46, 23, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(47, 24, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(48, 24, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(49, 25, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:37', '1_1493095897', 1),
(50, 25, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(51, 26, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(52, 26, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(53, 27, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(54, 27, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:37', '1_1493095897', 1),
(55, 28, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(56, 28, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:38', '1_1493095898', 1),
(57, 29, 4, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:38', '1_1493095898', 1),
(58, 29, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:38', '1_1493095898', 1),
(59, 30, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:38', '1_1493095898', 1),
(60, 30, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(61, 31, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(62, 31, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(63, 32, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(64, 32, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(65, 33, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(66, 33, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(67, 34, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(68, 34, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:38', '1_1493095898', 1),
(69, 35, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:38', '1_1493095898', 1),
(70, 35, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(71, 36, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(72, 36, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(73, 37, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(74, 37, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(75, 38, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(76, 38, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(77, 39, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(78, 39, 1, '', 'Normal', 'auto', 1, 1, '2017-04-25 04:51:38', '1_1493095898', 1),
(79, 40, 1, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(80, 40, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(81, 41, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(82, 41, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(83, 42, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(84, 42, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(85, 43, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(86, 43, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(87, 44, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(88, 44, 1, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(89, 45, 1, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(90, 45, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(91, 46, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(92, 46, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(93, 47, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(94, 47, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(95, 48, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(96, 48, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(97, 49, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(98, 49, 1, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(99, 50, 1, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(100, 50, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(101, 51, 2, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(102, 51, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(103, 52, 3, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(104, 52, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(105, 53, 5, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(106, 53, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(107, 54, 4, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1),
(108, 54, 1, '', 'Normal', 'auto', 1, 0, '2017-04-25 04:51:38', '1_1493095898', 1);

-- --------------------------------------------------------

--
-- Table structure for table `assignment_screen_validate`
--

DROP TABLE IF EXISTS `assignment_screen_validate`;
CREATE TABLE IF NOT EXISTS `assignment_screen_validate` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) DEFAULT NULL,
  `screening_done` int(2) NOT NULL DEFAULT '0',
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `assignment_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `assignment_screen_validate`
--

INSERT INTO `assignment_screen_validate` (`assignment_id`, `paper_id`, `user_id`, `note`, `assignment_type`, `assignment_mode`, `assigned_by`, `screening_done`, `assignment_time`, `operation_code`, `assignment_active`) VALUES
(1, 24, 4, '', 'Normal', 'auto', 4, 1, '2017-06-16 01:33:53', '4_1497576833', 1),
(2, 29, 4, '', 'Normal', 'auto', 4, 1, '2017-06-16 01:33:53', '4_1497576833', 1),
(3, 19, 4, '', 'Normal', 'auto', 4, 1, '2017-06-16 01:33:53', '4_1497576833', 1),
(4, 14, 4, '', 'Normal', 'auto', 4, 1, '2017-06-16 01:33:53', '4_1497576833', 1);

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
CREATE TABLE IF NOT EXISTS `author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(200) NOT NULL,
  `author_desc` text,
  `author_picture` varchar(300) DEFAULT NULL,
  `author_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classification`
--

DROP TABLE IF EXISTS `classification`;
CREATE TABLE IF NOT EXISTS `classification` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_paper_id` int(11) DEFAULT NULL,
  `transformation_name` varchar(100) NOT NULL,
  `domain` int(11) DEFAULT NULL,
  `transformation_language` int(11) DEFAULT NULL,
  `source_language` int(11) DEFAULT NULL,
  `target_language` int(11) DEFAULT NULL,
  `Scope` enum('Exogenous','Inplace','Outplace') NOT NULL,
  `Industrial` int(2) DEFAULT NULL,
  `hot` int(2) NOT NULL,
  `bidirectional` int(2) DEFAULT NULL,
  `implementation` int(2) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `class_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classification_scheme`
--

DROP TABLE IF EXISTS `classification_scheme`;
CREATE TABLE IF NOT EXISTS `classification_scheme` (
  `scheme_id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme_label` varchar(100) NOT NULL,
  `scheme_title` varchar(100) NOT NULL,
  `scheme_parent` varchar(100) NOT NULL DEFAULT 'main',
  `scheme_mandatory` int(1) NOT NULL DEFAULT '0',
  `scheme_category` varchar(30) NOT NULL,
  `scheme_type` varchar(30) DEFAULT NULL,
  `scheme_size` int(11) DEFAULT NULL,
  `scheme_source` varchar(1000) DEFAULT NULL,
  `scheme_source_main_field` varchar(100) DEFAULT NULL,
  `scheme_number_of_values` varchar(2) NOT NULL DEFAULT '1',
  `scheme_order` int(2) NOT NULL DEFAULT '1',
  `scheme_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`scheme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_type` varchar(100) NOT NULL DEFAULT 'default',
  `editor_url` varchar(100) NOT NULL,
  `editor_generated_path` varchar(100) DEFAULT NULL,
  `csv_field_separator` enum(';',',') NOT NULL DEFAULT ';',
  `csv_field_separator_export` enum(';',',') NOT NULL DEFAULT ',',
  `screening_screening_conflict_resolution` enum('Unanimity','Majority') NOT NULL DEFAULT 'Unanimity',
  `screening_conflict_type` enum('IncludeExclude','ExclusionCriteria') NOT NULL DEFAULT 'IncludeExclude',
  `import_papers_on` int(2) NOT NULL DEFAULT '1',
  `assign_papers_on` int(2) NOT NULL DEFAULT '1',
  `screening_on` int(2) NOT NULL DEFAULT '1',
  `screening_validation_on` int(2) NOT NULL DEFAULT '1',
  `classification_on` int(2) NOT NULL DEFAULT '1',
  `screening_result_on` int(2) NOT NULL DEFAULT '1',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_id`, `config_type`, `editor_url`, `editor_generated_path`, `csv_field_separator`, `csv_field_separator_export`, `screening_screening_conflict_resolution`, `screening_conflict_type`, `import_papers_on`, `assign_papers_on`, `screening_on`, `screening_validation_on`, `classification_on`, `screening_result_on`, `config_active`) VALUES
(1, 'default', 'http://127.0.0.1:8080/relis/texteditor', 'C:/relis_workspace', ';', ',', 'Unanimity', 'IncludeExclude', 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exclusion`
--

DROP TABLE IF EXISTS `exclusion`;
CREATE TABLE IF NOT EXISTS `exclusion` (
  `exclusion_id` int(11) NOT NULL AUTO_INCREMENT,
  `exclusion_paper_id` int(11) NOT NULL,
  `exclusion_criteria` int(11) NOT NULL,
  `exclusion_note` text,
  `exclusion_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `exclusion_by` int(11) NOT NULL,
  `exclusion_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`exclusion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `installation_info`
--

DROP TABLE IF EXISTS `installation_info`;
CREATE TABLE IF NOT EXISTS `installation_info` (
  `install_id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_tables` text NOT NULL,
  `generated_tables` text NOT NULL,
  `foreign_key_constraint` text,
  `install_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`install_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `installation_info`
--

INSERT INTO `installation_info` (`install_id`, `reference_tables`, `generated_tables`, `foreign_key_constraint`, `install_active`) VALUES
(1, '["ref_domain","ref_transformation_language","ref_language"]', '["classification"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_transformation_language   , DROP FOREIGN KEY  classification_source_language   , DROP FOREIGN KEY  classification_target_language   ;"]', 1);

-- --------------------------------------------------------

--
-- Table structure for table `operations`
--

DROP TABLE IF EXISTS `operations`;
CREATE TABLE IF NOT EXISTS `operations` (
  `operation_id` int(11) NOT NULL AUTO_INCREMENT,
  `operation_code` varchar(20) NOT NULL DEFAULT '01',
  `operation_type` enum('import_paper','assign_papers','assign_papers_validation') NOT NULL DEFAULT 'import_paper',
  `operation_desc` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `operation_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`operation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `operations`
--

INSERT INTO `operations` (`operation_id`, `operation_code`, `operation_type`, `operation_desc`, `user_id`, `operation_time`, `operation_active`) VALUES
(1, '1_1489085284', 'import_paper', 'Paper import before screening', 1, '2017-03-09 18:48:05', 1),
(2, '1_1489085367', 'assign_papers', 'Assign papers for screening', 1, '2017-03-09 18:49:27', 1),
(3, '1_1489085570', 'assign_papers', 'Assign papers for screening', 1, '2017-03-09 18:52:50', 1),
(4, '1_1489086387', 'assign_papers', 'Assign papers for screening', 1, '2017-03-09 19:06:27', 1),
(5, '1_1493095842', 'import_paper', 'Paper import before screening', 1, '2017-04-25 04:50:43', 1),
(6, '1_1493095898', 'assign_papers', 'Assign papers for screening', 1, '2017-04-25 04:51:38', 1),
(7, '4_1497576833', 'assign_papers_validation', 'Assign 100 % (4) of Excluded papers for validation', 4, '2017-06-16 01:33:53', 1);

-- --------------------------------------------------------

--
-- Table structure for table `paper`
--

DROP TABLE IF EXISTS `paper`;
CREATE TABLE IF NOT EXISTS `paper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bibtexKey` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `doi` varchar(1000) DEFAULT NULL,
  `venueId` int(11) DEFAULT NULL,
  `bibtex` longtext,
  `preview` longtext,
  `abstract` longtext,
  `screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded') NOT NULL DEFAULT 'Pending',
  `classification_status` enum('Waiting','To classify','Classified') NOT NULL DEFAULT 'Waiting',
  `paper_excluded` int(1) NOT NULL DEFAULT '0',
  `operation_code` varchar(20) DEFAULT '01',
  `paper_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_Paper_bibtexKey` (`bibtexKey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `paper`
--

INSERT INTO `paper` (`id`, `bibtexKey`, `title`, `doi`, `venueId`, `bibtex`, `preview`, `abstract`, `screening_status`, `classification_status`, `paper_excluded`, `operation_code`, `paper_active`) VALUES
(1, 'paper_1', '"5W+1H pattern: A perspective of systematic mapping studies and a case study on cloud software testing"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84923328222&partnerID=40&md5=ab9586291eb660686744b0d525513668', NULL, '<b>Authors:</b><br/>"Jia C., Cai Y., Yu Y.T., Tse T.H." <br/><b>Key words:</b><br/>"5W+1H pattern, Cloud software testing, Systematic mapping study"', '"A common type of study used by researchers to map out the landscape of a research topic is known as mapping study. Such a study typically begins with an exploratory search on the possible ideas of the research topic, which is often done in an unsystematic manner. Hence, the activity of formulating research questions in mapping studies is ill-defined, rendering it difficult for researchers who are new to the topic. There is a need to guide them kicking off a mapping study of an unfamiliar domain. This paper proposes a 5W+1H pattern to help investigators systematically examine a generic set of dimensions in a mapping study toward the formulation of research questions before identifying, reading, and analyzing sufficient articles of the topic. We have validated the feasibility of our proposal by conducting a case study of a mapping study on cloud software testing, that is, software testing for and on cloud computing platforms. The case study reveals that the 5W+1H pattern can lead investigators to define a set of systematic, generic, and complementary research questions, enabling them to kick off and expedite the mapping study process in a well-defined manner. We also share our experiences and lessons learned from our case study on the use of the 5W+1H pattern in mapping studies. Â© 2015 Elsevier Inc. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(2, 'paper_2', '"A Mapping Study of Software Causal Factors for Improving Maintenance"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84961661951&partnerID=40&md5=692d940e823529be710d2f4f2ee0307f', NULL, '<b>Authors:</b><br/>"Carroll C., Falessi D., Forney V., Frances A., Izurieta C., Seaman C." <br/><b>Key words:</b><br/>"controlled experiments, defects, mapping study, Software maintenance, systematic literature review"', '"Context: Software maintenance is important to keep existing software systems functional for organizations or users that depend on that software. Goal: We aim to identify the factors, i.e., software characteristics such as code complexity, leading to maintenance problems. Method: We present a Mapping Study (MS) on controlled experiments that investigated software characteristics related to defects during maintenance. Results: The search strategy identified 78 papers, of which 9 have been included in our study, dated from 1985 to 2013, after applying our inclusion and exclusion criteria. We extracted data from these papers to identify the research methods, and the independent, dependent, blocked, and measured variables. Conclusions: Our MS results point to a weak evidence on software factors causing defects during maintenance. Stronger evidence can be developed via more controlled experiments that address multiple independent variables and hold the software objects constant. Â© 2015 IEEE."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(3, 'paper_3', '"A first systematic mapping study on combinatorial interaction testing for software product lines"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84934343294&partnerID=40&md5=ec6b20b311c1f97790d067319331ba4d', NULL, '<b>Authors:</b><br/>"Lopez-Herrejon R.E., Fischer S., Ramler R., Egyed A." <br/><b>Key words:</b><br/>', '"Software Product Lines (SPLs) are families of related software systems distinguished by the set of features each one provides. Over the past decades SPLs have been the subject of extensive research and application both in academia and industry. SPLs practices have proven benefits such as better product customization and reduced time to market. Testing SPLs pose additional challenges stemming from the typically large number of product variants which make it infeasible to test every single one of them. In recent years, there has been an extensive research on applying Combinatorial Interaction Testing (CIT) for SPL testing. In this paper we present the first systematic mapping study on this subject. Our research questions aim to gather information regarding the techniques that have been applied, the nature of the case studies used for their evaluation, and what phases of CIT have been addressed. Our goal is to identify common trends, gaps, and opportunities for further research and application. Â© 2015 IEEE.,"', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(4, 'paper_4', '"A systematic literature review of literature reviews in software testing"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84987968030&partnerID=40&md5=39f3eeecc191a79349289ea4d0d321f6', NULL, '<b>Authors:</b><br/>"Garousi V., MÃ¤ntylÃ¤ M.V." <br/><b>Key words:</b><br/>"Secondary studies, Software testing, Surveys, Systematic literature reviews, Systematic mapping, Tertiary study"', '"Context Any newcomer or industrial practitioner is likely to experience difficulties in digesting large volumes of knowledge in software testing. In an ideal world, all knowledge used in industry, education and research should be based on high-quality evidence. Since no decision should be made based on a single study, secondary studies become essential in presenting the evidence. According to our search, over 101 secondary studies have been published in the area of software testing since 1994. With this high number of secondary studies, it is important to conduct a review in this area to provide an overview of the research landscape in this area. Objective The goal of this study is to systematically map (classify) the secondary studies in software testing. We propose that tertiary studies can serve as summarizing indexes which facilitate finding the most relevant information from secondary studies and thus supporting evidence-based decision making in any given area of software engineering. Our research questions (RQs) investigate: (1) Software-testing-specific areas, (2) Types of RQs investigated, (3) Numbers and Trends, and (4) Citations of the secondary studies. Method To conduct the tertiary study, we use the systematic-mapping approach. Additionally, we contrast the testing topics to the number of Google hits to address a general popularity of a testing topic and study the most popular papers in terms of citations. We furthermore demonstrate the practicality and usefulness of our results by mapping them to ISTQB foundation syllabus and to SWEBOK to provide implications for practitioners, testing educators, and researchers. Results After a systematic search and voting process, our study pool included 101 secondary studies in the area of software testing between 1994 and 2015. Among our results are the following: (1) In terms of number of secondary studies, model-based approach is the most popular testing method, web services are the most popular system under test (SUT), while regression testing is the most popular testing phase, (2) The quality of secondary studies, as measured by a criteria set established in the community, is slowly increasing as the years go by, and (3) Analysis of research questions, raised and studied in the pool of secondary studies, showed that there is a lack of causality and relationship type of research questions, a situation which needs to be improved if we, as a community, want to advance as a scientific field. (4) Among secondary studies, we found that regular surveys receive significantly more citations than SMs (pÂ =Â 0.009) and SLRs (pÂ =Â 0.014). Conclusion Despite the large number of secondary studies, we found that many important areas of software testing currently lack secondary studies, e.g., test management, role of product risk in testing, human factors in software testing, beta-testing (A/B-testing), exploratory testing, testability, test stopping criteria, and test-environment development. Having secondary studies in those areas is important for satisfying industrial and educational needs in software testing. On the other hand, education material of ISTQB foundation syllabus and SWEBOK could benefit from the inclusion of the latest research topics, namely search-based testing, use of cloud-computing for testing and symbolic execution. Â© 2016 Elsevier B.V."', NULL, 'In conflict', 'Waiting', 0, '1_1489085284', 1),
(5, 'paper_5', '"A systematic mapping of data generation for integration software testing"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988345153&partnerID=40&md5=f10417d2aad10c1c762d0ff6ba8926ac', NULL, '<b>Authors:</b><br/>"Brito M.A.S., Santos M.P., Souza S.R.S., Souza P.S.L." <br/><b>Key words:</b><br/>', '"Different techniques have been proposed to test software artifacts and source code. Integration testing, however, has not been sufficiently applied to all types of systems that require high-quality evaluation. This paper summarizes approaches proposed to test data generation for integration testing identifying gaps and opportunities for further research. We conducted a systematic mapping study in order to discover how data generation for integration testing is supported by existing approaches. A subjective evaluation of the studies was also carried out to evaluate them in terms of quality. As a result of the systematic mapping we found 38 primary studies, published between 1996 and 2015. Most of them focus on specification-based coverage, and to a lesser extent, code coverage. The following trends were identified: increased use of UML models and concern regarding automated test data generation. Gaps were found in the use of gray-box approaches, mutation testing, data generation tools, and experimental validation studies. The study''s findings enable researchers to attain an overview of existing approaches and identify points that require further attention. Future research work should look at cost and effectiveness of such approaches.,"', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(6, 'paper_6', '"A systematic mapping study of software product lines testing"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-79952451558&partnerID=40&md5=a966054f3f281e0f2e4234c8bea7f399', NULL, '<b>Authors:</b><br/>"Da Mota Silveira Neto P.A., Carmo MacHado I.D., McGregor J.D., De Almeida E.S., De Lemos Meira S.R." <br/><b>Key words:</b><br/>"Mapping study, Software product lines, Software testing"', '"Context: In software development, Testing is an important mechanism both to identify defects and assure that completed products work as specified. This is a common practice in single-system development, and continues to hold in Software Product Lines (SPL). Even though extensive research has been done in the SPL Testing field, it is necessary to assess the current state of research and practice, in order to provide practitioners with evidence that enable fostering its further development. Objective: This paper focuses on Testing in SPL and has the following goals: investigate state-of-the-art testing practices, synthesize available evidence, and identify gaps between required techniques and existing approaches, available in the literature. Method: A systematic mapping study was conducted with a set of nine research questions, in which 120 studies, dated from 1993 to 2009, were evaluated. Results: Although several aspects regarding testing have been covered by single-system development approaches, many cannot be directly applied in the SPL context due to specific issues. In addition, particular aspects regarding SPL are not covered by the existing SPL approaches, and when the aspects are covered, the literature just gives brief overviews. This scenario indicates that additional investigation, empirical and practical, should be performed. Conclusion: The results can help to understand the needs in SPL Testing, by identifying points that still require additional investigation, since important aspects regarding particular points of software product lines have not been addressed yet. Â© 2010 Elsevier B.V. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(7, 'paper_7', '"A systematic mapping study on non-functional search-based software testing"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-79952453274&partnerID=40&md5=0d3653455ce936d871b57b8f516b2988', NULL, '<b>Authors:</b><br/>"Afzal W., Torkar R., Feldt R." <br/><b>Key words:</b><br/>', '"Automated software test generation has been applied across the spectrum of test case design methods, this includes white-box (structural), black-box (functional), grey-box (combination of structural and functional) and non-functional testing. In this paper, we undertake a systematic mapping study to present a broad review of primary studies on the application of search-based optimization techniques to non-functional testing. The motivation is to identify the evidence available on the topic and to identify gaps in the application of search-based optimization techniques to different types of non-functional testing. The study is based on a comprehensive set of 35 papers obtained after using a multi-stage selection criteria and are published in workshops, conferences and journals in the time span 1996-2007. We conclude that the search-based software testing community needs to do more and broader studies on non-functional search-based software testing (NFSBST) and the results from our systematic map can help direct such efforts.,"', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(8, 'paper_8', '"A systematic mapping study on software engineering testbeds"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84858737751&partnerID=40&md5=ea351c7fbb76a17afc002da9e7fa4d10', NULL, '<b>Authors:</b><br/>"Barreiros E., Almeida A., Saraiva J., Soares S." <br/><b>Key words:</b><br/>"Empirical software engineering, Technology evaluation, Technology transfer, Testbeds"', '"Even though empirical research has grown in interest, techniques, methodologies and best practices are still in debate. In this context, testbeds are effective when one needs to evaluate and compare technologies. The concept is well disseminated in other areas such as Computer Networks, but remains poorly explored in Software Engineering (SE). This paper presents a systematic mapping study on the SE testbeds literature. From the initial set of 4239 studies, 13 primary studies were selected and categorized. Based on that, we found that Software Architecture is the most investigated topic, controlled experiment is the most used method to evaluate such testbeds, 20 benefits of using testbeds in SE have been identified and that testbeds comprise very heterogeneous structural elements. Â© 2011 IEEE."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(9, 'paper_9', '"Alignment of requirements specification and testing: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-80051659665&partnerID=40&md5=946d9ca5308f2b04884f4276b6c2a12e', NULL, '<b>Authors:</b><br/>"Barmi Z.A., Ebrahimi A.H., Feldt R." <br/><b>Key words:</b><br/>', '"Requirements should specify expectations on a software system and testing should ensure these expectations are met. Thus, to enable high product quality and efficient development it is crucial that requirements and testing activities and information are aligned. A lot of research has been done in the respective fields Requirements Engineering and Testing but there is a lack of summaries of the current state of the art on how to link the two. This study presents a systematic mapping of the alignment of specification and testing of functional or nonfunctional requirements in order to identify useful approaches and needs for future research. In particular we focus on results relevant for nonfunctional requirements but since only a few studies was found on alignment in total we also cover the ones on functional requirements. The map summarizes the 35 relevant papers found and discuss them within six major sub categories with model-based testing and traceability being the ones with most prior results. Â© 2011 IEEE.,"', NULL, 'In conflict', 'Waiting', 0, '1_1489085284', 1),
(10, 'paper_10', '"Analyzing an automotive testing process with evidence-based software engineering"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877922741&partnerID=40&md5=b6dc2fcdca02a51db47c5925cfbaaa66', NULL, '<b>Authors:</b><br/>"Kasoju A., Petersen K., MÃ¤ntylÃ¤ M.V." <br/><b>Key words:</b><br/>"Automotive software testing, Evidence-based software engineering, Process assessment"', '"Context: Evidence-based software engineering (EBSE) provides a process for solving practical problems based on a rigorous research approach. The primary focus so far was on mapping and aggregating evidence through systematic reviews. Objectives: We extend existing work on evidence-based software engineering by using the EBSE process in an industrial case to help an organization to improve its automotive testing process. With this we contribute in (1) providing experiences on using evidence based processes to analyze a real world automotive test process and (2) provide evidence of challenges and related solutions for automotive software testing processes. Methods: In this study we perform an in-depth investigation of an automotive test process using an extended EBSE process including case study research (gain an understanding of practical questions to define a research scope), systematic literature review (identify solutions through systematic literature), and value stream mapping (map out an improved automotive test process based on the current situation and improvement suggestions identified). These are followed by reflections on the EBSE process used. Results: In the first step of the EBSE process we identified 10 challenge areas with a total of 26 individual challenges. For 15 out of those 26 challenges our domain specific systematic literature review identified solutions. Based on the input from the challenges and the solutions, we created a value stream map of the current and future process. Conclusions: Overall, we found that the evidence-based process as presented in this study helps in technology transfer of research results to industry, but at the same time some challenges lie ahead (e.g. scoping systematic reviews to focus more on concrete industry problems, and understanding strategies of conducting EBSE with respect to effort and quality of the evidence). Â© 2013 Elsevier B.V. All rights reserved."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(11, 'paper_11', '"Challenges and opportunities for software change request repositories: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84904626790&partnerID=40&md5=7e8fe6e32dba1cdb6f3f9a3e39b3fed1', NULL, '<b>Authors:</b><br/>"Cavalcanti Y.C., Da Mota Silveira Neto P.A., Machado I.D.C., Vale T.F., De Almeida E.S., Meira S.R.D.L." <br/><b>Key words:</b><br/>"bug report, bug tracking, change request repository, software evolution, software maintenance, software quality assurance"', '"Software maintenance starts as soon as the first artifacts are delivered and is essential for the success of the software. However, keeping maintenance activities and their related artifacts on track comes at a high cost. In this respect, change request (CR) repositories are fundamental in software maintenance. They facilitate the management of CRs and are also the central point to coordinate activities and communication among stakeholders. However, the benefits of CR repositories do not come without issues, and commonly occurring ones should be dealt with, such as the following: duplicate CRs, the large number of CRs to assign, or poorly described CRs. Such issues have led researchers to an increased interest in investigating CR repositories, by considering different aspects of software development and CR management. In this paper, we performed a systematic mapping study to characterize this research field. We analyzed 142 studies, which we classified in two ways. First, we classified the studies into different topics and grouped them into two dimensions: challenges and opportunities. Second, the challenge topics were classified in accordance with an existing taxonomy for information retrieval models. In addition, we investigated tools and services for CR management, to understand whether and how they addressed the topics identified. Copyright Â© 2013 John Wiley & Sons, Ltd. Change request repositories are fundamental for software maintenance. However, their benefits do not come without issues. We analyzed 142 studies to characterize the research on these issues and provide directions for future investigation. The studies were classified into topics and grouped into two dimensions: challenges and opportunities. Then, the challenges were classified in accordance with an existing taxonomy for information retrieval models. Additionally, we investigated different change request repositories to understand whether and how they addressed the topics identified. Copyright Â© 2013 John Wiley & Sons, Ltd."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(12, 'paper_12', '"Change impact in product lines: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988892509&partnerID=40&md5=e13d8fd1207f2f064c58fb7a85a09838', NULL, '<b>Authors:</b><br/>"Brink C., Heisig P., Wackermann F." <br/><b>Key words:</b><br/>"Change impact analysis, Embedded systems, Hardware/Software, Product family, Product line, Systematic mapping study"', '"A product line (PL) supports and simplifies the development process of (software) systems by reusing assets. As systems are subjected to frequent alterations, the implementation of this changes can be a complex and error-prone task. For this reason a change impact analysis (CIA) systematically identifies locations that are affected by a change. While both approaches (PL and CIA) per se are often discussed in literature, the combination of them is still a challenge. This paper gives a comprehensive overview of literature, which addresses the integration of PL and CIA concepts. Furthermore, we classify our results to outline both, the current research stage as well as gaps. Therefore, we conducted a systematic mapping study incorporating 165 papers. While most of the papers have their background within Software Product Lines (SPLs) (44.2%) or PLs (5.5%), CIA in the combination with Multi Product Lines (2.4%) or Product Families (PFs) (1.8%) is sparsely addressed in literature. The results show that CIA for SPLs has been partially addressed yet, whereas the consideration of different disciplines (PFs) is insufficiently covered. Â© Springer International Publishing Switzerland 2016."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(13, 'paper_13', '"Characteristics, attributes, metrics and usability recommendations: A systematic mapping"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84966602566&partnerID=40&md5=7b11e8b0f75c1d4766c99f68b59e8772', NULL, '<b>Authors:</b><br/>"Nissola F., Benitti F.B.V." <br/><b>Key words:</b><br/>"Systematic Mapping, Usability Evaluation"', '"The research scenario concerned about software usability addresses a wide range of characteristics, attributes and evaluation models. As result, we can observe the evaluators difficult in order to select the characteristics that best apply to the product that is being evaluated. By this way, this paper presents a systematic mapping in order to identify the main characteristics of usability evaluation related to web, desktop and mobile devices environments. As results, we selected 31 papers in order to perform data extraction and way possible to produce a list of 28 evaluation characteristics. Copyright Â© IARIA, 2014."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(14, 'paper_14', '"Concurrent software testing in practice: A catalog of tools"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84960350804&partnerID=40&md5=5490f6be1c5b623eff6d7593c770b4cd', NULL, '<b>Authors:</b><br/>"Melo S.M., Souza S.R.S., Silva R.A., Souza P.S.L." <br/><b>Key words:</b><br/>"Concurrent programs, Systematic mapping, Testing tools"', '"The testing of concurrent programs is very complex due to the non-determinism present in those programs. They must be subjected to a systematic testing process that assists in the identification of defects and guarantees quality. Although testing tools have been proposed to support the concurrent program testing, to the best of our knowledge, no study that concentrates all testing tools to be used as a catalog for testers is available in the literature. This paper proposes a new classification for a set of testing tools for concurrent programs, regarding attributes, such as testing technique supported, programming language, and paradigm of development. The purpose is to provide a useful categorization guide that helps testing practitioners and researchers in the selection of testing tools for concurrent programs. A systematic mapping was conducted so that studies on testing tools for concurrent programs could be identified. As a main result, we provide a catalog with 116 testing tools appropriately selected and classified, among which the following techniques were identifies with higher support were Java and C/C++. Although a large number of tools have been categoirzed, most of them are academic and only few are available on a commercial scale. The classification proposed here can contribute to the state-of-the-art of testing tools for concurrent programs and also provides information for the exchange of knowledge between academy and industry. Â© 2015 ACM."', NULL, 'Excluded', 'Waiting', 0, '1_1489085284', 1),
(15, 'paper_15', '"Cost, benefits and quality of software development documentation: A systematic mapping"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84912534729&partnerID=40&md5=5a2b8c80ac6e71817e1fa2ffb79f59fc', NULL, '<b>Authors:</b><br/>"Zhi J., Garousi-Yusifo?lu V., Sun B., Garousi G., Shahnewaz S., Ruhe G." <br/><b>Key words:</b><br/>"Documentation benefit, Software documentation, Systematic mapping"', '"Context: Software documentation is an integral part of any software development process. Researchers and practitioners have expressed concerns about costs, benefits and quality of software documentation in practice. On the one hand, there is a lack of a comprehensive model to evaluate the quality of documentation. On the other hand, researchers and practitioners need to assess whether documentation cost outweighs its benefit. Objectives: In this study, we aim to summarize the existing literature and provide an overview of the field of software documentation cost, benefit and quality. Method: We use the systematic-mapping methodology to map the existing body of knowledge related to software documentation cost, benefit and quality. To achieve our objectives, 11 Research Questions (RQ) are raised. The primary papers are carefully selected. After applying the inclusion and exclusion criteria, our study pool included a set of 69 papers from 1971 to 2011. A systematic map is developed and refined iteratively. Results: We present the results of a systematic mapping covering different research aspects related to software documentation cost, benefit and quality (RQ 1-11). Key findings include: (1) validation research papers are dominating (27 papers), followed by solution proposals (21 papers). (2) Most papers (61 out of 69) do not mention the development life-cycle model explicitly. Agile development is only mentioned in 6 papers. (3) Most papers include only one System under Study (SUS) which is mostly academic prototype. The average number of participants in survey-based papers is 106, the highest one having approximately 1000 participants. (4) In terms of focus of papers, 50 papers focused on documentation quality, followed by 37 papers on benefit, and 12 papers on documentation cost. (5) The quality attributes of documentation that appear in most papers are, in order: completeness, consistency and accessibility. Additionally, improved meta-models for documentation cost, benefit and quality are also presented. Furthermore, we have created an online paper repository of the primary papers analyzed and mapped during this study. Conclusion: Our study results show that this research area is emerging but far from mature. Firstly, documentation cost aspect seems to have been neglected in the existing literature and there are no systematic methods or models to measure cost. Also, despite a substantial number of solutions proposed during the last 40 years, more and stronger empirical evidences are still needed to enhance our understanding of this area. In particular, what we expect includes (1) more validation or evaluation studies, (2) studies involving large-scale development projects, or from large number of study participants of various organizations, (3) more industry-academia collaborations, (4) more estimation models or methods to assess documentation quality, benefit and, especially, cost. Â© 2014 Elsevier Inc. All rights reserved."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(16, 'paper_16', '"Empirical studies concerning the maintenance of UML diagrams and their use in the maintenance of code: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877909370&partnerID=40&md5=b548f09fd4efa3d1319209f1db1125a6', NULL, '<b>Authors:</b><br/>"FernÃ¡ndez-SÃ¡ez A.M., Genero M., Chaudron M.R.V." <br/><b>Key words:</b><br/>"Empirical studies, Software maintenance, Systematic literature review, Systematic mapping study, UML"', '"Context: The Unified Modelling Language (UML) has, after ten years, become established as the de facto standard for the modelling of object-oriented software systems. It is therefore relevant to investigate whether its use is important as regards the costs involved in its implantation in industry being worthwhile. Method: We have carried out a systematic mapping study to collect the empirical studies published in order to discover What is the current existing empirical evidence with regard to the use of UML diagrams in source code maintenance and the maintenance of the UML diagrams themselves? Results: We found 38 papers, which contained 63 experiments and 3 case studies. Conclusion: Although there is common belief that the use of UML is beneficial for source code maintenance, since the quality of the modifications is greater when UML diagrams are available, only 3 papers concerning this issue have been published. Most research (60 empirical studies) concerns the maintainability and comprehensibility of the UML diagrams themselves which form part of the system''s documentation, since it is assumed that they may influence source code maintainability, although this has not been empirically validated. Moreover, the generalizability of the majority of the experiments is questionable given the material, tasks and subjects used. There is thus a need for more experiments and case studies to be performed in industrial contexts, i.e., with real systems and using maintenance tasks conducted by practitioners under real conditions that truly show the utility of UML diagrams in maintaining code, and that the fact that a diagram is more comprehensible or modifiable influences the maintainability of the code itself. This utility should also be studied from the viewpoint of cost and productivity, and the consistent and simultaneous maintenance of diagrams and code must also be considered in future empirical studies. Â© 2013 Elsevier B.V. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(17, 'paper_17', '"Evaluating software product quality: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84924054129&partnerID=40&md5=19c52fa109db72d3bcb6b46d8b326ee1', NULL, '<b>Authors:</b><br/>"Ouhbi S., Idri A., Aleman J.L.F., Toval A." <br/><b>Key words:</b><br/>', '"Evaluating software product quality (SPQ) is an important task to ensure the quality of software products. In this paper a systematic mapping study was performed to summarize the existing SPQ evaluation (SPQE) approaches in literature and to classify the selected studies according to seven classification criteria: SPQE approaches, research types, empirical types, data sets used in the empirical evaluation of these studies, artifacts, SQ models, and SQ characteristics. Publication channels and trends were also identified. 57 papers were selected. The results show that the main publication sources of the papers identified were journals. Data mining techniques are the most frequently approaches reported in literature. Solution proposals were the main research type identified. The majority of the selected papers were history-based evaluations using existing data, which were mainly obtained from open source software projects and domain specific projects. Source code was the main artifacts used by SPQE approaches. Well-known SQ models were mentioned by half of the selected papers and reliability is the SQ characteristic through which SPQE was mainly achieved. SPQE-related subjects seem to attract more interest from researchers since the past years. Â© 2014 IEEE.,"', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(18, 'paper_18', '"Feature location for software product line migration: A mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907833307&partnerID=40&md5=48b514819a4aba2c01c7cea8bb911254', NULL, '<b>Authors:</b><br/>"AssunÃ§Ã£o W.K.G., Vergilio S.R." <br/><b>Key words:</b><br/>"Evolution, Reengineering, Reuse, Software product line"', '"Developing software from scratch is a high cost and errorprone activity. A possible solution to reduce time-to-market and produce high quality software is the reuse of existing software. But when the number of features in the system grows, the maintenance becomes more complex. In such cases, to adopt a systematic approach, such as Software Product Line Engineering, is necessary. Existing systems are generally migrated to a product line, allowing systematic reuse of artefacts and easing maintenance. To this end, some approaches have been proposed in the literature in the last years. A mapping of works on this subject and the identification of some research gaps can lead to an improvement of such approaches. This paper describes the main outcomes of a systematic mapping study on the evolution and migration of systems to SPL. The main works found are presented and classified according to adopted strategy, artefacts used, and evaluation conducted. Analysis of the evolution along the past years are also presented. At the end, we summarize some trends and open issues to serve as reference to new researches. Copyright 2014 ACM."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(19, 'paper_19', '"Graphical user interface (GUI) testing: Systematic mapping and repository"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84880786120&partnerID=40&md5=6a4843e704cb6d905ce9da59d7d402ad', NULL, '<b>Authors:</b><br/>"Banerjee I., Nguyen B., Garousi V., Memon A." <br/><b>Key words:</b><br/>"Bibliometrics, GUI application, Paper repository, Systematic mapping, Testing"', '"Context GUI testing is system testing of a software that has a graphical-user interface (GUI) front-end. Because system testing entails that the entire software system, including the user interface, be tested as a whole, during GUI testing, test cases - modeled as sequences of user input events - are developed and executed on the software by exercising the GUI''s widgets (e.g., text boxes and clickable buttons). More than 230 articles have appeared in the area of GUI testing since 1991. Objective In this paper, we study this existing body of knowledge using a systematic mapping (SM). Method The SM is conducted using the guidelines proposed by Petersen et al. We pose three sets of research questions. We define selection and exclusion criteria. From the initial pool of 230 articles, published in years 1991-2011, our final pool consisted of 136 articles. We systematically develop a classification scheme and map the selected articles to this scheme. Results We present two types of results. First, we report the demographics and bibliometrics trends in this domain, including: top-cited articles, active researchers, top venues, and active countries in this research area. Moreover, we derive the trends, for instance, in terms of types of articles, sources of information to derive test cases, types of evaluations used in articles, etc. Our second major result is a publicly-accessible repository that contains all our mapping data. We plan to update this repository on a regular basis, making it a live resource for all researchers. Conclusion Our SM provides an overview of existing GUI testing approaches and helps spot areas in the field that require more attention from the research community. For example, much work is needed to connect academic model-based techniques with commercially available tools. To this end, studies are needed to compare the state-of-the-art in GUI testing in academic techniques and industrial tools. Â© 2013 Elsevier B.V. All rights reserved."', NULL, 'Excluded', 'Waiting', 0, '1_1489085284', 1),
(20, 'paper_20', '"ISBSG variables most frequently used for software effort estimation: A mapping review"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907808906&partnerID=40&md5=cf63a03ed883a32324a27bd726f9a00e', NULL, '<b>Authors:</b><br/>"Gonzalez-Ladron-De-Guevara F., FernÃ¡ndez-Diego M." <br/><b>Key words:</b><br/>"ISBSG, missing values, software effort estimation, software engineering, systematic mapping study"', '"Background: The International Software Benchmarking Standards Group (ISBSG) dataset makes it possible to estimate a project''s size, effort, duration, and cost. Aim: The aim was to analyze the ISBSG variables that have been used by researchers for software effort estimation from 2000, when the first papers were published, until the end of 2013. Method: A systematic mapping review was applied to over 167 papers obtained after the filtering process. From these, it was found that 133 papers produce effort estimation and only 107 list the independent variables used in the effort estimation models. Results: Seventy-one out of 118 ISBSG variables have been used at least once. There is a group of 20 variables that appear in more than 50% of the papers and include Functional Size (62%), Development Type (58%), Language Type (53%), and Development Platform (52%) following ISBSG recommendations. Sizing and Size attributes altogether represent the most relevant group along with Project attributes that includes 24 technical features of the project and the development platform. All in all, variables that have more missing values are used less frequently. Conclusions: This work presents a snapshot of the existing usage of ISBSG variables in software development estimation. Moreover, some insights are provided to guide future studies. Â© 2014 ACM."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(21, 'paper_21', '"Knowledge management applied to software testing: A systematic mapping"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84922663129&partnerID=40&md5=f38645ba853196e34678283ee883a71e', NULL, '<b>Authors:</b><br/>"Souza E.F., Falbo R.A., Vijaykumar N.L." <br/><b>Key words:</b><br/>"Knowledge management, Software testing, Systematic mapping"', '"With the growth of data from several different sources of knowledge within an organization, it becomes necessary to provide computerized support for tasks of acquiring, processing, analyzing and disseminating knowledge. In the software process, testing is a critical factor for product quality, and thus there is an increasing concern in how to improve the accomplishment of this task. In software testing, finding relevant knowledge to reuse can be a difficult and complex task, due to the lack of a strategy to represent or to associate semantics to a large volume of test data, including test cases, testing techniques to be applied and so on. This paper aims to investigate, through a Systematic Mapping of the Literature, some aspects associated with applying Knowledge Management to Software Testing. Copyright Â© 2013 by Knowledge Systems Institute Graduate School."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(22, 'paper_22', '"Predicting software product quality: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84943600627&partnerID=40&md5=27f0050c8409ce3cf88e684e2a45a4b4', NULL, '<b>Authors:</b><br/>"Ouhbi S., Idri A., Fer?andez-AlemÃ¡n J.L., Toval A." <br/><b>Key words:</b><br/>"Prediction, Software product quality, Systematic mapping study"', '"Predicting software product quality (SPQ) is becoming a permanent concern during software life cycle phases. In this paper, a systematic mapping study was performed to summarize the existing SPQ prediction (SPQP) approaches in literature and to organize the selected studies according to seven classification criteria: SPQP approaches, research types, empirical types, data sets used in the empirical evaluation of these studies, artifacts, SQ models, and SQ characteristics. Publication channels and trends were also identified. After identifying 182 documents in ACM Digital Library, IEEE Xplore, ScienceDirect, SpringerLink, and Google scholar, 69 papers were selected. The results show that the main publication source of the papers identified was conference. Data mining techniques are the most frequently SPQP approaches reported in literature. Solution proposal was the main research type identified. The majority of the papers selected were history-based evaluations using existing data which were mainly obtained from open source software projects and domain specific projects. Source code was the main artifact concerned with SPQP approaches. Well-known SQ models were hardly mentioned and reliability is the SQ characteristic through which SPQP was mainly achieved. SPQP-related subject seems to need more investigation from researchers and practitioners. Moreover, SQ models and standards need to be considered more in future SPQP research."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(23, 'paper_23', '"Reducing test effort: A systematic mapping study on existing approaches"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84863453536&partnerID=40&md5=2d892e6bc6835d86cc6e6c508857db8f', NULL, '<b>Authors:</b><br/>"Elberzhager F., Rosbach A., MÃ¼nch J., Eschbach R." <br/><b>Key words:</b><br/>"Efficiency improvement, Mapping study, Quality assurance, Software testing, Test effort reduction"', '"Context: Quality assurance effort, especially testing effort, is often a major cost factor during software development, which sometimes consumes more than 50% of the overall development effort. Consequently, one major goal is often to reduce testing effort. Objective: The main goal of the systematic mapping study is the identification of existing approaches that are able to reduce testing effort. Therefore, an overview should be presented both for researchers and practitioners in order to identify, on the one hand, future research directions and, on the other hand, potential for improvements in practical environments. Method: Two researchers performed a systematic mapping study, focusing on four databases with an initial result set of 4020 articles. Results: In total, we selected and categorized 144 articles. Five different areas were identified that exploit different ways to reduce testing effort: approaches that predict defect-prone parts or defect content, automation, test input reduction approaches, quality assurance techniques applied before testing, and test strategy approaches. Conclusion: The results reflect an increased interest in this topic in recent years. A lot of different approaches have been developed, refined, and evaluated in different environments. The highest attention was found with respect to automation and prediction approaches. In addition, some input reduction approaches were found. However, in terms of combining early quality assurance activities with testing to reduce test effort, only a small number of approaches were found. Due to the continuous challenge of reducing test effort, future research in this area is expected. Â© 2012 Elsevier B.V. All rights reserved."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(24, 'paper_24', '"Risk management in software product line engineering: A mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84881014807&partnerID=40&md5=83fe16cebf1cd3ccebfb7b597fcd2cae', NULL, '<b>Authors:</b><br/>"Lobato L.L., Bittar T.J., Neto P.A.D.M.S., MacHado I.D.C., De Almeida E.S., Meira S.R.D.L." <br/><b>Key words:</b><br/>"Mapping study, Risk management, Software product lines"', '"Software Product Line (SPL) Engineering focuses on systematic software reuse, which has benefits such as reductions in time-to-market and effort, and improvements in the quality of products. However, establishing a SPL is not a simple matter, and can affect all aspects of the organization, since the approach is complex and involves major investment and considerable risk. These risks can have a negative impact on the expected ROI for an organization, if SPL is not sufficiently managed. This paper presents a mapping study of Risk Management (RM) in SPL Engineering. We analyzed a set of thirty studies in the field. The results points out the need for risk management practices in SPL, due to the little research on RM practices in SPL and the importance of identifying insight on RM in SPL. Most studies simply mention the importance of RM, however the steps for managing risk are not clearly specified. Our findings suggest that greater attention should be given, through the use of industrial case studies and experiments, to improve SPL productivity and ensure its success. This research is a first attempt within the SPL community to identify, classify, and manage risks, and establish mitigation strategies. Â© 2013 World Scientific Publishing Company."', NULL, 'Excluded', 'Waiting', 0, '1_1489085284', 1),
(25, 'paper_25', '"Software fault prediction: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84936110818&partnerID=40&md5=f18253acbe762249e0a5803739257b51', NULL, '<b>Authors:</b><br/>"Murillo-Morera J., Quesada-LÃ³pez C., Jenkins M." <br/><b>Key words:</b><br/>"Fault prediction models, Software metrics, Software quality"', '"Context: Software fault prediction has been an important research topic in the software engineering field for more than 30 years. Software defect prediction models are commonly used to detect faulty software modules based on software metrics collected during the software development process. Objective: Data mining techniques and machine learning studies in the fault prediction software context are mapped and characterized. We investigated the metrics and techniques and their performance according to performance metrics studied. An analysis and synthesis of these studies is conducted. Method: A systematic mapping study has been conducted for identifying and aggregating evidence about software fault prediction. Results: About 70 studies published from January 2002 to December 2014 were identified. Top 40 studies were selected for analysis, based on the quality criteria results. The main metrics used were: Halstead, McCabe and LOC (67.14%), Halstead, McCabe and LOC + Object-Oriented (15.71%), others (17.14%). The main models were: Machine Learning(ML) (47.14%), ML + Statistical Analysis (31.42%), others (21.41%). The data sets used were: private access (35%) and public access (65%). The most frequent combination of metrics, models and techniques were: Halstead, McCabe and LOC + Random Forest, Naive Bayes, Logistic Regression and Decision Tree representing the (60%) of the analyzed studies. Conclusions: This article has identified and classified the performance of the metrics, techniques and their combinations. This will help researchers to select datasets, metrics and models based on experimental results, with the objective to generate learning schemes that allow a better prediction software failures. Copyright Â© 2015 by the authors."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1);
INSERT INTO `paper` (`id`, `bibtexKey`, `title`, `doi`, `venueId`, `bibtex`, `preview`, `abstract`, `screening_status`, `classification_status`, `paper_excluded`, `operation_code`, `paper_active`) VALUES
(26, 'paper_26', '"Software product line testing - A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-78049529957&partnerID=40&md5=d0c91740e3fa70679e4560d266a06d48', NULL, '<b>Authors:</b><br/>"EngstrÃ¶m E., Runeson P." <br/><b>Key words:</b><br/>"Software product line testing, Systematic literature review, Systematic mapping, Testing"', '"Context: Software product lines (SPL) are used in industry to achieve more efficient software development. However, the testing side of SPL is underdeveloped. Objective: This study aims at surveying existing research on SPL testing in order to identify useful approaches and needs for future research. Method: A systematic mapping study is launched to find as much literature as possible, and the 64 papers found are classified with respect to focus, research type and contribution type. Results: A majority of the papers are of proposal research types (64%). System testing is the largest group with respect to research focus (40%), followed by management (23%). Method contributions are in majority. Conclusions: More validation and evaluation research is needed to provide a better foundation for SPL testing. Â© 2010 Elsevier B.V. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(27, 'paper_27', '"Software quality requirements: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84933501221&partnerID=40&md5=16c9a1d2da950000184c6347a78c4f83', NULL, '<b>Authors:</b><br/>"Ouhbi S., Idri A., FernÃ¡ndez-AlemÃ¡n J.L., Toval A." <br/><b>Key words:</b><br/>"Requirement engineering, Software quality requirements, Systematic mapping study"', '"Software quality requirements (SQR) play a central role in software quality (SQ) success. The importance of mastering SQR can be seen as obvious, however, when it comes to customer satisfaction, end-users are often dissatisfied with SQ. In this paper, a systematic mapping study aims to summarize SQR research by answering nine mapping questions. In total, 51 articles were selected and classified according to multiple criteria: publication source, publication year, research type, research approach, contribution type of SQR literature, requirements engineering activity, well-known SQ model, software artifact and SQR type. The results show an increased interest in SQR research in recent years and reveal that conferences are the main SQR publication target. Most SQR research has used case studies. The dominant contribution type of SQR research is method while specification is the main requirements engineering activity identified. SQ models need to be more used for SQR identification. Design module and requirements documentation are the principal artifacts reported in SQR literature. External and internal SQR were the main SQR types addressed in literature. Identifying empirical solutions to address SQR is a promising research direction for researchers. Â© 2013 IEEE."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(28, 'paper_28', '"Software test-code engineering: A systematic mapping"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84914181487&partnerID=40&md5=c284c62c41ba472eab9a053ccbd08710', NULL, '<b>Authors:</b><br/>"Garousi Yusifo?lu V., Amannejad Y., Betin Can A." <br/><b>Key words:</b><br/>"Development of test code, Quality assessment of test code, Software test-code engineering, Study repository, Survey, Systematic mapping"', '"Context: As a result of automated software testing, large amounts of software test code (script) are usually developed by software teams. Automated test scripts provide many benefits, such as repeatable, predictable, and efficient test executions. However, just like any software development activity, development of test scripts is tedious and error prone. We refer, in this study, to all activities that should be conducted during the entire lifecycle of test-code as Software Test-Code Engineering (STCE). Objective: As the STCE research area has matured and the number of related studies has increased, it is important to systematically categorize the current state-of-the-art and to provide an overview of the trends in this field. Such summarized and categorized results provide many benefits to the broader community. For example, they are valuable resources for new researchers (e.g., PhD students) aiming to conduct additional secondary studies. Method: In this work, we systematically classify the body of knowledge related to STCE through a systematic mapping (SM) study. As part of this study, we pose a set of research questions, define selection and exclusion criteria, and systematically develop and refine a systematic map. Results: Our study pool includes a set of 60 studies published in the area of STCE between 1999 and 2012. Our mapping data is available through an online publicly-accessible repository. We derive the trends for various aspects of STCE. Among our results are the following: (1) There is an acceptable mix of papers with respect to different contribution facets in the field of STCE and the top two leading facets are tool (68%) and method (65%). The studies that presented new processes, however, had a low rate (3%), which denotes the need for more process-related studies in this area. (2) Results of investigation about research facet of studies and comparing our result to other SM studies shows that, similar to other fields in software engineering, STCE is moving towards more rigorous validation approaches. (3) A good mixture of STCE activities has been presented in the primary studies. Among them, the two leading activities are quality assessment and co-maintenance of test-code with production code. The highest growth rate for co-maintenance activities in recent years shows the importance and challenges involved in this activity. (4) There are two main categories of quality assessment activity: detection of test smells and oracle assertion adequacy. (5) JUnit is the leading test framework which has been used in about 50% of the studies. (6) There is a good mixture of SUT types used in the studies: academic experimental systems (or simple code examples), real open-source and commercial systems. (7) Among 41 tools that are proposed for STCE, less than half of the tools (45%) were available for download. It is good to have this percentile of tools to be available, although not perfect, since the availability of tools can lead to higher impact on research community and industry. Conclusion: We discuss the emerging trends in STCE, and discuss the implications for researchers and practitioners in this area. The results of our systematic mapping can help researchers to obtain an overview of existing STCE approaches and spot areas in the field that require more attention from the research community. Â© 2014 Elsevier B.V. All rights reserved."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(29, 'paper_29', '"Strategies for consistency checking on software product lines: A mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84961159520&partnerID=40&md5=27caea57da59de999eb3c9a77aee00ed', NULL, '<b>Authors:</b><br/>"Santos A.R., De Oliveira R.P., De Almeida E.S." <br/><b>Key words:</b><br/>"Consistency checking, Literature review, Mapping study, Software product line engineering"', '"Context. Software Product Lines (SPL) has become one of the most prominents way to promote the systematic reuse of software artifacts. Like any other piece of software, with the SPL aging, it becomes necessary to manage their evolution. However, in this process, engineers might introduce divergences among the SPL artifacts. Thus, a number of initiatives address the management of such inconsistencies. Objective. In this paper, we mapped the existing approaches to inconsistency management within SPL. Method. We used the systematic mapping study methodology. Results. We classified and performed a characterization of the approaches found, which we mangaged to arrange in three main categories. Most papers selected proposed new methods as solution research. Besides, there is still a need for validation and evaluation studies. Conclusion. We identified a lack of support for a number of activities of consistency assurance. For instance, no paper addressed the tracking of findings, decisions, and actions, as well as, few papers describing either the handling or a management policy for identified inconsistencies. Copyright 2015 ACM."', NULL, 'Excluded', 'Waiting', 0, '1_1489085284', 1),
(30, 'paper_30', '"Systematic mapping study of quality attributes measurement in service oriented architecture"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84866998707&partnerID=40&md5=a7fad9b2f2d879fe0b8d347d9936099b', NULL, '<b>Authors:</b><br/>"Nik Daud N.M., Kadir W.M.N.W." <br/><b>Key words:</b><br/>"Quality attributes measurement, service oriented architecture, systematic mapping study"', '"Background: Service oriented architecture (SOA) promotes software reuse and interoperability as its niche. Developer usually expects that services being used are performing as promised. Capability to measure quality of services helps developer to predict the software behavior. Measuring quality attributes of software can be treated as a way to ensure that the developed software will/does meet expected qualities. Objectives: This study investigates the state-of-art in quality attributes measurement for service oriented architecture. It will try to answer on type of studies that have been done regarding quality attributes measurement over service oriented architecture. Method: Systematic mapping study is selected as method for this study where primary studies related to quality attributes measurement are chosen and analyzed based on research questions. Result: Based on research questions, results of this mapping study shows, performance as highly seek quality attributes in this fields, where measurement technique that mostly used is metric and finally the measurement usually done on service level. Conclusion: this study is initiated to seek for how studies on quality attributes measurement in service oriented architecture has mature during these recent years. The result shows an up and down trends regarding number of studies whilst a lot of research gap can still be covered for future researches. Â© 2012 AICIT."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(31, 'paper_31', '"Ten years of research on fault management in grid computing: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84908011115&partnerID=40&md5=2721d0954867de0184a7751167f088e8', NULL, '<b>Authors:</b><br/>"Filho P.C., Brasilino C., Duarte A." <br/><b>Key words:</b><br/>', '"BACKGROUND: There is a large body of literature on research about fault management in grid computing. Despite being a well-established research area, there are no systematic studies focusing on characterizing the sorts of research that have been conducted, identifying well-explored topics as well as opportunities for further research. OBJECTIVE: This study aims at surveying the existing research on fault management in grid computing in order to identify useful approaches and opportunities for future research. METHOD: We conducted a systematic mapping study to collect, classify and analyze the research literature on fault management in grid computing indexed by the main search engines in the field. RESULTS: Our study selected and classified 257 scientific papers and was able to answer five research questions regarding the distribution of the scientific production over the time and space. CONCLUSIONS: The majority of the selected studies focus on fault tolerance, with very few efforts towards fault prevention, prediction and removal. Â© 2013 IEEE.,"', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(32, 'paper_32', '"Testability and software performance: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84975789870&partnerID=40&md5=aa948ec1cf1aee77815cf56d0b933199', NULL, '<b>Authors:</b><br/>"Hassan M.M., Shah S.M.A., Afzal W., Andler S.F., LindstrÃ¶m B., Blom M." <br/><b>Key words:</b><br/>"Software performance, Systematic mapping study, Testability"', '"In most of the research on software testability, functional correctness of the software has been the focus while the evidence regarding testability and non-functional properties such as performance is sporadic. The objective of this study is to present the current state-of-the-art related to issues of importance, types and domains of software under test, types of research, contribution types and design evaluation methods concerning testability and software performance. We find that observability, controllability and testing effort are the main testability issues while timeliness and response time (i.e., time constraints) are the main performance issues in focus. The primary studies in the area use diverse types of software under test within different domains, with realtime systems as being a dominant domain. The researchers have proposed many different methods in the area, however these methods lack implementation in practice. Â© 2016 ACM."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(33, 'paper_33', '"The role of process in early software defect prediction: Methods, attributes and metrics"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84994005243&partnerID=40&md5=aa6f7438c816fe1687d04b9c387b2b7d', NULL, '<b>Authors:</b><br/>"Ozakinci R., Tarhan A." <br/><b>Key words:</b><br/>"Defect prediction, Early, Prediction model, Process metrics, Software defect, Software quality, Software reliability, Systematic mapping"', '"Software quality is the set of inherent characteristics that are built into a software product throughout software development process. An important indicator of software quality is the trend of software defects in the life-cycle. The models of software defect prediction and software reliability provide the opportunity for practitioners to observe the defectiveness distribution of their products in development and operation. However, reported studies are mostly focused on coding or testing stages. Though this is reasonable due to executable nature of the product, it prevents practitioners from taking the advantages (such as cost reduction) of identifying and predicting software defects earlier in the life-cycle. This paper, therefore, provides an overview of the trend of early software defect prediction studies as retrieved by a systematic mapping of the literature, and elaborates on the methods, attributes, and metrics of the studies that comprise software process data in the defect prediction. Â© Springer International Publishing Switzerland 2016."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(34, 'paper_34', '"Usable results from the field of API usability: A systematic mapping and further analysis"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84870895497&partnerID=40&md5=f9dac6e9ebcbd3d7c1d02844ae3aee4a', NULL, '<b>Authors:</b><br/>"Burns C., Ferreira J., Hellmann T.D., Maurer F." <br/><b>Key words:</b><br/>"API usability, application programming interface, meta-analysis, systematic map, systematic review"', '"Modern software development often involves the use of complex, reusable components called Application Programming Interfaces (APIs). Developers use APIs to complete tasks they could not otherwise accomplish in a reasonable time. These components are now vital to mainstream software development. But as APIs have become more important, understanding how to make them more usable is becoming a significant research question. To assess the current state of research in the field, we conducted a systematic mapping. A total of 28 papers were reviewed and categorized based on their research type and on the evaluation method employed by its authors. We extended the analysis of a subset of the papers we reviewed beyond the usual limits of a systematic map in order to more closely examine details of their evaluations - such as their structure and validity - and to summarize their recommendations. Based on these results, common problems in the field are discussed and future research directions are suggested. Â© 2012 IEEE."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(35, 'paper_35', '"Validation of software visualization tools: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84920660808&partnerID=40&md5=797cc12a015ec2d7ef9d22b3103e0bb5', NULL, '<b>Authors:</b><br/>"Seriai A., Benomar O., Cerat B., Sahraoui H." <br/><b>Key words:</b><br/>"Software visualization, Systematic mapping study, Validation techniques"', '"Software visualization as a research field focuses on the visualization of the structure, behavior, and evolution of software. It studies techniques and methods for graphically representing these different aspects of software. Interest in software visualization has grown in recent years, producing rapid advances in the diversity of research and in the scope of proposed techniques, and aiding the application experts who use these techniques to advance their own research. Despite the importance of evaluating software visualization research, there is little work studying validation methods. As a consequence, it is usually difficult producing compelling evidence about the effectiveness of software visualization contributions. The goal of this paper is to study the validation techniques performed in the software visualization literature. We conducted a systematic mapping study of validation methods in software visualization. We consider 752 articles from multiple sources, published between 2000 and 2012, and study the validation techniques of the software visualization articles. The main outcome of this study is the lack in rigor when validating software visualization tool and techniques. Although software visualization has grown in interest in the last decade, it still lacks the necessary maturity to be properly and thoroughly evaluating its claims. Most article evaluations studied in this paper are qualitative case studies, including discussions about the benefits of the proposed visualizations. The results help understand the needs in software visualization validation techniques. They identify the type of evaluations that should be performed to address this deficiency. The specific analysis of SOFTVIS series articles shows that the specialized conference suffers from the same shortage. Â© 2014 IEEE."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(36, 'paper_36', '"Vertical Test Reuse for Embedded Systems: A Systematic Mapping Study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84958235305&partnerID=40&md5=16444cc014261bf229bc5003e5f50f50', NULL, '<b>Authors:</b><br/>"Flemstrom D., Sundmark D., Afzal W." <br/><b>Key words:</b><br/>"embedded system, systematic mapping study, vertical test reuse"', '"Vertical test reuse refers to the reuse of test cases or other test artifacts over different integration levels in the software or system engineering process. Vertical test reuse has previously been proposed for reducing test effort and improving test effectiveness, particularly for embedded system development. The goal of this study is to provide an overview of the state of the art in the field of vertical test reuse for embedded system development. For this purpose, a systematic mapping study has been performed, identifying 11 papers on vertical test reuse for embedded systems. The primary result from the mapping is a classification of published work on vertical test reuse in the embedded system domain, covering motivations for reuse, reuse techniques, test levels and reusable test artifacts considered, and to what extent the effects of reuse have been evaluated. Â© 2015 IEEE."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(37, 'paper_37', '"What do we know about the defect types detected in conceptual models?"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84937942055&partnerID=40&md5=f5d60b4ef9d480f4806a8bad04269abe', NULL, '<b>Authors:</b><br/>"Granda M.F., Condori-Fernandez N., Vos T.E.J., Pastor O." <br/><b>Key words:</b><br/>"Conceptual Schema Defects, Defect Classification Scheme, Model-Driven Development, Systematic Mapping Study"', '"In Model-Driven Development (MDD), defects are managed at the level of conceptual models because the other artefacts are generated from them, such as more refined models, test cases and code. Although some studies have reported on defect types at model level, there still does not exist a clear and complete overview of the defect types that occur at the abstraction level. This paper presents a systematic mapping study to identify the model defect types reported in the literature and determine how they have been detected. Among the 282 articles published in software engineering area, 28 articles were selected for analysis. A total of 226 defects were identified, classified and their results analysed. For this, an appropriate defect classification scheme was built based on appropriate dimensions for models in an MDD context. Â© 2015 IEEE."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(38, 'paper_38', '"When and what to automate in software testing? A multi-vocal literature review"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84969529104&partnerID=40&md5=b1a7b786fb5bbbec9737993a11f4e652', NULL, '<b>Authors:</b><br/>"Garousi V., MÃ¤ntylÃ¤ M.V." <br/><b>Key words:</b><br/>"Decision support, Multivocal literature review, Software test automation, Systematic literature review, Systematic Mapping study, What to automate, When to automate"', '"Context Many organizations see software test automation as a solution to decrease testing costs and to reduce cycle time in software development. However, establishment of automated testing may fail if test automation is not applied in the right time, right context and with the appropriate approach. Objective The decisions on when and what to automate is important since wrong decisions can lead to disappointments and major wrong expenditures (resources and efforts). To support decision making on when and what to automate, researchers and practitioners have proposed various guidelines, heuristics and factors since the early days of test automation technologies. As the number of such sources has increased, it is important to systematically categorize the current state-of-The-art and -practice, and to provide a synthesized overview. Method To achieve the above objective, we have performed a Multivocal Literature Review (MLR) study on when and what to automate in software testing. A MLR is a form of a Systematic Literature Review (SLR) which includes the grey literature (e.g., blog posts and white papers) in addition to the published (formal) literature (e.g., journal and conference papers). We searched the academic literature using the Google Scholar and the grey literature using the regular Google search engine. Results Our MLR and its results are based on 78 sources, 52 of which were grey literature and 26 were formally published sources. We used the qualitative analysis (coding) to classify the factors affecting the when- And what-to-automate questions to five groups: (1) Software Under Test (SUT)-related factors, (2) test-related factors, (3) test-tool-related factors, (4) human and organizational factors, and (5) cross-cutting and other factors. The most frequent individual factors were: need for regression testing (44 sources), economic factors (43), and maturity of SUT (39). Conclusion We show that current decision-support in software test automation provides reasonable advice for industry, and as a practical outcome of this research we have summarized it as a checklist that can be used by practitioners. However, we recommend developing systematic empirically-validated decision-support approaches as the existing advice is often unsystematic and based on weak empirical evidence. Â© 2016 Elsevier B.V."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(39, 'paper_39', '"A Systematic Mapping Study on Test Generation from Input/Output Transition Systems"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84958235921&partnerID=40&md5=4a11222530cf3542f8047a0b76a39271', NULL, '<b>Authors:</b><br/>"Paiva S.L.D.C., Simao A.D.S." <br/><b>Key words:</b><br/>"Input/Output Transition Systems, systematic mapping study, test generation"', '"Context: The construction of complex systems has increased the adoption of technologies that aim at automating the testing activity. Model-Based Testing (MBT) has emerged as an approach to automate the generation of high-quality test suites from behavioural models. Input/Output Transition Systems(IOTSs) have been used in MBT because they are more expressive than other formalisms. Objective: This paper focuses on methods for test generation from IOTSs, aiming at synthesizing available knowledge and identifying gaps in the existing approaches. Method: A systematic mapping was conducted, in which 84 studies were evaluated and categorized in the taxonomy of MBT approaches. Results: The results indicate most of the reported approaches apply non-deterministic algorithms to test generation which do not employ measures of coverage or quality. This scenario underscores the importance of further research into this topic. Conclusion: The evidences indicate that the generation of complete test suites is guaranteed in theory without satisfying a certain test selection criterion. This result points out the need of additional investigation in this topic. Â© 2015 IEEE."', NULL, 'In review', 'Waiting', 0, '1_1489085284', 1),
(40, 'paper_40', '"A mapping study to investigate component-based software system metrics"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84872676227&partnerID=40&md5=168cb6d0d2c29588e6a74450ccc234fc', NULL, '<b>Authors:</b><br/>"Abdellatief M., Sultan A.B.M., Ghani A.A.A., Jabar M.A." <br/><b>Key words:</b><br/>"Component-based software system, Software components, Software metrics, Software quality, Systematic mapping study"', '"A component-based software system (CBSS) is a software system that is developed by integrating components that have been deployed independently. In the last few years, many researchers have proposed metrics to evaluate CBSS attributes. However, the practical use of these metrics can be difficult. For example, some of the metrics have concepts that either overlap or are not well defined, which could hinder their implementation. The aim of this study is to understand, classify and analyze existing research in component-based metrics, focusing on approaches and elements that are used to evaluate the quality of CBSS and its components from a component consumer''s point of view. This paper presents a systematic mapping study of several metrics that were proposed to measure the quality of CBSS and its components. We found 17 proposals that could be applied to evaluate CBSSs, while 14 proposals could be applied to evaluate individual components in isolation. Various elements of the software components that were measured are reviewed and discussed. Only a few of the proposed metrics are soundly defined. The quality assessment of the primary studies detected many limitations and suggested guidelines for possibilities for improving and increasing the acceptance of metrics. However, it remains a challenge to characterize and evaluate a CBSS and its components quantitatively. For this reason, much effort must be made to achieve a better evaluation approach in the future. Â© 2012 Elsevier Inc."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(41, 'paper_41', '"A review of research on risk analysis methods for IT systems"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877289265&partnerID=40&md5=e1f98654dd2286cf5fd9e00497f14c7b', NULL, '<b>Authors:</b><br/>"Sulaman S.M., Weyns K., HÃ¶st M." <br/><b>Key words:</b><br/>"IT systems, Mapping study, Risk analysis"', '"Context: At the same time as our dependence on IT systems increases, the number of reports of problems caused by failures of critical IT systems has also increased. This means that there is a need for risk analysis in the development of this kind of systems. Risk analysis of technical systems has a long history in mechanical and electrical engineering. Objective: Even if a number of methods for risk analysis of technical systems exist, the failure behavior of information systems is typically very different from mechanical systems. Therefore, risk analysis of IT systems requires different risk analysis techniques, or at least adaptations of traditional approaches. This means that there is a need to understand what types of methods are available for IT systems and what research that has been conducted on these methods. Method: In this paper we present a systematic mapping study on risk analysis for IT systems. 1086 unique papers were identified in a database search and 57 papers were identified as relevant for this study. These papers were classified based on 5 different criteria. Results: This classification, for example, shows that most of the discussed risk analysis methods are qualitative and not quantitative and that most of the risk analysis methods that are presented in these papers are developed for IT systems in general and not for specific types of IT system. Conclusions: The results show that many new risk analysis methods have been proposed in the last decade but even more that there is a need for more empirical evaluations of the different risk analysis methods. Many papers were identified that propose new risk analysis methods, but few papers discuss a systematic evaluation of these methods or a comparison of different methods based on empirical data. Copyright 2013 ACM."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(42, 'paper_42', '"A systematic mapping study of mobile application testing techniques"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84963641809&partnerID=40&md5=76dba7bb0f8605cbc0fd95a05873dca4', NULL, '<b>Authors:</b><br/>"Zein S., Salleh N., Grundy J." <br/><b>Key words:</b><br/>"Mobile application testing, Software testing, Systematic mapping"', '"The importance of mobile application specific testing techniques and methods has been attracting much attention of software engineers over the past few years. This is due to the fact that mobile applications are different than traditional web and desktop applications, and more and more they are moving to being used in critical domains. Mobile applications require a different approach to application quality and dependability and require an effective testing approach to build high quality and more reliable software. We performed a systematic mapping study to categorize and to structure the research evidence that has been published in the area of mobile application testing techniques and challenges that they have reported. Seventy nine (79) empirical studies are mapped to a classification schema. Several research gaps are identified and specific key testing issues for practitioners are identified: there is a need for eliciting testing requirements early during development process, the need to conduct research in real-world development environments, specific testing techniques targeting application life-cycle conformance and mobile services testing, and comparative studies for security and usability testing. Â© 2016 Elsevier Inc. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(43, 'paper_43', '"A systematic mapping study of web application testing"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84878316262&partnerID=40&md5=efb3d8db2cdcf51f20930ef18222929d', NULL, '<b>Authors:</b><br/>"Garousi V., Mesbah A., Betin-Can A., Mirshokraie S." <br/><b>Key words:</b><br/>"Bibliometrics, Paper repository, Systematic mapping, Testing, Web application"', '"Context: The Web has had a significant impact on all aspects of our society. As our society relies more and more on the Web, the dependability of web applications has become increasingly important. To make these applications more dependable, for the past decade researchers have proposed various techniques for testing web-based software applications. Our literature search for related studies retrieved 147 papers in the area of web application testing, which have appeared between 2000 and 2011. Objective As this research area matures and the number of related papers increases, it is important to systematically identify, analyze, and classify the publications and provide an overview of the trends in this specialized field. Method We review and structure the body of knowledge related to web application testing through a systematic mapping (SM) study. As part of this study, we pose two sets of research questions, define selection and exclusion criteria, and systematically develop and refine a classification schema. In addition, we conduct a bibliometrics analysis of the papers included in our study. Results Our study includes a set of 79 papers (from the 147 retrieved papers) published in the area of web application testing between 2000 and 2011. We present the results of our systematic mapping study. Our mapping data is available through a publicly-accessible repository. We derive the observed trends, for instance, in terms of types of papers, sources of information to derive test cases, and types of evaluations used in papers. We also report the demographics and bibliometrics trends in this domain, including top-cited papers, active countries and researchers, and top venues in this research area. Conclusion We discuss the emerging trends in web application testing, and discuss the implications for researchers and practitioners in this area. The results of our systematic mapping can help researchers to obtain an overview of existing web application testing approaches and indentify areas in the field that require more attention from the research community. Â© 2013 Elsevier B.V. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(44, 'paper_44', '"A systematic mapping study on fault management in cloud computing"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84908005906&partnerID=40&md5=4d276f88513f45493729ad18a23aebee', NULL, '<b>Authors:</b><br/>"Neto C.B.L., Filho P.B.D.C., Duarte A.N." <br/><b>Key words:</b><br/>"Cloud Computing, Dependability, Evidence-Based Research, Fault Management, Mapping Study, Secondary Study"', '"Background: The large computational infrastructures required to provide the on-demand services that most users are now used to are more prone to failures than any single computational device. Thus, fault management is a essential activity in the realization of the cloud computing model. Aims: This work aims at identifying well-explored topics on fault management in cloud computing as well as pin-pointing gaps in the scientific literature that may represent opportunities for further research and development in this area. Method: We conducted a systematic mapping study to collect, filter and classify scientific works in this area. The 4535 scientific papers found on major search engines were filtered and the remaining 166 papers were classified according to a taxonomy described in this work. Results: We found that IaaS is most explored in the selected studies. The main dependability functions explored were Tolerance and Removal, and the attributes were Reliability and Availability. Most papers had been classified by research type as Solution Proposal. Conclusion: This work summarizes and classifies the research effort conducted on fault management in cloud computing, providing a good starting point for further research in this area. Â© 2013 IEEE."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(45, 'paper_45', '"A systematic mapping study on legacy system modernization"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988349883&partnerID=40&md5=451bac271599396ea4902529ffac10fa', NULL, '<b>Authors:</b><br/>"De Vargas Agilar E., De Almeida R.B., Canedo E.D." <br/><b>Key words:</b><br/>"Legacy systems, Mapping studies in software engineering, Software modernization"', '"Legacy system modernization has gained increasing attention from both researchers and practitioners, mainly due to the need of maintaining legacy systems towards business needs and technology advances. In this way, a set of techniques, tools and terms related to software modernization have been proposed- although they have not been consolidated yet. This hinders the characterization of real modernization scenarios according to the existing literature. This paper synthesize the existing contributions related to software modernization by means of a mapping study that characterizes the main results in terms of proposed processes, techniques, and tools. As one of our main findings, we report a lack of empirical studies trying to understand the benefits of using the existing approaches for software modernization."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(46, 'paper_46', '"A systematic mapping study on testing technique experiments: Has the situation changed since 2000?"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907807087&partnerID=40&md5=00c82980bdc011d47bb2182dc9e3a806', NULL, '<b>Authors:</b><br/>"GonzÃ¡lez J.E., Juristo N., Vegas S." <br/><b>Key words:</b><br/>"mapping study, software testing techniques, testing experiments"', '"Context Juristo et al. [7] published a literature review about testing technique expenments. The goal was to provide a picture of which techniques and aspects of techniques had been studied experimentally, and try to compile a body of knowledge on testing techniques. Goal: In this paper, we extend Junsto et al.''s study to cover the years from 2000 (where it ended) until 2013. Method: We have performed a systematic mapping study. Results: The situation in testing experimentation has not changed since Junsto et al.''s study. Conclusions: The research field has the same shortcomings. Â© 2014 ACM."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(47, 'paper_47', '"A systematic mapping study on the combination of static and dynamic quality assurance techniques"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-80055068778&partnerID=40&md5=79090e7196d4dd5edae0bed3976791e4', NULL, '<b>Authors:</b><br/>"Elberzhager F., MÃ¼nch J., Nha V.T.N." <br/><b>Key words:</b><br/>"Combination, Dynamic quality assurance, Inspection, Static quality assurance, Systematic mapping study, Testing"', '"Context: A lot of different quality assurance techniques exist to ensure high quality products. However, most often they are applied in isolation. A systematic combination of different static and dynamic quality assurance techniques promises to exploit synergy effects, such as higher defect detection rates or reduced quality assurance costs. However, a systematic overview of such combinations and reported evidence about achieving synergy effects with such kinds of combinations is missing. Objective: The main goal of this article is the classification and thematic analysis of existing approaches that combine different static and dynamic quality assurance technique, including reported effects, characteristics, and constraints. The result is an overview of existing approaches and a suitable basis for identifying future research directions. Method: A systematic mapping study was performed by two researchers, focusing on four databases with an initial result set of 2498 articles, covering articles published between 1985 and 2010. Results: In total, 51 articles were selected and classified according to multiple criteria. The two main dimensions of a combination are integration (i.e., the output of one quality assurance technique is used for the second one) and compilation (i.e., different quality assurance techniques are applied to ensure a common goal, but in isolation). The combination of static and dynamic analyses is one of the most common approaches and usually conducted in an integrated manner. With respect to the combination of inspection and testing techniques, this is done more often in a compiled way than in an integrated way. Conclusion: The results show an increased interest in this topic in recent years, especially with respect to the integration of static and dynamic analyses. Inspection and testing techniques are currently mostly performed in an isolated manner. The integration of inspection and testing techniques is a promising research direction for the exploitation of additional synergy effects. Â© 2011 Elsevier B.V. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(48, 'paper_48', '"Agile testing: Past, present, and future - Charting a systematic map of testing in agile software development"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84868294056&partnerID=40&md5=07cb548e86ce68641af0917124a13d80', NULL, '<b>Authors:</b><br/>"Hellmann T.D., Sharma A., Ferreira J., Maurer F." <br/><b>Key words:</b><br/>"agile software development, empirical, software testing, systematic mapping, test-driven development, testing tools"', '"Testing has been a cornerstone of agile software development methodologies since early in the history of the field. However, the terminology used to describe the field - as well as the evidence in existing literature - is largely inconsistent. In order to better structure our understanding of the field and to guide future work, we conducted a systematic mapping of agile testing. We investigated five research questions: which authors are most active in agile testing, what is agile testing used for, what types of paper tend to be published in this field, how do practitioners and academics contribute to research in this field, and what tools are used to conduct agile testing? Of particular interest is our investigation into the source of these publications, which indicates that academics and practitioners focus on different types of publication and, disturbingly, that the number of practitioner papers in the sources we searched is strongly down since 2010. Â© 2012 IEEE."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(49, 'paper_49', '"RiPLE-TE: A process for testing Software Product Lines"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84855554904&partnerID=40&md5=e8613b35f4a36d18abc967fb4a53af68', NULL, '<b>Authors:</b><br/>"Do Carmo Machado I., Da Mota Silveira Neto P.A., De Almeida E.S., De Lemos Meira S.R." <br/><b>Key words:</b><br/>"Software process, Software product lines, Software reuse, Software testing"', '"Software Product Lines Testing has received special attention in recent years, due to its crucial role in quality and also due to the high cost this activity poses. In this effect, to make testing a feasible activity, some improvements are required. This paper presents a process for testing product lines, designed based on the gaps identified by a systematic mapping study, performed in order to understand the current scenario in this research field. An experimental study was performed in order to evaluate the proposed process in terms of understanding the role of a structured testing process in a SPL project."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(50, 'paper_50', '"Systematic mapping study in automatic test case generation"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84948782811&partnerID=40&md5=ce17b999150fefd2e67fae653350f6ca', NULL, '<b>Authors:</b><br/>"Mohi-Aldeen S.M., Deris S., Mohamad R." <br/><b>Key words:</b><br/>"Automatic test case generation methods, Software testing, Test case generation, Test case generation methods"', '"Test case generation is a painstaking task in software testing and has a strong influence on the efficiency and the effectiveness of software tests. It is an important subject in software testing research that has led to the development of several tools and approaches over the decades. This paper presented a systematic mapping study to get an overview about the current studies of distinct techniques for generation of test cases automatically. The techniques presented in this paper are random-based methods, search-based methods and data mining-based methods. Each technique is explored briefly to give the basic idea behind it. In general, the paper''s objective is to give an up-to-date introduction and short review of the research in generation of test cases automatically. Systematic mapping study is the process of finding and collecting as much literature as possible, provides a structure of the type of research reports and the results that have been published by categorizing them depending on specific search questions to provide a background for further research. This study was based on a comprehensive set of 85 papers published in conference and journals between 2002 and 2013 obtained after using multistage selection criteria in the field of automatic test cases generation. The results from our systematic mapping study include information about the researches techniques used to generate test cases automatically and types of coverage within a specific period that can help researchers in this field through providing an overview of the current researches in this area. Furthermore, it may serve as a first step towards a great explanation of the topic with the help of systematic literature review. Â© 2014 The authors and IOS Press. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(51, 'paper_51', '"Systematic mapping study of model transformations for concrete problems"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84969921820&partnerID=40&md5=3845b641095db79942e3712d847bb345', NULL, '<b>Authors:</b><br/>"Batot E., Sahraoui H., Syriani E., Molins P., Sboui W." <br/><b>Key words:</b><br/>"Model Transformation, Software Engineering, Systematic Mapping"', '"As a contribution to the adoption of the Model-Driven Engineering (MDE) paradigm, the research community has proposed concrete model transformation solutions for the MDE infrastructure and for domain-specific problems. However, as the adoption increases and with the advent of the new initiatives for the creation of repositories, it is legitimate to question whether proposals for concrete transformation problems can be still considered as research contributions or if they respond to a practical/technical work. In this paper, we report on a systematic mapping study that aims at understanding the trends and characteristics of concrete model transformations published in the past decade. Our study shows that the number of papers with, as main contribution, a concrete transformation solution, is not as high as expected. This number increased to reach a peak in 2010 and is decreasing since then. Our results also include a characterization and an analysis of the published proposals following a rigorous classification scheme. Â© Copyright 2016 by SCITEPRESS - Science and Technology Publications, Lda. All rights reserved."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(52, 'paper_52', '"Test case prioritization: A systematic mapping study"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84880587969&partnerID=40&md5=442d06af0d109613e52157d932d6d107', NULL, '<b>Authors:</b><br/>"Catal C., Mishra D." <br/><b>Key words:</b><br/>"Regression testing, Systematic literature review, Systematic mapping study, Test case prioritization"', '"Test case prioritization techniques, which are used to improve the cost-effectiveness of regression testing, order test cases in such a way that those cases that are expected to outperform others in detecting software faults are run earlier in the testing phase. The objective of this study is to examine what kind of techniques have been widely used in papers on this subject, determine which aspects of test case prioritization have been studied, provide a basis for the improvement of test case prioritization research, and evaluate the current trends of this research area. We searched for papers in the following five electronic databases: IEEE Explorer, ACM Digital Library, Science Direct, Springer, and Wiley. Initially, the search string retrieved 202 studies, but upon further examination of titles and abstracts, 120 papers were identified as related to test case prioritization. There exists a large variety of prioritization techniques in the literature, with coverage-based prioritization techniques (i.e., prioritization in terms of the number of statements, basic blocks, or methods test cases cover) dominating the field. The proportion of papers on model-based techniques is on the rise, yet the growth rate is still slow. The proportion of papers that use datasets from industrial projects is found to be 64 %, while those that utilize public datasets for validation are only 38 %. On the basis of this study, the following recommendations are provided for researchers: (1) Give preference to public datasets rather than proprietary datasets, (2) develop more model-based prioritization methods, (3) conduct more studies on the comparison of prioritization methods, (4) always evaluate the effectiveness of the proposed technique with well-known evaluation metrics and compare the performance with the existing methods, (5) publish surveys and systematic review papers on test case prioritization, and (6) use datasets from industrial projects that represent real industrial problems. Â© 2012 Springer Science+Business Media, LLC."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1);
INSERT INTO `paper` (`id`, `bibtexKey`, `title`, `doi`, `venueId`, `bibtex`, `preview`, `abstract`, `screening_status`, `classification_status`, `paper_excluded`, `operation_code`, `paper_active`) VALUES
(53, 'paper_53', '"Web application testing: A systematic literature review"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84900597825&partnerID=40&md5=29b2691a945894ddceca3e7f69123b48', NULL, '<b>Authors:</b><br/>"Do?an S., Betin-Can A., Garousi V." <br/><b>Key words:</b><br/>"Systematic literature review, Testing, Web application"', '"Context The web has had a significant impact on all aspects of our society. As our society relies more and more on the web, the dependability of web applications has become increasingly important. To make these applications more dependable, for the past decade researchers have proposed various techniques for testing web-based software applications. Our literature search for related studies retrieved 193 papers in the area of web application testing, which have appeared between 2000 and 2013. Objective As this research area matures and the number of related papers increases, it is important to systematically identify, analyze, and classify the publications and provide an overview of the trends and empirical evidence in this specialized field. Methods We systematically review the body of knowledge related to functional testing of web application through a systematic literature review (SLR) study. This SLR is a follow-up and complimentary study to a recent systematic mapping (SM) study that we conducted in this area. As part of this study, we pose three sets of research questions, define selection and exclusion criteria, and synthesize the empirical evidence in this area. Results Our pool of studies includes a set of 95 papers (from the 193 retrieved papers) published in the area of web application testing between 2000 and 2013. The data extracted during our SLR study is available through a publicly-accessible online repository. Among our results are the followings: (1) the list of test tools in this area and their capabilities, (2) the types of test models and fault models proposed in this domain, (3) the way the empirical studies in this area have been designed and reported, and (4) the state of empirical evidence and industrial relevance. Conclusion We discuss the emerging trends in web application testing, and discuss the implications for researchers and practitioners in this area. The results of our SLR can help researchers to obtain an overview of existing web application testing approaches, fault models, tools, metrics and empirical evidence, and subsequently identify areas in the field that require more attention from the research community. Â© 2014 Elsevier Inc."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1),
(54, 'paper_54', '"What a long, strange trip it''s been: Past, present, and future perspectives on software testing research"', 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-82255172046&partnerID=40&md5=cd89afa234a6f03b9cae5e3e617ab60d', NULL, '<b>Authors:</b><br/>"Durelli V.H.S., Araujo R.F., Silva M.A.G., Oliveira R.A.P., Maldonado J.C., Delamaro M.E." <br/><b>Key words:</b><br/>"Software Testing, systematic mapping"', '"Over the past 25 years the Brazilian Symposium on Software Engineering (SBES) has evolved to become the most important event on software engineering in Brazil. Throughout these years, SBES has gathered a large body of studies in software testing. Aimed at providing an insightful understanding of what has already been published in such event, we synthesized its rich 25-year history of research on software testing. Using information drawn from this overview we attempted to highlight which types of study have been the most applied for conveying software testing efforts. We also devised a co-authorship network to obtain a bird''s-eye view of which research groups and scholars have been the most prolific ones. Moreover, by performing a citation analysis of the selected studies we set out to ascertain the importance of SBES in a wider scenario. Finally, borne out by the information extracted from the studies, we shed some light on the state-of-the-art of software testing in Brazil and provide an outlook on its foreseeable future. Â© 2011 IEEE."', NULL, 'Pending', 'Waiting', 0, '1_1489085284', 1);

-- --------------------------------------------------------

--
-- Table structure for table `paperauthor`
--

DROP TABLE IF EXISTS `paperauthor`;
CREATE TABLE IF NOT EXISTS `paperauthor` (
  `paperauthor_id` int(11) NOT NULL AUTO_INCREMENT,
  `paperId` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `paperauthor_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paperauthor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ref_domain`
--

DROP TABLE IF EXISTS `ref_domain`;
CREATE TABLE IF NOT EXISTS `ref_domain` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ref_domain`
--

INSERT INTO `ref_domain` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Artificial Intelligence', 'Artificial Intelligence', 1),
(2, 'Collaborative system', 'Collaborative system', 1),
(3, 'Compilation', 'Compilation', 1),
(4, 'E-commerce', 'E-commerce', 1),
(5, 'Any', 'Any', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_language`
--

DROP TABLE IF EXISTS `ref_language`;
CREATE TABLE IF NOT EXISTS `ref_language` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_language`
--

INSERT INTO `ref_language` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'UML', 'UML', 1),
(2, 'SySML', 'SySML', 1),
(3, 'Java', 'Java', 1),
(4, 'DSL', 'DSL', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_tables`
--

DROP TABLE IF EXISTS `ref_tables`;
CREATE TABLE IF NOT EXISTS `ref_tables` (
  `reftab_id` int(11) NOT NULL AUTO_INCREMENT,
  `reftab_label` varchar(50) NOT NULL,
  `reftab_table` varchar(50) NOT NULL,
  `reftab_desc` varchar(200) NOT NULL,
  `reftab_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`reftab_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_tables`
--

INSERT INTO `ref_tables` (`reftab_id`, `reftab_label`, `reftab_table`, `reftab_desc`, `reftab_active`) VALUES
(1, 'ref_exclusioncrieria', 'zref_exclusioncrieria', 'Exclusion criteria', 1),
(2, 'ref_domain', 'ref_domain', 'Domain', 1),
(3, 'ref_transformation_language', 'ref_transformation_language', 'Transformation Language', 1),
(4, 'ref_language', 'ref_language', 'Language', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_transformation_language`
--

DROP TABLE IF EXISTS `ref_transformation_language`;
CREATE TABLE IF NOT EXISTS `ref_transformation_language` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_transformation_language`
--

INSERT INTO `ref_transformation_language` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'MoTif', 'MoTif', 1),
(2, 'ATL', 'ATL', 1),
(3, 'Henshin', 'Henshin', 1),
(4, 'QVT', 'QVT', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screening`
--

DROP TABLE IF EXISTS `screening`;
CREATE TABLE IF NOT EXISTS `screening` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `decision` enum('accepted','excluded') NOT NULL DEFAULT 'accepted',
  `exclusion_criteria` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `screening_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `screening`
--

INSERT INTO `screening` (`screening_id`, `paper_id`, `user_id`, `decision`, `exclusion_criteria`, `note`, `assignment_id`, `screening_time`, `screening_active`) VALUES
(1, 4, 1, 'accepted', NULL, '', 8, '2017-06-16 01:29:18', 1),
(2, 5, 1, 'accepted', NULL, '', 9, '2017-06-16 01:29:21', 1),
(3, 9, 1, 'accepted', NULL, '', 18, '2017-06-16 01:29:24', 1),
(4, 10, 1, 'excluded', 1, '', 19, '2017-06-16 01:31:00', 1),
(5, 14, 1, 'excluded', 1, '', 28, '2017-06-16 01:31:04', 1),
(6, 15, 1, 'excluded', 1, '', 29, '2017-06-16 01:31:09', 1),
(7, 19, 1, 'excluded', 1, '', 38, '2017-06-16 01:31:13', 1),
(8, 20, 1, 'excluded', 1, '', 39, '2017-06-16 01:31:18', 1),
(9, 24, 1, 'excluded', 1, '', 48, '2017-06-16 01:31:23', 1),
(10, 25, 1, 'excluded', 1, '', 49, '2017-06-16 01:31:27', 1),
(11, 29, 1, 'excluded', 1, '', 58, '2017-06-16 01:31:31', 1),
(12, 30, 1, 'excluded', 1, '', 59, '2017-06-16 01:31:35', 1),
(13, 34, 1, 'excluded', 1, '', 68, '2017-06-16 01:31:39', 1),
(14, 35, 1, 'excluded', 1, '', 69, '2017-06-16 01:31:43', 1),
(15, 39, 1, 'excluded', 1, '', 78, '2017-06-16 01:31:49', 1),
(16, 3, 4, 'excluded', 1, '', 6, '2017-06-16 01:32:26', 1),
(17, 4, 4, 'excluded', 1, '', 7, '2017-06-16 01:32:31', 1),
(18, 8, 4, 'excluded', 1, '', 16, '2017-06-16 01:32:35', 1),
(19, 9, 4, 'excluded', 1, '', 17, '2017-06-16 01:32:40', 1),
(20, 13, 4, 'excluded', 1, '', 26, '2017-06-16 01:32:44', 1),
(21, 14, 4, 'excluded', 1, '', 27, '2017-06-16 01:32:48', 1),
(22, 18, 4, 'excluded', 1, '', 36, '2017-06-16 01:32:53', 1),
(23, 19, 4, 'excluded', 1, '', 37, '2017-06-16 01:33:00', 1),
(24, 23, 4, 'excluded', 1, '', 46, '2017-06-16 01:33:04', 1),
(25, 24, 4, 'excluded', 1, '', 47, '2017-06-16 01:33:08', 1),
(26, 28, 4, 'excluded', 1, '', 56, '2017-06-16 01:33:13', 1),
(27, 29, 4, 'excluded', 1, '', 57, '2017-06-16 01:33:18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screening_validate`
--

DROP TABLE IF EXISTS `screening_validate`;
CREATE TABLE IF NOT EXISTS `screening_validate` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `decision` enum('accepted','excluded') NOT NULL DEFAULT 'accepted',
  `exclusion_criteria` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `screening_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `screening_validate`
--

INSERT INTO `screening_validate` (`screening_id`, `paper_id`, `user_id`, `decision`, `exclusion_criteria`, `note`, `assignment_id`, `screening_time`, `screening_active`) VALUES
(1, 24, 4, 'excluded', 1, '', 1, '2017-06-16 01:34:04', 1),
(2, 29, 4, 'excluded', 1, '', 2, '2017-06-16 01:34:08', 1),
(3, 19, 4, 'accepted', NULL, '', 3, '2017-06-16 01:34:11', 1),
(4, 14, 4, 'excluded', 1, '', 4, '2017-06-16 01:34:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `str_management`
--

DROP TABLE IF EXISTS `str_management`;
CREATE TABLE IF NOT EXISTS `str_management` (
  `str_id` int(11) NOT NULL AUTO_INCREMENT,
  `str_label` varchar(500) NOT NULL,
  `str_text` varchar(1000) NOT NULL,
  `str_category` varchar(20) NOT NULL DEFAULT 'default',
  `str_lang` varchar(3) NOT NULL DEFAULT 'en',
  `str_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`str_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=165 ;

--
-- Dumping data for table `str_management`
--

INSERT INTO `str_management` (`str_id`, `str_label`, `str_text`, `str_category`, `str_lang`, `str_active`) VALUES
(1, 'Welcome', 'Welcome', 'default', 'en', 1),
(2, 'General', 'General', 'default', 'en', 1),
(3, 'Home', 'Home', 'default', 'en', 1),
(4, 'Screen', 'Screen', 'default', 'en', 1),
(5, 'Papers', 'Papers', 'default', 'en', 1),
(6, 'Import papers', 'Import papers', 'default', 'en', 1),
(7, 'All papers', 'All papers', 'default', 'en', 1),
(8, 'Papers pending', 'Papers pending', 'default', 'en', 1),
(9, 'Papers in review', 'Papers in review', 'default', 'en', 1),
(10, 'Papers included', 'Papers included', 'default', 'en', 1),
(11, 'Papers excluded', 'Papers excluded', 'default', 'en', 1),
(12, 'Papers in conflict', 'Papers in conflict', 'default', 'en', 1),
(13, 'Screening', 'Screening', 'default', 'en', 1),
(14, 'Assign papers for screening', 'Assign papers for screening', 'default', 'en', 1),
(15, 'My assignments', 'My assignments', 'default', 'en', 1),
(16, 'My screenings', 'My screenings', 'default', 'en', 1),
(17, 'All assignments', 'All assignments', 'default', 'en', 1),
(18, 'All screenings', 'All screenings', 'default', 'en', 1),
(19, 'Completion', 'Completion', 'default', 'en', 1),
(20, 'Result', 'Result', 'default', 'en', 1),
(21, 'Screening validation', 'Screening validation', 'default', 'en', 1),
(22, 'Assign papers for validation', 'Assign papers for validation', 'default', 'en', 1),
(23, 'Assignments', 'Assignments', 'default', 'en', 1),
(24, 'Screenings', 'Screenings', 'default', 'en', 1),
(25, 'Validation result', 'Validation result', 'default', 'en', 1),
(26, 'Settings', 'Settings', 'default', 'en', 1),
(27, 'Admin', 'Admin', 'default', 'en', 1),
(28, 'Exclusion criteria', 'Exclusion criteria', 'default', 'en', 1),
(29, 'Operations', 'Operations', 'default', 'en', 1),
(30, 'SQL', 'SQL', 'default', 'en', 1),
(31, 'String mangement', 'String mangement', 'default', 'en', 1),
(32, 'Configuration', 'Configuration', 'default', 'en', 1),
(33, 'Update Installation', 'Update Installation', 'default', 'en', 1),
(34, 'Choose project', 'Choose project', 'default', 'en', 1),
(35, 'UP', 'UP', 'default', 'en', 1),
(36, 'Log Out', 'Log Out', 'default', 'en', 1),
(37, 'Project', 'Project', 'default', 'en', 1),
(38, 'Description', 'Description', 'default', 'en', 1),
(39, 'My screening completion', 'My screening completion', 'default', 'en', 1),
(40, ' Screened papers', ' Screened papers', 'default', 'en', 1),
(41, 'Pending papers', 'Pending papers', 'default', 'en', 1),
(42, 'Participants', 'Participants', 'default', 'en', 1),
(43, 'user', 'user', 'default', 'en', 1),
(44, 'ReLiS - Revue Littéraire Systématique', 'ReLiS - Revue Littéraire Systématique', 'default', 'en', 1),
(45, 'Select', 'Select', 'default', 'en', 1),
(46, 'Select multi', 'Select multi', 'default', 'en', 1),
(47, '#', '#', 'default', 'en', 1),
(48, 'Configuration type', 'Configuration type', 'default', 'en', 1),
(49, 'Editor location(url)', 'Editor location(url)', 'default', 'en', 1),
(50, 'Editor workspace', 'Editor workspace', 'default', 'en', 1),
(51, 'CSV  separator for import', 'CSV  separator for import', 'default', 'en', 1),
(52, 'CSV separator for export', 'CSV separator for export', 'default', 'en', 1),
(53, 'Screening comfict type', 'Screening comfict type', 'default', 'en', 1),
(54, 'import papers activated', 'import papers activated', 'default', 'en', 1),
(55, 'assign papers activated', 'assign papers activated', 'default', 'en', 1),
(56, 'Screening activated', 'Screening activated', 'default', 'en', 1),
(57, 'Screening result activated', 'Screening result activated', 'default', 'en', 1),
(58, 'Screening validation activated', 'Screening validation activated', 'default', 'en', 1),
(59, 'Classification activated', 'Classification activated', 'default', 'en', 1),
(60, 'Edit', 'Edit', 'default', 'en', 1),
(61, 'Back', 'Back', 'default', 'en', 1),
(62, 'Load a CSV file', 'Load a CSV file', 'default', 'en', 1),
(63, 'Upload the CSV file', 'Upload the CSV file', 'default', 'en', 1),
(64, 'Upload', 'Upload', 'default', 'en', 1),
(65, 'Import papers - match fields', 'Import papers - match fields', 'default', 'en', 1),
(66, 'Match csv fields', 'Match csv fields', 'default', 'en', 1),
(67, 'Key', 'Key', 'default', 'en', 1),
(68, 'Title', 'Title', 'default', 'en', 1),
(69, 'View', 'View', 'default', 'en', 1),
(70, 'Name', 'Name', 'default', 'en', 1),
(71, 'Username', 'Username', 'default', 'en', 1),
(72, 'Email', 'Email', 'default', 'en', 1),
(73, 'Usergroup', 'Usergroup', 'default', 'en', 1),
(74, 'Value', 'Value', 'default', 'en', 1),
(75, 'Action', 'Action', 'default', 'en', 1),
(76, 'Close', 'Close', 'default', 'en', 1),
(77, 'List of papers', 'List of papers', 'default', 'en', 1),
(78, 'Reviews per paper', 'Reviews per paper', 'default', 'en', 1),
(79, 'Assignement done', 'Assignement done', 'default', 'en', 1),
(80, 'Paper', 'Paper', 'default', 'en', 1),
(81, 'Assigned to', 'Assigned to', 'default', 'en', 1),
(82, 'Assignment mode', 'Assignment mode', 'default', 'en', 1),
(83, 'Assigned by', 'Assigned by', 'default', 'en', 1),
(84, 'Screened', 'Screened', 'default', 'en', 1),
(85, 'Paper assignment for screening', 'Paper assignment for screening', 'default', 'en', 1),
(86, 'The Reviews per paper cannot exceed the number of selected users  ', 'The Reviews per paper cannot exceed the number of selected users  ', 'default', 'en', 1),
(87, 'Error', 'Error', 'default', 'en', 1),
(88, 'Edit Configuration', 'Edit Configuration', 'default', 'en', 1),
(89, 'Success', 'Success', 'default', 'en', 1),
(90, 'List of Configuration', 'List of Configuration', 'default', 'en', 1),
(91, 'Utilisateur', 'Utilisateur', 'default', 'en', 1),
(92, 'Evenement', 'Evenement', 'default', 'en', 1),
(93, 'Time', 'Time', 'default', 'en', 1),
(94, 'No papers assigned to you for validation', 'No papers assigned to you for validation', 'default', 'en', 1),
(95, 'Set screening validation', 'Set screening validation', 'default', 'en', 1),
(96, 'Percentage of papers(%)', 'Percentage of papers(%)', 'default', 'en', 1),
(97, 'Operation type', 'Operation type', 'default', 'en', 1),
(98, 'List of Operations', 'List of Operations', 'default', 'en', 1),
(99, 'Processed', 'Processed', 'default', 'en', 1),
(100, 'Pending', 'Pending', 'default', 'en', 1),
(101, 'Assigned to me', 'Assigned to me', 'default', 'en', 1),
(102, 'Excluded', 'Excluded', 'default', 'en', 1),
(103, 'Classification', 'Classification', 'default', 'en', 1),
(104, 'Graphs', 'Graphs', 'default', 'en', 1),
(105, 'Export', 'Export', 'default', 'en', 1),
(106, 'Reference Tables', 'Reference Tables', 'default', 'en', 1),
(107, 'Domain', 'Domain', 'default', 'en', 1),
(108, 'Language', 'Language', 'default', 'en', 1),
(109, 'Transformation Language', 'Transformation Language', 'default', 'en', 1),
(110, 'Classification completion', 'Classification completion', 'default', 'en', 1),
(111, 'Processed papers', 'Processed papers', 'default', 'en', 1),
(112, 'Search for...', 'Search for...', 'default', 'en', 1),
(113, 'Transformation name', 'Transformation name', 'default', 'en', 1),
(114, 'Source language', 'Source language', 'default', 'en', 1),
(115, 'Target language', 'Target language', 'default', 'en', 1),
(116, 'Scope', 'Scope', 'default', 'en', 1),
(117, 'Note', 'Note', 'default', 'en', 1),
(118, 'Excluded papers', 'Excluded papers', 'default', 'en', 1),
(119, 'No value !', 'No value !', 'default', 'en', 1),
(120, 'Paper assignment for screening validation', 'Paper assignment for screening validation', 'default', 'en', 1),
(121, 'No records found', 'No records found', 'default', 'en', 1),
(122, 'Screened by', 'Screened by', 'default', 'en', 1),
(123, 'Decision', 'Decision', 'default', 'en', 1),
(124, 'matches out of', 'matches out of', 'default', 'en', 1),
(125, 'Validation result : 0 matches out of 0 <i class="fa fa-arrow-right"></i> 0  % ', 'Validation result : 0 matches out of 0 <i class="fa fa-arrow-right"></i> 0  % ', 'default', 'en', 1),
(126, 'Label', 'Label', 'default', 'en', 1),
(127, 'Text', 'Text', 'default', 'en', 1),
(128, 'Delete', 'Delete', 'default', 'en', 1),
(129, 'Open edition mode', 'Open edition mode', 'default', 'en', 1),
(130, 'List of String management', 'List of String management', 'default', 'en', 1),
(131, 'Update project', 'Update project', 'default', 'en', 1),
(132, 'Upload configuration file', 'Upload configuration file', 'default', 'en', 1),
(133, 'Load from editor', 'Load from editor', 'default', 'en', 1),
(134, 'Choose setup file', 'Choose setup file', 'default', 'en', 1),
(135, 'New project', 'New project', 'default', 'en', 1),
(136, 'Users', 'Users', 'default', 'en', 1),
(137, 'User groups', 'User groups', 'default', 'en', 1),
(138, 'Logs', 'Logs', 'default', 'en', 1),
(139, 'Edit Domain', 'Edit Domain', 'default', 'en', 1),
(140, 'Add new', 'Add new', 'default', 'en', 1),
(141, 'List of Domain', 'List of Domain', 'default', 'en', 1),
(142, 'No papers assigned to you for screening', 'No papers assigned to you for screening', 'default', 'en', 1),
(143, 'Classifications', 'Classifications', 'default', 'en', 1),
(144, 'Abreviation', 'Abreviation', 'default', 'en', 1),
(145, 'Full name', 'Full name', 'default', 'en', 1),
(146, 'Year', 'Year', 'default', 'en', 1),
(147, 'Add new paper', 'Add new paper', 'default', 'en', 1),
(148, 'Switch to multi query!', 'Switch to multi query!', 'default', 'en', 1),
(149, 'Parse an SQL query', 'Parse an SQL query', 'default', 'en', 1),
(150, 'Return table', 'Return table', 'default', 'en', 1),
(151, 'Write your sql query here', 'Write your sql query here', 'default', 'en', 1),
(152, 'Submit', 'Submit', 'default', 'en', 1),
(153, 'Save and Next', 'Save and Next', 'default', 'en', 1),
(154, 'Papers assigned to me for screening', 'Papers assigned to me for screening', 'default', 'en', 1),
(155, 'Screening Progress', 'Screening Progress', 'default', 'en', 1),
(156, 'Screening Results', 'Screening Results', 'default', 'en', 1),
(157, 'Screening validation progress', 'Screening validation progress', 'default', 'en', 1),
(158, 'Element saved', 'Element saved', 'default', 'en', 1),
(159, 'List of Exclusion criteria', 'List of Exclusion criteria', 'default', 'en', 1),
(160, 'Add Exclusion criteria', 'Add Exclusion criteria', 'default', 'en', 1),
(161, 'Edit Exclusion criteria', 'Edit Exclusion criteria', 'default', 'en', 1),
(162, 'Operation completed', 'Operation completed', 'default', 'en', 1),
(163, 'Validation - All papers have been screened', 'Validation - All papers have been screened', 'default', 'en', 1),
(164, 'Validation result : 3 matches out of 4 <i class="fa fa-arrow-right"></i> 75  % ', 'Validation result : 3 matches out of 4 <i class="fa fa-arrow-right"></i> 75  % ', 'default', 'en', 1);

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
CREATE TABLE IF NOT EXISTS `venue` (
  `venue_id` int(11) NOT NULL AUTO_INCREMENT,
  `venue_abbreviation` varchar(20) NOT NULL,
  `venue_fullName` longtext,
  `venue_year` smallint(6) NOT NULL,
  `venue_volume` smallint(6) DEFAULT NULL,
  `venue_totalNumPapers` smallint(6) DEFAULT NULL,
  `venue_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`venue_id`),
  UNIQUE KEY `IX_Venue` (`venue_abbreviation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_assigned`
--
DROP VIEW IF EXISTS `view_paper_assigned`;
CREATE TABLE IF NOT EXISTS `view_paper_assigned` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(100)
,`title` varchar(200)
,`doi` varchar(1000)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(1)
,`operation_code` varchar(20)
,`paper_active` int(1)
,`assigned_user_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_pending`
--
DROP VIEW IF EXISTS `view_paper_pending`;
CREATE TABLE IF NOT EXISTS `view_paper_pending` (
`id` int(11)
,`bibtexKey` varchar(100)
,`title` varchar(200)
,`doi` varchar(1000)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(1)
,`operation_code` varchar(20)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_processed`
--
DROP VIEW IF EXISTS `view_paper_processed`;
CREATE TABLE IF NOT EXISTS `view_paper_processed` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(100)
,`title` varchar(200)
,`doi` varchar(1000)
,`venueId` int(11)
,`bibtex` longtext
,`preview` longtext
,`abstract` longtext
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`paper_excluded` int(1)
,`operation_code` varchar(20)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `zref_exclusioncrieria`
--

DROP TABLE IF EXISTS `zref_exclusioncrieria`;
CREATE TABLE IF NOT EXISTS `zref_exclusioncrieria` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zref_exclusioncrieria`
--

INSERT INTO `zref_exclusioncrieria` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'crit', '', 1);

-- --------------------------------------------------------

--
-- Structure for view `view_paper_assigned`
--
DROP TABLE IF EXISTS `view_paper_assigned`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_assigned` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`doi` AS `doi`,`p`.`venueId` AS `venueId`,`p`.`bibtex` AS `bibtex`,`p`.`preview` AS `preview`,`p`.`abstract` AS `abstract`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`operation_code` AS `operation_code`,`p`.`paper_active` AS `paper_active`,`a`.`assigned_user_id` AS `assigned_user_id` from (`paper` `p` join `assigned` `a` on((`p`.`id` = `a`.`assigned_paper_id`))) where ((`a`.`assigned_active` = 1) and (`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_pending`
--
DROP TABLE IF EXISTS `view_paper_pending`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_pending` AS select `paper`.`id` AS `id`,`paper`.`bibtexKey` AS `bibtexKey`,`paper`.`title` AS `title`,`paper`.`doi` AS `doi`,`paper`.`venueId` AS `venueId`,`paper`.`bibtex` AS `bibtex`,`paper`.`preview` AS `preview`,`paper`.`abstract` AS `abstract`,`paper`.`screening_status` AS `screening_status`,`paper`.`classification_status` AS `classification_status`,`paper`.`paper_excluded` AS `paper_excluded`,`paper`.`operation_code` AS `operation_code`,`paper`.`paper_active` AS `paper_active` from `paper` where ((not(`paper`.`id` in (select distinct `p`.`id` AS `id` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`c`.`class_active` = 1))))) and (`paper`.`paper_active` = 1) and (`paper`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_processed`
--
DROP TABLE IF EXISTS `view_paper_processed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_processed` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`doi` AS `doi`,`p`.`venueId` AS `venueId`,`p`.`bibtex` AS `bibtex`,`p`.`preview` AS `preview`,`p`.`abstract` AS `abstract`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`operation_code` AS `operation_code`,`p`.`paper_active` AS `paper_active` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0) and (`c`.`class_active` = 1));
--
-- Database: `relis_general_mt_bm_d`
--
CREATE DATABASE `relis_general_mt_bm_d` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `relis_general_mt_bm_d`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `add_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignation`(_assigned_id INT , _assigned_paper_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205) , _assigned_by INT)
BEGIN
START TRANSACTION;
INSERT INTO assigned (assigned_paper_id , assigned_user_id , assigned_note , assigned_by) VALUES (_assigned_paper_id , _assigned_user_id , _assigned_note , _assigned_by);
SELECT assigned_id AS id_value FROM assigned WHERE assigned_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_assignment_screen`(_assignment_id INT , _paper_id INT , _user_id INT , _note  VARCHAR(205) , _assignment_type INT , _assignment_mode  VARCHAR(35) , _assigned_by INT , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO assignment_screen (paper_id , user_id , note , assignment_type , assignment_mode , assigned_by , screening_done) VALUES (_paper_id , _user_id , _note , _assignment_type , _assignment_mode , _assigned_by , _screening_done);
SELECT assignment_id AS id_value FROM assignment_screen WHERE assignment_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_author`(_author_id INT , _author_name  VARCHAR(35) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
INSERT INTO author (author_name , author_desc , author_picture) VALUES (_author_name , _author_desc , _author_picture);
SELECT author_id AS id_value FROM author WHERE author_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_classification`(_class_id INT , _class_paper_id INT , _transformation_name  VARCHAR(105) , _text_multi  VARCHAR(105) , _intent_1 INT)
BEGIN
START TRANSACTION;
INSERT INTO classification (class_paper_id , transformation_name , text_multi , intent_1) VALUES (_class_paper_id , _transformation_name , _text_multi , _intent_1);
SELECT class_id AS id_value FROM classification WHERE class_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_config`(_config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
INSERT INTO config (config_type , editor_url , editor_generated_path , csv_field_separator , csv_field_separator_export , screening_screening_conflict_resolution , screening_conflict_type , import_papers_on , assign_papers_on , screening_on , screening_result_on , screening_validation_on , classification_on) VALUES (_config_type , _editor_url , _editor_generated_path , _csv_field_separator , _csv_field_separator_export , _screening_screening_conflict_resolution , _screening_conflict_type , _import_papers_on , _assign_papers_on , _screening_on , _screening_result_on , _screening_validation_on , _classification_on);
SELECT config_id AS id_value FROM config WHERE config_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_domain`(_domain_id INT , _parent_field_id INT , _domain INT)
BEGIN
START TRANSACTION;
INSERT INTO domain (parent_field_id , domain) VALUES (_parent_field_id , _domain);
SELECT domain_id AS id_value FROM domain WHERE domain_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_exclusion`(_exclusion_id INT , _exclusion_paper_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205) , _exclusion_by INT)
BEGIN
START TRANSACTION;
INSERT INTO exclusion (exclusion_paper_id , exclusion_criteria , exclusion_note , exclusion_by) VALUES (_exclusion_paper_id , _exclusion_criteria , _exclusion_note , _exclusion_by);
SELECT exclusion_id AS id_value FROM exclusion WHERE exclusion_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_intent`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_intent`(_intent_id INT , _parent_field_id INT , _intent INT , _name_used  VARCHAR(105) , _comment  VARCHAR(505))
BEGIN
START TRANSACTION;
INSERT INTO intent (parent_field_id , intent , name_used , comment) VALUES (_parent_field_id , _intent , _name_used , _comment);
SELECT intent_id AS id_value FROM intent WHERE intent_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_intent_relation`(_intent_relation_id INT , _parent_field_id INT , _intent_relation INT , _intent1 INT , _intent2 INT , _comment  VARCHAR(505))
BEGIN
START TRANSACTION;
INSERT INTO intent_relation (parent_field_id , intent_relation , intent1 , intent2 , comment) VALUES (_parent_field_id , _intent_relation , _intent1 , _intent2 , _comment);
SELECT intent_relation_id AS id_value FROM intent_relation WHERE intent_relation_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_papers`(_id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _screening_status  VARCHAR(25) , _classification_status  VARCHAR(25) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
INSERT INTO paper (bibtexKey , title , preview , bibtex , abstract , doi , screening_status , classification_status , venueId , paper_excluded) VALUES (_bibtexKey , _title , _preview , _bibtex , _abstract , _doi , _screening_status , _classification_status , _venueId , _paper_excluded);
SELECT id AS id_value FROM paper WHERE id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_paper_author`(_paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
INSERT INTO paperauthor (paperId , authorId) VALUES (_paperId , _authorId);
SELECT paperauthor_id AS id_value FROM paperauthor WHERE paperauthor_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_domain`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_domain (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_domain WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_exclusioncrieria`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO zref_exclusioncrieria (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM zref_exclusioncrieria WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_goal`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_goal`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_goal (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_goal WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_intents`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_intents`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_intents (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_intents WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_intent_relation`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_intent_relation (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_intent_relation WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_language`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_language (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_language WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_ref_types_of_goals`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_ref_types_of_goals`(_ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
INSERT INTO ref_types_of_goals (ref_value , ref_desc) VALUES (_ref_value , _ref_desc);
SELECT ref_id AS id_value FROM ref_types_of_goals WHERE ref_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_Scope`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_Scope`(_Scope_id INT , _parent_field_id INT , _Scope  VARCHAR(15))
BEGIN
START TRANSACTION;
INSERT INTO Scope (parent_field_id , Scope) VALUES (_parent_field_id , _Scope);
SELECT Scope_id AS id_value FROM Scope WHERE Scope_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_screening`(_screening_id INT , _paper_id INT , _user_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205) , _assignment_id INT)
BEGIN
START TRANSACTION;
INSERT INTO screening (paper_id , user_id , decision , exclusion_criteria , note , assignment_id) VALUES (_paper_id , _user_id , _decision , _exclusion_criteria , _note , _assignment_id);
SELECT screening_id AS id_value FROM screening WHERE screening_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_source_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_source_language`(_source_language_id INT , _parent_field_id INT , _source_language INT)
BEGIN
START TRANSACTION;
INSERT INTO source_language (parent_field_id , source_language) VALUES (_parent_field_id , _source_language);
SELECT source_language_id AS id_value FROM source_language WHERE source_language_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_str_mng`(_str_id INT , _str_label  VARCHAR(405) , _str_text  VARCHAR(805) , _str_lang  VARCHAR(8) , _str_category  VARCHAR(23))
BEGIN
START TRANSACTION;
INSERT INTO str_management (str_label , str_text , str_lang , str_category) VALUES (_str_label , _str_text , _str_lang , _str_category);
SELECT str_id AS id_value FROM str_management WHERE str_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_text_multi`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_text_multi`(_text_multi_id INT , _parent_field_id INT , _text_multi  VARCHAR(105))
BEGIN
START TRANSACTION;
INSERT INTO text_multi (parent_field_id , text_multi) VALUES (_parent_field_id , _text_multi);
SELECT text_multi_id AS id_value FROM text_multi WHERE text_multi_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_transformation_language`(_transformation_language_id INT , _parent_field_id INT , _transformation_language INT)
BEGIN
START TRANSACTION;
INSERT INTO transformation_language (parent_field_id , transformation_language) VALUES (_parent_field_id , _transformation_language);
SELECT transformation_language_id AS id_value FROM transformation_language WHERE transformation_language_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_users`(_user_id INT , _user_name  VARCHAR(55) , _user_username  VARCHAR(25) , _user_mail  VARCHAR(55) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  LONGBLOB  , _user_default_lang  VARCHAR(16))
BEGIN
START TRANSACTION;
INSERT INTO users (user_name , user_username , user_mail , user_usergroup , user_password , user_picture , user_default_lang) VALUES (_user_name , _user_username , _user_mail , _user_usergroup , _user_password , _user_picture , _user_default_lang);
SELECT user_id AS id_value FROM users WHERE user_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `add_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_venue`(_venue_id INT , _venue_abbreviation  VARCHAR(15) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
INSERT INTO venue (venue_abbreviation , venue_fullName , venue_year , venue_volume , venue_totalNumPapers) VALUES (_venue_abbreviation , _venue_fullName , _venue_year , _venue_volume , _venue_totalNumPapers);
SELECT venue_id AS id_value FROM venue WHERE venue_id = LAST_INSERT_ID();
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_list`(IN  source  VARCHAR(200), IN  condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select count(*) as nombre from  ',source ,'   WHERE 1=1  ', condition_stat );
PREPARE stmt FROM @query;
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;
END$$

DROP PROCEDURE IF EXISTS `count_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM paper WHERE paper_active=1   AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_assigned`(IN  _user_id  INT,IN _search VARCHAR(100))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
SELECT count(*) as nbr FROM view_paper_assigned WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `count_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_class`(IN _search VARCHAR(100) ,IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	SELECT count(*) as nbr FROM paper WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_'  )   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
	COMMIT;
	END$$

DROP PROCEDURE IF EXISTS `count_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_pending`(IN _search VARCHAR(100))
BEGIN
		START TRANSACTION;
		 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
		SELECT count(*) as nbr FROM view_paper_pending WHERE paper_active=1 AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
		COMMIT;
		END$$

DROP PROCEDURE IF EXISTS `count_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_papers_processed`(IN _search VARCHAR(100))
BEGIN
				START TRANSACTION;
				 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
				SELECT count(*) as nbr FROM view_paper_processed WHERE paper_active=1  AND classification_status <> 'Waiting'   AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  ) ;
				COMMIT;
				END$$

DROP PROCEDURE IF EXISTS `exclude_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `exclude_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 1  WHERE id = _paper_id ;
  COMMIT;
 END$$

DROP PROCEDURE IF EXISTS `get_assignations`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_assignations`(_paperId INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned WHERE (assigned_paper_id = _paperId AND assigned_active=1);
COMMIT; 
END$$

DROP PROCEDURE IF EXISTS `get_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_author`(IN  _start_by  INT, IN  _range  INT, IN  _search  VARCHAR(100))
BEGIN
START TRANSACTION;
SET @search_author_name := CONCAT('%',_search,'%') ;  SET @search_author_desc := CONCAT('%',_search,'%') ; 
SELECT  author_id , author_name , author_desc FROM author
WHERE author_active=1  AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC LIMIT _start_by , _range;	
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classifications`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classifications`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * 
FROM classification 
WHERE (class_paper_id = _paperId AND class_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_paper`( _classificationId  INT)
BEGIN
START TRANSACTION;
SELECT class_paper_id
FROM classification 
WHERE (class_id = _classificationId);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_classification_scheme`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_classification_scheme`()
BEGIN
START TRANSACTION;
SELECT * FROM classification_scheme 
WHERE (scheme_active=1) ORDER BY field_order ASC;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignation`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assigned
WHERE assigned_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_assignment_screen`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM assignment_screen
WHERE assignment_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_author`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM author
WHERE author_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_classification`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM classification
WHERE class_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_config`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM config
WHERE config_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_domain`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM domain
WHERE domain_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_exclusion`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion
WHERE exclusion_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_intent`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_intent`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM intent
WHERE intent_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_intent_relation`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM intent_relation
WHERE intent_relation_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_papers`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paper
WHERE id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_paper_author`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM paperauthor
WHERE paperauthor_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_domain`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_domain
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_exclusioncrieria`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM zref_exclusioncrieria
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_goal`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_goal`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_goal
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_intents`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_intents`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_intents
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_intent_relation`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_intent_relation
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_language`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_language
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_ref_types_of_goals`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_ref_types_of_goals`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM ref_types_of_goals
WHERE ref_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_Scope`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_Scope`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM Scope
WHERE Scope_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_screening`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM screening
WHERE screening_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_source_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_source_language`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM source_language
WHERE source_language_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_str_mng`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM str_management
WHERE str_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_text_multi`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_text_multi`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM text_multi
WHERE text_multi_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_transformation_language`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM transformation_language
WHERE transformation_language_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_users`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM users
WHERE user_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_detail_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_detail_venue`(IN _row_id INT)
BEGIN
START TRANSACTION;
SELECT * FROM venue
WHERE venue_id= _row_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list`(IN  _source  VARCHAR(100), IN  _fields  VARCHAR(1000), IN  _condition_stat  VARCHAR(1000))
BEGIN
SET @query = CONCAT('Select ',_fields,' from  ',_source ,'   WHERE 1=1   ', _condition_stat );
 PREPARE stmt FROM @query;
 EXECUTE stmt;
 DEALLOCATE PREPARE stmt; 
END$$

DROP PROCEDURE IF EXISTS `get_list_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignation`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC ;
ELSE
SELECT * FROM assigned
WHERE assigned_active=1   ORDER BY assigned_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_assignment_screen`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC ;
ELSE
SELECT * FROM assignment_screen
WHERE assignment_active=1   ORDER BY assignment_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_author_name := CONCAT('%',TRIM(_search),'%') ;  SET @search_author_desc := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC ;
ELSE
SELECT * FROM author
WHERE author_active=1   AND (  (author_name LIKE  @search_author_name)  OR (author_desc LIKE  @search_author_desc)  )  ORDER BY  author_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_classification`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC ;
ELSE
SELECT * FROM classification
WHERE class_active=1   ORDER BY class_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_config`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC ;
ELSE
SELECT * FROM config
WHERE config_active=1   ORDER BY config_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_domain`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM domain
WHERE domain_active=1   ORDER BY domain_id ASC ;
ELSE
SELECT * FROM domain
WHERE domain_active=1   ORDER BY domain_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_exclusion`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC ;
ELSE
SELECT * FROM exclusion
WHERE exclusion_active=1   ORDER BY exclusion_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_intent`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_intent`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM intent
WHERE intent_active=1   ORDER BY intent_id ASC ;
ELSE
SELECT * FROM intent
WHERE intent_active=1   ORDER BY intent_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_intent_relation`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM intent_relation
WHERE intent_relation_active=1   ORDER BY intent_relation_id ASC;
ELSE
SELECT * FROM intent_relation
WHERE intent_relation_active=1   ORDER BY intent_relation_id ASC LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500),IN _excluded VARCHAR(2))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM paper
WHERE paper_active=1  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_assigned`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_assigned`(IN  _user_id  INT,IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND (assigned_user_id = _user_id)    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_assigned
WHERE paper_active=1  AND classification_status <> 'Waiting' AND  (assigned_user_id = _user_id)      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_class`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_class`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500),IN _excluded VARCHAR(2))
BEGIN
	START TRANSACTION;
	 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
	IF _range < 1 THEN
	SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting'  AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM paper
WHERE paper_active=1 AND classification_status <> 'Waiting' AND (paper_excluded = _excluded OR _excluded ='_' )    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_pending`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_pending`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_pending
WHERE paper_active=1  AND classification_status <> 'Waiting'    AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_pending
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_papers_processed`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_papers_processed`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_bibtexKey := CONCAT('%',TRIM(_search),'%') ;  SET @search_title := CONCAT('%',TRIM(_search),'%') ;  SET @search_preview := CONCAT('%',TRIM(_search),'%') ;  SET @search_abstract := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'     AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC ;
ELSE
SELECT * FROM view_paper_processed
WHERE paper_active=1 AND classification_status <> 'Waiting'      AND (  (bibtexKey LIKE  @search_bibtexKey)  OR (title LIKE  @search_title)  OR (preview LIKE  @search_preview)  OR (abstract LIKE  @search_abstract)  )  ORDER BY  id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_paper_author`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC ;
ELSE
SELECT * FROM paperauthor
WHERE paperauthor_active=1   ORDER BY paperauthor_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_domain`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_domain
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_domain
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_exclusioncrieria`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM zref_exclusioncrieria
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_goal`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_goal`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_goal
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_goal
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_intents`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_intents`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_intents
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_intents
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_intent_relation`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_intent_relation
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_intent_relation
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_language`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_language
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_ref_types_of_goals`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_ref_types_of_goals`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_ref_value := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM ref_types_of_goals
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC ;
ELSE
SELECT * FROM ref_types_of_goals
WHERE ref_active=1   AND (  (ref_value LIKE  @search_ref_value)  )  ORDER BY ref_value ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_Scope`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_Scope`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM Scope
WHERE Scope_active=1   ORDER BY Scope_id ASC;
ELSE
SELECT * FROM Scope
WHERE Scope_active=1   ORDER BY Scope_id ASC LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_screening`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC ;
ELSE
SELECT * FROM screening
WHERE screening_active=1   ORDER BY screening_id DESC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_source_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_source_language`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM source_language
WHERE source_language_active=1   ORDER BY source_language_id ASC ;
ELSE
SELECT * FROM source_language
WHERE source_language_active=1   ORDER BY source_language_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_str_mng`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500) ,IN _lang VARCHAR(3))
BEGIN
START TRANSACTION;
 SET @search_str_text := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC ;
ELSE
SELECT * FROM str_management
WHERE str_active=1  AND str_lang = _lang   AND (  (str_text LIKE  @search_str_text)  )  ORDER BY str_text ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_text_multi`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_text_multi`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM text_multi
WHERE text_multi_active=1   ORDER BY text_multi_id ASC ;
ELSE
SELECT * FROM text_multi
WHERE text_multi_active=1   ORDER BY text_multi_id ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_transformation_language`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;

IF _range < 1 THEN
SELECT * FROM transformation_language
WHERE transformation_language_active=1   ORDER BY transformation_language_id ASC;
ELSE
SELECT * FROM transformation_language
WHERE transformation_language_active=1   ORDER BY transformation_language_id ASC LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_users`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_user_name := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM users
WHERE user_active=1   AND (  (user_name LIKE  @search_user_name)  )  ORDER BY user_name ASC ;
ELSE
SELECT * FROM users
WHERE user_active=1   AND (  (user_name LIKE  @search_user_name)  )  ORDER BY user_name ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_list_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_list_venue`(IN _start_by INT,IN _range INT, IN _search VARCHAR(500))
BEGIN
START TRANSACTION;
 SET @search_venue_abbreviation := CONCAT('%',TRIM(_search),'%') ;  SET @search_venue_fullName := CONCAT('%',TRIM(_search),'%') ; 
IF _range < 1 THEN
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC ;
ELSE
SELECT * FROM venue
WHERE venue_active=1   AND (  (venue_abbreviation LIKE  @search_venue_abbreviation)  OR (venue_fullName LIKE  @search_venue_fullName)  )  ORDER BY venue_abbreviation ASC  LIMIT _start_by , _range;
END IF;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_paper_exclusion_info`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_paper_exclusion_info`( _paperId  INT)
BEGIN
START TRANSACTION;
SELECT * FROM exclusion WHERE (exclusion_paper_id = _paperId AND exclusion_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_table`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_table`( _configId  VARCHAR(100))
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE (reftab_label = _configId AND reftab_active=1);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_tables_list`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_tables_list`()
BEGIN
START TRANSACTION;
SELECT * FROM ref_tables WHERE reftab_active=1 order by  reftab_desc;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `get_reference_value`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_reference_value`(IN  _table  VARCHAR(100), IN  _id  VARCHAR(100), IN  _field  VARCHAR(100), IN  _table_id  VARCHAR(100))
BEGIN
SET @query = CONCAT('Select ',_field,' from  ',_table ,'   WHERE ', _table_id, ' = ', _id );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_result_count`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_result_count`(IN  _fields  VARCHAR(100))
BEGIN
SET @query = CONCAT('SELECT ',_fields,' AS field,count(*) AS nombre from classification,paper WHERE class_paper_id=id  AND paper_excluded = 0	 AND  paper_active=1 AND class_active=1 group by  ',_fields );
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_row`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_row`(IN  source  VARCHAR(100), IN  source_id  VARCHAR(100), IN  id_value  VARCHAR(100))
BEGIN
SET @query = CONCAT("Select * from  ",source ,"  WHERE ", source_id ," = '",id_value,"'");
PREPARE stmt FROM @query;
EXECUTE stmt;  
DEALLOCATE PREPARE stmt;  
END$$

DROP PROCEDURE IF EXISTS `get_string`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_string`(IN  _text  VARCHAR(500), IN  _category  VARCHAR(30), IN  _lang  VARCHAR(3))
BEGIN
START TRANSACTION;
SELECT str_id, str_text FROM str_management WHERE str_active=1 AND str_label = _text AND str_category = _category AND str_lang = _lang ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `include_paper`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `include_paper`(IN  _paper_id  INT)
BEGIN
START TRANSACTION;
UPDATE paper SET  paper_excluded = 0  WHERE id = _paper_id ;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignation`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assigned SET assigned_active=0
WHERE assigned_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_assignment_screen`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE assignment_screen SET assignment_active=0
WHERE assignment_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE author SET author_active=0
WHERE author_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_classification`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE classification SET class_active=0
WHERE class_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_config`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE config SET config_active=0
WHERE config_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_domain`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE domain SET domain_active=0
WHERE domain_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_exclusion`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE exclusion SET exclusion_active=0
WHERE exclusion_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_intent`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_intent`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE intent SET intent_active=0
WHERE intent_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_intent_relation`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE intent_relation SET intent_relation_active=0
WHERE intent_relation_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_papers`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paper SET paper_active=0
WHERE id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_paper_author`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE paperauthor SET paperauthor_active=0
WHERE paperauthor_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_domain`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_domain SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_exclusioncrieria`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE zref_exclusioncrieria SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_goal`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_goal`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_goal SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_intents`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_intents`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_intents SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_intent_relation`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_intent_relation SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_language`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_language SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_ref_types_of_goals`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_ref_types_of_goals`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE ref_types_of_goals SET ref_active=0
WHERE ref_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_Scope`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_Scope`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE Scope SET Scope_active=0
WHERE Scope_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_screening`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE screening SET screening_active=0
WHERE screening_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_source_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_source_language`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE source_language SET source_language_active=0
WHERE source_language_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_str_mng`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE str_management SET str_active=0
WHERE str_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_text_multi`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_text_multi`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE text_multi SET text_multi_active=0
WHERE text_multi_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_transformation_language`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE transformation_language SET transformation_language_active=0
WHERE transformation_language_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_users`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE users SET user_active=0
WHERE user_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `remove_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `remove_venue`(IN _element_id INT)
BEGIN
START TRANSACTION;
UPDATE venue SET venue_active=0
WHERE venue_id= _element_id;
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignation`(_element_id INT , _assigned_id INT , _assigned_user_id INT , _assigned_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  assigned SET assigned_id = _assigned_id , assigned_user_id = _assigned_user_id , assigned_note = _assigned_note
WHERE (assigned_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_assignment_screen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_assignment_screen`(_element_id INT , _assignment_id INT , _user_id INT , _note  VARCHAR(205) , _screening_done  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  assignment_screen SET assignment_id = _assignment_id , user_id = _user_id , note = _note , screening_done = _screening_done
WHERE (assignment_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_author`(_element_id INT , _author_id INT , _author_name  VARCHAR(35) , _author_desc  VARCHAR(205) , _author_picture  LONGBLOB )
BEGIN
START TRANSACTION;
UPDATE  author SET author_id = _author_id , author_name = _author_name , author_desc = _author_desc , author_picture = _author_picture
WHERE (author_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_classification`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_classification`(_element_id INT , _class_id INT , _class_paper_id INT , _transformation_name  VARCHAR(105) , _text_multi  VARCHAR(105) , _intent_1 INT)
BEGIN
START TRANSACTION;
UPDATE  classification SET class_id = _class_id , class_paper_id = _class_paper_id , transformation_name = _transformation_name , text_multi = _text_multi , intent_1 = _intent_1
WHERE (class_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_config`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_config`(_element_id INT , _config_id INT , _config_type  VARCHAR(105) , _editor_url  VARCHAR(105) , _editor_generated_path  VARCHAR(105) , _csv_field_separator  VARCHAR(7) , _csv_field_separator_export  VARCHAR(7) , _screening_screening_conflict_resolution  VARCHAR(55) , _screening_conflict_type  VARCHAR(55) , _import_papers_on  VARCHAR(6) , _assign_papers_on  VARCHAR(6) , _screening_on  VARCHAR(6) , _screening_result_on  VARCHAR(6) , _screening_validation_on  VARCHAR(6) , _classification_on  VARCHAR(6))
BEGIN
START TRANSACTION;
UPDATE  config SET config_id = _config_id , config_type = _config_type , editor_url = _editor_url , editor_generated_path = _editor_generated_path , csv_field_separator = _csv_field_separator , csv_field_separator_export = _csv_field_separator_export , screening_screening_conflict_resolution = _screening_screening_conflict_resolution , screening_conflict_type = _screening_conflict_type , import_papers_on = _import_papers_on , assign_papers_on = _assign_papers_on , screening_on = _screening_on , screening_result_on = _screening_result_on , screening_validation_on = _screening_validation_on , classification_on = _classification_on
WHERE (config_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_domain`(_element_id INT , _domain_id INT , _parent_field_id INT , _domain INT)
BEGIN
START TRANSACTION;
UPDATE  domain SET domain_id = _domain_id , parent_field_id = _parent_field_id , domain = _domain
WHERE (domain_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_exclusion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_exclusion`(_element_id INT , _exclusion_id INT , _exclusion_criteria INT , _exclusion_note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  exclusion SET exclusion_id = _exclusion_id , exclusion_criteria = _exclusion_criteria , exclusion_note = _exclusion_note
WHERE (exclusion_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_intent`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_intent`(_element_id INT , _intent_id INT , _parent_field_id INT , _intent INT , _name_used  VARCHAR(105) , _comment  VARCHAR(505))
BEGIN
START TRANSACTION;
UPDATE  intent SET intent_id = _intent_id , parent_field_id = _parent_field_id , intent = _intent , name_used = _name_used , comment = _comment
WHERE (intent_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_intent_relation`(_element_id INT , _intent_relation_id INT , _parent_field_id INT , _intent_relation INT , _intent1 INT , _intent2 INT , _comment  VARCHAR(505))
BEGIN
START TRANSACTION;
UPDATE  intent_relation SET intent_relation_id = _intent_relation_id , parent_field_id = _parent_field_id , intent_relation = _intent_relation , intent1 = _intent1 , intent2 = _intent2 , comment = _comment
WHERE (intent_relation_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_papers`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_papers`(_element_id INT , _id INT , _bibtexKey  VARCHAR(35) , _title  VARCHAR(205) , _preview  VARCHAR(205) , _bibtex  VARCHAR(205) , _abstract  VARCHAR(1005) , _doi  VARCHAR(205) , _venueId INT , _paper_excluded  VARCHAR(7))
BEGIN
START TRANSACTION;
UPDATE  paper SET id = _id , bibtexKey = _bibtexKey , title = _title , preview = _preview , bibtex = _bibtex , abstract = _abstract , doi = _doi , venueId = _venueId , paper_excluded = _paper_excluded
WHERE (id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_paper_author`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_paper_author`(_element_id INT , _paperauthor_id INT , _paperId INT , _authorId INT)
BEGIN
START TRANSACTION;
UPDATE  paperauthor SET paperauthor_id = _paperauthor_id , paperId = _paperId , authorId = _authorId
WHERE (paperauthor_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_domain`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_domain`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_domain SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_exclusioncrieria`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_exclusioncrieria`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  zref_exclusioncrieria SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_goal`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_goal`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_goal SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_intents`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_intents`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_intents SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_intent_relation`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_intent_relation`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_intent_relation SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_language`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_language SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_ref_types_of_goals`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_ref_types_of_goals`(_element_id INT , _ref_id INT , _ref_value  VARCHAR(105) , _ref_desc  VARCHAR(245))
BEGIN
START TRANSACTION;
UPDATE  ref_types_of_goals SET ref_id = _ref_id , ref_value = _ref_value , ref_desc = _ref_desc
WHERE (ref_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_Scope`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_Scope`(_element_id INT , _Scope_id INT , _parent_field_id INT , _Scope  VARCHAR(15))
BEGIN
START TRANSACTION;
UPDATE  Scope SET Scope_id = _Scope_id , parent_field_id = _parent_field_id , Scope = _Scope
WHERE (Scope_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_screening`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_screening`(_element_id INT , _screening_id INT , _decision  VARCHAR(35) , _exclusion_criteria INT , _note  VARCHAR(205))
BEGIN
START TRANSACTION;
UPDATE  screening SET screening_id = _screening_id , decision = _decision , exclusion_criteria = _exclusion_criteria , note = _note
WHERE (screening_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_source_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_source_language`(_element_id INT , _source_language_id INT , _parent_field_id INT , _source_language INT)
BEGIN
START TRANSACTION;
UPDATE  source_language SET source_language_id = _source_language_id , parent_field_id = _parent_field_id , source_language = _source_language
WHERE (source_language_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_str_mng`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_str_mng`(_element_id INT , _str_id INT , _str_text  VARCHAR(805))
BEGIN
START TRANSACTION;
UPDATE  str_management SET str_id = _str_id , str_text = _str_text
WHERE (str_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_text_multi`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_text_multi`(_element_id INT , _text_multi_id INT , _parent_field_id INT , _text_multi  VARCHAR(105))
BEGIN
START TRANSACTION;
UPDATE  text_multi SET text_multi_id = _text_multi_id , parent_field_id = _parent_field_id , text_multi = _text_multi
WHERE (text_multi_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_transformation_language`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_transformation_language`(_element_id INT , _transformation_language_id INT , _parent_field_id INT , _transformation_language INT)
BEGIN
START TRANSACTION;
UPDATE  transformation_language SET transformation_language_id = _transformation_language_id , parent_field_id = _parent_field_id , transformation_language = _transformation_language
WHERE (transformation_language_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_users`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_users`(_element_id INT , _user_id INT , _user_name  VARCHAR(55) , _user_mail  VARCHAR(55) , _user_usergroup INT , _user_password  VARCHAR(40) , _user_picture  LONGBLOB  , _user_default_lang  VARCHAR(16))
BEGIN
START TRANSACTION;
UPDATE  users SET user_id = _user_id , user_name = _user_name , user_mail = _user_mail , user_usergroup = _user_usergroup , user_password = _user_password , user_picture = _user_picture , user_default_lang = _user_default_lang
WHERE (user_id = _element_id);
COMMIT;
END$$

DROP PROCEDURE IF EXISTS `update_venue`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_venue`(_element_id INT , _venue_id INT , _venue_abbreviation  VARCHAR(15) , _venue_fullName  VARCHAR(205) , _venue_year INT , _venue_volume INT , _venue_totalNumPapers INT)
BEGIN
START TRANSACTION;
UPDATE  venue SET venue_id = _venue_id , venue_abbreviation = _venue_abbreviation , venue_fullName = _venue_fullName , venue_year = _venue_year , venue_volume = _venue_volume , venue_totalNumPapers = _venue_totalNumPapers
WHERE (venue_id = _element_id);
COMMIT;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assigned`
--

DROP TABLE IF EXISTS `assigned`;
CREATE TABLE IF NOT EXISTS `assigned` (
  `assigned_id` int(11) NOT NULL AUTO_INCREMENT,
  `assigned_paper_id` int(11) NOT NULL,
  `assigned_user_id` int(11) NOT NULL,
  `assigned_note` text,
  `assigned_by` int(11) NOT NULL,
  `assigned_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `assigned_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assigned_id`),
  KEY `assigned_paper_id_idx` (`assigned_paper_id`),
  KEY `assigned_user_id_idx` (`assigned_user_id`),
  KEY `assigned_by_idx` (`assigned_by`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `assignment_screen`
--

DROP TABLE IF EXISTS `assignment_screen`;
CREATE TABLE IF NOT EXISTS `assignment_screen` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `assignment_type` enum('Normal','Veto','Info') NOT NULL DEFAULT 'Normal',
  `assignment_mode` enum('auto','manualy_bulk','manualy_single') NOT NULL DEFAULT 'auto',
  `assigned_by` int(11) DEFAULT NULL,
  `screening_done` int(2) NOT NULL DEFAULT '0',
  `assignment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `assignment_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`assignment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;

--
-- Dumping data for table `assignment_screen`
--

INSERT INTO `assignment_screen` (`assignment_id`, `paper_id`, `user_id`, `note`, `assignment_type`, `assignment_mode`, `assigned_by`, `screening_done`, `assignment_time`, `assignment_active`) VALUES
(1, 1, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(2, 1, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(3, 2, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(4, 2, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(5, 3, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(6, 3, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:23', 1),
(7, 4, 4, '', 'Normal', 'auto', 1, 0, '2017-03-09 16:36:26', 1),
(8, 4, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 19:21:17', 1),
(9, 5, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:54:34', 1),
(10, 5, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(11, 6, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(12, 6, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(13, 7, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(14, 7, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(15, 8, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(16, 8, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:28', 1),
(17, 9, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:30', 1),
(18, 9, 1, '', 'Normal', 'auto', 1, 1, '2017-03-02 21:21:14', 1),
(19, 10, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:54:40', 1),
(20, 10, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(21, 11, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(22, 11, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(23, 12, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(24, 12, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(25, 13, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(26, 13, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:33', 1),
(27, 14, 4, '', 'Normal', 'auto', 1, 1, '2017-03-02 21:24:50', 1),
(28, 14, 1, '', 'Normal', 'auto', 1, 1, '2017-03-02 21:20:16', 1),
(29, 15, 1, '', 'Normal', 'auto', 1, 1, '2017-03-02 21:13:37', 1),
(30, 15, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(31, 16, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(32, 16, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(33, 17, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(34, 17, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(35, 18, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(36, 18, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:40', 1),
(37, 19, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:43', 1),
(38, 19, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:54:45', 1),
(39, 20, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:54:47', 1),
(40, 20, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(41, 21, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(42, 21, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(43, 22, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(44, 22, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(45, 23, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(46, 23, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:46', 1),
(47, 24, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:50', 1),
(48, 24, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:54:49', 1),
(49, 25, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:54:50', 1),
(50, 25, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(51, 26, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(52, 26, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(53, 27, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(54, 27, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:41', 1),
(55, 28, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(56, 28, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:53', 1),
(57, 29, 4, '', 'Normal', 'auto', 1, 1, '2017-03-02 21:24:52', 1),
(58, 29, 1, '', 'Normal', 'auto', 1, 1, '2017-03-09 16:58:13', 1),
(59, 30, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:00', 1),
(60, 30, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(61, 31, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(62, 31, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(63, 32, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(64, 32, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(65, 33, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(66, 33, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:56:58', 1),
(67, 34, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:00', 1),
(68, 34, 1, '', 'Normal', 'auto', 1, 0, '2017-03-09 19:27:44', 1),
(69, 35, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:07', 1),
(70, 35, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(71, 36, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(72, 36, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(73, 37, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(74, 37, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(75, 38, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(76, 38, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:03', 1),
(77, 39, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:07', 1),
(78, 39, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:10', 1),
(79, 40, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:14', 1),
(80, 40, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(81, 41, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(82, 41, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(83, 42, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(84, 42, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(85, 43, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(86, 43, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:13', 1),
(87, 44, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:16', 1),
(88, 44, 1, '', 'Normal', 'auto', 1, 1, '2017-03-02 21:20:20', 1),
(89, 45, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:19', 1),
(90, 45, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(91, 46, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(92, 46, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(93, 47, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(94, 47, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(95, 48, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(96, 48, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:19', 1),
(97, 49, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:22', 1),
(98, 49, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:21', 1),
(99, 50, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:23', 1),
(100, 50, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(101, 51, 2, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(102, 51, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(103, 52, 3, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(104, 52, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(105, 53, 5, '', 'Normal', 'auto', 1, 0, '2017-02-28 23:30:42', 1),
(106, 53, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:25', 1),
(107, 54, 4, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:57:31', 1),
(108, 54, 1, '', 'Normal', 'auto', 1, 1, '2017-03-01 00:55:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
CREATE TABLE IF NOT EXISTS `author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(200) NOT NULL,
  `author_desc` text,
  `author_picture` varchar(300) DEFAULT NULL,
  `author_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classification`
--

DROP TABLE IF EXISTS `classification`;
CREATE TABLE IF NOT EXISTS `classification` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_paper_id` int(11) DEFAULT NULL,
  `transformation_name` varchar(100) DEFAULT NULL,
  `text_multi` varchar(100) DEFAULT NULL,
  `intent_1` int(11) DEFAULT NULL,
  `class_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `classification_scheme`
--

DROP TABLE IF EXISTS `classification_scheme`;
CREATE TABLE IF NOT EXISTS `classification_scheme` (
  `scheme_id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme_label` varchar(100) NOT NULL,
  `scheme_title` varchar(100) NOT NULL,
  `scheme_parent` varchar(100) NOT NULL DEFAULT 'main',
  `scheme_mandatory` int(1) NOT NULL DEFAULT '0',
  `scheme_category` varchar(30) NOT NULL,
  `scheme_type` varchar(30) DEFAULT NULL,
  `scheme_size` int(11) DEFAULT NULL,
  `scheme_source` varchar(1000) DEFAULT NULL,
  `scheme_source_main_field` varchar(100) DEFAULT NULL,
  `scheme_number_of_values` varchar(2) NOT NULL DEFAULT '1',
  `scheme_order` int(2) NOT NULL DEFAULT '1',
  `scheme_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`scheme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_type` varchar(100) NOT NULL DEFAULT 'default',
  `editor_url` varchar(100) NOT NULL,
  `editor_generated_path` varchar(100) DEFAULT NULL,
  `csv_field_separator` enum(';',',') NOT NULL DEFAULT ';',
  `csv_field_separator_export` enum(';',',') NOT NULL DEFAULT ',',
  `screening_screening_conflict_resolution` enum('Unanimity','Majority') NOT NULL DEFAULT 'Unanimity',
  `screening_conflict_type` enum('IncludeExclude','ExclusionCriteria') NOT NULL DEFAULT 'IncludeExclude',
  `import_papers_on` int(2) NOT NULL DEFAULT '1',
  `assign_papers_on` int(2) NOT NULL DEFAULT '1',
  `screening_on` int(2) NOT NULL DEFAULT '1',
  `screening_result_on` int(2) NOT NULL DEFAULT '1',
  `screening_validation_on` int(2) NOT NULL DEFAULT '1',
  `classification_on` int(2) NOT NULL DEFAULT '1',
  `config_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_id`, `config_type`, `editor_url`, `editor_generated_path`, `csv_field_separator`, `csv_field_separator_export`, `screening_screening_conflict_resolution`, `screening_conflict_type`, `import_papers_on`, `assign_papers_on`, `screening_on`, `screening_result_on`, `screening_validation_on`, `classification_on`, `config_active`) VALUES
(1, 'default', 'http://127.0.0.1:8080/relis/texteditor', 'C:/relis_workspace', ';', ',', 'Unanimity', 'IncludeExclude', 1, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `domain`
--

DROP TABLE IF EXISTS `domain`;
CREATE TABLE IF NOT EXISTS `domain` (
  `domain_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_field_id` int(11) DEFAULT NULL,
  `domain` int(11) DEFAULT NULL,
  `domain_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `exclusion`
--

DROP TABLE IF EXISTS `exclusion`;
CREATE TABLE IF NOT EXISTS `exclusion` (
  `exclusion_id` int(11) NOT NULL AUTO_INCREMENT,
  `exclusion_paper_id` int(11) NOT NULL,
  `exclusion_criteria` int(11) NOT NULL,
  `exclusion_note` text,
  `exclusion_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `exclusion_by` int(11) NOT NULL,
  `exclusion_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`exclusion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `installation_info`
--

DROP TABLE IF EXISTS `installation_info`;
CREATE TABLE IF NOT EXISTS `installation_info` (
  `install_id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_tables` text NOT NULL,
  `generated_tables` text NOT NULL,
  `foreign_key_constraint` text,
  `install_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`install_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `installation_info`
--

INSERT INTO `installation_info` (`install_id`, `reference_tables`, `generated_tables`, `foreign_key_constraint`, `install_active`) VALUES
(1, '["ref_domain","ref_types_of_goals","ref_language","ref_intents","ref_intent_relation"]', '["classification","transformation_language","source_language","Scope","intent","intent_relation"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE transformation_language DROP FOREIGN KEY  transformation_language_parent_field_id   , DROP FOREIGN KEY  transformation_language_transformation_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE Scope DROP FOREIGN KEY  Scope_parent_field_id   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;","ALTER TABLE intent_relation DROP FOREIGN KEY  intent_relation_parent_field_id   , DROP FOREIGN KEY  intent_relation_intent_relation   , DROP FOREIGN KEY  intent_relation_intent1   , DROP FOREIGN KEY  intent_relation_intent2   ;"]', 0),
(2, '["ref_domain","ref_types_of_goals","ref_language","ref_intents","ref_intent_relation"]', '["classification","transformation_language","source_language","Scope","intent","intent_relation"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE transformation_language DROP FOREIGN KEY  transformation_language_parent_field_id   , DROP FOREIGN KEY  transformation_language_transformation_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE Scope DROP FOREIGN KEY  Scope_parent_field_id   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;","ALTER TABLE intent_relation DROP FOREIGN KEY  intent_relation_parent_field_id   , DROP FOREIGN KEY  intent_relation_intent_relation   , DROP FOREIGN KEY  intent_relation_intent1   , DROP FOREIGN KEY  intent_relation_intent2   ;"]', 0),
(3, '["ref_domain","ref_goal","ref_language","ref_intents","ref_intent_relation"]', '["classification","source_language","intent","intent_relation"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_transformation_language   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;","ALTER TABLE intent_relation DROP FOREIGN KEY  intent_relation_parent_field_id   , DROP FOREIGN KEY  intent_relation_intent_relation   ;"]', 0),
(4, '["ref_domain","ref_goal","ref_language"]', '["classification","source_language"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_transformation_language   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;"]', 0),
(5, '["ref_domain","ref_goal","ref_language","ref_intents"]', '["classification","source_language","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_transformation_language   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(6, '["ref_domain","ref_types_of_goals","ref_language","ref_intents","ref_intent_relation"]', '["classification","transformation_language","source_language","Scope","intent","intent_relation"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE transformation_language DROP FOREIGN KEY  transformation_language_parent_field_id   , DROP FOREIGN KEY  transformation_language_transformation_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE Scope DROP FOREIGN KEY  Scope_parent_field_id   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;","ALTER TABLE intent_relation DROP FOREIGN KEY  intent_relation_parent_field_id   , DROP FOREIGN KEY  intent_relation_intent_relation   , DROP FOREIGN KEY  intent_relation_intent1   , DROP FOREIGN KEY  intent_relation_intent2   ;"]', 0),
(7, '["ref_domain","ref_goal","ref_language","ref_intents"]', '["classification","source_language","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_transformation_language   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(8, '["ref_domain","ref_types_of_goals","ref_language","ref_intents","ref_intent_relation"]', '["classification","transformation_language","source_language","Scope","intent","intent_relation"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE transformation_language DROP FOREIGN KEY  transformation_language_parent_field_id   , DROP FOREIGN KEY  transformation_language_transformation_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE Scope DROP FOREIGN KEY  Scope_parent_field_id   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;","ALTER TABLE intent_relation DROP FOREIGN KEY  intent_relation_parent_field_id   , DROP FOREIGN KEY  intent_relation_intent_relation   , DROP FOREIGN KEY  intent_relation_intent1   , DROP FOREIGN KEY  intent_relation_intent2   ;"]', 0),
(9, '["ref_domain","ref_types_of_goals","ref_language","ref_intents","ref_intent_relation"]', '["classification","transformation_language","source_language","Scope","intent","intent_relation"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE transformation_language DROP FOREIGN KEY  transformation_language_parent_field_id   , DROP FOREIGN KEY  transformation_language_transformation_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE Scope DROP FOREIGN KEY  Scope_parent_field_id   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;","ALTER TABLE intent_relation DROP FOREIGN KEY  intent_relation_parent_field_id   , DROP FOREIGN KEY  intent_relation_intent_relation   , DROP FOREIGN KEY  intent_relation_intent1   , DROP FOREIGN KEY  intent_relation_intent2   ;"]', 0),
(10, '["ref_domain"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   ;"]', 0),
(11, '["ref_domain","ref_intents"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(12, '["ref_domain","ref_goal","ref_language","ref_intents"]', '["classification","source_language","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_Goal   , DROP FOREIGN KEY  classification_transformation_language   , DROP FOREIGN KEY  classification_target_language   ;","ALTER TABLE source_language DROP FOREIGN KEY  source_language_parent_field_id   , DROP FOREIGN KEY  source_language_source_language   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(13, '["ref_domain"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   ;"]', 0),
(14, '["ref_domain","ref_intents"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(15, '["ref_domain","ref_intents"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(16, '["ref_domain","ref_intents"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(17, '["ref_domain","ref_intents"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(18, '["ref_domain","ref_intents"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(19, '["ref_domain","ref_intents"]', '["classification","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_domain   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(20, '["ref_domain","ref_intents"]', '["classification","domain","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE domain DROP FOREIGN KEY  domain_parent_field_id   , DROP FOREIGN KEY  domain_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(21, '["ref_domain","ref_intents"]', '["classification","domain","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE domain DROP FOREIGN KEY  domain_parent_field_id   , DROP FOREIGN KEY  domain_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(22, '["ref_domain","ref_intents"]', '["classification","text_multi","domain","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE text_multi DROP FOREIGN KEY  text_multi_parent_field_id   ;","ALTER TABLE domain DROP FOREIGN KEY  domain_parent_field_id   , DROP FOREIGN KEY  domain_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(23, '["ref_domain","ref_intents"]', '["classification","text_multi","domain","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE text_multi DROP FOREIGN KEY  text_multi_parent_field_id   ;","ALTER TABLE domain DROP FOREIGN KEY  domain_parent_field_id   , DROP FOREIGN KEY  domain_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 0),
(24, '["ref_domain","ref_intents"]', '["classification","domain","intent"]', '["ALTER TABLE classification DROP FOREIGN KEY  classification_class_paper_id   , DROP FOREIGN KEY  classification_intent_1   ;","ALTER TABLE domain DROP FOREIGN KEY  domain_parent_field_id   , DROP FOREIGN KEY  domain_domain   ;","ALTER TABLE intent DROP FOREIGN KEY  intent_parent_field_id   , DROP FOREIGN KEY  intent_intent   ;"]', 1);

-- --------------------------------------------------------

--
-- Table structure for table `intent`
--

DROP TABLE IF EXISTS `intent`;
CREATE TABLE IF NOT EXISTS `intent` (
  `intent_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_field_id` int(11) DEFAULT NULL,
  `intent` int(11) DEFAULT NULL,
  `name_used` varchar(100) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `intent_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`intent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `paper`
--

DROP TABLE IF EXISTS `paper`;
CREATE TABLE IF NOT EXISTS `paper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bibtexKey` varchar(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `preview` varchar(200) DEFAULT NULL,
  `bibtex` varchar(200) DEFAULT NULL,
  `abstract` varchar(1000) DEFAULT NULL,
  `doi` varchar(200) DEFAULT NULL,
  `screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded') NOT NULL DEFAULT 'Pending',
  `classification_status` enum('Waiting','To classify','Classified') NOT NULL DEFAULT 'Waiting',
  `venueId` int(11) DEFAULT NULL,
  `paper_excluded` int(2) NOT NULL DEFAULT '0',
  `paper_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `paper`
--

INSERT INTO `paper` (`id`, `bibtexKey`, `title`, `preview`, `bibtex`, `abstract`, `doi`, `screening_status`, `classification_status`, `venueId`, `paper_excluded`, `paper_active`) VALUES
(1, 'paper_1', '5W+1H pattern: A perspective of systematic mapping studies and a case study on cloud software testing', 'A common type of study used by researchers to map out the landscape of a research topic is known as mapping study. Such a study typically begins with an exploratory search on the possible ideas of the', '<b>Authors:</b><br/>Jia C., Cai Y., Yu Y.T., Tse T.H. <br/><b>Key words:</b><br/>5W+1H pattern, Cloud software testing, Systematic mapping study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84923328222&partnerID=40&md5=ab9586291eb660686744b0d525513668', 'Pending', 'Waiting', NULL, 0, 1),
(2, 'paper_2', 'A Mapping Study of Software Causal Factors for Improving Maintenance', 'Context: Software maintenance is important to keep existing software systems functional for organizations or users that depend on that software. Goal: We aim to identify the factors, i.e., software ch', '<b>Authors:</b><br/>Carroll C., Falessi D., Forney V., Frances A., Izurieta C., Seaman C. <br/><b>Key words:</b><br/>controlled experiments, defects, mapping study, Software maintenance, systematic li', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84961661951&partnerID=40&md5=692d940e823529be710d2f4f2ee0307f', 'Pending', 'Waiting', NULL, 0, 1),
(3, 'paper_3', 'A first systematic mapping study on combinatorial interaction testing for software product lines', 'Software Product Lines (SPLs) are families of related software systems distinguished by the set of features each one provides. Over the past decades SPLs have been the subject of extensive research an', '<b>Authors:</b><br/>Lopez-Herrejon R.E., Fischer S., Ramler R., Egyed A. <br/><b>Key words:</b><br/>', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84934343294&partnerID=40&md5=ec6b20b311c1f97790d067319331ba4d', 'In review', 'Waiting', NULL, 0, 1),
(4, 'paper_4', 'A systematic literature review of literature reviews in software testing', 'Context Any newcomer or industrial practitioner is likely to experience difficulties in digesting large volumes of knowledge in software testing. In an ideal world, all knowledge used in industry, edu', '<b>Authors:</b><br/>Garousi V., MÃ¤ntylÃ¤ M.V. <br/><b>Key words:</b><br/>Secondary studies, Software testing, Surveys, Systematic literature reviews, Systematic mapping, Tertiary study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84987968030&partnerID=40&md5=39f3eeecc191a79349289ea4d0d321f6', 'In review', 'Waiting', NULL, 0, 1),
(5, 'paper_5', 'A systematic mapping of data generation for integration software testing', 'Different techniques have been proposed to test software artifacts and source code. Integration testing, however, has not been sufficiently applied to all types of systems that require high-quality ev', '<b>Authors:</b><br/>Brito M.A.S., Santos M.P., Souza S.R.S., Souza P.S.L. <br/><b>Key words:</b><br/>', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988345153&partnerID=40&md5=f10417d2aad10c1c762d0ff6ba8926ac', 'In review', 'Waiting', NULL, 0, 1),
(6, 'paper_6', 'A systematic mapping study of software product lines testing', 'Context: In software development, Testing is an important mechanism both to identify defects and assure that completed products work as specified. This is a common practice in single-system developmen', '<b>Authors:</b><br/>Da Mota Silveira Neto P.A., Carmo MacHado I.D., McGregor J.D., De Almeida E.S., De Lemos Meira S.R. <br/><b>Key words:</b><br/>Mapping study, Software product lines, Software testi', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-79952451558&partnerID=40&md5=a966054f3f281e0f2e4234c8bea7f399', 'Pending', 'Waiting', NULL, 0, 1),
(7, 'paper_7', 'A systematic mapping study on non-functional search-based software testing', 'Automated software test generation has been applied across the spectrum of test case design methods, this includes white-box (structural), black-box (functional), grey-box (combination of structural a', '<b>Authors:</b><br/>Afzal W., Torkar R., Feldt R. <br/><b>Key words:</b><br/>', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-79952453274&partnerID=40&md5=0d3653455ce936d871b57b8f516b2988', 'Pending', 'Waiting', NULL, 0, 1),
(8, 'paper_8', 'A systematic mapping study on software engineering testbeds', 'Even though empirical research has grown in interest, techniques, methodologies and best practices are still in debate. In this context, testbeds are effective when one needs to evaluate and compare t', '<b>Authors:</b><br/>Barreiros E., Almeida A., Saraiva J., Soares S. <br/><b>Key words:</b><br/>Empirical software engineering, Technology evaluation, Technology transfer, Testbeds', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84858737751&partnerID=40&md5=ea351c7fbb76a17afc002da9e7fa4d10', 'In review', 'Waiting', NULL, 0, 1),
(9, 'paper_9', 'Alignment of requirements specification and testing: A systematic mapping study', 'Requirements should specify expectations on a software system and testing should ensure these expectations are met. Thus, to enable high product quality and efficient development it is crucial that re', '<b>Authors:</b><br/>Barmi Z.A., Ebrahimi A.H., Feldt R. <br/><b>Key words:</b><br/>', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-80051659665&partnerID=40&md5=946d9ca5308f2b04884f4276b6c2a12e', 'Included', 'To classify', NULL, 0, 1),
(10, 'paper_10', 'Analyzing an automotive testing process with evidence-based software engineering', 'Context: Evidence-based software engineering (EBSE) provides a process for solving practical problems based on a rigorous research approach. The primary focus so far was on mapping and aggregating evi', '<b>Authors:</b><br/>Kasoju A., Petersen K., MÃ¤ntylÃ¤ M.V. <br/><b>Key words:</b><br/>Automotive software testing, Evidence-based software engineering, Process assessment', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877922741&partnerID=40&md5=b6dc2fcdca02a51db47c5925cfbaaa66', 'In review', 'Waiting', NULL, 0, 1),
(11, 'paper_11', 'Challenges and opportunities for software change request repositories: A systematic mapping study', 'Software maintenance starts as soon as the first artifacts are delivered and is essential for the success of the software. However, keeping maintenance activities and their related artifacts on track ', '<b>Authors:</b><br/>Cavalcanti Y.C., Da Mota Silveira Neto P.A., Machado I.D.C., Vale T.F., De Almeida E.S., Meira S.R.D.L. <br/><b>Key words:</b><br/>bug report, bug tracking, change request reposito', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84904626790&partnerID=40&md5=7e8fe6e32dba1cdb6f3f9a3e39b3fed1', 'Pending', 'Waiting', NULL, 0, 1),
(12, 'paper_12', 'Change impact in product lines: A systematic mapping study', 'A product line (PL) supports and simplifies the development process of (software) systems by reusing assets. As systems are subjected to frequent alterations, the implementation of this changes can be', '<b>Authors:</b><br/>Brink C., Heisig P., Wackermann F. <br/><b>Key words:</b><br/>Change impact analysis, Embedded systems, Hardware/Software, Product family, Product line, Systematic mapping study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988892509&partnerID=40&md5=e13d8fd1207f2f064c58fb7a85a09838', 'Pending', 'Waiting', NULL, 0, 1),
(13, 'paper_13', 'Characteristics, attributes, metrics and usability recommendations: A systematic mapping', 'The research scenario concerned about software usability addresses a wide range of characteristics, attributes and evaluation models. As result, we can observe the evaluators difficult in order to sel', '<b>Authors:</b><br/>Nissola F., Benitti F.B.V. <br/><b>Key words:</b><br/>Systematic Mapping, Usability Evaluation', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84966602566&partnerID=40&md5=7b11e8b0f75c1d4766c99f68b59e8772', 'In review', 'Waiting', NULL, 0, 1),
(14, 'paper_14', 'Concurrent software testing in practice: A catalog of tools', 'The testing of concurrent programs is very complex due to the non-determinism present in those programs. They must be subjected to a systematic testing process that assists in the identification of de', '<b>Authors:</b><br/>Melo S.M., Souza S.R.S., Silva R.A., Souza P.S.L. <br/><b>Key words:</b><br/>Concurrent programs, Systematic mapping, Testing tools', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84960350804&partnerID=40&md5=5490f6be1c5b623eff6d7593c770b4cd', 'Excluded', 'Waiting', NULL, 0, 1),
(15, 'paper_15', 'Cost, benefits and quality of software development documentation: A systematic mapping', 'Context: Software documentation is an integral part of any software development process. Researchers and practitioners have expressed concerns about costs, benefits and quality of software documentati', '<b>Authors:</b><br/>Zhi J., Garousi-Yusifo?lu V., Sun B., Garousi G., Shahnewaz S., Ruhe G. <br/><b>Key words:</b><br/>Documentation benefit, Software documentation, Systematic mapping', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84912534729&partnerID=40&md5=5a2b8c80ac6e71817e1fa2ffb79f59fc', 'In review', 'Waiting', NULL, 0, 1),
(16, 'paper_16', 'Empirical studies concerning the maintenance of UML diagrams and their use in the maintenance of code: A systematic mapping study', 'Context: The Unified Modelling Language (UML) has, after ten years, become established as the de facto standard for the modelling of object-oriented software systems. It is therefore relevant to inves', '<b>Authors:</b><br/>FernÃ¡ndez-SÃ¡ez A.M., Genero M., Chaudron M.R.V. <br/><b>Key words:</b><br/>Empirical studies, Software maintenance, Systematic literature review, Systematic mapping study, UML', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877909370&partnerID=40&md5=b548f09fd4efa3d1319209f1db1125a6', 'Pending', 'Waiting', NULL, 0, 1),
(17, 'paper_17', 'Evaluating software product quality: A systematic mapping study', 'Evaluating software product quality (SPQ) is an important task to ensure the quality of software products. In this paper a systematic mapping study was performed to summarize the existing SPQ evaluati', '<b>Authors:</b><br/>Ouhbi S., Idri A., Aleman J.L.F., Toval A. <br/><b>Key words:</b><br/>', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84924054129&partnerID=40&md5=19c52fa109db72d3bcb6b46d8b326ee1', 'Pending', 'Waiting', NULL, 0, 1),
(18, 'paper_18', 'Feature location for software product line migration: A mapping study', 'Developing software from scratch is a high cost and errorprone activity. A possible solution to reduce time-to-market and produce high quality software is the reuse of existing software. But when the ', '<b>Authors:</b><br/>AssunÃ§Ã£o W.K.G., Vergilio S.R. <br/><b>Key words:</b><br/>Evolution, Reengineering, Reuse, Software product line', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907833307&partnerID=40&md5=48b514819a4aba2c01c7cea8bb911254', 'In review', 'Waiting', NULL, 0, 1),
(19, 'paper_19', 'Graphical user interface (GUI) testing: Systematic mapping and repository', 'Context GUI testing is system testing of a software that has a graphical-user interface (GUI) front-end. Because system testing entails that the entire software system, including the user interface, b', '<b>Authors:</b><br/>Banerjee I., Nguyen B., Garousi V., Memon A. <br/><b>Key words:</b><br/>Bibliometrics, GUI application, Paper repository, Systematic mapping, Testing', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84880786120&partnerID=40&md5=6a4843e704cb6d905ce9da59d7d402ad', 'Excluded', 'Waiting', NULL, 0, 1),
(20, 'paper_20', 'ISBSG variables most frequently used for software effort estimation: A mapping review', 'Background: The International Software Benchmarking Standards Group (ISBSG) dataset makes it possible to estimate a project''s size, effort, duration, and cost. Aim: The aim was to analyze the ISBSG va', '<b>Authors:</b><br/>Gonzalez-Ladron-De-Guevara F., FernÃ¡ndez-Diego M. <br/><b>Key words:</b><br/>ISBSG, missing values, software effort estimation, software engineering, systematic mapping study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907808906&partnerID=40&md5=cf63a03ed883a32324a27bd726f9a00e', 'In review', 'Waiting', NULL, 0, 1),
(21, 'paper_21', 'Knowledge management applied to software testing: A systematic mapping', 'With the growth of data from several different sources of knowledge within an organization, it becomes necessary to provide computerized support for tasks of acquiring, processing, analyzing and disse', '<b>Authors:</b><br/>Souza E.F., Falbo R.A., Vijaykumar N.L. <br/><b>Key words:</b><br/>Knowledge management, Software testing, Systematic mapping', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84922663129&partnerID=40&md5=f38645ba853196e34678283ee883a71e', 'Pending', 'Waiting', NULL, 0, 1),
(22, 'paper_22', 'Predicting software product quality: A systematic mapping study', 'Predicting software product quality (SPQ) is becoming a permanent concern during software life cycle phases. In this paper, a systematic mapping study was performed to summarize the existing SPQ predi', '<b>Authors:</b><br/>Ouhbi S., Idri A., Fer?andez-AlemÃ¡n J.L., Toval A. <br/><b>Key words:</b><br/>Prediction, Software product quality, Systematic mapping study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84943600627&partnerID=40&md5=27f0050c8409ce3cf88e684e2a45a4b4', 'Pending', 'Waiting', NULL, 0, 1),
(23, 'paper_23', 'Reducing test effort: A systematic mapping study on existing approaches', 'Context: Quality assurance effort, especially testing effort, is often a major cost factor during software development, which sometimes consumes more than 50% of the overall development effort. Conseq', '<b>Authors:</b><br/>Elberzhager F., Rosbach A., MÃ¼nch J., Eschbach R. <br/><b>Key words:</b><br/>Efficiency improvement, Mapping study, Quality assurance, Software testing, Test effort reduction', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84863453536&partnerID=40&md5=2d892e6bc6835d86cc6e6c508857db8f', 'In review', 'Waiting', NULL, 0, 1),
(24, 'paper_24', 'Risk management in software product line engineering: A mapping study', 'Software Product Line (SPL) Engineering focuses on systematic software reuse, which has benefits such as reductions in time-to-market and effort, and improvements in the quality of products. However, ', '<b>Authors:</b><br/>Lobato L.L., Bittar T.J., Neto P.A.D.M.S., MacHado I.D.C., De Almeida E.S., Meira S.R.D.L. <br/><b>Key words:</b><br/>Mapping study, Risk management, Software product lines', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84881014807&partnerID=40&md5=83fe16cebf1cd3ccebfb7b597fcd2cae', 'Included', 'To classify', NULL, 0, 1),
(25, 'paper_25', 'Software fault prediction: A systematic mapping study', 'Context: Software fault prediction has been an important research topic in the software engineering field for more than 30 years. Software defect prediction models are commonly used to detect faulty s', '<b>Authors:</b><br/>Murillo-Morera J., Quesada-LÃ³pez C., Jenkins M. <br/><b>Key words:</b><br/>Fault prediction models, Software metrics, Software quality', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84936110818&partnerID=40&md5=f18253acbe762249e0a5803739257b51', 'In review', 'Waiting', NULL, 0, 1),
(26, 'paper_26', 'Software product line testing - A systematic mapping study', 'Context: Software product lines (SPL) are used in industry to achieve more efficient software development. However, the testing side of SPL is underdeveloped. Objective: This study aims at surveying e', '<b>Authors:</b><br/>EngstrÃ¶m E., Runeson P. <br/><b>Key words:</b><br/>Software product line testing, Systematic literature review, Systematic mapping, Testing', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-78049529957&partnerID=40&md5=d0c91740e3fa70679e4560d266a06d48', 'Pending', 'Waiting', NULL, 0, 1),
(27, 'paper_27', 'Software quality requirements: A systematic mapping study', 'Software quality requirements (SQR) play a central role in software quality (SQ) success. The importance of mastering SQR can be seen as obvious, however, when it comes to customer satisfaction, end-u', '<b>Authors:</b><br/>Ouhbi S., Idri A., FernÃ¡ndez-AlemÃ¡n J.L., Toval A. <br/><b>Key words:</b><br/>Requirement engineering, Software quality requirements, Systematic mapping study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84933501221&partnerID=40&md5=16c9a1d2da950000184c6347a78c4f83', 'Pending', 'Waiting', NULL, 0, 1),
(28, 'paper_28', 'Software test-code engineering: A systematic mapping', 'Context: As a result of automated software testing, large amounts of software test code (script) are usually developed by software teams. Automated test scripts provide many benefits, such as repeatab', '<b>Authors:</b><br/>Garousi Yusifo?lu V., Amannejad Y., Betin Can A. <br/><b>Key words:</b><br/>Development of test code, Quality assessment of test code, Software test-code engineering, Study reposit', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84914181487&partnerID=40&md5=c284c62c41ba472eab9a053ccbd08710', 'In review', 'Waiting', NULL, 0, 1),
(29, 'paper_29', 'Strategies for consistency checking on software product lines: A mapping study', 'Context. Software Product Lines (SPL) has become one of the most prominents way to promote the systematic reuse of software artifacts. Like any other piece of software, with the SPL aging, it becomes ', '<b>Authors:</b><br/>Santos A.R., De Oliveira R.P., De Almeida E.S. <br/><b>Key words:</b><br/>Consistency checking, Literature review, Mapping study, Software product line engineering', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84961159520&partnerID=40&md5=27caea57da59de999eb3c9a77aee00ed', 'In conflict', 'Waiting', NULL, 0, 1),
(30, 'paper_30', 'Systematic mapping study of quality attributes measurement in service oriented architecture', 'Background: Service oriented architecture (SOA) promotes software reuse and interoperability as its niche. Developer usually expects that services being used are performing as promised. Capability to ', '<b>Authors:</b><br/>Nik Daud N.M., Kadir W.M.N.W. <br/><b>Key words:</b><br/>Quality attributes measurement, service oriented architecture, systematic mapping study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84866998707&partnerID=40&md5=a7fad9b2f2d879fe0b8d347d9936099b', 'In review', 'Waiting', NULL, 0, 1),
(31, 'paper_31', 'Ten years of research on fault management in grid computing: A systematic mapping study', 'BACKGROUND: There is a large body of literature on research about fault management in grid computing. Despite being a well-established research area, there are no systematic studies focusing on charac', '<b>Authors:</b><br/>Filho P.C., Brasilino C., Duarte A. <br/><b>Key words:</b><br/>', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84908011115&partnerID=40&md5=2721d0954867de0184a7751167f088e8', 'Pending', 'Waiting', NULL, 0, 1),
(32, 'paper_32', 'Testability and software performance: A systematic mapping study', 'In most of the research on software testability, functional correctness of the software has been the focus while the evidence regarding testability and non-functional properties such as performance is', '<b>Authors:</b><br/>Hassan M.M., Shah S.M.A., Afzal W., Andler S.F., LindstrÃ¶m B., Blom M. <br/><b>Key words:</b><br/>Software performance, Systematic mapping study, Testability', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84975789870&partnerID=40&md5=aa948ec1cf1aee77815cf56d0b933199', 'Pending', 'Waiting', NULL, 0, 1),
(33, 'paper_33', 'The role of process in early software defect prediction: Methods, attributes and metrics', 'Software quality is the set of inherent characteristics that are built into a software product throughout software development process. An important indicator of software quality is the trend of softw', '<b>Authors:</b><br/>Ozakinci R., Tarhan A. <br/><b>Key words:</b><br/>Defect prediction, Early, Prediction model, Process metrics, Software defect, Software quality, Software reliability, Systematic m', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84994005243&partnerID=40&md5=aa6f7438c816fe1687d04b9c387b2b7d', 'In review', 'Waiting', NULL, 0, 1),
(34, 'paper_34', 'Usable results from the field of API usability: A systematic mapping and further analysis', 'Modern software development often involves the use of complex, reusable components called Application Programming Interfaces (APIs). Developers use APIs to complete tasks they could not otherwise acco', '<b>Authors:</b><br/>Burns C., Ferreira J., Hellmann T.D., Maurer F. <br/><b>Key words:</b><br/>API usability, application programming interface, meta-analysis, systematic map, systematic review', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84870895497&partnerID=40&md5=f9dac6e9ebcbd3d7c1d02844ae3aee4a', 'In review', 'Waiting', NULL, 0, 1),
(35, 'paper_35', 'Validation of software visualization tools: A systematic mapping study', 'Software visualization as a research field focuses on the visualization of the structure, behavior, and evolution of software. It studies techniques and methods for graphically representing these diff', '<b>Authors:</b><br/>Seriai A., Benomar O., Cerat B., Sahraoui H. <br/><b>Key words:</b><br/>Software visualization, Systematic mapping study, Validation techniques', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84920660808&partnerID=40&md5=797cc12a015ec2d7ef9d22b3103e0bb5', 'In review', 'Waiting', NULL, 0, 1),
(36, 'paper_36', 'Vertical Test Reuse for Embedded Systems: A Systematic Mapping Study', 'Vertical test reuse refers to the reuse of test cases or other test artifacts over different integration levels in the software or system engineering process. Vertical test reuse has previously been p', '<b>Authors:</b><br/>Flemstrom D., Sundmark D., Afzal W. <br/><b>Key words:</b><br/>embedded system, systematic mapping study, vertical test reuse', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84958235305&partnerID=40&md5=16444cc014261bf229bc5003e5f50f50', 'Pending', 'Waiting', NULL, 0, 1),
(37, 'paper_37', 'What do we know about the defect types detected in conceptual models?', 'In Model-Driven Development (MDD), defects are managed at the level of conceptual models because the other artefacts are generated from them, such as more refined models, test cases and code. Although', '<b>Authors:</b><br/>Granda M.F., Condori-Fernandez N., Vos T.E.J., Pastor O. <br/><b>Key words:</b><br/>Conceptual Schema Defects, Defect Classification Scheme, Model-Driven Development, Systematic Ma', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84937942055&partnerID=40&md5=f5d60b4ef9d480f4806a8bad04269abe', 'Pending', 'Waiting', NULL, 0, 1),
(38, 'paper_38', 'When and what to automate in software testing? A multi-vocal literature review', 'Context Many organizations see software test automation as a solution to decrease testing costs and to reduce cycle time in software development. However, establishment of automated testing may fail i', '<b>Authors:</b><br/>Garousi V., MÃ¤ntylÃ¤ M.V. <br/><b>Key words:</b><br/>Decision support, Multivocal literature review, Software test automation, Systematic literature review, Systematic Mapping stu', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84969529104&partnerID=40&md5=b1a7b786fb5bbbec9737993a11f4e652', 'In review', 'Waiting', NULL, 0, 1),
(39, 'paper_39', 'A Systematic Mapping Study on Test Generation from Input/Output Transition Systems', 'Context: The construction of complex systems has increased the adoption of technologies that aim at automating the testing activity. Model-Based Testing (MBT) has emerged as an approach to automate th', '<b>Authors:</b><br/>Paiva S.L.D.C., Simao A.D.S. <br/><b>Key words:</b><br/>Input/Output Transition Systems, systematic mapping study, test generation', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84958235921&partnerID=40&md5=4a11222530cf3542f8047a0b76a39271', 'Included', 'To classify', NULL, 0, 1),
(40, 'paper_40', 'A mapping study to investigate component-based software system metrics', 'A component-based software system (CBSS) is a software system that is developed by integrating components that have been deployed independently. In the last few years, many researchers have proposed m', '<b>Authors:</b><br/>Abdellatief M., Sultan A.B.M., Ghani A.A.A., Jabar M.A. <br/><b>Key words:</b><br/>Component-based software system, Software components, Software metrics, Software quality, Systema', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84872676227&partnerID=40&md5=168cb6d0d2c29588e6a74450ccc234fc', 'In review', 'Waiting', NULL, 0, 1),
(41, 'paper_41', 'A review of research on risk analysis methods for IT systems', 'Context: At the same time as our dependence on IT systems increases, the number of reports of problems caused by failures of critical IT systems has also increased. This means that there is a need for', '<b>Authors:</b><br/>Sulaman S.M., Weyns K., HÃ¶st M. <br/><b>Key words:</b><br/>IT systems, Mapping study, Risk analysis', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84877289265&partnerID=40&md5=e1f98654dd2286cf5fd9e00497f14c7b', 'Pending', 'Waiting', NULL, 0, 1),
(42, 'paper_42', 'A systematic mapping study of mobile application testing techniques', 'The importance of mobile application specific testing techniques and methods has been attracting much attention of software engineers over the past few years. This is due to the fact that mobile appli', '<b>Authors:</b><br/>Zein S., Salleh N., Grundy J. <br/><b>Key words:</b><br/>Mobile application testing, Software testing, Systematic mapping', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84963641809&partnerID=40&md5=76dba7bb0f8605cbc0fd95a05873dca4', 'Pending', 'Waiting', NULL, 0, 1),
(43, 'paper_43', 'A systematic mapping study of web application testing', 'Context: The Web has had a significant impact on all aspects of our society. As our society relies more and more on the Web, the dependability of web applications has become increasingly important. To', '<b>Authors:</b><br/>Garousi V., Mesbah A., Betin-Can A., Mirshokraie S. <br/><b>Key words:</b><br/>Bibliometrics, Paper repository, Systematic mapping, Testing, Web application', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84878316262&partnerID=40&md5=efb3d8db2cdcf51f20930ef18222929d', 'In review', 'Waiting', NULL, 0, 1),
(44, 'paper_44', 'A systematic mapping study on fault management in cloud computing', 'Background: The large computational infrastructures required to provide the on-demand services that most users are now used to are more prone to failures than any single computational device. Thus, fa', '<b>Authors:</b><br/>Neto C.B.L., Filho P.B.D.C., Duarte A.N. <br/><b>Key words:</b><br/>Cloud Computing, Dependability, Evidence-Based Research, Fault Management, Mapping Study, Secondary Study', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84908005906&partnerID=40&md5=4d276f88513f45493729ad18a23aebee', 'Excluded', 'Waiting', NULL, 0, 1),
(45, 'paper_45', 'A systematic mapping study on legacy system modernization', 'Legacy system modernization has gained increasing attention from both researchers and practitioners, mainly due to the need of maintaining legacy systems towards business needs and technology advances', '<b>Authors:</b><br/>De Vargas Agilar E., De Almeida R.B., Canedo E.D. <br/><b>Key words:</b><br/>Legacy systems, Mapping studies in software engineering, Software modernization', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84988349883&partnerID=40&md5=451bac271599396ea4902529ffac10fa', 'In review', 'Waiting', NULL, 0, 1),
(46, 'paper_46', 'A systematic mapping study on testing technique experiments: Has the situation changed since 2000?', 'Context Juristo et al. [7] published a literature review about testing technique expenments. The goal was to provide a picture of which techniques and aspects of techniques had been studied experiment', '<b>Authors:</b><br/>GonzÃ¡lez J.E., Juristo N., Vegas S. <br/><b>Key words:</b><br/>mapping study, software testing techniques, testing experiments', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84907807087&partnerID=40&md5=00c82980bdc011d47bb2182dc9e3a806', 'Pending', 'Waiting', NULL, 0, 1),
(47, 'paper_47', 'A systematic mapping study on the combination of static and dynamic quality assurance techniques', 'Context: A lot of different quality assurance techniques exist to ensure high quality products. However, most often they are applied in isolation. A systematic combination of different static and dyna', '<b>Authors:</b><br/>Elberzhager F., MÃ¼nch J., Nha V.T.N. <br/><b>Key words:</b><br/>Combination, Dynamic quality assurance, Inspection, Static quality assurance, Systematic mapping study, Testing', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-80055068778&partnerID=40&md5=79090e7196d4dd5edae0bed3976791e4', 'Pending', 'Waiting', NULL, 0, 1),
(48, 'paper_48', 'Agile testing: Past, present, and future - Charting a systematic map of testing in agile software development', 'Testing has been a cornerstone of agile software development methodologies since early in the history of the field. However, the terminology used to describe the field - as well as the evidence in exi', '<b>Authors:</b><br/>Hellmann T.D., Sharma A., Ferreira J., Maurer F. <br/><b>Key words:</b><br/>agile software development, empirical, software testing, systematic mapping, test-driven development, te', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84868294056&partnerID=40&md5=07cb548e86ce68641af0917124a13d80', 'In review', 'Waiting', NULL, 0, 1),
(49, 'paper_49', 'RiPLE-TE: A process for testing Software Product Lines', 'Software Product Lines Testing has received special attention in recent years, due to its crucial role in quality and also due to the high cost this activity poses. In this effect, to make testing a f', '<b>Authors:</b><br/>Do Carmo Machado I., Da Mota Silveira Neto P.A., De Almeida E.S., De Lemos Meira S.R. <br/><b>Key words:</b><br/>Software process, Software product lines, Software reuse, Software ', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84855554904&partnerID=40&md5=e8613b35f4a36d18abc967fb4a53af68', 'Included', 'To classify', NULL, 0, 1),
(50, 'paper_50', 'Systematic mapping study in automatic test case generation', 'Test case generation is a painstaking task in software testing and has a strong influence on the efficiency and the effectiveness of software tests. It is an important subject in software testing rese', '<b>Authors:</b><br/>Mohi-Aldeen S.M., Deris S., Mohamad R. <br/><b>Key words:</b><br/>Automatic test case generation methods, Software testing, Test case generation, Test case generation methods', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84948782811&partnerID=40&md5=ce17b999150fefd2e67fae653350f6ca', 'In review', 'Waiting', NULL, 0, 1),
(51, 'paper_51', 'Systematic mapping study of model transformations for concrete problems', 'As a contribution to the adoption of the Model-Driven Engineering (MDE) paradigm, the research community has proposed concrete model transformation solutions for the MDE infrastructure and for domain-', '<b>Authors:</b><br/>Batot E., Sahraoui H., Syriani E., Molins P., Sboui W. <br/><b>Key words:</b><br/>Model Transformation, Software Engineering, Systematic Mapping', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84969921820&partnerID=40&md5=3845b641095db79942e3712d847bb345', 'Pending', 'Waiting', NULL, 0, 1),
(52, 'paper_52', 'Test case prioritization: A systematic mapping study', 'Test case prioritization techniques, which are used to improve the cost-effectiveness of regression testing, order test cases in such a way that those cases that are expected to outperform others in d', '<b>Authors:</b><br/>Catal C., Mishra D. <br/><b>Key words:</b><br/>Regression testing, Systematic literature review, Systematic mapping study, Test case prioritization', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84880587969&partnerID=40&md5=442d06af0d109613e52157d932d6d107', 'Pending', 'Waiting', NULL, 0, 1),
(53, 'paper_53', 'Web application testing: A systematic literature review', 'Context The web has had a significant impact on all aspects of our society. As our society relies more and more on the web, the dependability of web applications has become increasingly important. To ', '<b>Authors:</b><br/>Do?an S., Betin-Can A., Garousi V. <br/><b>Key words:</b><br/>Systematic literature review, Testing, Web application', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-84900597825&partnerID=40&md5=29b2691a945894ddceca3e7f69123b48', 'In review', 'Waiting', NULL, 0, 1),
(54, 'paper_54', 'What a long, strange trip it''s been: Past, present, and future perspectives on software testing research', 'Over the past 25 years the Brazilian Symposium on Software Engineering (SBES) has evolved to become the most important event on software engineering in Brazil. Throughout these years, SBES has gathere', '<b>Authors:</b><br/>Durelli V.H.S., Araujo R.F., Silva M.A.G., Oliveira R.A.P., Maldonado J.C., Delamaro M.E. <br/><b>Key words:</b><br/>Software Testing, systematic mapping', NULL, 'https://www.scopus.com/inward/record.uri?eid=2-s2.0-82255172046&partnerID=40&md5=cd89afa234a6f03b9cae5e3e617ab60d', 'Included', 'To classify', NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `paperauthor`
--

DROP TABLE IF EXISTS `paperauthor`;
CREATE TABLE IF NOT EXISTS `paperauthor` (
  `paperauthor_id` int(11) NOT NULL AUTO_INCREMENT,
  `paperId` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `paperauthor_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`paperauthor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ref_domain`
--

DROP TABLE IF EXISTS `ref_domain`;
CREATE TABLE IF NOT EXISTS `ref_domain` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `ref_domain`
--

INSERT INTO `ref_domain` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Artificial Intelligence', 'Artificial Intelligence', 1),
(2, 'Collaborative systeme', 'Collaborative systeme', 1),
(3, 'Compilation', 'Compilation', 1),
(4, 'E-commerce', 'E-commerce', 1),
(5, 'Anny', 'Anny', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_intents`
--

DROP TABLE IF EXISTS `ref_intents`;
CREATE TABLE IF NOT EXISTS `ref_intents` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `ref_intents`
--

INSERT INTO `ref_intents` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'Translation', 'Translation', 1),
(2, 'Simulation', 'Simulation', 1),
(3, 'Migration', 'Migration', 1),
(4, 'Composition', 'Composition', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ref_tables`
--

DROP TABLE IF EXISTS `ref_tables`;
CREATE TABLE IF NOT EXISTS `ref_tables` (
  `reftab_id` int(11) NOT NULL AUTO_INCREMENT,
  `reftab_label` varchar(50) NOT NULL,
  `reftab_table` varchar(50) NOT NULL,
  `reftab_desc` varchar(200) NOT NULL,
  `reftab_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`reftab_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `ref_tables`
--

INSERT INTO `ref_tables` (`reftab_id`, `reftab_label`, `reftab_table`, `reftab_desc`, `reftab_active`) VALUES
(1, 'ref_exclusioncrieria', 'zref_exclusioncrieria', 'Exclusion criteria', 1),
(71, 'ref_domain', 'ref_domain', 'Domain', 1),
(72, 'ref_intents', 'ref_intents', 'Intents', 1);

-- --------------------------------------------------------

--
-- Table structure for table `screening`
--

DROP TABLE IF EXISTS `screening`;
CREATE TABLE IF NOT EXISTS `screening` (
  `screening_id` int(11) NOT NULL AUTO_INCREMENT,
  `paper_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `decision` enum('accepted','excluded') NOT NULL DEFAULT 'accepted',
  `exclusion_criteria` int(11) DEFAULT '0',
  `note` varchar(200) DEFAULT NULL,
  `assignment_id` int(11) DEFAULT '0',
  `screening_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `screening_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`screening_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `screening`
--

INSERT INTO `screening` (`screening_id`, `paper_id`, `user_id`, `decision`, `exclusion_criteria`, `note`, `assignment_id`, `screening_time`, `screening_active`) VALUES
(1, 4, 1, 'accepted', NULL, '', 8, '2017-03-01 00:54:32', 0),
(2, 5, 1, 'accepted', NULL, '', 9, '2017-03-01 00:54:34', 1),
(3, 9, 1, 'excluded', 2, '', 18, '2017-03-01 00:54:38', 0),
(4, 10, 1, 'accepted', NULL, '', 19, '2017-03-01 00:54:40', 1),
(5, 14, 1, 'accepted', NULL, '', 28, '2017-03-01 00:54:41', 0),
(6, 15, 1, 'accepted', NULL, '', 29, '2017-03-01 00:54:43', 0),
(7, 19, 1, 'excluded', 2, '', 38, '2017-03-01 00:54:45', 1),
(8, 20, 1, 'accepted', NULL, '', 39, '2017-03-01 00:54:47', 1),
(9, 24, 1, 'accepted', NULL, '', 48, '2017-03-01 00:54:49', 1),
(10, 25, 1, 'accepted', NULL, '', 49, '2017-03-01 00:54:50', 1),
(11, 29, 1, 'excluded', 2, '', 58, '2017-03-01 00:54:54', 0),
(12, 30, 1, 'excluded', 1, '', 59, '2017-03-01 00:55:00', 1),
(13, 34, 1, 'excluded', 2, '', 68, '2017-03-01 00:55:02', 0),
(14, 35, 1, 'excluded', 1, '', 69, '2017-03-01 00:55:07', 1),
(15, 39, 1, 'accepted', NULL, '', 78, '2017-03-01 00:55:10', 1),
(16, 40, 1, 'excluded', 1, '', 79, '2017-03-01 00:55:14', 1),
(17, 44, 1, 'excluded', 1, '', 88, '2017-03-01 00:55:16', 0),
(18, 45, 1, 'excluded', 1, '', 89, '2017-03-01 00:55:19', 1),
(19, 49, 1, 'accepted', NULL, '', 98, '2017-03-01 00:55:21', 1),
(20, 50, 1, 'excluded', 1, '', 99, '2017-03-01 00:55:23', 1),
(21, 54, 1, 'accepted', NULL, '', 108, '2017-03-01 00:55:26', 1),
(22, 3, 4, 'accepted', NULL, '', 6, '2017-03-01 00:56:23', 1),
(23, 4, 4, 'accepted', NULL, '', 7, '2017-03-01 00:56:26', 0),
(24, 8, 4, 'accepted', NULL, '', 16, '2017-03-01 00:56:28', 1),
(25, 9, 4, 'accepted', NULL, '', 17, '2017-03-01 00:56:30', 1),
(26, 13, 4, 'excluded', 1, '', 26, '2017-03-01 00:56:33', 1),
(27, 14, 1, 'accepted', NULL, '', 27, '2017-03-01 00:56:38', 0),
(28, 18, 4, 'excluded', 1, '', 36, '2017-03-01 00:56:40', 1),
(29, 19, 4, 'excluded', 2, '', 37, '2017-03-01 00:56:43', 1),
(30, 23, 4, 'excluded', 1, '', 46, '2017-03-01 00:56:46', 1),
(31, 24, 1, 'accepted', NULL, '', 47, '2017-03-01 00:56:50', 1),
(32, 28, 4, 'excluded', 1, '', 56, '2017-03-01 00:56:52', 1),
(33, 29, 1, 'excluded', 2, '', 57, '2017-03-01 00:56:55', 0),
(34, 33, 4, 'excluded', 1, '', 66, '2017-03-01 00:56:58', 1),
(35, 34, 4, 'excluded', 2, '', 67, '2017-03-01 00:57:00', 1),
(36, 38, 4, 'accepted', NULL, '', 76, '2017-03-01 00:57:03', 1),
(37, 39, 4, 'accepted', NULL, '', 77, '2017-03-01 00:57:07', 1),
(38, 43, 4, 'excluded', 1, '', 86, '2017-03-01 00:57:13', 1),
(39, 44, 4, 'excluded', 1, '', 87, '2017-03-01 00:57:16', 1),
(40, 48, 4, 'excluded', 2, '', 96, '2017-03-01 00:57:19', 1),
(41, 49, 4, 'accepted', NULL, '', 97, '2017-03-01 00:57:22', 1),
(42, 53, 4, 'excluded', 1, '', 106, '2017-03-01 00:57:25', 1),
(43, 54, 4, 'accepted', NULL, '', 107, '2017-03-01 00:57:31', 1),
(44, 4, 1, 'accepted', NULL, 'not excluded', 8, '2017-03-01 19:21:17', 1),
(45, 9, 1, 'accepted', NULL, '', 18, '2017-03-01 19:21:21', 0),
(46, 15, 1, 'accepted', NULL, '', 29, '2017-03-01 20:17:05', 0),
(47, 29, 1, 'excluded', 2, '', 58, '2017-03-01 20:17:08', 0),
(48, 15, 1, 'accepted', NULL, '', 29, '2017-03-02 21:13:37', 1),
(49, 14, 1, 'excluded', 2, '', 28, '2017-03-02 21:20:16', 1),
(50, 44, 1, 'excluded', 1, '', 88, '2017-03-02 21:20:20', 1),
(51, 9, 1, 'accepted', NULL, '', 18, '2017-03-02 21:21:14', 1),
(52, 29, 1, 'accepted', NULL, '', 58, '2017-03-02 21:23:04', 0),
(53, 14, 1, 'excluded', 2, '', 27, '2017-03-02 21:24:50', 1),
(54, 29, 4, 'accepted', NULL, '', 57, '2017-03-02 21:24:52', 1),
(55, 4, 4, 'excluded', 2, '', 7, '2017-03-02 21:27:47', 0),
(56, 29, 1, 'excluded', 1, '', 58, '2017-03-09 16:58:13', 1),
(57, 34, 1, 'excluded', 1, '', 68, '2017-03-09 16:58:19', 0);

-- --------------------------------------------------------

--
-- Table structure for table `str_management`
--

DROP TABLE IF EXISTS `str_management`;
CREATE TABLE IF NOT EXISTS `str_management` (
  `str_id` int(11) NOT NULL AUTO_INCREMENT,
  `str_label` varchar(500) NOT NULL,
  `str_text` varchar(1000) NOT NULL,
  `str_category` varchar(20) NOT NULL DEFAULT 'default',
  `str_lang` varchar(3) NOT NULL DEFAULT 'en',
  `str_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`str_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=245 ;

--
-- Dumping data for table `str_management`
--

INSERT INTO `str_management` (`str_id`, `str_label`, `str_text`, `str_category`, `str_lang`, `str_active`) VALUES
(1, 'Welcome', 'Welcome', 'default', 'en', 1),
(2, 'General', 'General', 'default', 'en', 1),
(3, 'Home', 'Home', 'default', 'en', 1),
(4, 'Papers', 'Papers', 'default', 'en', 1),
(5, 'All papers', 'All papers', 'default', 'en', 1),
(6, 'Processed', 'Processed', 'default', 'en', 1),
(7, 'Pending', 'Pending', 'default', 'en', 1),
(8, 'Assigned to me', 'Assigned to me', 'default', 'en', 1),
(9, 'Excluded', 'Excluded', 'default', 'en', 1),
(10, 'Import papers', 'Import papers', 'default', 'en', 1),
(11, 'Classification', 'Classification', 'default', 'en', 1),
(12, 'Result', 'Result', 'default', 'en', 1),
(13, 'Graphs', 'Graphs', 'default', 'en', 1),
(14, 'Export', 'Export', 'default', 'en', 1),
(15, 'Reference Tables', 'Reference Tables', 'default', 'en', 1),
(16, 'Domain', 'Domain', 'default', 'en', 1),
(17, 'Exclusion criteria', 'Exclusion criteria', 'default', 'en', 1),
(18, 'Intent relation', 'Intent relation', 'default', 'en', 1),
(19, 'Intents', 'Intents', 'default', 'en', 1),
(20, 'Language', 'Language', 'default', 'en', 1),
(21, 'Types of goals', 'Types of goals', 'default', 'en', 1),
(22, 'Screening', 'Screening', 'default', 'en', 1),
(23, 'List of papers', 'List of papers', 'default', 'en', 1),
(24, 'Assign papers for screening', 'Assign papers for screening', 'default', 'en', 1),
(25, 'Screen', 'Screen', 'default', 'en', 1),
(26, 'Screening result', 'Screening result', 'default', 'en', 1),
(27, 'Settings', 'Settings', 'default', 'en', 1),
(28, 'Admin', 'Admin', 'default', 'en', 1),
(29, 'SQL', 'SQL', 'default', 'en', 1),
(30, 'String mangement', 'String mangement', 'default', 'en', 1),
(31, 'Configuration', 'Configuration', 'default', 'en', 1),
(32, 'Update Installation', 'Update Installation', 'default', 'en', 1),
(33, 'Choose project', 'Choose project', 'default', 'en', 1),
(34, 'UP', 'UP', 'default', 'en', 1),
(35, 'Log Out', 'Log Out', 'default', 'en', 1),
(36, 'Project', 'Project', 'default', 'en', 1),
(37, 'Description', 'Description', 'default', 'en', 1),
(38, 'Classification completion', 'Classification completion', 'default', 'en', 1),
(39, 'Processed papers', 'Processed papers', 'default', 'en', 1),
(40, 'Pending papers', 'Pending papers', 'default', 'en', 1),
(41, 'Participants', 'Participants', 'default', 'en', 1),
(42, 'ReLiS - Revue Littéraire Systématique', 'ReLiS - Revue Littéraire Systématique', 'default', 'en', 1),
(43, 'Select', 'Select', 'default', 'en', 1),
(44, 'Select multi', 'Select multi', 'default', 'en', 1),
(45, 'Back', 'Back', 'default', 'en', 1),
(46, 'Load a CSV file', 'Load a CSV file', 'default', 'en', 1),
(47, 'Upload the CSV file', 'Upload the CSV file', 'default', 'en', 1),
(48, 'Upload', 'Upload', 'default', 'en', 1),
(49, 'Import papers - match fields', 'Import papers - match fields', 'default', 'en', 1),
(50, 'Match csv fields', 'Match csv fields', 'default', 'en', 1),
(51, '#', '#', 'default', 'en', 1),
(52, 'Name', 'Name', 'default', 'en', 1),
(53, 'Username', 'Username', 'default', 'en', 1),
(54, 'Email', 'Email', 'default', 'en', 1),
(55, 'Usergroup', 'Usergroup', 'default', 'en', 1),
(56, 'Reviews per paper', 'Reviews per paper', 'default', 'en', 1),
(57, 'user', 'user', 'default', 'en', 1),
(58, 'Assignement done', 'Assignement done', 'default', 'en', 1),
(59, 'Key', 'Key', 'default', 'en', 1),
(60, 'Title', 'Title', 'default', 'en', 1),
(61, 'Edit', 'Edit', 'default', 'en', 1),
(62, 'View', 'View', 'default', 'en', 1),
(63, 'Delete', 'Delete', 'default', 'en', 1),
(64, 'Action', 'Action', 'default', 'en', 1),
(65, 'Display element', 'Display element', 'default', 'en', 1),
(66, 'Close', 'Close', 'default', 'en', 1),
(67, 'Search for...', 'Search for...', 'default', 'en', 1),
(68, 'Author', 'Author', 'default', 'en', 1),
(69, 'Paper', 'Paper', 'default', 'en', 1),
(70, 'Transformation name', 'Transformation name', 'default', 'en', 1),
(71, 'Goal', 'Goal', 'default', 'en', 1),
(72, 'Transformation language', 'Transformation language', 'default', 'en', 1),
(73, 'Emplementation Status', 'Emplementation Status', 'default', 'en', 1),
(74, 'Industrial', 'Industrial', 'default', 'en', 1),
(75, 'Is HOT', 'Is HOT', 'default', 'en', 1),
(76, 'Note', 'Note', 'default', 'en', 1),
(77, 'Value', 'Value', 'default', 'en', 1),
(78, 'Classifications', 'Classifications', 'default', 'en', 1),
(79, 'No records found', 'No records found', 'default', 'en', 1),
(80, 'Assigned to', 'Assigned to', 'default', 'en', 1),
(81, 'Decision', 'Decision', 'default', 'en', 1),
(82, 'List of Exclusion criteria', 'List of Exclusion criteria', 'default', 'en', 1),
(83, 'Edit Intent relation', 'Edit Intent relation', 'default', 'en', 1),
(84, 'List of Intent relation', 'List of Intent relation', 'default', 'en', 1),
(85, 'Edit Domain', 'Edit Domain', 'default', 'en', 1),
(86, 'List of Domain', 'List of Domain', 'default', 'en', 1),
(87, 'Add new', 'Add new', 'default', 'en', 1),
(88, 'Add Exclusion criteria', 'Add Exclusion criteria', 'default', 'en', 1),
(89, 'Success', 'Success', 'default', 'en', 1),
(90, 'Edit Exclusion criteria', 'Edit Exclusion criteria', 'default', 'en', 1),
(91, 'Assignment type', 'Assignment type', 'default', 'en', 1),
(92, 'Assignment mode', 'Assignment mode', 'default', 'en', 1),
(93, 'Assigned by', 'Assigned by', 'default', 'en', 1),
(94, 'Screening done', 'Screening done', 'default', 'en', 1),
(95, 'Abstract', 'Abstract', 'default', 'en', 1),
(96, 'Preview', 'Preview', 'default', 'en', 1),
(97, 'Venue', 'Venue', 'default', 'en', 1),
(98, 'Authors', 'Authors', 'default', 'en', 1),
(99, 'Excluded by', 'Excluded by', 'default', 'en', 1),
(100, 'Time', 'Time', 'default', 'en', 1),
(101, 'Add classification', 'Add classification', 'default', 'en', 1),
(102, 'Assigne to someone', 'Assigne to someone', 'default', 'en', 1),
(103, 'Assigne to a user', 'Assigne to a user', 'default', 'en', 1),
(104, 'Exclude', 'Exclude', 'default', 'en', 1),
(105, 'Exclude the paper', 'Exclude the paper', 'default', 'en', 1),
(106, 'Edit paper', 'Edit paper', 'default', 'en', 1),
(107, 'No classification', 'No classification', 'default', 'en', 1),
(108, 'Assignations', 'Assignations', 'default', 'en', 1),
(109, 'No assignation', 'No assignation', 'default', 'en', 1),
(110, 'All papers have been screened', 'All papers have been screened', 'default', 'en', 1),
(111, 'List of screening', 'List of screening', 'default', 'en', 1),
(112, 'List of assignment', 'List of assignment', 'default', 'en', 1),
(113, 'Edit screening', 'Edit screening', 'default', 'en', 1),
(114, 'Assigment', 'Assigment', 'default', 'en', 1),
(115, 'List of Paper assignment for screening', 'List of Paper assignment for screening', 'default', 'en', 1),
(116, 'Remove screening', 'Remove screening', 'default', 'en', 1),
(117, 'Screenings', 'Screenings', 'default', 'en', 1),
(118, 'Remove', 'Remove', 'default', 'en', 1),
(119, 'Cancel', 'Cancel', 'default', 'en', 1),
(120, 'Screening detail', 'Screening detail', 'default', 'en', 1),
(121, 'Utilisateur', 'Utilisateur', 'default', 'en', 1),
(122, 'Evenement', 'Evenement', 'default', 'en', 1),
(123, 'Screened by', 'Screened by', 'default', 'en', 1),
(124, 'Edit assignment', 'Edit assignment', 'default', 'en', 1),
(125, 'Paper assignment for screening', 'Paper assignment for screening', 'default', 'en', 1),
(126, 'Source language', 'Source language', 'default', 'en', 1),
(127, 'Scope', 'Scope', 'default', 'en', 1),
(128, 'Intent', 'Intent', 'default', 'en', 1),
(129, 'Name used by the author', 'Name used by the author', 'default', 'en', 1),
(130, 'Comment', 'Comment', 'default', 'en', 1),
(131, 'Intent 1', 'Intent 1', 'default', 'en', 1),
(132, 'Intent 2', 'Intent 2', 'default', 'en', 1),
(133, 'Add a Classification to the Paper', 'Add a Classification to the Paper', 'default', 'en', 1),
(134, 'Remove the classification', 'Remove the classification', 'default', 'en', 1),
(135, 'Edit the classification', 'Edit the classification', 'default', 'en', 1),
(136, 'My assignments', 'My assignments', 'default', 'en', 1),
(137, 'My screenings', 'My screenings', 'default', 'en', 1),
(138, 'Papers assigned to me for screening', 'Papers assigned to me for screening', 'default', 'en', 1),
(139, 'Completion', 'Completion', 'default', 'en', 1),
(140, 'Screening Progress', 'Screening Progress', 'default', 'en', 1),
(141, 'List papers', 'List papers', 'default', 'en', 1),
(142, 'Papers in conflict', 'Papers in conflict', 'default', 'en', 1),
(143, 'Screening completion', 'Screening completion', 'default', 'en', 1),
(144, ' Screened papers', ' Screened papers', 'default', 'en', 1),
(145, 'Abreviation', 'Abreviation', 'default', 'en', 1),
(146, 'Full name', 'Full name', 'default', 'en', 1),
(147, 'Year', 'Year', 'default', 'en', 1),
(148, 'Link', 'Link', 'default', 'en', 1),
(149, 'Assignment', 'Assignment', 'default', 'en', 1),
(150, 'My screening completion', 'My screening completion', 'default', 'en', 1),
(151, 'Update project', 'Update project', 'default', 'en', 1),
(152, 'Upload configuration file', 'Upload configuration file', 'default', 'en', 1),
(153, 'New project', 'New project', 'default', 'en', 1),
(154, 'Users', 'Users', 'default', 'en', 1),
(155, 'User groups', 'User groups', 'default', 'en', 1),
(156, 'Logs', 'Logs', 'default', 'en', 1),
(157, 'Eve', 'Eve', 'default', 'en', 1),
(158, 'accepted', 'accepted', 'default', 'en', 1),
(159, 'Alice', 'Alice', 'default', 'en', 1),
(160, 'No screening data', 'No screening data', 'default', 'en', 1),
(161, 'Bob', 'Bob', 'default', 'en', 1),
(162, 'Brice', 'Brice', 'default', 'en', 1),
(163, 'Edit  Classification for the Paper', 'Edit  Classification for the Paper', 'default', 'en', 1),
(164, 'Excluded papers', 'Excluded papers', 'default', 'en', 1),
(165, 'No value !', 'No value !', 'default', 'en', 1),
(166, 'No papers assigned to you for screening', 'No papers assigned to you for screening', 'default', 'en', 1),
(167, 'Please choose the exclusion criter', 'Please choose the exclusion criter', 'default', 'en', 1),
(168, 'Screened', 'Screened', 'default', 'en', 1),
(169, 'Update screening', 'Update screening', 'default', 'en', 1),
(170, 'Save', 'Save', 'default', 'en', 1),
(171, 'Save and Next', 'Save and Next', 'default', 'en', 1),
(172, 'Please choose the exclusion criteria', 'Please choose the exclusion criteria', 'default', 'en', 1),
(173, 'Element updated', 'Element updated', 'default', 'en', 1),
(174, 'Element saved', 'Element saved', 'default', 'en', 1),
(175, 'Paper excluded', 'Paper excluded', 'default', 'en', 1),
(176, 'Criteria', 'Criteria', 'default', 'en', 1),
(177, 'Label', 'Label', 'default', 'en', 1),
(178, 'Text', 'Text', 'default', 'en', 1),
(179, 'Open edition mode', 'Open edition mode', 'default', 'en', 1),
(180, 'List of String management', 'List of String management', 'default', 'en', 1),
(181, 'Papers pending', 'Papers pending', 'default', 'en', 1),
(182, 'Papers in review', 'Papers in review', 'default', 'en', 1),
(183, 'Papes included', 'Papes included', 'default', 'en', 1),
(184, 'Papes excluded', 'Papes excluded', 'default', 'en', 1),
(185, 'Papes in conflict', 'Papes in conflict', 'default', 'en', 1),
(186, 'Papers included', 'Papers included', 'default', 'en', 1),
(187, 'Papers excluded', 'Papers excluded', 'default', 'en', 1),
(188, 'Screening Results', 'Screening Results', 'default', 'en', 1),
(189, 'Edit Paper assignment for screening', 'Edit Paper assignment for screening', 'default', 'en', 1),
(190, 'All assignments', 'All assignments', 'default', 'en', 1),
(191, 'All screenings', 'All screenings', 'default', 'en', 1),
(192, 'Screening validation', 'Screening validation', 'default', 'en', 1),
(193, 'Assign papers for validation', 'Assign papers for validation', 'default', 'en', 1),
(194, 'Assignments', 'Assignments', 'default', 'en', 1),
(195, 'Validation result', 'Validation result', 'default', 'en', 1),
(196, 'Operations', 'Operations', 'default', 'en', 1),
(197, 'Editor location(url)', 'Editor location(url)', 'default', 'en', 1),
(198, 'Editor workspace', 'Editor workspace', 'default', 'en', 1),
(199, 'CSV  separator for import', 'CSV  separator for import', 'default', 'en', 1),
(200, 'CSV separator for export', 'CSV separator for export', 'default', 'en', 1),
(201, 'Screening comfict type', 'Screening comfict type', 'default', 'en', 1),
(202, 'import papers activated', 'import papers activated', 'default', 'en', 1),
(203, 'assign papers activated', 'assign papers activated', 'default', 'en', 1),
(204, 'Screening activated', 'Screening activated', 'default', 'en', 1),
(205, 'Screening validation activated', 'Screening validation activated', 'default', 'en', 1),
(206, 'Classification activated', 'Classification activated', 'default', 'en', 1),
(207, 'Configuration type', 'Configuration type', 'default', 'en', 1),
(208, 'Edit Configuration', 'Edit Configuration', 'default', 'en', 1),
(209, 'List of Configuration', 'List of Configuration', 'default', 'en', 1),
(210, 'Add a reviewer', 'Add a reviewer', 'default', 'en', 1),
(211, 'Screening result activated', 'Screening result activated', 'default', 'en', 1),
(212, 'Set screening validation', 'Set screening validation', 'default', 'en', 1),
(213, 'Percentage of papers(%)', 'Percentage of papers(%)', 'default', 'en', 1),
(214, 'new Paper assignment for screening', 'new Paper assignment for screening', 'default', 'en', 1),
(215, 'Switch to multi query!', 'Switch to multi query!', 'default', 'en', 1),
(216, 'Parse an SQL query', 'Parse an SQL query', 'default', 'en', 1),
(217, 'Return table', 'Return table', 'default', 'en', 1),
(218, 'Write your sql query here', 'Write your sql query here', 'default', 'en', 1),
(219, 'Submit', 'Submit', 'default', 'en', 1),
(220, 'Switch to single query!', 'Switch to single query!', 'default', 'en', 1),
(221, 'Parse multiple SQL queries', 'Parse multiple SQL queries', 'default', 'en', 1),
(222, 'Operation type', 'Operation type', 'default', 'en', 1),
(223, 'Add new paper', 'Add new paper', 'default', 'en', 1),
(224, 'Screening status', 'Screening status', 'default', 'en', 1),
(225, 'Bibtex', 'Bibtex', 'default', 'en', 1),
(226, 'Error : Page "" not found!', 'Error : Page "" not found!', 'default', 'en', 1),
(227, 'Load from editor', 'Load from editor', 'default', 'en', 1),
(228, 'Choose setup file', 'Choose setup file', 'default', 'en', 1),
(229, 'Go back to the project', 'Go back to the project', 'default', 'en', 1),
(230, 'Error', 'Error', 'default', 'en', 1),
(231, 'Edit Intents', 'Edit Intents', 'default', 'en', 1),
(232, 'List of Intents', 'List of Intents', 'default', 'en', 1),
(233, 'This value will  be available after first saving', 'This value will  be available after first saving', 'default', 'en', 1),
(234, 'Add Intent', 'Add Intent', 'default', 'en', 1),
(235, 'Parent', 'Parent', 'default', 'en', 1),
(236, 'Add Intent relation', 'Add Intent relation', 'default', 'en', 1),
(237, 'ReLiS editor', 'ReLiS editor', 'default', 'en', 1),
(238, 'Error : Page "ref_domain_domain" not found!', 'Error : Page "ref_domain_domain" not found!', 'default', 'en', 1),
(239, 'Transformation namesss', 'Transformation namesss', 'default', 'en', 1),
(240, 'Error : Page "domain" not found!', 'Error : Page "domain" not found!', 'default', 'en', 1),
(241, 'text_multi name', 'text_multi name', 'default', 'en', 1),
(242, 'text_multi name5', 'text_multi name5', 'default', 'en', 1),
(243, 'Edit user informations', 'Edit user informations', 'default', 'en', 1),
(244, 'User detail', 'User detail', 'default', 'en', 1);

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
CREATE TABLE IF NOT EXISTS `venue` (
  `venue_id` int(11) NOT NULL AUTO_INCREMENT,
  `venue_abbreviation` varchar(20) NOT NULL,
  `venue_fullName` longtext,
  `venue_year` smallint(6) NOT NULL,
  `venue_volume` smallint(6) DEFAULT NULL,
  `venue_totalNumPapers` smallint(6) DEFAULT NULL,
  `venue_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`venue_id`),
  UNIQUE KEY `IX_Venue` (`venue_abbreviation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_assigned`
--
DROP VIEW IF EXISTS `view_paper_assigned`;
CREATE TABLE IF NOT EXISTS `view_paper_assigned` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`preview` varchar(200)
,`bibtex` varchar(200)
,`abstract` varchar(1000)
,`doi` varchar(200)
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`venueId` int(11)
,`paper_excluded` int(2)
,`paper_active` int(1)
,`assigned_user_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_pending`
--
DROP VIEW IF EXISTS `view_paper_pending`;
CREATE TABLE IF NOT EXISTS `view_paper_pending` (
`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`preview` varchar(200)
,`bibtex` varchar(200)
,`abstract` varchar(1000)
,`doi` varchar(200)
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`venueId` int(11)
,`paper_excluded` int(2)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `view_paper_processed`
--
DROP VIEW IF EXISTS `view_paper_processed`;
CREATE TABLE IF NOT EXISTS `view_paper_processed` (
`Pid` int(11)
,`id` int(11)
,`bibtexKey` varchar(30)
,`title` varchar(200)
,`preview` varchar(200)
,`bibtex` varchar(200)
,`abstract` varchar(1000)
,`doi` varchar(200)
,`screening_status` enum('Pending','In review','Included','Excluded','In conflict','Resolved included','Resolved excluded')
,`classification_status` enum('Waiting','To classify','Classified')
,`venueId` int(11)
,`paper_excluded` int(2)
,`paper_active` int(1)
);
-- --------------------------------------------------------

--
-- Table structure for table `zref_exclusioncrieria`
--

DROP TABLE IF EXISTS `zref_exclusioncrieria`;
CREATE TABLE IF NOT EXISTS `zref_exclusioncrieria` (
  `ref_id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_value` varchar(50) NOT NULL,
  `ref_desc` varchar(250) DEFAULT NULL,
  `ref_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zref_exclusioncrieria`
--

INSERT INTO `zref_exclusioncrieria` (`ref_id`, `ref_value`, `ref_desc`, `ref_active`) VALUES
(1, 'exclude', '', 1),
(2, 'exclude egain', '', 1);

-- --------------------------------------------------------

--
-- Structure for view `view_paper_assigned`
--
DROP TABLE IF EXISTS `view_paper_assigned`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_assigned` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`preview` AS `preview`,`p`.`bibtex` AS `bibtex`,`p`.`abstract` AS `abstract`,`p`.`doi` AS `doi`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`venueId` AS `venueId`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`paper_active` AS `paper_active`,`a`.`assigned_user_id` AS `assigned_user_id` from (`paper` `p` join `assigned` `a` on((`p`.`id` = `a`.`assigned_paper_id`))) where ((`a`.`assigned_active` = 1) and (`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_pending`
--
DROP TABLE IF EXISTS `view_paper_pending`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_pending` AS select `paper`.`id` AS `id`,`paper`.`bibtexKey` AS `bibtexKey`,`paper`.`title` AS `title`,`paper`.`preview` AS `preview`,`paper`.`bibtex` AS `bibtex`,`paper`.`abstract` AS `abstract`,`paper`.`doi` AS `doi`,`paper`.`screening_status` AS `screening_status`,`paper`.`classification_status` AS `classification_status`,`paper`.`venueId` AS `venueId`,`paper`.`paper_excluded` AS `paper_excluded`,`paper`.`paper_active` AS `paper_active` from `paper` where ((not(`paper`.`id` in (select distinct `p`.`id` AS `id` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`c`.`class_active` = 1))))) and (`paper`.`paper_active` = 1) and (`paper`.`paper_excluded` = 0));

-- --------------------------------------------------------

--
-- Structure for view `view_paper_processed`
--
DROP TABLE IF EXISTS `view_paper_processed`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_paper_processed` AS select distinct `p`.`id` AS `Pid`,`p`.`id` AS `id`,`p`.`bibtexKey` AS `bibtexKey`,`p`.`title` AS `title`,`p`.`preview` AS `preview`,`p`.`bibtex` AS `bibtex`,`p`.`abstract` AS `abstract`,`p`.`doi` AS `doi`,`p`.`screening_status` AS `screening_status`,`p`.`classification_status` AS `classification_status`,`p`.`venueId` AS `venueId`,`p`.`paper_excluded` AS `paper_excluded`,`p`.`paper_active` AS `paper_active` from (`paper` `p` join `classification` `c` on((`p`.`id` = `c`.`class_paper_id`))) where ((`p`.`paper_active` = 1) and (`p`.`paper_excluded` = 0) and (`c`.`class_active` = 1));

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
